(function() {
    var aa = typeof Object.create == "function" ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };

    function ca(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var da = ca(this);

    function k(a, b) {
        if (b) a: {
            var c = da;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    var m;
    if (typeof Object.setPrototypeOf == "function") m = Object.setPrototypeOf;
    else {
        var n;
        a: {
            var fa = {
                    a: !0
                },
                p = {};
            try {
                p.__proto__ = fa;
                n = p.a;
                break a
            } catch (a) {}
            n = !1
        }
        m = n ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var q = m;

    function r(a, b) {
        a.prototype = aa(b.prototype);
        a.prototype.constructor = a;
        if (q) q(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.F = b.prototype
    }

    function ha(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function t(a) {
        var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: ha(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function u(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    }

    function v(a, b) {
        var c;
        b && !b.done && (c = a["return"]) && c.call(a)
    }

    function w() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }

    function x(a, b) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + b + " must not be null or undefined");
        return a + ""
    }
    k("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = x(this, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    k("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
            return c
        }
    });
    k("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = x(this, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    k("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var y = this || self;

    function z(a) {
        z[" "](a);
        return a
    }
    z[" "] = function() {};

    function ia(a) {
        var b = !1;
        b = b === void 0 ? !1 : b;
        var c = c === void 0 ? y : c;
        for (var d = 0; c && d++ < 40;) {
            var e;
            if (!(e = b)) try {
                var f;
                if (f = !!c && c.location.href != null) b: {
                    try {
                        z(c.foo);
                        f = !0;
                        break b
                    } catch (l) {}
                    f = !1
                }
                e = f
            } catch (l) {
                e = !1
            }
            if (e && a(c)) break;
            a: {
                try {
                    var g = c.parent;
                    if (g && g !== c) {
                        c = g;
                        break a
                    }
                } catch (l) {}
                c = null
            }
        }
    };
    var ja = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };

    function A(a) {
        var b = this;
        this.i = !1;
        this.h = [];
        a(function(c) {
            B(b, c)
        })
    }

    function B(a, b) {
        if (!a.i)
            if (b instanceof A) b.then(function(c) {
                B(a, c)
            });
            else {
                a.i = !0;
                a.j = b;
                for (b = 0; b < a.h.length; ++b) C(a, a.h[b]);
                a.h = []
            }
    }

    function C(a, b) {
        a.i ? b(a.j) : a.h.push(b)
    }
    A.prototype.then = function(a) {
        var b = this;
        return new A(function(c) {
            C(b, function(d) {
                c(a(d))
            })
        })
    };

    function ka() {
        return new A(function(a) {
            return a(void 0)
        })
    };

    function la(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function ma(a) {
        a = a === void 0 ? document : a;
        return a.createElement("img")
    };

    function na(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = ma(a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        l = ja(g, e);
                    l >= 0 && Array.prototype.splice.call(g, l, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, !1);
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, !1)
            };
            typeof e.addEventListener === "function" && e.addEventListener("load", f, !1);
            typeof e.addEventListener === "function" && e.addEventListener("error",
                f, !1)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function oa(a) {
        a = (a === void 0 ? {} : a).v;
        return (a === void 0 ? 0 : a) ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
    }

    function pa(a) {
        var b = {};
        var c = b.D;
        c = c === void 0 ? !1 : c;
        b = b.v;
        var d = "https://" + oa({
            v: b === void 0 ? !1 : b
        }) + "/pagead/gen_204?id=rhmss";
        la(a, function(e, f) {
            if (e || e === 0) d += "&" + f + "=" + encodeURIComponent(String(e))
        });
        qa(d, c)
    }

    function qa(a, b) {
        var c = window;
        b = b === void 0 ? !1 : b;
        var d = d === void 0 ? !1 : d;
        c.fetch ? (b = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
            eventSourceEligible: "true",
            triggerEligible: "false"
        } : b.headers = {
            "Attribution-Reporting-Eligible": "event-source"
        }), c.fetch(a, b)) : na(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };
    var ra = {
        B: "app",
        C: "web"
    };

    function D(a) {
        if (!a) throw Error("functionToExecute must not be truthy.");
    };

    function E() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.11-google_20261022")
    }

    function F() {
        for (var a = ["1", "6", "11"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };

    function G(a, b, c, d) {
        this.i = a;
        this.method = b;
        this.version = c;
        this.h = d
    }

    function H(a) {
        return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
    }

    function I(a) {
        return new G(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
    }

    function J(a) {
        var b = {};
        b = (b.omid_message_guid = a.i, b.omid_message_method = a.method, b.omid_message_version = a.version, b);
        a.h !== void 0 && (b.omid_message_args = a.h);
        return b
    };

    function K(a) {
        this.i = a
    };

    function L(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }

    function sa(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
            return L(a, b)
        })
    }

    function M(a) {
        var b = t(Object.values(ra)),
            c = b.next();
        try {
            for (; !c.done; c = b.next()) {
                var d = c.value,
                    e = {};
                var f = (e.app = "omid_v1_present_app", e.web = "omid_v1_present_web", e)[d];
                if (L(a, f)) return d
            }
        } finally {
            v(b, c)
        }
        return null
    };

    function ta(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function N() {
        return typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function"
    }

    function ua() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        for (var b = [], c = 0; c < 16; c++) b.push(a[c].toString(16).padStart(2, "0"));
        return b[0] + b[1] + b[2] + b[3] + "-" + b[4] + b[5] + "-" + b[6] + b[7] + "-" + b[8] + b[9] + "-" + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function va() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function wa() {
        var a = w.apply(0, arguments);
        xa(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(a instanceof Array ? a : u(t(a)))));
        }, function() {
            return console.error.apply(console, a instanceof Array ? a : u(t(a)))
        })
    }

    function xa(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var O = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Could not determine global object context.");
    }();

    function P(a) {
        this.i = a;
        this.handleExportedMessage = P.prototype.j.bind(this)
    }
    r(P, K);
    P.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.i : b;
        if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
        b.handleExportedMessage(J(a), this)
    };
    P.prototype.j = function(a, b) {
        H(a) && this.h && this.h(I(a), b)
    };

    function Q(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function ya(a) {
        if (a === O) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function za() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return Q(a) ? a : O
    };

    function R(a, b) {
        this.i = b = b === void 0 ? O : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                H(e) && d.source && c.h && c.h(I(e), d.source)
            }
        })
    }
    r(R, K);
    R.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.i : b;
        if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
        b.postMessage(J(a), "*")
    };
    var Aa = ["omid", "v1_VerificationServiceCommunication"],
        Ba = ["omidVerificationProperties", "serviceWindow"];

    function Ca(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };

    function S(a) {
        if (!a) {
            var b = za();
            var c = c === void 0 ? sa : c;
            var d = [],
                e = Ca(b, Ba);
            e && d.push(e);
            d.push(Q(b) ? b.top : O);
            a: {
                d = t(d);e = d.next();
                try {
                    for (; !e.done; e = d.next()) {
                        b: {
                            var f = b,
                                g = e.value,
                                l = c;
                            if (!ya(g)) try {
                                var h = Ca(g, Aa);
                                if (h) {
                                    var ea = new P(h);
                                    break b
                                }
                            } catch (La) {}
                            ea = l(g) ? new R(f, g) : null
                        }
                        if (f = ea) {
                            a = f;
                            break a
                        }
                    }
                } finally {
                    v(d, e)
                }
                a = null
            }
        }
        if (this.i = a) this.i.h = this.m.bind(this);
        else if (c = (c = O.omid3p) && typeof c.registerSessionObserver === "function" && typeof c.addEventListener === "function" ? c : null) this.omid3p = c;
        this.j = {};
        (this.h = (c = O.omidVerificationProperties) ? c.injectionId : void 0) || (N() ? ua() : va())
    }
    S.prototype.registerSessionObserver = function(a, b) {
        D(a);
        this.omid3p ? this.omid3p.registerSessionObserver(a, b, this.h) : this.l("addSessionListener", a, b, this.h)
    };
    S.prototype.addEventListener = function(a, b) {
        if (!a) throw Error("Value for eventType is undefined, null or blank.");
        if (typeof a !== "string" && !(a instanceof String)) throw Error("Value for eventType is not a string.");
        if (a.trim() === "") throw Error("Value for eventType is empty string.");
        D(b);
        this.omid3p ? this.omid3p.addEventListener(a, b, this.h) : this.l("addEventListener", b, a, this.h)
    };
    S.prototype.m = function(a) {
        var b = a.method,
            c = a.i;
        a = a.h;
        if (b === "response" && this.j[c]) {
            var d = E() && F() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.j[c].apply(this, d)
        }
        b === "error" && window.console && wa(a)
    };
    S.prototype.l = function(a, b) {
        var c = w.apply(2, arguments);
        if (this.i) {
            var d = N() ? ua() : va();
            b && (this.j[d] = b);
            var e = "VerificationService." + a;
            c = E() && F() ? c : JSON.stringify(c);
            this.i.sendMessage(new G(d, e, "1.6.11-google_20261022", c))
        }
    };
    var T = void 0;
    if (T = T === void 0 ? typeof omidExports === "undefined" ? null : omidExports : T) {
        var U = ["OmidVerificationClient"];
        U.slice(0, U.length - 1).reduce(ta, T)[U[U.length - 1]] = S
    };

    function Da() {
        var a = null;
        ia(function(b) {
            return (b = b.mraid) && b.IS_GMA_SDK ? (a = b, !0) : !1
        });
        return a
    }

    function Ea() {
        return new A(function(a) {
            y.document.readyState && y.document.readyState === "complete" ? a() : y.addEventListener("load", a)
        })
    }

    function Fa() {
        return new A(function(a) {
            var b = Da();
            b && (b.getState() === "loading" ? b.addEventListener("ready", function() {
                a(b)
            }) : a(b))
        })
    }

    function Ga(a) {
        a = a === void 0 ? {} : a;
        var b = this.m = (b = a.client) != null ? b : new S;
        var c = za();
        var d = (d = O.omidVerificationProperties) && d.injectionSource ? d.injectionSource : void 0;
        this.o = (d || M(c) || M(Q(c) ? c.top : O)) !== "web" || b.h ? !(!b.i && !b.omid3p) : !1;
        this.i = null;
        this.l = this.o ? 4 : 1;
        this.u = this.o;
        this.h = {};
        var e;
        this.j = (e = a.timeout) != null ? e : null;
        this.A = !1
    }

    function Ha() {
        return new A(function(a) {
            Ea().then(function() {
                Fa().then(function(b) {
                    function c(d, e) {
                        e.width > 0 && e.height > 0 && (a(), b.removeEventListener("exposureChange", c))
                    }
                    b.addEventListener("exposureChange", c)
                })
            })
        })
    }

    function Ia(a) {
        a.u ? (a.i = new A(function(b) {
            var c = new A(function(e) {
                    var f = !1,
                        g, l = (new Date).getTime();
                    a.m.registerSessionObserver(function(h) {
                        h.type === "sessionStart" && (g && y.clearTimeout(g), f ? (f = !1, h = (new Date).getTime() - l, a.A || (a.A = !0, pa({
                            te: h,
                            to: a.j
                        }))) : (h = h.data, e(h.context.environment == "app"), h.context.omidNativeInfo && (a.h.sdk = h.context.omidNativeInfo.partnerName)))
                    });
                    a.j != null && (g = y.setTimeout(function() {
                        f = !0;
                        e(!1)
                    }, a.j))
                }),
                d = new A(function(e) {
                    a.m.addEventListener("geometryChange", function(f) {
                        f =
                            f.data;
                        var g = f.adView.reasons;
                        if (g = !g || g.indexOf("hidden") == -1) f = f.adView, f = f.onScreenContainerGeometry || f.onScreenGeometry, g = !!(f && f.width && f.height);
                        g && (a.l = 3, e())
                    })
                });
            c.then(function(e) {
                e ? (d.then(function() {
                    a.h.src = 1;
                    b(a.h)
                }), Ha().then(function() {
                    a.h.src = 2;
                    a.l = 3;
                    b(a.h)
                })) : (a.l = 1, b())
            })
        }), a.i.then(function() {
            a.u = !1
        })) : a.i = ka()
    };
    var V, W = document.currentScript;
    V = (W = W === void 0 ? null : W) && W.getAttribute("data-jc") === "86" ? W : document.querySelector('[data-jc="86"]');
    var X;
    if (V) {
        for (var Ja = {}, Y = V.attributes, Z = Y.length - 1; Z >= 0; Z--) {
            var Ka = Y[Z].name;
            Ka.indexOf("data-jcp-") === 0 && (Ja[Ka.substring(9)] = Y[Z].value)
        }
        X = Ja
    } else X = {};
    window.omrhp = function(a) {
        var b = +(a == null ? NaN : a.owwt);
        Number.isNaN(b) && (b = null);
        return function(c) {
            var d = new Ga({
                timeout: b === void 0 ? null : b
            });
            d.i || Ia(d);
            d.i.then(c)
        }
    }(X);
}).call(this);
;
(function(omidGlobal) {
    var n;

    function aa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function p(a) {
        var b = 'undefined' != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if ('number' == typeof a.length) return {
            next: aa(a)
        };
        throw Error(String(a) + ' is not an iterable or ArrayLike');
    }

    function r(a) {
        if (!(a instanceof Array)) {
            a = p(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    }
    var ha = 'function' == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ia = 'function' == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };

    function ja(a) {
        a = ['object' == typeof globalThis && globalThis, a, 'object' == typeof window && window, 'object' == typeof self && self, 'object' == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error('Cannot find global object');
    }
    var ka = ja(this);

    function t(a, b) {
        if (b) a: {
            var c = ka;a = a.split('.');
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ia(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    var la;
    if ('function' == typeof Object.setPrototypeOf) la = Object.setPrototypeOf;
    else {
        var ma;
        a: {
            var na = {
                    a: !0
                },
                oa = {};
            try {
                oa.__proto__ = na;
                ma = oa.a;
                break a
            } catch (a) {}
            ma = !1
        }
        la = ma ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + ' is not extensible');
            return a
        } : null
    }
    var pa = la;

    function qa(a, b) {
        a.prototype = ha(b.prototype);
        a.prototype.constructor = a;
        if (pa) pa(a, b);
        else
            for (var c in b)
                if ('prototype' != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.xa = b.prototype
    }

    function u() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }

    function v(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    var ra = 'function' == typeof Object.assign ? Object.assign : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) v(d, e) && (a[e] = d[e])
        }
        return a
    };
    t('Object.assign', function(a) {
        return a || ra
    });
    t('Object.is', function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    t('Array.prototype.includes', function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });

    function sa(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + ' must not be null or undefined');
        if (b instanceof RegExp) throw new TypeError('First argument to String.prototype.' + c + ' must not be a regular expression');
        return a + ''
    }
    t('String.prototype.includes', function(a) {
        return a ? a : function(b, c) {
            return -1 !== sa(this, b, 'includes').indexOf(b, c || 0)
        }
    });
    t('Symbol', function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError('Symbol is not a constructor');
            return new c(d + (f || '') + '_' + e++, f)
        }

        function c(f, h) {
            this.g = f;
            ia(this, 'description', {
                configurable: !0,
                writable: !0,
                value: h
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = 'jscomp_symbol_' + (1E9 * Math.random() >>> 0) + '_',
            e = 0;
        return b
    });
    t('Symbol.iterator', function(a) {
        if (a) return a;
        a = Symbol('Symbol.iterator');
        for (var b = 'Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array'.split(' '), c = 0; c < b.length; c++) {
            var d = ka[b[c]];
            'function' === typeof d && 'function' != typeof d.prototype[a] && ia(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ta(aa(this))
                }
            })
        }
        return a
    });

    function ta(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    }
    t('WeakMap', function(a) {
        function b(k) {
            this.g = (g += Math.random() + 1).toString();
            if (k) {
                k = p(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        }

        function c() {}

        function d(k) {
            var l = typeof k;
            return 'object' === l && null !== k || 'function' === l
        }

        function e(k) {
            if (!v(k, h)) {
                var l = new c;
                ia(k, h, {
                    value: l
                })
            }
        }

        function f(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof c) return m;
                Object.isExtensible(m) && e(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (2 != m.get(k) || 3 != m.get(l)) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && 4 == m.get(l)
                } catch (q) {
                    return !1
                }
            }()) return a;
        var h = '$jscomp_hidden_' + Math.random();
        f('freeze');
        f('preventExtensions');
        f('seal');
        var g = 0;
        b.prototype.set = function(k, l) {
            if (!d(k)) throw Error('Invalid WeakMap key');
            e(k);
            if (!v(k, h)) throw Error('WeakMap key fail: ' + k);
            k[h][this.g] = l;
            return this
        };
        b.prototype.get = function(k) {
            return d(k) && v(k, h) ? k[h][this.g] : void 0
        };
        b.prototype.has = function(k) {
            return d(k) && v(k,
                h) && v(k[h], this.g)
        };
        b.prototype.delete = function(k) {
            return d(k) && v(k, h) && v(k[h], this.g) ? delete k[h][this.g] : !1
        };
        return b
    });
    t('Map', function(a) {
        function b() {
            var g = {};
            return g.L = g.next = g.head = g
        }

        function c(g, k) {
            var l = g.g;
            return ta(function() {
                if (l) {
                    for (; l.head != g.g;) l = l.L;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }

        function d(g, k) {
            var l = k && typeof k;
            'object' == l || 'function' == l ? f.has(k) ? l = f.get(k) : (l = '' + ++h, f.set(k, l)) : l = 'p_' + k;
            var m = g.h[l];
            if (m && v(g.h, l))
                for (g = 0; g < m.length; g++) {
                    var q = m[g];
                    if (k !== k && q.key !== q.key || k === q.key) return {
                        id: l,
                        list: m,
                        index: g,
                        A: q
                    }
                }
            return {
                id: l,
                list: m,
                index: -1,
                A: void 0
            }
        }

        function e(g) {
            this.h = {};
            this.g = b();
            this.size = 0;
            if (g) {
                g = p(g);
                for (var k; !(k = g.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        }
        if (function() {
                if (!a || 'function' != typeof a || !a.prototype.entries || 'function' != typeof Object.seal) return !1;
                try {
                    var g = Object.seal({
                            x: 4
                        }),
                        k = new a(p([
                            [g, 's']
                        ]));
                    if ('s' != k.get(g) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, 't') != k || 2 != k.size) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != g || 's' != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x ||
                        't' != m.value[1] || !l.next().done ? !1 : !0
                } catch (q) {
                    return !1
                }
            }()) return a;
        var f = new WeakMap;
        e.prototype.set = function(g, k) {
            g = 0 === g ? 0 : g;
            var l = d(this, g);
            l.list || (l.list = this.h[l.id] = []);
            l.A ? l.A.value = k : (l.A = {
                next: this.g,
                L: this.g.L,
                head: this.g,
                key: g,
                value: k
            }, l.list.push(l.A), this.g.L.next = l.A, this.g.L = l.A, this.size++);
            return this
        };
        e.prototype.delete = function(g) {
            g = d(this, g);
            return g.A && g.list ? (g.list.splice(g.index, 1), g.list.length || delete this.h[g.id], g.A.L.next = g.A.next, g.A.next.L = g.A.L, g.A.head = null, this.size--, !0) : !1
        };
        e.prototype.clear = function() {
            this.h = {};
            this.g = this.g.L = b();
            this.size = 0
        };
        e.prototype.has = function(g) {
            return !!d(this, g).A
        };
        e.prototype.get = function(g) {
            return (g = d(this, g).A) && g.value
        };
        e.prototype.entries = function() {
            return c(this, function(g) {
                return [g.key, g.value]
            })
        };
        e.prototype.keys = function() {
            return c(this, function(g) {
                return g.key
            })
        };
        e.prototype.values = function() {
            return c(this, function(g) {
                return g.value
            })
        };
        e.prototype.forEach = function(g, k) {
            for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value,
                g.call(k, m[1], m[0], this)
        };
        e.prototype[Symbol.iterator] = e.prototype.entries;
        var h = 0;
        return e
    });
    t('Set', function(a) {
        function b(c) {
            this.g = new Map;
            if (c) {
                c = p(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        }
        if (function() {
                if (!a || 'function' != typeof a || !a.prototype.entries || 'function' != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(p([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x ||
                        f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (h) {
                    return !1
                }
            }()) return a;
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return this.g.entries()
        };
        b.prototype.values = function() {
            return this.g.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] =
            b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    t('Object.values', function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) v(b, d) && c.push(b[d]);
            return c
        }
    });

    function ua(a, b) {
        a instanceof String && (a += '');
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    }
    t('Array.prototype.keys', function(a) {
        return a ? a : function() {
            return ua(this, function(b) {
                return b
            })
        }
    });
    t('String.prototype.repeat', function(a) {
        return a ? a : function(b) {
            var c = sa(this, null, 'repeat');
            if (0 > b || 1342177279 < b) throw new RangeError('Invalid count value');
            b |= 0;
            for (var d = ''; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    t('String.prototype.padStart', function(a) {
        return a ? a : function(b, c) {
            var d = sa(this, null, 'padStart');
            b -= d.length;
            c = void 0 !== c ? String(c) : ' ';
            return (0 < b && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : '') + d
        }
    });
    t('Array.prototype.values', function(a) {
        return a ? a : function() {
            return ua(this, function(b, c) {
                return c
            })
        }
    });
    var w = {
            oa: 'loaded',
            ua: 'start',
            la: 'firstQuartile',
            pa: 'midpoint',
            va: 'thirdQuartile',
            ja: 'complete',
            qa: 'pause',
            sa: 'resume',
            ia: 'bufferStart',
            ha: 'bufferFinish',
            ta: 'skipped',
            wa: 'volumeChange',
            ra: 'playerStateChange',
            ga: 'adUserInteraction'
        },
        va = {
            ma: 'full',
            ka: 'domain',
            na: 'limited'
        };

    function x(a, b) {
        this.x = null != a.x ? a.x : a.left;
        this.y = null != a.y ? a.y : a.top;
        this.width = a.width;
        this.height = a.height;
        this.J = this.x + this.width;
        this.K = this.y + this.height;
        this.D = a.D || void 0;
        this.X = a.X || [];
        this.h = a.friendlyObstructionClass || void 0;
        this.i = a.friendlyObstructionPurpose || void 0;
        this.j = a.friendlyObstructionReason || void 0;
        this.R = void 0 !== a.R ? !0 === a.R : !0;
        this.m = void 0 !== a.hasWindowFocus ? !0 === a.hasWindowFocus : !0;
        this.F = a.F || void 0;
        this.ba = a.ba || void 0;
        this.Y = 'true' === a.Y || !0 === a.Y || !1;
        this.O = a.O || [];
        this.S = a.S || !1;
        this.g = b
    }

    function wa(a) {
        var b = {};
        return b.width = a.width, b.height = a.height, b
    }

    function z(a) {
        var b = {};
        return Object.assign({}, wa(a), (b.x = a.x, b.y = a.y, b))
    }

    function xa(a) {
        var b = z(a),
            c = {};
        return Object.assign({}, b, (c.endX = a.J, c.endY = a.K, c))
    }
    x.prototype.T = function(a) {
        if (null == a) return !1;
        a = z(a);
        var b = a.y,
            c = a.width,
            d = a.height;
        return this.x === a.x && this.y === b && this.width === c && this.height === d
    };

    function ya(a) {
        return a.width * a.height
    }

    function za(a) {
        return 0 === a.width || 0 === a.height
    };

    function Ga(a, b) {
        a = z(a);
        for (var c = [], d = [], e = 0; e < b.length; e++) {
            var f = z(b[e]);
            f = Ha(a, f);
            Ia(c, f.x);
            Ia(c, f.J);
            Ia(d, f.y);
            Ia(d, f.K)
        }
        c = c.sort(function(h, g) {
            return h - g
        });
        d = d.sort(function(h, g) {
            return h - g
        });
        return {
            ea: c,
            fa: d
        }
    }

    function Ha(a, b) {
        return {
            x: Math.max(a.x, b.x),
            y: Math.max(a.y, b.y),
            J: Math.min(a.x + a.width, b.x + b.width),
            K: Math.min(a.y + a.height, b.y + b.height)
        }
    }

    function Ia(a, b) {
        -1 === a.indexOf(b) && a.push(b)
    };

    function Ja() {
        this.h = this.g = this.i = this.l = void 0;
        this.u = 0;
        this.o = [];
        this.v = [];
        this.B = 0;
        this.s = [];
        this.j = [];
        this.m = []
    }
    Ja.prototype.T = function(a) {
        return null == a ? !1 : JSON.stringify(Ka(this)) === JSON.stringify(Ka(a))
    };

    function Ka(a) {
        var b = [],
            c = [],
            d = {
                viewport: a.l,
                adView: {
                    percentageInView: a.u,
                    pixelsInView: a.B,
                    reasons: a.m
                },
                declaredFriendlyObstructions: a.o.length
            };
        if (void 0 !== a.g) {
            d.adView.geometry = z(a.g);
            d.adView.geometry.pixels = ya(a.g);
            d.adView.onScreenGeometry = z(a.h);
            d.adView.onScreenGeometry.pixels = La(a);
            for (var e = 0; e < a.j.length; e++) b.push(z(a.j[e]));
            for (e = 0; e < a.v.length; e++) {
                var f = a.v[e],
                    h = f,
                    g = {};
                h.h && (g.obstructionClass = h.h);
                h.i && (g.obstructionPurpose = h.i);
                h.j && (g.obstructionReason = h.j);
                f = Ha(a.g, f);
                c.push(Object.assign({}, {
                    x: f.x,
                    y: f.y,
                    width: f.J - f.x,
                    height: f.K - f.y
                }, g))
            }
            d.adView.onScreenGeometry.obstructions = b;
            d.adView.onScreenGeometry.friendlyObstructions = c
        }
        return d
    }

    function Ma(a, b) {
        b = wa(b);
        a.l = {};
        a.l.width = b.width;
        a.l.height = b.height;
        a.i = {};
        a.i.x = 0;
        a.i.y = 0;
        a.i.width = b.width;
        a.i.height = b.height;
        a.i.endX = b.width;
        a.i.endY = b.height
    }

    function Na() {
        return {
            x: 0,
            y: 0,
            endX: 0,
            endY: 0,
            width: 0,
            height: 0
        }
    }

    function Oa(a, b) {
        var c = {};
        c.x = Math.max(a.x, b.x);
        c.y = Math.max(a.y, b.y);
        c.endX = Math.min(a.endX, b.endX);
        c.endY = Math.min(a.endY, b.endY);
        c.width = Math.max(0, c.endX - c.x);
        c.height = Math.max(0, c.endY - c.y);
        return c
    }

    function Pa(a, b) {
        return .01 < b.width - a.width || .01 < b.height - a.height
    }

    function Qa(a) {
        if (-1 !== a.m.indexOf('backgrounded')) a.u = 0, a.B = 0;
        else {
            var b = ya(a.g);
            if (0 !== b) {
                var c = La(a);
                a.u = Math.round(c / b * 100);
                a.B = c
            }
        }
    }

    function Ra(a, b) {
        if (za(b) || !a.h) b = !1;
        else {
            var c = xa(a.h),
                d = c.y,
                e = c.endX;
            a = c.endY;
            var f = b.J;
            c = c.x;
            (f = f < c || .01 > Math.abs(f - c)) || (f = b.x, f = f > e || .01 > Math.abs(f - e));
            (e = f) || (e = b.K, e = e < d || .01 > Math.abs(e - d));
            (d = e) || (b = b.y, d = b > a || .01 > Math.abs(b - a));
            b = !d
        }
        return b
    }

    function C(a, b) {
        for (var c = !1, d = 0; d < a.m.length; d++) a.m[d] === b && (c = !0);
        c || a.m.push(b)
    }

    function La(a) {
        var b = Math,
            c = b.max,
            d = ya(a.h),
            e = a.j,
            f = 0;
        if (0 < e.length) {
            var h = Ga(a.h, e);
            a = h.ea;
            h = h.fa;
            for (var g = 0; g < a.length - 1; g++)
                for (var k = (a[g] + (a[g] + 1)) / 2, l = a[g + 1] - a[g], m = 0; m < h.length - 1; m++) {
                    for (var q = (h[m] + (h[m] + 1)) / 2, y = h[m + 1] - h[m], B = !1, E = 0; E < e.length; E++) {
                        var D = z(e[E]);
                        if (D.x < k && D.x + D.width > k && D.y < q && D.y + D.height > q) {
                            B = !0;
                            break
                        }
                    }
                    B && (f += Math.round(l) * Math.round(y))
                }
        }
        return c.call(b, 0, d - f)
    };

    function Sa() {};

    function Ta() {}

    function Ua(a, b, c, d) {
        var e = b.S ? !0 : b.D === d;
        if (e) {
            c.g = b;
            var f = xa(c.g);
            a = Oa(c.i, f);
            var h = c.g;
            'notAttached' === h.F || 'noWindowFocus' === h.F || 'noAdView' === h.F ? (C(c, 'notFound'), c.h = new x(Na(), !1)) : (h = c.g, 'viewInvisible' === h.F || 'viewGone' === h.F || 'viewNotVisible' === h.F || 'viewAlphaZero' === h.F || 'viewHidden' === h.F || void 0 !== c.g.F || za(c.g) ? (C(c, 'hidden'), c.h = new x(Na(), !1)) : (c.g.Y && C(c, 'pictureInPicture'), c.g.m || (C(c, 'backgrounded'), C(c, 'noWindowFocus')), Pa(a, f) && C(c, 'clipped'), c.h = new x(a, !1)))
        } else if (f = !0, b.g &&
            (f = -1 !== b.X.indexOf(d) ? !1 : !1 === b.R), f) {
            h = b.O;
            for (var g = 0; g < h.length; g++) f = void 0 !== c.g, Ua(a, new x(h[g], f), c, d)
        }
        e || void 0 === c.g || (b.g ? -1 !== b.X.indexOf(d) ? c.o.push(b) : c.s.push(b) : (e = xa(b), d = xa(c.h), z(c.h), !za(c.h) && b.R && (b = Oa(d, e), Pa(b, d) && (C(c, 'clipped'), c.h = new x(b, !1)))))
    };

    function H() {
        var a = u.apply(0, arguments);
        Va(function() {
            throw new(Function.prototype.bind.apply(Error, [null, 'Could not complete the test successfully - '].concat(r(a))));
        }, function() {
            return console.error.apply(console, r(a))
        })
    }

    function Wa() {
        var a = u.apply(0, arguments);
        Va(function() {}, function() {
            return console.error.apply(console, r(a))
        })
    }

    function Va(a, b) {
        'undefined' !== typeof jasmine && jasmine ? a() : 'undefined' !== typeof console && console && console.error && b()
    };

    function Xa(a) {
        return a && a.omidNative && 'function' === typeof a.omidNative.attest
    }

    function Ya() {
        var a = I;
        if (!a || !a.navigator) return !1;
        a = a.navigator.userAgent;
        var b = /Safari\/[\d.]*$/.test(a) && !/Chrome|Firefox|Edg|OPR/.test(a),
            c = /(iPhone|iPad|iPod)/.test(a),
            d = /(Macintosh)/.test(a);
        try {
            if (c) {
                var e = /(iPhone OS|iPad OS|CPU OS) (\d+[_.]\d+)/.exec(a);
                return e ? 16 <= parseInt(e[2], 10) : !1
            }
            if (b && d) {
                var f = /OS X (\d+(?:[_.]\d+)+)/.exec(a);
                if (!f) return !0;
                a: {
                    if (f && f[1]) {
                        var h = f[0].includes('.') ? '.' : '_',
                            g = f[1].split(h);
                        if (3 === g.length) {
                            var k = parseInt(g[1], 10);
                            break a
                        }
                        if (2 === g.length) {
                            k = parseInt(g[0],
                                10);
                            break a
                        }
                    }
                    k = null
                }
                return (e = k) ? 13 <= e : void 0
            }
        } catch (l) {
            H('Error analyzing the user agent. Contact OM SDK with the user agent.')
        }
        return !1
    };

    function Za() {
        var a;
        this.g = a = void 0 === a ? omidGlobal : a
    }
    Za.prototype.setInterval = function(a, b) {
        return $a(this, 'setInterval')(a, b)
    };
    Za.prototype.clearInterval = function(a) {
        $a(this, 'clearInterval')(a)
    };

    function ab(a, b) {
        $a(a, 'clearTimeout')(b)
    }

    function $a(a, b) {
        return a.g && a.g[b] ? a.g[b] : bb(a, b)
    }

    function cb(a, b, c, d) {
        if (a.g.document && a.g.document.body) {
            var e = a.g.document.createElement('img');
            e.width = 1;
            e.height = 1;
            e.style.display = 'none';
            e.src = b;
            c && e.addEventListener('load', function() {
                return c()
            });
            d && e.addEventListener('error', function() {
                return d()
            });
            a.g.document.body.appendChild(e)
        } else bb(a, 'sendUrl')(b, c, d)
    }

    function db(a, b, c) {
        if (b) try {
            if (Xa(a.g)) a.g.omidNative.attest(b, c);
            else if (a.g.document && a.g.document.body) {
                var d = a.g.document.createElement('img');
                d.width = 1;
                d.height = 1;
                d.style.display = 'none';
                d.src = b;
                c && d.addEventListener('load', function() {
                    return c()
                });
                a.g.document.body.appendChild(d)
            }
        } catch (e) {}
    }

    function bb(a, b) {
        if (a.g && a.g.omidNative && a.g.omidNative[b]) return a.g.omidNative[b].bind(a.g.omidNative);
        throw Error('Native interface method "' + b + '" not found.');
    };
    var I = function() {
        if ('undefined' !== typeof omidGlobal && omidGlobal) return omidGlobal;
        if ('undefined' !== typeof global && global) return global;
        if ('undefined' !== typeof window && window) return window;
        if ('undefined' !== typeof globalThis && globalThis) return globalThis;
        var a = Function('return this')();
        if (a) return a;
        throw Error('Could not determine global object context.');
    }();

    function eb() {
        this.h = new Map;
        this.i = null;
        this.g = [];
        Xa(I) ? this.g.push({
            mechanism: 'ApplePAT',
            version: 'default',
            executionEnvironment: 'native'
        }) : Ya() && this.g.push({
            mechanism: 'ApplePAT',
            version: 'default',
            executionEnvironment: 'web'
        })
    }

    function fb() {
        gb || (gb = new eb);
        return gb
    }
    var gb = null;

    function pb() {
        this.h = new Set;
        this.g = 0
    };

    function qb(a, b) {
        this.y = this.x = 0;
        this.width = a;
        this.height = b
    };

    function rb() {
        this.D = null;
        this.i = {
            apiVersion: '1.0',
            accessMode: 'limited',
            environment: 'web',
            omidJsInfo: {
                omidImplementer: 'omsdk',
                serviceVersion: '1.6.11-google35'
            },
            adSessionType: 'html',
            supports: ['clid', 'vlid']
        };
        this.H = null;
        this.B = 'foregrounded';
        this.s = this.j = 'none';
        this.o = this.l = this.m = this.M = this.h = this.g = this.N = this.C = null;
        this.u = new Map;
        this.v = new pb
    };

    function sb(a) {
        if (a === I) return !1;
        try {
            if ('undefined' === typeof a.location.hostname) return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function tb() {
        var a = omidGlobal;
        if (null == a || 'undefined' === typeof a.top || null == a.top) return null;
        try {
            var b = a.top;
            return sb(b) ? null : b.location.href
        } catch (c) {
            return null
        }
    };

    function ub(a, b) {
        this.g = a;
        this.h = b
    }
    ka.Object.defineProperties(ub.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.g
            }
        },
        origin: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.h
            }
        }
    });

    function vb(a) {
        return {
            supportedAttestationMechanisms: a.map(function(b) {
                return {
                    mechanism: b.mechanism,
                    version: b.version
                }
            })
        }
    };

    function wb(a) {
        this.g = a;
        this.m = [];
        this.i = [];
        this.j = [];
        this.l = [];
        this.o = {}
    }

    function xb(a, b) {
        if (void 0 !== a.g && a.g.D && !1 !== yb(a, b)) {
            var c = b.event;
            a.j.filter(function(d) {
                return d.type === c.type
            }).forEach(function(d) {
                a.h(d.I, c)
            })
        }
    }

    function K(a, b) {
        a.m.push(b);
        xb(a, b)
    }

    function zb(a, b, c) {
        void 0 !== a.g && a.g.D && a.m.filter(function(d) {
            return d.event.type === b && yb(a, d)
        }).map(function(d) {
            return d.event
        }).forEach(function(d) {
            a.h(c.I, d)
        })
    }

    function yb(a, b) {
        var c = b.event.type,
            d = -1 !== Object.values(w).indexOf(c) && 'volumeChange' !== c;
        return 'impression' === c || 'loaded' === c && a.g.h ? b.origin === a.g.s : d ? b.origin === a.g.j : !0
    }

    function Ab(a, b, c) {
        Object.keys(w).forEach(function(d) {
            d = w[d];
            var e = {
                type: d,
                W: c,
                I: b
            };
            a.j.push(e);
            zb(a, d, e)
        })
    }

    function Bb(a, b, c, d) {
        var e = {
            ca: c,
            W: d,
            I: b
        };
        a.l.push(e);
        a.i.forEach(function(f) {
            var h = Cb(f);
            'sessionStart' === f.event.type && Db(a, h, e);
            a.h(e.I, h)
        })
    }

    function Eb(a, b, c) {
        var d = L(a, 'sessionError', 'native', {
            errorType: b,
            message: c
        });
        a.i.push(d);
        a.l.forEach(function(e) {
            a.h(e.I, d.event)
        })
    }

    function Fb(a, b) {
        a.o = Object.assign(a.o, b);
        b = a.g.i;
        if (void 0 !== b) {
            b = Object.assign({}, Gb(Hb(a, Ib(a, {
                context: b
            }), !0)), {
                supportsLoadedEvent: !!a.g.h || 'video' == a.g.g
            });
            Object.assign(b, {
                pageUrl: tb(),
                contentUrl: a.g.H
            });
            Jb(b);
            var c = L(a, 'sessionStart', 'native', b);
            a.i.push(c);
            a.l.forEach(function(d) {
                var e = Cb(c);
                Db(a, e, d);
                a.h(d.I, e)
            }, a);
            Kb(a)
        }
    }

    function Db(a, b, c) {
        var d = b.data.context;
        c.ca && (b.data.verificationParameters = a.o[c.ca]);
        c.W && (c = a.g.u.get(c.W)) && (b.data.verificationParameters = c.verificationParameters, d.accessMode = c.accessMode, 'full' === c.accessMode && (a.g.l && (d.videoElement = a.g.l), a.g.m && (d.slotElement = a.g.m)))
    }

    function Lb(a) {
        var b = L(a, 'sessionFinish', 'native');
        a.i.push(b);
        a.l.forEach(function(c) {
            a.h(c.I, b.event)
        })
    }
    wb.prototype.h = function(a) {
        var b = u.apply(1, arguments);
        try {
            a.apply(null, r(b))
        } catch (c) {
            Wa(c)
        }
    };

    function Kb(a) {
        var b = a.m.filter(function(f) {
                return Object.values(w).includes(f.event.type) && 'video' == a.g.g && f.origin === a.g.j || 'loaded' == f.event.type && 'display' == a.g.g && f.origin === a.g.s ? !0 : !1
            }).map(function(f) {
                return f.event
            }),
            c = a.g.D || '',
            d = {};
        b = p(b);
        for (var e = b.next(); !e.done; d = {
                G: d.G
            }, e = b.next()) {
            d.G = e.value;
            d.G.adSessionId || (d.G.adSessionId = c);
            if ('loaded' == d.G.type) {
                if (!a.g.h && 'display' == a.g.g) continue;
                d.G.data = Hb(a, Ib(a, d.G.data))
            }
            a.j.filter(function(f) {
                return function(h) {
                    return h.type === f.G.type
                }
            }(d)).forEach(function(f) {
                return function(h) {
                    return h.I(f.G)
                }
            }(d))
        }
    }

    function Mb(a, b) {
        a: {
            b = new Set(b);a = p(a.m.concat(a.i));
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, b.has(c.event.type) && 'javascript' != c.origin) {
                    b = !0;
                    break a
                }
            b = !1
        }
        return b ? (H('Event owner cannot be registered after its events have already been published.'), !1) : !0
    }

    function Nb(a) {
        var b = a.g.s;
        return 'none' != b && 'javascript' != b ? (H('Impression event is owned by ' + (a.g.s + ', not javascript.')), !1) : !0
    }

    function Ob(a) {
        var b = a.g.j;
        return 'none' != b && 'javascript' != b ? (H('Media events are owned by ' + (a.g.j + ', not javascript.')), !1) : !0
    }

    function Hb(a, b, c) {
        c = void 0 === c ? !1 : c;
        b = Object.assign({}, b);
        a.g.g && Object.assign(b, {
            mediaType: a.g.g
        });
        a.g.h && (c || 'definedByJavaScript' !== a.g.h) && Object.assign(b, {
            creativeType: a.g.h
        });
        return b
    }

    function Gb(a) {
        var b = fb().i;
        return b ? Object.assign({}, a, {
            lastActivity: b
        }) : a
    }

    function Ib(a, b) {
        return a.g.M ? Object.assign({}, b, {
            impressionType: a.g.M
        }) : b
    }

    function Jb(a) {
        var b = fb().g;
        Object.assign(a, vb(b))
    }

    function L(a, b, c, d) {
        return new ub({
            adSessionId: a.g.D || '',
            timestamp: (new Date).getTime(),
            type: b,
            data: d
        }, c)
    }

    function Cb(a) {
        a = a.event;
        var b = a.data ? Object.assign({}, a.data) : void 0;
        'sessionStart' === a.type && (b.context = Object.assign({}, b.context));
        return {
            adSessionId: a.adSessionId,
            timestamp: a.timestamp,
            type: a.type,
            data: b
        }
    }

    function Pb(a, b, c) {
        'start' !== b && 'volumeChange' !== b || null != (c && c.deviceVolume) || (c.deviceVolume = a.g.C)
    }

    function Qb(a, b, c) {
        if (c && ('start' === b || 'volumeChange' === b)) {
            b = c.videoPlayerVolume;
            var d = c.mediaPlayerVolume;
            null != b ? (Object.assign(c, {
                mediaPlayerVolume: b
            }), a.g.N = b) : null != d && (Object.assign(c, {
                videoPlayerVolume: d
            }), a.g.N = d)
        }
    };

    function Rb(a, b) {
        this.h = a;
        this.g = b
    };

    function Sb(a) {
        return !(!a || !a.tagName || 'iframe' !== a.tagName.toLowerCase())
    };

    function N(a, b, c, d, e) {
        this.j = a;
        this.da = b;
        this.U = c;
        this.i = d;
        this.aa = e;
        this.h = null;
        this.g = this.m = this.M = void 0;
        this.$ = !0;
        this.o = void 0;
        Tb(this)
    }

    function Tb(a) {
        if (!a.h) {
            var b;
            a: {
                if ((b = a.j.document) && b.getElementsByClassName && (b = b.getElementsByClassName('omid-element'))) {
                    if (1 == b.length) {
                        b = b[0];
                        break a
                    }
                    1 < b.length && a.$ && (Eb(a.U, 'generic', "More than one element with 'omid-element' class name."), a.$ = !1)
                }
                b = null
            }
            if (b && b.tagName && 'video' === b.tagName.toLowerCase()) a.i.l = b;
            else if (b && b.tagName) a.i.m = b;
            else return;
            Ub(a)
        }
    }

    function Ub(a) {
        a.i.l ? (a.h = a.i.l, a.s()) : a.i.m && (a.h = a.i.m, Sb(a.h) ? a.i.o && a.s() : a.s())
    }

    function Vb(a) {
        a.g && (Sb(a.h) ? a.i.o && (a.P(), Wb(a)) : (a.P(), Wb(a)))
    }
    N.prototype.v = function() {
        this.o && (this.j.document.removeEventListener('visibilitychange', this.o), this.o = void 0)
    };
    N.prototype.s = function() {
        var a = this;
        this.o || (this.o = function() {
            a.i.B = a.j.document.hidden ? 'backgrounded' : 'foregrounded';
            Vb(a)
        }, this.j.document.addEventListener('visibilitychange', this.o), this.o())
    };

    function Wb(a) {
        if (a.M) {
            a.i.U = a.M;
            a = a.da;
            var b = a.g.U,
                c = a.g.P;
            if (b && !b.T(c)) {
                c = Ka(b);
                var d = a.h;
                'audio' != d.g.h && K(d, L(d, 'geometryChange', 'native', c));
                a.g.P = b
            }
        }
    }

    function Xb(a) {
        if (a.g && a.i.o) {
            var b = new x(a.i.o, !1),
                c = a.g.x;
            a = a.g.y;
            b.x += c;
            b.y += a;
            b.J += c;
            b.K += a;
            b.R = !0;
            return b
        }
    };

    function P(a, b, c, d, e, f) {
        N.call(this, a, c, d, e, f);
        this.u = b;
        this.l = void 0
    }
    qa(P, N);
    P.prototype.v = function() {
        void 0 !== this.l && (this.aa.clearInterval(this.l), this.l = void 0);
        N.prototype.v.call(this)
    };
    P.prototype.s = function() {
        var a = this;
        N.prototype.s.call(this);
        null == this.h ? this.l = void 0 : void 0 === this.l && (this.l = this.aa.setInterval(function() {
            return Yb(a)
        }, 200), Yb(this))
    };
    P.prototype.P = function() {
        if (this.m) {
            var a = Xb(this);
            if (a) {
                this.g.S = !1;
                a.S = !0;
                for (var b = !1, c = 0; c < this.g.O.length; c++)
                    if (this.g.O[c].S) {
                        this.g.O[c] = a;
                        b = !0;
                        break
                    }
                b || this.g.O.push(a)
            } else this.g.S = !0;
            b = this.u;
            c = this.i.B;
            var d = this.i.D,
                e = this.N();
            a = new Ja;
            var f = new x(this.m, !1);
            Ma(a, f);
            Ua(b, f, a, d);
            if (e)
                if (f.ba) C(a, 'backgrounded'), C(a, 'noOutputDevice');
                else if ('backgrounded' === c) C(a, 'backgrounded');
            else if (void 0 !== a.g) {
                for (b = 0; b < a.o.length; b++) Ra(a, a.o[b]) && a.v.push(a.o[b]);
                for (b = 0; b < a.s.length; b++) {
                    if (c =
                        Ra(a, a.s[b])) {
                        b: {
                            c = a.s[b];
                            for (d = 0; d < a.j.length; d++)
                                if (a.j[d].T(c)) {
                                    c = !0;
                                    break b
                                }
                            c = !1
                        }
                        c = !c
                    }
                    c && (C(a, 'obstructed'), a.j.push(a.s[b]))
                }
                Qa(a)
            } else C(a, 'notFound');
            else a.m = ['unmeasurable'], a.l = void 0, a.u = 0, a.j = [], a.g && (b = a.g, c = {}, b = new x((c.x = 0, c.y = 0, c.width = b.width, c.height = b.height, c), b.g), a.g = b), a.h = Na();
            this.M = a
        }
    };
    P.prototype.N = function() {
        return Zb(this)
    };

    function Yb(a) {
        if (void 0 !== a.l) {
            if (Zb(a)) {
                var b = a.j.top;
                b = new x(new qb(b.innerWidth, b.innerHeight), !1)
            } else b = new x(new qb(0, 0), !1);
            var c = a.h.getBoundingClientRect();
            if (null == c.x || isNaN(c.x)) c.x = c.left;
            if (null == c.y || isNaN(c.y)) c.y = c.top;
            c = new x(c, !1);
            b.T(a.m) && c.T(a.g) || (a.g = c, a.g.R = !0, a.m = b, a.m.O.push(a.g), Vb(a))
        }
    }

    function Zb(a) {
        try {
            var b = a.j.top;
            return 0 <= b.innerHeight && 0 <= b.innerWidth
        } catch (c) {}
        return !1
    };

    function Q(a, b, c, d, e, f) {
        N.call(this, a, c, d, e, f);
        this.C = this.u = this.B = this.l = void 0;
        this.Z = !1;
        this.H = void 0
    }
    qa(Q, N);
    Q.prototype.v = function() {
        this.l && this.l.disconnect();
        $b(this);
        this.C && ((0, this.j.removeEventListener)('resize', this.C), this.C = void 0);
        N.prototype.v.call(this)
    };
    Q.prototype.s = function() {
        N.prototype.s.call(this);
        if (this.h && (this.l || (this.l = ac(this)), bc(this), cc(this), dc(this.h) && ec(this), 'backgrounded' === this.i.B)) {
            var a = fc(new qb(0, 0));
            this.H = this.g = this.m = a;
            Vb(this)
        }
    };
    Q.prototype.P = function() {
        if (this.g && this.H) {
            var a = Xb(this);
            if (a) {
                var b = a;
                var c = this.H;
                var d = Math.max(a.x, c.x);
                var e = Math.max(a.y, c.y),
                    f = Math.min(a.J, c.J);
                a = Math.min(a.K, c.K);
                f <= d || a <= e ? d = null : (c = {}, d = new x((c.x = d, c.y = e, c.width = Math.abs(f - d), c.height = Math.abs(a - e), c), !1));
                d || (d = new x({
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                }, !1))
            } else b = this.g, d = this.H;
            e = new Ja;
            this.m && Ma(e, this.m);
            (f = 'backgrounded' == this.i.B) && C(e, 'backgrounded');
            e.g = b;
            e.h = d;
            Qa(e);
            this.Z ? !f && za(e.g) ? C(e, 'hidden') : f || 100 === e.u || C(e, 'clipped') : C(e,
                'viewport');
            this.M = e
        }
    };
    Q.prototype.N = function() {
        return !0
    };

    function $b(a) {
        a.B && (a.B.disconnect(), a.B = void 0);
        a.u && (a.u.disconnect(), a.u = void 0)
    }

    function bc(a) {
        a.l && a.h && (a.l.unobserve(a.h), a.l.observe(a.h))
    }

    function dc(a) {
        a = a.getBoundingClientRect();
        return 0 == a.width || 0 == a.height
    }

    function ac(a) {
        return new a.j.IntersectionObserver(function(b) {
            try {
                if (b.length) {
                    for (var c, d = b[0], e = 1; e < b.length; e++) b[e].time > d.time && (d = b[e]);
                    c = d;
                    a.m = fc(c.rootBounds);
                    a.g = fc(c.boundingClientRect);
                    a.H = fc(c.intersectionRect);
                    a.Z = !!c.isIntersecting;
                    Vb(a)
                }
            } catch (f) {
                a.v(), Eb(a.U, 'generic', 'Problem handling IntersectionObserver callback: ' + f.message)
            }
        }, {
            root: null,
            rootMargin: '0px',
            threshold: [0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        })
    }

    function ec(a) {
        a.j.ResizeObserver ? a.B || (a.B = gc(a, function() {
            return hc(a)
        }), a.B.observe(a.h)) : a.u || (a.u = new MutationObserver(function() {
            return hc(a)
        }), a.u.observe(a.h, {
            childList: !1,
            attributes: !0,
            subtree: !1
        }))
    }

    function cc(a) {
        a.C || (a.C = function() {
            bc(a);
            a.h && !dc(a.h) && $b(a)
        }, (0, a.j.addEventListener)('resize', a.C))
    }

    function hc(a) {
        a.h && !dc(a.h) && (bc(a), $b(a))
    }

    function gc(a, b) {
        return new a.j.ResizeObserver(b)
    }

    function fc(a) {
        if (a && null !== a.x && null !== a.y && null !== a.width && null !== a.height) return new x(a, !1)
    };

    function ic(a) {
        if ('object' === typeof a && 'object' === typeof a.webOSSystem) return a.webOSSystem
    }

    function jc(a) {
        return 'object' === typeof ic(a)
    }

    function R(a) {
        if ('object' === typeof a && 'object' === typeof a.tizen) return a.tizen
    }

    function S(a) {
        return 'object' === typeof R(a)
    };

    function kc(a, b) {
        this.h = a;
        this.g = b
    };

    function Bc() {
        return 'undefined' !== typeof crypto && 'function' === typeof crypto.getRandomValues
    }

    function Cc() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        for (var b = [], c = 0; 16 > c; c++) b.push(a[c].toString(16).padStart(2, '0'));
        return b[0] + b[1] + b[2] + b[3] + '-' + b[4] + b[5] + '-' + b[6] + b[7] + '-' + b[8] + b[9] + '-' + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function Dc() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(a) {
            var b = 16 * Math.random() | 0;
            return 'y' === a ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function Ec(a, b, c) {
        var d = void 0 === d ? I : d;
        var e = void 0 === e ? function(f) {
            eval(f)
        } : e;
        this.i = a;
        this.g = d;
        this.j = b;
        this.l = c;
        this.m = e;
        this.h = []
    }

    function Fc(a) {
        if (!a.g) throw Error('OMID Service Script is not running within a window.');
        var b = void 0 !== a.g.document,
            c = void 0;
        if (!b) try {
            c = bb(a.l, 'downloadJavaScriptResource')
        } catch (e) {}
        if (!b && void 0 === c) throw Error('OMID Service Script does not have access to a document or native downloadJavaScriptResource method.');
        var d = a.h;
        a.h = [];
        d.forEach(function(e) {
            try {
                var f = Bc() ? Cc() : Dc();
                if (b) {
                    var h = e.accessMode,
                        g = 'string' === typeof h && -1 !== Object.values(va).indexOf(h) ? e.accessMode : null;
                    var k = g ? 'domain' ==
                        g ? 'limited' : g : 'limited';
                    e.accessMode = k;
                    a: {
                        var l = e.resourceUrl;
                        try {
                            var m = new URL(l, a.g.location.origin);
                            break a
                        } catch (B) {}
                        try {
                            m = new URL(l);
                            break a
                        } catch (B) {}
                        m = null
                    }(h = m) && Gc(a, f, h, k)
                } else Hc(a, e, f, c);
                var q = e.vendorKey,
                    y = e.verificationParameters;
                q = void 0 === q ? '' : q;
                y = void 0 === y ? '' : y;
                q && 'string' === typeof q && '' !== q && y && 'string' === typeof y && '' !== y && (a.i.o[q] = y);
                a.j.u.set(f, e)
            } catch (B) {
                Wa('OMID verification script ' + e.resourceUrl + ' failed to load: ' + B)
            }
        })
    }

    function Hc(a, b, c, d) {
        b.accessMode = 'limited';
        d(b.resourceUrl, function(e) {
            var f = b.resourceUrl;
            try {
                (0, a.m)("this['omidVerificationProperties'] = {\n        'serviceWindow': this,\n        'injectionSource': 'web',\n      };\n      (function(injectionId) {\n        var scopedProps = new Proxy(this.omidVerificationProperties || {},\n          {\n            get: function(target, prop) {\n              if (prop === 'injectionId') {\n                return injectionId;\n              }\n              return Reflect.get(target, prop);\n            }\n          }\n        );\n\n        var scopedGlobal = new Proxy(this, {\n          get: function(target, prop) {\n            if (prop === 'omidVerificationProperties') {\n              return scopedProps;\n            }\n            return Reflect.get(target, prop);\n          }\n        });\n\n        return (function(globalScope, omidVerificationProperties) {\n          " +
                    e + "\n        }).call(scopedGlobal, scopedGlobal, scopedProps);\n      }).call(this, '" + c + "');\n      ")
            } catch (h) {
                H('Error evaluating the JavaScript resource from "' + f + '": ' + h + '.')
            }
        }, function(e) {
            Wa('Failed getting JS resource (' + b.resourceUrl + '): ' + e)
        })
    }

    function Gc(a, b, c, d) {
        var e = a.g.document,
            f = e.createElement('iframe');
        f.id = 'omid-verification-script-frame-' + b;
        f.style.display = 'none';
        if ('full' == d) {
            var h = function() {
                var g = f.contentWindow;
                g.omidVerificationProperties = {
                    serviceWindow: a.g,
                    injectionSource: 'web',
                    injectionId: b
                };
                g = g.document;
                var k = g.createElement('script');
                k.src = c.href;
                g.head.appendChild(k);
                f.removeEventListener('load', h)
            };
            f.addEventListener('load', h)
        } else 'limited' == d && (f.srcdoc = "<html><head>\n<script type=\"text/javascript\">window['omidVerificationProperties'] = {\n'serviceWindow': window.parent,\n'injectionSource': 'web',\n'injectionId': '" +
            (b + '\',\n};\x3c/script>\n<script type="text/javascript" src="') + c.href + '">\x3c/script>\n</head><body></body></html>', f.sandbox = 'allow-scripts');
        e.body.appendChild(f);
        fb().h.set(b, f)
    };

    function Ic(a, b) {
        var c = window,
            d = this;
        if (jc(c))
            if (c)
                if (c.WebOSServiceBridge) {
                    this.i = a;
                    this.h = b;
                    this.g = new c.WebOSServiceBridge;
                    this.g.onservicecallback = function(e) {
                        try {
                            var f = JSON.parse(e);
                            if (f && f.errorCode) d.error(e);
                            else if (!f) d.error('No object recieved from webOS bridge');
                            else if (!Jc(d, e, f, 'volumeStatus', 'object')) {
                                var h = f.volumeStatus;
                                Jc(d, e, h, 'muteStatus', 'boolean') || Jc(d, e, h, 'volume', 'number') || Jc(d, e, h, 'maxVolume', 'number') || (0 >= h.maxVolume ? d.error('Invalid max volume status.') : d.i(h.muteStatus ?
                                    0 : h.volume / h.maxVolume))
                            }
                        } catch (g) {
                            d.error(g)
                        }
                    };
                    try {
                        this.g.call('luna://com.webos.service.audio/master/getVolume', '{"subscribe":true}')
                    } catch (e) {
                        this.error(e)
                    }
                } else this.h('No WebOSServiceBridge on windowContext');
        else this.h('No window context')
    }
    Ic.prototype.stop = function() {
        this.g && this.g.cancel && this.g.cancel();
        this.g = null
    };
    Ic.prototype.error = function(a) {
        this.stop();
        this.h && this.h(a)
    };

    function Jc(a, b, c, d, e) {
        if (typeof c[d] === e) return !1;
        a.error('Unexpected formatting on message from webOS bridge: "' + b + '". Expected "' + d + '" to be of type "' + e + '" but was of type "' + typeof c[d] + '".');
        return !0
    };

    function Kc(a) {
        return S(a) ? 'object' === typeof R(a).tvinputdevice : !1
    }

    function Lc(a, b) {
        var c = window,
            d = this;
        if (c)
            if (this.validate(c)) {
                this.h = b;
                var e = R(c).tvaudiocontrol;
                this.g = void 0;
                b = function() {
                    var f = e.isMute() ? 0 : e.getVolume() / 100;
                    if (void 0 === d.g || d.g != f) d.g = f, a(d.g)
                };
                b();
                this.i = c.setInterval(b, 200);
                this.j = c
            } else b('Invalid Tizen window context');
        else b('No window context')
    }
    Lc.prototype.stop = function() {
        void 0 !== this.i && 'function' === typeof this.j.clearInterval && this.j.clearInterval(this.i);
        this.h = this.g = this.i = void 0
    };
    Lc.prototype.validate = function(a) {
        return S(a) && Kc(a) && 'object' === typeof R(a).tvaudiocontrol && 'function' === typeof a.setInterval && 'function' === typeof a.clearInterval
    };
    Lc.prototype.error = function(a) {
        this.stop();
        this.h && this.h(a)
    };

    function Mc(a, b, c, d, e) {
        var f = this;
        this.g = a;
        this.i = b;
        this.h = c;
        this.l = d;
        this.o = e;
        this.m = !1;
        Nc(this, function(h) {
            if ('sessionStart' === h.type) {
                f.m = !0;
                try {
                    Fc(f.l)
                } catch (g) {
                    H(g.message)
                }
            }
            'sessionFinish' === h.type && (f.m = !1)
        })
    }

    function Nc(a, b, c, d) {
        Bb(a.i, b, c, d)
    }
    n = Mc.prototype;
    n.setSlotElement = function(a) {
        a && a.tagName ? (this.g.m = a, this.h && Ub(this.h)) : H('setSlotElement called with a non-HTMLElement.  It will be ignored.')
    };
    n.setElementBounds = function(a) {
        this.g.o = a;
        this.h && Ub(this.h);
        this.h && Vb(this.h)
    };
    n.error = function(a, b) {
        Eb(this.i, a, b)
    };
    n.injectVerificationScriptResources = function(a) {
        var b = this.l;
        b.h.push.apply(b.h, r(a));
        if (this.m) try {
            Fc(this.l)
        } catch (c) {
            H(c.message)
        }
    };
    n.setCreativeType = function(a, b) {
        b = void 0 === b ? null : b;
        if (!this.g.g || this.g.h) this.g.h = a, 'video' == a || 'audio' == a ? this.g.g = 'video' : 'htmlDisplay' == a || 'nativeDisplay' == a ? this.g.g = 'display' : 'definedByJavaScript' == a && b && (this.g.g = 'none' == b ? 'display' : 'video')
    };
    n.setImpressionType = function(a) {
        if (!this.g.g || this.g.h) this.g.M = a
    };
    n.setClientInfo = function(a, b, c) {
        var d = this.g.i || {};
        d.omidJsInfo = Object.assign({}, d.omidJsInfo, {
            sessionClientVersion: a,
            partnerName: b,
            partnerVersion: c
        });
        this.g.i = d;
        return this.g.i.omidJsInfo.serviceVersion
    };

    function Oc(a) {
        if (S(window) || jc(window)) {
            var b = function(d) {
                    if (a.g.C !== d && 'none' !== a.i.g.j && 'number' === typeof d && !isNaN(d)) {
                        a.g.C = d;
                        var e = a.o,
                            f = e.g.N;
                        null != f && (d = e.h, e = {
                            mediaPlayerVolume: f,
                            deviceVolume: e.g.C
                        }, Pb(d, 'volumeChange', e), Qb(d, 'volumeChange', e), K(d, L(d, 'volumeChange', 'native', e)))
                    }
                },
                c = function(d) {
                    H(d)
                };
            jc(window) ? a.j = new Ic(b, c) : S(window) && (a.j = new Lc(b, c))
        }
    };

    function Pc(a, b) {
        if (!b) return a.g;
        for (var c = p(a.h.values()), d = c.next(); !d.done; d = c.next())
            if (d = d.value, d.g.u.has(b)) return d;
        return a.g
    }

    function T(a, b) {
        return null == b ? a.g : a.h.get(b) || a.g
    }

    function Qc(a) {
        var b = new rb,
            c = new wb(b),
            d = new Sa,
            e = new Ta,
            f = new Rb(c, b),
            h = a.i,
            g = omidGlobal;
        d = g ? g.IntersectionObserver && (g.MutationObserver || g.ResizeObserver) ? new Q(g, d, f, c, b, h) : new P(g, e, f, c, b, h) : null;
        return new Mc(b, c, d, new Ec(c, b, a.i), new kc(c, b))
    };

    function U(a, b, c, d) {
        this.h = a;
        this.method = b;
        this.version = c;
        this.g = d
    }

    function Rc(a) {
        return !!a && void 0 !== a.omid_message_guid && void 0 !== a.omid_message_method && void 0 !== a.omid_message_version && 'string' === typeof a.omid_message_guid && 'string' === typeof a.omid_message_method && 'string' === typeof a.omid_message_version && (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
    }

    function Sc(a) {
        return new U(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
    }

    function Tc(a) {
        var b = {};
        b = (b.omid_message_guid = a.h, b.omid_message_method = a.method, b.omid_message_version = a.version, b);
        void 0 !== a.g && (b.omid_message_args = a.g);
        return b
    };

    function Uc(a) {
        this.i = a
    };

    function V(a) {
        this.i = a;
        this.handleExportedMessage = V.prototype.j.bind(this)
    }
    qa(V, Uc);
    V.prototype.h = function(a, b) {
        b = void 0 === b ? this.i : b;
        if (!b) throw Error('Message destination must be defined at construction time or when sending the message.');
        b.handleExportedMessage(Tc(a), this)
    };
    V.prototype.j = function(a, b) {
        Rc(a) && this.g && this.g(Sc(a), b)
    };

    function Vc(a) {
        return Wc(a, 'SessionService.')
    }

    function Wc(a, b) {
        return (a = a.match(new RegExp('^' + b + '(.*)'))) && a[1]
    };

    function Xc(a, b) {
        this.h = a;
        this.i = b
    }
    Xc.prototype.g = function(a) {
        var b = u.apply(1, arguments);
        a: switch (a) {
            case 'registerSessionObserver':
                var c = b.slice(1);
                break a;
            default:
                c = b
        }
        return this.h('SessionService.' + a, this.j.bind(this, a, b), c)
    };
    Xc.prototype.j = function(a, b, c) {
        switch (a) {
            case 'registerSessionObserver':
                a = p(b).next().value, a(c)
        }
    };

    function Y(a, b) {
        return a.g.bind(a, b)
    }

    function Yc(a, b) {
        b = void 0 === b ? I : b;
        null == b.omidSessionInterface && (a = {
            setSessionClientWindow: a.i,
            setClientInfo: Y(a, 'setClientInfo'),
            registerSessionObserver: Y(a, 'registerSessionObserver'),
            startAdSession: Y(a, 'startSession'),
            finishAdSession: Y(a, 'finishSession'),
            reportError: Y(a, 'sessionError'),
            registerAdEvents: Y(a, 'registerAdEvents'),
            registerMediaEvents: Y(a, 'registerMediaEvents'),
            injectVerificationScriptResources: Y(a, 'injectVerificationScriptResources'),
            setSlotElement: Y(a, 'setSlotElement'),
            setVideoElement: Y(a,
                'setVideoElement'),
            setElementBounds: Y(a, 'setElementBounds'),
            setCreativeType: Y(a, 'setCreativeType'),
            setImpressionType: Y(a, 'setImpressionType'),
            setContentUrl: Y(a, 'setContentUrl'),
            adEvents: {
                impressionOccurred: Y(a, 'impressionOccurred'),
                loaded: Y(a, 'loaded')
            },
            mediaEvents: {
                start: Y(a, 'start'),
                firstQuartile: Y(a, 'firstQuartile'),
                midpoint: Y(a, 'midpoint'),
                thirdQuartile: Y(a, 'thirdQuartile'),
                complete: Y(a, 'complete'),
                pause: Y(a, 'pause'),
                resume: Y(a, 'resume'),
                bufferStart: Y(a, 'bufferStart'),
                bufferFinish: Y(a, 'bufferFinish'),
                skipped: Y(a, 'skipped'),
                volumeChange: Y(a, 'volumeChange'),
                playerStateChange: Y(a, 'playerStateChange'),
                adUserInteraction: Y(a, 'adUserInteraction')
            }
        }, a.mediaEvents.loaded = a.adEvents.loaded, a.videoEvents = a.mediaEvents, Object.freeze(a), Object.defineProperty(b, 'omidSessionInterface', {
            value: a,
            writable: !1
        }))
    };

    function Zc(a, b) {
        this.i = b = void 0 === b ? I : b;
        var c = this;
        a.addEventListener('message', function(d) {
            if ('object' === typeof d.data) {
                var e = d.data;
                Rc(e) && d.source && c.g && c.g(Sc(e), d.source)
            }
        })
    }
    qa(Zc, Uc);
    Zc.prototype.h = function(a, b) {
        b = void 0 === b ? this.i : b;
        if (!b) throw Error('Message destination must be defined at construction time or when sending the message.');
        b.postMessage(Tc(a), '*')
    };

    function $c(a) {
        if (I.document) {
            var b = I.document.createElement('iframe');
            b.style.display = 'none';
            b.src = a;
            a = function() {
                var c = I.document.body || I.document.documentElement;
                c && (c.appendChild(b), setTimeout(function() {
                    b.parentNode && b.parentNode.removeChild(b)
                }, 100))
            };
            'loading' === I.document.readyState ? I.document.addEventListener('DOMContentLoaded', a) : a()
        }
    };

    function ad() {
        this.g = bd
    }
    n = ad.prototype;
    n.registerSessionObserver = function(a, b) {
        Nc(T(this.g, a), b)
    };
    n.setSlotElement = function(a, b) {
        T(this.g, a).setSlotElement(b)
    };
    n.setElementBounds = function(a, b) {
        T(this.g, a).setElementBounds(b)
    };
    n.error = function(a, b, c) {
        T(this.g, a).error(b, c)
    };

    function Z(a, b, c, d) {
        a = T(a.g, b);
        if ('impression' == c) Nb(a.i) && (c = a.i, d = (d = c.g.P) ? Ka(d) : null, d = Hb(c, Ib(c, d)), K(c, L(c, 'impression', 'javascript', d)), a.h && Tb(a.h));
        else {
            if ('loaded' == c) {
                if (b = d, b = void 0 === b ? null : b, Ob(a.i) && (d = a.i, d.g.h || 'display' != d.g.g)) b = L(d, 'loaded', 'javascript', Hb(d, Ib(d, void 0 === b ? null : b))), K(d, b)
            } else Ob(a.i) && (b = a.i, Pb(b, c, d), Qb(b, c, d), K(b, L(b, c, 'javascript', d)));
            ['loaded', 'start'].includes(c) && a.h && Tb(a.h)
        }
    }
    n.injectVerificationScriptResources = function(a, b) {
        T(this.g, a).injectVerificationScriptResources(b)
    };
    n.setCreativeType = function(a, b, c) {
        c = void 0 === c ? null : c;
        T(this.g, a).setCreativeType(b, c)
    };
    n.setImpressionType = function(a, b) {
        T(this.g, a).setImpressionType(b)
    };
    n.setClientInfo = function(a, b, c, d) {
        var e = this.g;
        if (null == a) a = e.g;
        else {
            var f = [].concat(r(e.h.values())).includes(e.g) ? Qc(e) : e.g;
            e.h.set(a, f);
            a = f
        }
        return a.setClientInfo(b, c, d)
    };

    function cd(a) {
        a = a.split('-')[0].split('.');
        for (var b = ['1', '0', '3'], c = 0; 3 > c; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };

    function dd(a, b) {
        return /\d+\.\d+\.\d+(-.*)?/.test(a) && cd(a) ? b : JSON.stringify(b)
    }

    function ed(a, b) {
        return /\d+\.\d+\.\d+(-.*)?/.test(a) && cd(a) ? b ? b : [] : b && 'string' === typeof b ? JSON.parse(b) : []
    };

    function fd() {
        var a = gd,
            b = this;
        var c = void 0 === c ? omidGlobal : c;
        this.g = a;
        this.h = c;
        this.j = new V;
        this.h.omid = this.h.omid || {};
        this.h.omid.v1_SessionServiceCommunication = this.j;
        this.i = c && c.addEventListener && c.postMessage ? new Zc(c) : null;
        this.m = null;
        this.j.g = this.l.bind(this);
        this.i && (this.i.g = this.o.bind(this));
        this.s = new Xc(function(d, e, f) {
            try {
                hd(b, d, e, f)
            } catch (h) {
                H(id(h))
            }
        }, function(d) {
            b.m = d;
            var e = Bc() ? Cc() : Dc();
            b.i.h(new U(e, 'identifyServiceWindow', '1.6.11-google35'), d)
        });
        Yc(this.s, this.h)
    }
    fd.prototype.l = function(a, b) {
        null != Vc(a.method) && jd(this, a, b, this.j)
    };
    fd.prototype.o = function(a, b) {
        if (null != Vc(a.method)) {
            if (!this.m || b !== this.m) return H('Unrecognized session client window. Cross-origin session clients must register via the setSessionClientWindow API. See https://interactiveadvertisingbureau.github.io/Open-Measurement-SDKJS/iframes.html#om-sdk-js-session-client'), !1;
            jd(this, a, b, this.i)
        }
    };

    function jd(a, b, c, d) {
        function e() {
            var k = new U(f, 'response', g, dd(g, u.apply(0, arguments)));
            d.h(k, c)
        }
        var f = b.h,
            h = b.method,
            g = b.version;
        b = ed(g, b.g);
        try {
            hd(a, h, e, b)
        } catch (k) {
            d.h(new U(f, 'error', g, id(k)), c)
        }
    }

    function hd(a, b, c, d) {
        if (null != Vc(b)) switch (Vc(b)) {
            case 'registerAdEvents':
                var e = p(d).next().value,
                    f = T(a.g.g, e).i;
                Mb(f, ['impression']) && Nb(f) && (f.g.s = 'javascript');
                break;
            case 'registerMediaEvents':
                var h = p(d).next().value,
                    g = T(a.g.g, h).i;
                Mb(g, Object.values(w)) && Ob(g) && (g.g.j = 'javascript');
                break;
            case 'registerSessionObserver':
                var k = p(d).next().value;
                a.g.registerSessionObserver(k, c);
                break;
            case 'setSlotElement':
                var l = p(d),
                    m = l.next().value,
                    q = l.next().value;
                a.g.setSlotElement(q, m);
                break;
            case 'setVideoElement':
                var y =
                    p(d),
                    B = y.next().value,
                    E = y.next().value,
                    D = T(a.g.g, E);
                B && B.tagName && 'video' === B.tagName.toLowerCase() ? (D.g.l = B, D.h && Ub(D.h)) : H('setVideoElement called with a non-HTMLVideoElement. It will be ignored.');
                break;
            case 'setElementBounds':
                var Aa = p(d),
                    hb = Aa.next().value,
                    ib = Aa.next().value;
                a.g.setElementBounds(ib, hb);
                break;
            case 'startSession':
                var Ba = p(d),
                    F = Ba.next().value,
                    ba = Ba.next().value;
                var G = a.h;
                if (null != F && 'object' === typeof F) {
                    var ca = F.customReferenceData,
                        da = F.underEvaluation,
                        ea = F.universalAdId;
                    'string' ===
                    typeof ca || (ca = void 0);
                    'boolean' === typeof da || (da = !1);
                    var J = {
                        customReferenceData: ca,
                        underEvaluation: da
                    };
                    'string' === typeof ea && (J.universalAdId = ea);
                    if (jc(G)) {
                        var Ca = ic(G),
                            W;
                        'object' === typeof Ca && (W = Ca.identifier);
                        J.app = {
                            appId: W && 'string' === typeof W ? W : void 0
                        };
                        b: {
                            var Da = ic(G);
                            if ('object' === typeof Da) {
                                try {
                                    var A = JSON.parse(Da.deviceInfo)
                                } catch (sd) {
                                    var jb = void 0;
                                    break b
                                }
                                jb = {
                                    deviceType: A.modelName || 'Unknown',
                                    osVersion: A.platformVersion || 'Unknown',
                                    os: 'webOS'
                                }
                            } else jb = void 0
                        }
                        J.deviceInfo = jb;
                        J.deviceCategory =
                            'ctv'
                    } else if (S(G)) {
                        b: {
                            if (S(G)) {
                                try {
                                    var lc = R(G).application.getCurrentApplication().appInfo.id
                                } catch (sd) {
                                    var kb = void 0;
                                    break b
                                }
                                if ('string' === typeof lc) {
                                    kb = lc;
                                    break b
                                }
                            }
                            kb = void 0
                        }
                        J.app = {
                            appId: kb
                        };
                        if (S(G)) {
                            var Ea = R(G).systeminfo;
                            if ('object' === typeof Ea && 'function' === typeof Ea.getCapability) {
                                var td = Ea.getCapability('http://tizen.org/system/model_name');
                                var ud = Ea.getCapability('http://tizen.org/feature/platform.version')
                            }
                            var mc = {
                                deviceType: td || 'Unknown',
                                osVersion: ud || 'Unknown',
                                os: 'tizen'
                            }
                        } else mc = void 0;
                        J.deviceInfo = mc;Kc(G) && (J.deviceCategory = 'ctv')
                    }
                    F = J
                } else F = null;
                if (null == F) break;
                var O = F;
                var lb = void 0 === lb ? null : lb;
                var M = T(a.g.g, ba),
                    nc = M.g.i;
                nc.sessionOwner || (nc.sessionOwner = 'javascript');
                var vd = ba || (Bc() ? Cc() : Dc());
                M.g.D = vd;
                O.canMeasureVisibility = M.h.N();
                var mb = M.g;
                void 0 !== O.contentUrl && (mb.H = O.contentUrl, O.contentUrl = void 0);
                var oc = mb.i || {};
                O.omidJsInfo = Object.assign({}, oc.omidJsInfo || {}, O.omidJsInfo || {});
                mb.i = Object.assign({}, oc, O);
                Fb(M.i, lb);
                M.h && Tb(M.h);
                Oc(M);
                break;
            case 'finishSession':
                var wd =
                    p(d).next().value,
                    pc = a.g,
                    fa = T(pc.g, wd),
                    qc = pc.g;
                qc.g = Qc(qc);
                Lb(fa.i);
                fa.h.v();
                fa.j && (fa.j.stop(), fa.j = null);
                break;
            case 'impressionOccurred':
                var xd = p(d).next().value;
                Z(a.g, xd, 'impression');
                break;
            case 'loaded':
                var rc = p(d),
                    X = rc.next().value,
                    sc = rc.next().value;
                if (X) {
                    var tc = {
                        skippable: X.isSkippable,
                        autoPlay: X.isAutoPlay,
                        position: X.position
                    };
                    X.isSkippable && (tc.skipOffset = X.skipOffset);
                    Z(a.g, sc, 'loaded', tc)
                } else Z(a.g, sc, 'loaded');
                break;
            case 'start':
                var nb = p(d),
                    yd = nb.next().value,
                    zd = nb.next().value,
                    Ad = nb.next().value;
                Z(a.g, Ad, 'start', {
                    duration: yd,
                    mediaPlayerVolume: zd
                });
                break;
            case 'firstQuartile':
                var Bd = p(d).next().value;
                Z(a.g, Bd, 'firstQuartile');
                break;
            case 'midpoint':
                var Cd = p(d).next().value;
                Z(a.g, Cd, 'midpoint');
                break;
            case 'thirdQuartile':
                var Dd = p(d).next().value;
                Z(a.g, Dd, 'thirdQuartile');
                break;
            case 'complete':
                var Ed = p(d).next().value;
                Z(a.g, Ed, 'complete');
                break;
            case 'pause':
                var Fd = p(d).next().value;
                Z(a.g, Fd, 'pause');
                break;
            case 'resume':
                var Gd = p(d).next().value;
                Z(a.g, Gd, 'resume');
                break;
            case 'bufferStart':
                var Hd =
                    p(d).next().value;
                Z(a.g, Hd, 'bufferStart');
                break;
            case 'bufferFinish':
                var Id = p(d).next().value;
                Z(a.g, Id, 'bufferFinish');
                break;
            case 'skipped':
                var Jd = p(d).next().value;
                Z(a.g, Jd, 'skipped');
                break;
            case 'volumeChange':
                var uc = p(d),
                    Kd = uc.next().value,
                    Ld = uc.next().value;
                Z(a.g, Ld, 'volumeChange', {
                    mediaPlayerVolume: Kd
                });
                break;
            case 'playerStateChange':
                var vc = p(d),
                    Md = vc.next().value,
                    Nd = vc.next().value;
                Z(a.g, Nd, 'playerStateChange', {
                    state: Md
                });
                break;
            case 'adUserInteraction':
                var wc = p(d),
                    Od = wc.next().value,
                    Pd = wc.next().value;
                Z(a.g, Pd, 'adUserInteraction', {
                    interactionType: Od
                });
                break;
            case 'setClientInfo':
                var Fa = p(d),
                    Qd = Fa.next().value,
                    Rd = Fa.next().value,
                    Sd = Fa.next().value,
                    Td = Fa.next().value,
                    Ud = a.g.setClientInfo(Td, Qd, Rd, Sd);
                c(Ud);
                break;
            case 'injectVerificationScriptResources':
                var xc = p(d),
                    Vd = xc.next().value,
                    Wd = xc.next().value;
                a.g.injectVerificationScriptResources(Wd, Vd);
                break;
            case 'setCreativeType':
                var yc = p(d),
                    Xd = yc.next().value,
                    Yd = yc.next().value;
                a.g.setCreativeType(Yd, Xd);
                break;
            case 'setImpressionType':
                var zc = p(d),
                    Zd = zc.next().value,
                    $d = zc.next().value;
                a.g.setImpressionType($d, Zd);
                break;
            case 'setContentUrl':
                var Ac = p(d),
                    ae = Ac.next().value,
                    be = Ac.next().value;
                T(a.g.g, be).g.H = ae;
                break;
            case 'sessionError':
                var ob = p(d),
                    ce = ob.next().value,
                    de = ob.next().value,
                    ee = ob.next().value;
                a.g.error(ee, ce, de)
        }
    }

    function id(a) {
        return '\n        name: ' + a.name + '\n        message: ' + a.message + '\n        filename: ' + a.filename + '\n        lineNumber: ' + a.lineNumber + '\n        columnNumber: ' + a.columnNumber + '\n        stack: ' + a.stack + '\n        toString(): ' + a.toString()
    };

    function kd() {
        var a = bd,
            b = ld,
            c = this;
        var d = void 0 === d ? I : d;
        this.i = a;
        this.g = b;
        this.l = {};
        this.m = {};
        this.j = new V;
        d.omid = d.omid || {};
        d.omid.v1_VerificationServiceCommunication = this.j;
        this.h = null;
        d && d.addEventListener && d.postMessage && (this.h = new Zc(d));
        this.j.g = function(e, f) {
            md(c, e, f, c.j)
        };
        this.h && (this.h.g = function(e, f) {
            c.h && md(c, e, f, c.h)
        })
    }

    function nd(a) {
        a({
            adSessionId: '',
            timestamp: (new Date).getTime(),
            type: 'sessionError',
            data: {
                errorType: 'generic',
                message: 'Registration to session events is only allowed for verification clients injected by the OM-SDK service itself. Please note that in a future release registration in this manner will be rejected.'
            }
        })
    }

    function od(a, b, c, d) {
        a = Pc(a.i, d);
        void 0 !== d && a.g.u.has(d) ? (a = a.i, 'media' === b || 'video' === b ? Ab(a, c, d) : (c = {
            type: b,
            W: d,
            I: c
        }, a.j.push(c), zb(a, b, c))) : nd(c)
    }

    function pd(a, b, c, d) {
        a = Pc(a.i, d);
        void 0 !== d && a.g.u.has(d) ? Nc(a, b, c, d) : nd(b)
    }

    function qd(a, b, c, d, e, f, h) {
        h = Pc(a.i, h);
        var g = 2 <= h.g.v.g ? {
            V: !1,
            reason: 'SESSION_ATTESTATION_LIMIT_EXCEEDED'
        } : h.g.v.h.has(f) ? {
            V: !1,
            reason: 'TOO_MANY_REQUESTS'
        } : .5 <= Math.random() ? {
            V: !1,
            reason: 'SAMPLING_REJECTED'
        } : {
            V: !0,
            reason: null
        };
        h.g.v.h.add(f);
        if (g.V)
            if (h.g.v.g++, f = h.g.D, 'ApplePAT' === b) db(a.g, d.ya, e);
            else try {
                a = {};
                for (var k in d) d.hasOwnProperty(k) && (a[k.toLowerCase()] = d[k]);
                var l = I.webkit ? I.webkit.messageHandlers.omidJsAttestationListener : I.omidJsAttestationListener;
                if (l) l.postMessage(JSON.stringify({
                    method: 'attest',
                    data: {
                        adSessionId: f,
                        mechanism: b,
                        version: c,
                        attestationArgs: a
                    }
                }));
                else {
                    d = '';
                    for (var m in a) a.hasOwnProperty(m) && (d += '&' + m + '=' + a[m]);
                    $c('omid-native://?method=attest&adSessionId=' + f + '&mechanism=' + b + '&version=' + c + d)
                }
                e(!0, 'SUCCESS')
            } catch (q) {
                H('Failed to trigger native-layer attestation method: ' + q.message), e(!1, 'FAILED_TO_TRIGGER_ATTESTATION')
            } else e(!1, g.reason)
    }

    function rd(a, b, c, d) {
        cb(a.g, b, c, d)
    }
    kd.prototype.setInterval = function(a, b) {
        return this.g.setInterval(a, b)
    };
    kd.prototype.clearInterval = function(a) {
        this.g.clearInterval(a)
    };

    function fe(a, b, c, d) {
        bb(a.g, 'downloadJavaScriptResource')(b, c, d)
    }

    function md(a, b, c, d) {
        function e() {
            var A = new U(f, 'response', g, dd(g, u.apply(0, arguments)));
            d.h(A, c)
        }
        var f = b.h,
            h = b.method,
            g = b.version;
        b = ed(g, b.g);
        if (null != Wc(h, 'VerificationService.')) {
            h = Wc(h, 'VerificationService.');
            try {
                switch (h) {
                    case 'addEventListener':
                        var k = p(b),
                            l = k.next().value,
                            m = k.next().value || ge(c);
                        od(a, l, e, m);
                        break;
                    case 'addSessionListener':
                        var q = p(b),
                            y = q.next().value,
                            B = q.next().value || ge(c);
                        pd(a, e, y, B);
                        break;
                    case 'attest':
                        var E = p(b),
                            D = E.next().value,
                            Aa = E.next().value,
                            hb = E.next().value,
                            ib = E.next().value,
                            Ba = E.next().value || ge(c);
                        qd(a, D, Aa, hb, e, ib, Ba);
                        break;
                    case 'sendUrl':
                        var F = p(b).next().value;
                        rd(a, F, function() {
                            return e(!0)
                        }, function() {
                            return e(!1)
                        });
                        break;
                    case 'setTimeout':
                        var ba = p(b),
                            G = ba.next().value,
                            ca = ba.next().value;
                        a.l[G] = $a(a.g, 'setTimeout')(e, ca);
                        break;
                    case 'clearTimeout':
                        var da = p(b).next().value;
                        ab(a.g, a.l[da]);
                        break;
                    case 'setInterval':
                        var ea = p(b),
                            J = ea.next().value,
                            Ca = ea.next().value;
                        a.m[J] = a.setInterval(e, Ca);
                        break;
                    case 'clearInterval':
                        var W = p(b).next().value;
                        a.clearInterval(a.m[W]);
                        break;
                    case 'injectJavaScriptResource':
                        var Da = p(b).next().value;
                        fe(a, Da, function(A) {
                            return e(!0, A)
                        }, function() {
                            return e(!1)
                        });
                        break;
                    case 'getVersion':
                        e('1.6.11-google35')
                }
            } catch (A) {
                d.h(new U(f, 'error', g, '\n              name: ' + A.name + '\n              message: ' + A.message + '\n              filename: ' + A.filename + '\n              lineNumber: ' + A.lineNumber + '\n              columnNumber: ' + A.columnNumber + '\n              stack: ' + A.stack + '\n              toString(): ' + A.toString() + '\n          '), c)
            }
        }
    }

    function ge(a) {
        for (var b = fb().h, c = p(b.keys()), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = b.get(d);
            if (e) {
                if (e.contentWindow === a) return d;
                try {
                    if (e.contentWindow.Object.prototype.isPrototypeOf(a)) return d
                } catch (f) {}
            }
        }
    };

    function he(a) {
        var b = {};
        return (b.app = 'omid_v1_present_app', b.web = 'omid_v1_present_web', b)[a]
    }

    function ie(a, b) {
        a.document.write('<iframe style="display:none" id="' + (b + '" name="' + b + '" sandbox></iframe>'))
    }

    function je(a, b) {
        var c = a.document.createElement('iframe');
        c.id = b;
        c.name = b;
        c.style.display = 'none';
        c.sandbox = '';
        a.document.body.appendChild(c)
    }

    function ke(a, b) {
        var c = new MutationObserver(function(d) {
            d.forEach(function(e) {
                'BODY' === e.addedNodes[0].nodeName && (e = he(b), je(a, 'omid_v1_present'), je(a, e), c.disconnect())
            })
        });
        c.observe(a.document.documentElement, {
            childList: !0
        })
    };
    var ld = new Za,
        bd = new function() {
            this.i = ld;
            this.h = new Map;
            this.g = Qc(this)
        },
        gd = new ad;
    new kd;
    new fd;
    (function(a, b) {
        a.frames && a.document && !['omid_v1_present', 'omid_v1_present_web', 'omid_v1_present_app'].some(function(c) {
            return !!a.frames[c]
        }) && (null == a.document.body && 'MutationObserver' in a ? ke(a, b) : (b = he(b), a.document.body ? (je(a, 'omid_v1_present'), je(a, b)) : (ie(a, 'omid_v1_present'), ie(a, b))))
    })(I, 'web');
}).call(this, this);
(function() {
    'use strict';
    var aa = typeof Object.create == "function" ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        k = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };

    function ba(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var m = ba(this),
        p = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        q = {},
        u = {};

    function v(a, b, c) {
        if (!c || a != null) {
            c = u[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function x(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var f = d[0],
                g;!a && f in q ? g = q : g = m;
            for (f = 0; f < d.length - 1; f++) {
                var e = d[f];
                if (!(e in g)) break a;
                g = g[e]
            }
            d = d[d.length - 1];c = p && c === "es6" ? g[d] : null;b = b(c);b != null && (a ? k(q, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (u[d] === void 0 && (a = Math.random() * 1E9 >>> 0, u[d] = p ? m.Symbol(d) : "$jscp$" + a + "$" + d), k(g, u[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var y;
    if (p && typeof Object.setPrototypeOf == "function") y = Object.setPrototypeOf;
    else {
        var z;
        a: {
            var ca = {
                    a: !0
                },
                da = {};
            try {
                da.__proto__ = ca;
                z = da.a;
                break a
            } catch (a) {}
            z = !1
        }
        y = z ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ea = y;

    function A(a, b) {
        a.prototype = aa(b.prototype);
        a.prototype.constructor = a;
        if (ea) ea(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.ia = b.prototype
    }

    function fa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function B(a) {
        var b = typeof q.Symbol != "undefined" && v(q.Symbol, "iterator") && a[v(q.Symbol, "iterator")];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: fa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function C(a) {
        return ha(a, a)
    }

    function ha(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    }
    var ia = p && typeof v(Object, "assign") == "function" ? v(Object, "assign") : function(a, b) {
        if (a == null) throw new TypeError("No nullish arg");
        a = Object(a);
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var f in d) Object.prototype.hasOwnProperty.call(d, f) && (a[f] = d[f])
        }
        return a
    };
    x("Object.assign", function(a) {
        return a || ia
    }, "es6");

    function G(a) {
        if (!(a instanceof Object)) throw new TypeError("Iterator result " + a + " is not an object");
    }

    function H() {
        this.D = !1;
        this.m = null;
        this.l = void 0;
        this.h = 1;
        this.u = this.B = 0;
        this.J = this.j = null
    }

    function I(a) {
        if (a.D) throw new TypeError("Generator is already running");
        a.D = !0
    }
    H.prototype.I = function(a) {
        this.l = a
    };

    function J(a, b) {
        a.j = {
            X: b,
            Y: !0
        };
        a.h = a.B || a.u
    }
    H.prototype.getNextAddressJsc = function() {
        return this.h
    };
    H.prototype.getYieldResultJsc = function() {
        return this.l
    };
    H.prototype.return = function(a) {
        this.j = {
            return: a
        };
        this.h = this.u
    };
    H.prototype["return"] = H.prototype.return;
    H.prototype.da = function(a) {
        this.j = {
            A: a
        };
        this.u < a ? (this.h = a, this.j = null) : this.h = this.u
    };
    H.prototype.jumpThroughFinallyBlocks = H.prototype.da;
    H.prototype.i = function(a, b) {
        this.h = b;
        return {
            value: a
        }
    };
    H.prototype.yield = H.prototype.i;
    H.prototype.ga = function(a, b) {
        a = B(a);
        var c = a.next();
        G(c);
        if (c.done) this.l = c.value, this.h = b;
        else return this.m = a, this.i(c.value, b)
    };
    H.prototype.yieldAll = H.prototype.ga;
    H.prototype.A = function(a) {
        this.h = a
    };
    H.prototype.jumpTo = H.prototype.A;
    H.prototype.K = function() {
        this.h = 0
    };
    H.prototype.jumpToEnd = H.prototype.K;
    H.prototype.G = function(a, b) {
        this.B = a;
        b != void 0 && (this.u = b)
    };
    H.prototype.setCatchFinallyBlocks = H.prototype.G;
    H.prototype.fa = function(a) {
        this.B = 0;
        this.u = a || 0
    };
    H.prototype.setFinallyBlock = H.prototype.fa;
    H.prototype.L = function(a, b) {
        this.h = a;
        this.B = b || 0
    };
    H.prototype.leaveTryBlock = H.prototype.L;
    H.prototype.F = function(a) {
        this.B = a || 0;
        a = this.j.X;
        this.j = null;
        return a
    };
    H.prototype.enterCatchBlock = H.prototype.F;
    H.prototype.S = function(a, b, c) {
        c ? this.J[c] = this.j : this.J = [this.j];
        this.B = a || 0;
        this.u = b || 0;
        this.j = null
    };
    H.prototype.enterFinallyBlock = H.prototype.S;
    H.prototype.ea = function(a, b) {
        b = this.J.splice(b || 0)[0];
        (b = this.j = this.j || b) ? b.Y ? this.h = this.B || this.u : b.A != void 0 && this.u < b.A ? (this.h = b.A, this.j = null) : this.h = this.u: this.h = a
    };
    H.prototype.leaveFinallyBlock = H.prototype.ea;
    H.prototype.ca = function(a) {
        return new K(a)
    };
    H.prototype.forIn = H.prototype.ca;

    function K(a) {
        this.j = a;
        this.h = [];
        for (var b in a) this.h.push(b);
        this.h.reverse()
    }
    K.prototype.i = function() {
        for (; this.h.length > 0;) {
            var a = this.h.pop();
            if (a in this.j) return a
        }
        return null
    };
    K.prototype.getNext = K.prototype.i;

    function ja(a) {
        this.h = new H;
        this.i = a
    }

    function ka(a, b) {
        I(a.h);
        var c = a.h.m;
        if (c) return L(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.h.return);
        a.h.return(b);
        return M(a)
    }

    function L(a, b, c, d) {
        try {
            var f = b.call(a.h.m, c);
            G(f);
            if (!f.done) return a.h.D = !1, f;
            var g = f.value
        } catch (e) {
            return a.h.m = null, J(a.h, e), M(a)
        }
        a.h.m = null;
        d.call(a.h, g);
        return M(a)
    }

    function M(a) {
        for (; a.h.h;) try {
            var b = a.i(a.h);
            if (b) return a.h.D = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.h.l = void 0, J(a.h, c)
        }
        a.h.D = !1;
        if (a.h.j) {
            b = a.h.j;
            a.h.j = null;
            if (b.Y) throw b.X;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    }

    function la(a) {
        this.next = function(b) {
            I(a.h);
            a.h.m ? b = L(a, a.h.m.next, b, a.h.I) : (a.h.I(b), b = M(a));
            return b
        };
        this.throw = function(b) {
            I(a.h);
            if (a.h.m) {
                var c = a.h.m["throw"];
                if (c) var d = L(a, c, b, a.h.I);
                else {
                    b = a.h.m;
                    a.h.m = null;
                    try {
                        b["return"] && (d = b["return"](), G(d)), J(a.h, new TypeError("The iterator does not provide a 'throw' method."))
                    } catch (f) {
                        J(a.h, f)
                    }
                    d = M(a)
                }
            } else J(a.h, b), d = M(a);
            return d
        };
        this.return = function(b) {
            return ka(a, b)
        };
        this[v(q.Symbol, "iterator")] = function() {
            return this
        }
    }

    function ma(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new q.Promise(function(d, f) {
            function g(e) {
                e.done ? d(e.value) : q.Promise.resolve(e.value).then(b, c).then(g, f)
            }
            g(a.next())
        })
    }

    function N(a) {
        return ma(new la(new ja(a)))
    }

    function na() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    x("globalThis", function(a) {
        return a || m
    }, "es_2020");
    x("Symbol", function(a) {
        function b(g) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (g || "") + "_" + f++, g)
        }

        function c(g, e) {
            this.h = g;
            k(this, "description", {
                configurable: !0,
                writable: !0,
                value: e
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.h
        };
        var d = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            f = 0;
        return b
    }, "es6");
    x("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        k(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return oa(fa(this))
            }
        });
        return a
    }, "es6");

    function oa(a) {
        var b = (typeof Iterator != "undefined" && Iterator.prototype && !Iterator.prototype.next ? Iterator.prototype : null) || Object.prototype,
            c = aa(b);
        c.next = a;
        b[v(q.Symbol, "iterator")] || (c[v(q.Symbol, "iterator")] = function() {
            return this
        });
        return c
    }
    x("Promise", function(a) {
        function b(e) {
            this.i = 0;
            this.j = void 0;
            this.h = [];
            this.B = !1;
            var h = this.l();
            try {
                e(h.resolve, h.reject)
            } catch (l) {
                h.reject(l)
            }
        }

        function c() {
            this.h = null
        }

        function d(e) {
            return e instanceof b ? e : new b(function(h) {
                h(e)
            })
        }
        if (a) return a;
        c.prototype.i = function(e) {
            if (this.h == null) {
                this.h = [];
                var h = this;
                this.j(function() {
                    h.m()
                })
            }
            this.h.push(e)
        };
        var f = m.setTimeout;
        c.prototype.j = function(e) {
            f(e, 0)
        };
        c.prototype.m = function() {
            for (; this.h && this.h.length;) {
                var e = this.h;
                this.h = [];
                for (var h = 0; h < e.length; ++h) {
                    var l =
                        e[h];
                    e[h] = null;
                    try {
                        l()
                    } catch (n) {
                        this.l(n)
                    }
                }
            }
            this.h = null
        };
        c.prototype.l = function(e) {
            this.j(function() {
                throw e;
            })
        };
        b.prototype.l = function() {
            function e(n) {
                return function(r) {
                    l || (l = !0, n.call(h, r))
                }
            }
            var h = this,
                l = !1;
            return {
                resolve: e(this.J),
                reject: e(this.m)
            }
        };
        b.prototype.J = function(e) {
            if (e === this) this.m(new TypeError("A Promise cannot resolve to itself"));
            else if (e instanceof b) this.L(e);
            else {
                a: switch (typeof e) {
                    case "object":
                        var h = e != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.I(e) : this.u(e)
            }
        };
        b.prototype.I = function(e) {
            var h = void 0;
            try {
                h = e.then
            } catch (l) {
                this.m(l);
                return
            }
            typeof h == "function" ? this.S(h, e) : this.u(e)
        };
        b.prototype.m = function(e) {
            this.D(2, e)
        };
        b.prototype.u = function(e) {
            this.D(1, e)
        };
        b.prototype.D = function(e, h) {
            if (this.i != 0) throw Error("Cannot settle(" + e + ", " + h + "): Promise already settled in state" + this.i);
            this.i = e;
            this.j = h;
            this.i === 2 && this.K();
            this.F()
        };
        b.prototype.K = function() {
            var e = this;
            f(function() {
                if (e.G()) {
                    var h = m.console;
                    typeof h !== "undefined" && h.error(e.j)
                }
            }, 1)
        };
        b.prototype.G =
            function() {
                if (this.B) return !1;
                var e = m.CustomEvent,
                    h = m.Event,
                    l = m.dispatchEvent;
                if (typeof l === "undefined") return !0;
                typeof e === "function" ? e = new e("unhandledrejection", {
                    cancelable: !0
                }) : typeof h === "function" ? e = new h("unhandledrejection", {
                    cancelable: !0
                }) : (e = m.document.createEvent("CustomEvent"), e.initCustomEvent("unhandledrejection", !1, !0, e));
                e.promise = this;
                e.reason = this.j;
                return l(e)
            };
        b.prototype.F = function() {
            if (this.h != null) {
                for (var e = 0; e < this.h.length; ++e) g.i(this.h[e]);
                this.h = null
            }
        };
        var g = new c;
        b.prototype.L =
            function(e) {
                var h = this.l();
                e.O(h.resolve, h.reject)
            };
        b.prototype.S = function(e, h) {
            var l = this.l();
            try {
                e.call(h, l.resolve, l.reject)
            } catch (n) {
                l.reject(n)
            }
        };
        b.prototype.then = function(e, h) {
            function l(t, w) {
                return typeof t == "function" ? function(D) {
                    try {
                        n(t(D))
                    } catch (E) {
                        r(E)
                    }
                } : w
            }
            var n, r, F = new b(function(t, w) {
                n = t;
                r = w
            });
            this.O(l(e, n), l(h, r));
            return F
        };
        b.prototype.catch = function(e) {
            return this.then(void 0, e)
        };
        b.prototype.O = function(e, h) {
            function l() {
                switch (n.i) {
                    case 1:
                        e(n.j);
                        break;
                    case 2:
                        h(n.j);
                        break;
                    default:
                        throw Error("Unexpected state: " +
                            n.i);
                }
            }
            var n = this;
            this.h == null ? g.i(l) : this.h.push(l);
            this.B = !0
        };
        b.resolve = d;
        b.reject = function(e) {
            return new b(function(h, l) {
                l(e)
            })
        };
        b.race = function(e) {
            return new b(function(h, l) {
                for (var n = B(e), r = n.next(); !r.done; r = n.next()) d(r.value).O(h, l)
            })
        };
        b.all = function(e) {
            var h = B(e),
                l = h.next();
            return l.done ? d([]) : new b(function(n, r) {
                function F(D) {
                    return function(E) {
                        t[D] = E;
                        w--;
                        w == 0 && n(t)
                    }
                }
                var t = [],
                    w = 0;
                do t.push(void 0), w++, d(l.value).O(F(t.length - 1), r), l = h.next(); while (!l.done)
            })
        };
        return b
    }, "es6");
    x("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var f = [],
                g = typeof q.Symbol != "undefined" && v(q.Symbol, "iterator") && b[v(q.Symbol, "iterator")];
            if (typeof g == "function") {
                b = g.call(b);
                for (var e = 0; !(g = b.next()).done;) f.push(c.call(d, g.value, e++))
            } else
                for (g = b.length, e = 0; e < g; e++) f.push(c.call(d, b[e], e));
            return f
        }
    }, "es6");
    x("Promise.allSettled", function(a) {
        function b(d) {
            return {
                status: "fulfilled",
                value: d
            }
        }

        function c(d) {
            return {
                status: "rejected",
                reason: d
            }
        }
        return a ? a : function(d) {
            var f = this;
            d = v(Array, "from").call(Array, d, function(g) {
                return f.resolve(g).then(b, c)
            });
            return f.all(d)
        }
    }, "es_2020");
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var pa = q.globalThis.trustedTypes,
        O;

    function qa() {
        var a = null;
        if (!pa) return a;
        try {
            var b = function(c) {
                return c
            };
            a = pa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };

    function P(a) {
        this.h = a
    }
    P.prototype.toString = function() {
        return this.h + ""
    };

    function Q(a) {
        var b;
        O === void 0 && (O = qa());
        a = (b = O) ? b.createScriptURL(a) : a;
        return new P(a)
    }

    function ra(a) {
        if (a instanceof P) return a.h;
        throw Error("");
    };

    function R(a) {
        var b = na.apply(1, arguments);
        if (b.length === 0) return Q(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Q(c)
    };
    var sa = C(["https://www.google.com/recaptcha/api2/aframe"]),
        ta = R(sa);

    function ua(a, b) {
        a.src = ra(b);
        var c;
        b = a.ownerDocument;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };

    function S(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };

    function va(a, b) {
        var c = !1;
        c = c === void 0 ? !1 : c;
        return new q.Promise(function(d, f) {
            function g() {
                e.onload = null;
                e.onerror = null;
                var h;
                (h = e.parentElement) == null || h.removeChild(e)
            }
            var e = b.document.createElement("script");
            e.onload = function() {
                g();
                d()
            };
            e.onerror = function() {
                g();
                f(7)
            };
            e.type = "text/javascript";
            ua(e, a);
            c && b.document.readyState !== "complete" ? S(b, "load", function() {
                b.document.body.appendChild(e)
            }) : b.document.body.appendChild(e)
        })
    }

    function wa(a, b) {
        var c = window;
        return new q.Promise(function(d) {
            b === void 0 && (b = c.document.createElement("iframe"));
            b.addEventListener("load", function() {
                d(b)
            });
            b.src = ra(a).toString();
            b.width = "0";
            b.height = "0";
            b.style.display = "none";
            c.document.body.appendChild(b)
        })
    };

    function xa(a) {
        return new q.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    }

    function ya(a) {
        a = a === void 0 ? document : a;
        return a.createElement("img")
    };
    var za = C(["https://ep1.adtrafficquality.google/bg/", ".js"]),
        Aa = C(["https://pagead2.googlesyndication.com/bg/", ".js"]);

    function Ba(a, b, c, d, f) {
        var g = window;
        g = g === void 0 ? window : g;
        c = c === void 0 ? !1 : c;
        d = d === void 0 ? 0 : d;
        f = f === void 0 ? !1 : f;
        this.W = b;
        this.h = g;
        this.C = c;
        this.v = d;
        this.j = f ? R(za, encodeURIComponent(a)) : R(Aa, encodeURIComponent(a))
    }

    function Ca(a) {
        return N(function(b) {
            switch (b.h) {
                case 1:
                    return b.i(Da(a), 2);
                case 2:
                    return b.i(Ea(a), 3);
                case 3:
                    if (!(a.v > 0)) {
                        b.A(4);
                        break
                    }
                    return b.i(xa(a.v), 4);
                case 4:
                    return b.return(Fa(a))
            }
        })
    }

    function Da(a) {
        var b;
        return N(function(c) {
            if (a.C) {
                b = document.createElement("iframe");
                b.style.display = "none";
                document.body.appendChild(b);
                if (!b.contentWindow) throw 3;
                a.h = b.contentWindow;
                a.h.document.open();
                a.h.document.close()
            }
            return c.return(va(a.j, a.h))
        })
    }

    function Ea(a) {
        return new q.Promise(function(b, c) {
            a.h.botguard && a.h.botguard.bg ? a.i = new a.h.botguard.bg(a.W, b) : c(5)
        })
    }
    Ba.prototype.snapshotSync = function() {
        var a = void 0;
        if (this.i && this.i.invoke && (this.i.invoke(function(b) {
                a = b
            }, !1), a)) return a;
        throw 6;
    };

    function Fa(a) {
        return new q.Promise(function(b, c) {
            a.i && a.i.invoke ? a.i.invoke(function(d) {
                b(d)
            }, !0) : c(6)
        })
    };

    function T(a, b) {
        return a === void 0 ? b === void 0 ? !1 : b : a !== "0"
    }

    function Ga() {
        var a = window.GoogleGcLKhOms;
        if (a && a.length > 0 && (a = a.shift())) {
            a: {
                var b = a._ctx_;
                switch (b) {
                    case "pt":
                    case "cr":
                        break a;
                    default:
                        b = ""
                }
            }
            a: {
                var c = a._st_;
                switch (c) {
                    case "env":
                    case "int":
                        break a;
                    default:
                        c = "env"
                }
            }
            b = {
                context: b,
                N: a._bgv_,
                M: a._bgp_,
                V: a._li_,
                P: a._jk_,
                R: c,
                v: a._dl_,
                T: a._g2_,
                o: T(a._atqg_),
                ba: T(a._sic_),
                C: T(a._ivm_, !0)
            };a._rc_ !== void 0 && (b = v(Object, "assign").call(Object, {}, b, {
                U: a._rc_
            }));a._wvp_ !== void 0 && (b = v(Object, "assign").call(Object, {}, b, {
                H: T(a._wvp_)
            }));
            return b
        }
    }

    function Ha() {
        var a = window;
        Array.isArray(a.GoogleDX5YKUSkRag) || (a.GoogleDX5YKUSkRag = []);
        return new q.Promise(function(b) {
            a.GoogleDX5YKUSkRag.push(b)
        })
    }

    function Ia() {
        return window.GoogleGcLKhOms === void 0 ? 13 : 1
    };

    function U(a, b) {
        this.i = a;
        this.o = b
    }

    function Ja(a, b) {
        U.call(this, a, b);
        var c = this;
        this.h = !1;
        var d = new MessageChannel;
        this.port = d.port1;
        this.j = new q.Promise(function(f) {
            c.port.onmessage = function() {
                f()
            };
            var g = b ? "https://ep2.adtrafficquality.google" : "https://tpc.googlesyndication.com";
            c.i.postMessage("GoogleBasRYoCJlVEB", g.indexOf("https:") === -1 ? "http:" + g : g, [d.port2])
        })
    }
    A(Ja, U);

    function Ka(a, b) {
        return N(function(c) {
            return c.h == 1 ? c.i(a.j, 2) : c.return(new q.Promise(function(d, f) {
                var g = new MessageChannel;
                g.port1.onmessage = function(e) {
                    g.port1.close();
                    Array.isArray(e.data) ? d(e.data) : f(9)
                };
                a.port.postMessage(b, [g.port2])
            }))
        })
    }

    function La(a, b) {
        var c;
        return N(function(d) {
            if (d.h == 1) return d.G(2), d.i(Ka(a, [1, b.ha, b.W, b.v]), 4);
            if (d.h != 2) return c = d.l, d.return({
                response: c[0],
                error: c[1]
            });
            d.F();
            return d.return({
                error: 9
            })
        })
    }

    function Ma() {
        U.apply(this, arguments);
        this.h = !0
    }
    A(Ma, U);
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    function Na(a, b) {
        Oa(a, b === void 0 ? null : b)
    }

    function Oa(a, b) {
        var c = window,
            d = !1;
        d = d === void 0 ? !1 : d;
        c.google_image_requests || (c.google_image_requests = []);
        var f = ya(c.document);
        if (b) {
            var g = function(e) {
                b && b(e);
                typeof f.removeEventListener === "function" && f.removeEventListener("load", g, !1);
                typeof f.removeEventListener === "function" && f.removeEventListener("error", g, !1)
            };
            S(f, "load", g);
            S(f, "error", g)
        }
        d && (f.attributionSrc = "");
        f.src = a;
        c.google_image_requests.push(f)
    };

    function Pa(a) {
        this.url = (this.o = a) ? "https://ep1.adtrafficquality.google/pagead/gen_204?id=sodar2&v=257" : "https://pagead2.googlesyndication.com/pagead/gen_204?id=sodar2&v=257"
    }

    function V(a, b, c) {
        a.url += "&" + b + "=" + encodeURIComponent(c.toString())
    }

    function Qa(a, b, c) {
        var d = new Pa(b === void 0 ? !1 : b.o),
            f = b === void 0 || b.T !== "0";
        c !== !1 && f || (d.url = d.o ? "https://ep1.adtrafficquality.google/pagead/sodar?id=sodar2&v=257" : "https://pagead2.googlesyndication.com/pagead/sodar?id=sodar2&v=257");
        V(d, "t", a);
        b && (V(d, "li", b.V), V(d, b.context === "cr" && b.R === "int" ? "bgai" : "jk", b.P));
        return d
    }

    function Ra(a) {
        return new q.Promise(function(b) {
            Na(a, function() {
                b()
            })
        })
    }

    function W(a, b, c, d) {
        b = Qa(1, b);
        V(b, "e", a);
        c && V(b, "ds", c);
        d !== void 0 && V(b, "lat", String(d));
        return Ra(b.url)
    }

    function Sa(a, b, c, d) {
        var f = Qa(2, a, b !== void 0);
        b !== void 0 ? V(f, "bg", b) : c !== void 0 && V(f, "wvpt", c);
        d !== void 0 && V(f, "lat", String(d));
        return f.url.length > 6E4 ? W(4, a) : Ra(f.url)
    };
    var X = {},
        Ta = (X["internal-error"] = -1, X["non-recoverable-error"] = -2, X["api-disabled-by-application"] = -3, X["invalid-argument"] = -4, X["token-provider-invalid"] = -5, X);

    function Ua() {
        this.H = !1
    }
    var Va;

    function Y() {
        Va || (Va = new Ua);
        return Va
    }

    function Wa(a) {
        var b;
        return N(function(c) {
            if (c.h == 1) return c.G(2), c.i(window.android.webview.getExperimentalMediaIntegrityTokenProvider({
                cloudProjectNumber: 187810013193
            }), 4);
            if (c.h != 2) return a.i = c.l, a.h = void 0, c.L(0);
            b = c.F();
            a.h = Xa(b);
            c.K()
        })
    }

    function Ya(a, b) {
        var c, d;
        return N(function(f) {
            switch (f.h) {
                case 1:
                    return Za() && a.H ? f.i(a.j, 2) : f.return();
                case 2:
                    if (!a.i) return a.h === void 0 && (a.h = 100), f.return();
                    c = {};
                    f.G(3);
                    return f.i(a.i.requestToken(b), 5);
                case 5:
                    c.aa = f.l;
                    f.L(4);
                    break;
                case 3:
                    d = f.F(), c.Z = Xa(d);
                case 4:
                    return f.return(c)
            }
        })
    }

    function Xa(a) {
        if (!a || typeof a !== "object") return -100;
        var b = a.mediaIntegrityErrorName;
        if (typeof b === "string") {
            var c;
            return (c = Ta[b]) != null ? c : -100
        }
        a = a.code;
        if (typeof a === "function") try {
            return a()
        } catch (d) {}
        return -100
    }

    function Za() {
        return window.android && window.android.webview && window.android.webview.getExperimentalMediaIntegrityTokenProvider
    };

    function $a() {
        var a = this;
        this.promise = new q.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };

    function Z(a) {
        this.config = a;
        this.v = 0;
        this.o = !1;
        this.C = !0;
        this.v = Number(this.config.v) || 0;
        this.o = a.o;
        var b;
        this.C = (b = a.C) != null ? b : !0
    }

    function ab(a) {
        return N(function(b) {
            if (b.h == 1) {
                if (bb(a)) throw 7;
                a.h = new Ba(a.config.N, a.config.M, a.C, a.v, a.o);
                return b.i(Da(a.h), 2)
            }
            return b.i(Ea(a.h), 0)
        })
    }
    Z.prototype.snapshotSync = function() {
        if (this.h) return this.h.snapshotSync()
    };

    function cb(a) {
        return N(function(b) {
            if (b.h == 1) {
                var c = b.i;
                if (bb(a)) var d = db(a);
                else a.h = new Ba(a.config.N, a.config.M, a.C, a.v, a.config.o), d = Ca(a.h);
                return c.call(b, d, 2)
            }
            a.l = b.l;
            return a.l ? b.i(Sa(a.config, a.l), 0) : b.A(0)
        })
    }

    function eb(a) {
        var b, c, d;
        return N(function(f) {
            switch (f.h) {
                case 1:
                    if (!Y().H) return f.return();
                    b = Date.now();
                    return f.i(Ya(Y(), a.config.P), 2);
                case 2:
                    if (c = f.l) {
                        f.A(3);
                        break
                    }
                    Y();
                    if (Za() === void 0) {
                        f.A(4);
                        break
                    }
                    return f.i(W(17, a.config, "ftpe=" + String(Y().h)), 4);
                case 4:
                    return f.return();
                case 3:
                    return d = Date.now() - b, c.aa ? f.i(Sa(a.config, void 0, c.aa, d), 0) : c.Z ? f.i(W(16, a.config, "ftpe=" + String(Y().h) + ",ptb=" + String(c.Z), d), 0) : f.i(W(18, a.config, "ftpe=" + String(Y().h), d), 0)
            }
        })
    }

    function fb(a, b) {
        function c(g) {
            g && g.data !== null && g.origin === "https://www.google.com" && g.source != null && g.source === b.contentWindow && (a.i = "id=sodar2&v=257", a.config && (a.i += "&li=" + encodeURIComponent(a.config.V.toString()), a.i += "&" + (a.config.context === "cr" ? "bgai" : "jk") + "=" + encodeURIComponent(a.config.P.toString()), g.source.postMessage(JSON.stringify({
                id: "sodar",
                params: a.i
            }), "https://www.google.com"), d.removeEventListener("message", c, !1)), f.resolve())
        }
        var d = window,
            f = new $a;
        d.addEventListener("message",
            c, !1);
        return f.promise
    }

    function gb(a) {
        var b, c, d, f;
        return N(function(g) {
            if (g.h == 1) {
                if (a.config.U !== "y") return g.return();
                b = window.document.createElement("iframe");
                c = wa(ta, b);
                d = fb(a, b);
                return g.i(q.Promise.all([c, d]), 2)
            }
            f = g.l;
            if (f[0].contentWindow === null) throw 15;
            g.K()
        })
    }

    function hb(a) {
        return N(function(b) {
            return b.i(v(q.Promise, "allSettled").call(q.Promise, [cb(a), gb(a), eb(a)]), 0)
        })
    }

    function bb(a) {
        return !(a.config.ba || window.location.host === (a.o ? "ep2.adtrafficquality.google" : "tpc.googlesyndication.com") || a.config.R === "int")
    }

    function db(a) {
        var b, c, d;
        return N(function(f) {
            if (f.h == 1) return b = Q((a.o ? "https://ep2.adtrafficquality.google/sodar/" : "https://tpc.googlesyndication.com/sodar/") + "sodar2/257/runner.html"), f.i(wa(b), 2);
            if (f.h != 4) {
                c = f.l;
                if (!c.contentWindow) throw 3;
                var g = c.contentWindow;
                var e = a.o;
                g = window.hasOwnProperty("MessageChannel") ? new Ja(g, e) : new Ma(g, e);
                a.j = g;
                if (a.j.h) {
                    g = a.config;
                    e = g.o ? "https://ep2.adtrafficquality.google" : "https://tpc.googlesyndication.com";
                    e = e.indexOf("https:") === -1 ? "http:" + e : e;
                    var h = a.j.i,
                        l = h.postMessage,
                        n, r = g.U === void 0 ? "n" : g.U,
                        F = g.v === void 0 ? "0" : g.v,
                        t = g.T === void 0 ? "1" : g.T,
                        w = g.o === void 0 ? "0" : g.o ? "1" : "0",
                        D = g.ba ? "1" : "0",
                        E = ((n = g.C) != null ? n : 1) ? "1" : "0";
                    n = JSON.stringify([g.context, g.N, g.M, g.V, g.P, g.R, r, F, t, w, D, E]);
                    l.call(h, n, e);
                    return f.return(void 0)
                }
                return f.i(La(a.j, {
                    ha: a.config.N,
                    W: a.config.M,
                    v: a.v,
                    o: a.config.o
                }), 4)
            }
            d = f.l;
            c.parentNode && c.parentNode.removeChild(c);
            if (d.error) throw d.error;
            return f.return(d.response)
        })
    };

    function ib() {
        Z.apply(this, arguments)
    }
    A(ib, Z);
    ib.prototype.init = function() {
        var a = this,
            b;
        return N(function(c) {
            if (c.h == 1) {
                if (a.config.R === "env") return c.i(hb(a), 0);
                b = window;
                return Object.prototype.hasOwnProperty.call(b, "GoogleA13IjpGc") ? c.return() : c.i(ab(a), 4)
            }
            try {
                Object.defineProperty(b, "GoogleA13IjpGc", {
                    value: a,
                    writable: !1,
                    configurable: !1
                })
            } catch (d) {
                b.GoogleA13IjpGc = a
            }
            return c.A(0)
        })
    };

    function jb() {
        Z.apply(this, arguments)
    }
    A(jb, Z);
    jb.prototype.init = function() {
        var a = this;
        return N(function(b) {
            return b.i(hb(a), 0)
        })
    };

    function kb(a, b) {
        if (typeof a === "number") b = W(a, b);
        else {
            var c = Qa(3, b);
            V(c, "c", "init");
            var d = a.toString();
            a.name && d.indexOf(a.name) == -1 && (d += ": " + a.name);
            a.message && d.indexOf(a.message) == -1 && (d += ": " + a.message);
            if (a.stack) a: {
                a = a.stack;
                var f = d;
                try {
                    a.indexOf(f) == -1 && (a = f + "\n" + a);
                    for (var g; a != g;) g = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    d = a.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (e) {
                    d = f;
                    break a
                }
                d = void 0
            }
            V(c, "ex", d);
            b = c.url.length > 6E4 ? W(11, b) : Ra(c.url)
        }
        return b
    }

    function lb(a) {
        if (a.H === !0) {
            Y().H = !0;
            var b = Y();
            Za() && b.H && (b.j = Wa(b))
        }
        switch (a.context) {
            case "pt":
                a = new jb(a);
                break;
            case "cr":
                a = new ib(a);
                break;
            default:
                throw 2;
        }
        if (!window.postMessage && bb(a)) throw 8;
        return a.init()
    };
    (function() {
        var a = Ga();
        try {
            return a ? lb(a) : q.Promise.race([Ha(), new q.Promise(function(b, c) {
                setTimeout(function() {
                    c(Ia())
                }, 5E3)
            })]).then(function() {
                a = Ga();
                if (!a) throw Ia();
                return lb(a)
            }, function(b) {
                return kb(b, a)
            })
        } catch (b) {
            return kb(b, a)
        }
    })();
}).call(this);
(function() {
    var aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        g = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ba = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        ca = ba(this),
        k = function(a, b) {
            if (b) a: {
                var c = ca;a = a.split(".");
                for (var e = 0; e < a.length - 1; e++) {
                    var d = a[e];
                    if (!(d in c)) break a;
                    c = c[d]
                }
                a = a[a.length - 1];e = c[a];b = b(e);b != e && b != null && g(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        },
        m;
    if (typeof Object.setPrototypeOf == "function") m = Object.setPrototypeOf;
    else {
        var da;
        a: {
            var ea = {
                    a: !0
                },
                fa = {};
            try {
                fa.__proto__ = ea;
                da = fa.a;
                break a
            } catch (a) {}
            da = !1
        }
        m = da ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ha = m,
        ia = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (ha) ha(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var e = Object.getOwnPropertyDescriptor(b, c);
                            e && Object.defineProperty(a, c, e)
                        } else a[c] = b[c];
            a.D = b.prototype
        },
        ja = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        r = function(a) {
            return q(a, a)
        },
        q = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        ka = function() {
            for (var a = Number(this),
                    b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    k("globalThis", function(a) {
        return a || ca
    });
    k("Symbol", function(a) {
        if (a) return a;
        var b = function(h, f) {
            this.h = h;
            g(this, "description", {
                configurable: !0,
                writable: !0,
                value: f
            })
        };
        b.prototype.toString = function() {
            return this.h
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            e = 0,
            d = function(h) {
                if (this instanceof d) throw new TypeError("Symbol is not a constructor");
                return new b(c + (h || "") + "_" + e++, h)
            };
        return d
    });
    k("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        g(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return la(ja(this))
            }
        });
        return a
    });
    var la = function(a) {
        var b = (typeof Iterator != "undefined" && Iterator.prototype && !Iterator.prototype.next ? Iterator.prototype : null) || Object.prototype,
            c = aa(b);
        c.next = a;
        b[Symbol.iterator] || (c[Symbol.iterator] = function() {
            return this
        });
        return c
    };
    k("Array.from", function(a) {
        return a ? a : function(b, c, e) {
            c = c != null ? c : function(l) {
                return l
            };
            var d = [],
                h = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof h == "function") {
                b = h.call(b);
                for (var f = 0; !(h = b.next()).done;) d.push(c.call(e, h.value, f++))
            } else
                for (h = b.length, f = 0; f < h; f++) d.push(c.call(e, b[f], f));
            return d
        }
    });
    k("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                e;
            for (e in b) Object.prototype.hasOwnProperty.call(b, e) && c.push([e, b[e]]);
            return c
        }
    });
    k("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    k("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    k("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    var ma = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            e = !1;
        return la(function() {
            if (!e && c < a.length) {
                var d = c++;
                return {
                    value: b(d, a[d]),
                    done: !1
                }
            }
            e = !0;
            return {
                done: !0,
                value: void 0
            }
        })
    };
    k("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ma(this, function(b, c) {
                return [b, c]
            })
        }
    });
    k("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                e;
            for (e in b) Object.prototype.hasOwnProperty.call(b, e) && c.push(b[e]);
            return c
        }
    });
    k("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    k("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ma(this, function(b, c) {
                return c
            })
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var u = this || self,
        na = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var e = u, d = 0; d < c.length; d++)
                    if (e = e[c[d]], e == null) {
                        c = null;
                        break a
                    }
                c = e
            }
            a = c && c[a];
            return a != null ? a : b
        };
    var oa = na(610401301, !1),
        pa = na(748402147, !0);
    var ra = typeof u.BigInt === "function" && typeof u.BigInt(0) === "bigint";
    var sa = Number.MIN_SAFE_INTEGER.toString(),
        ta = ra ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        ua = Number.MAX_SAFE_INTEGER.toString(),
        va = ra ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function wa(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var e = a[c],
                d = b[c];
            if (e > d) return !1;
            if (e < d) return !0
        }
    };

    function xa(a) {
        u.setTimeout(function() {
            throw a;
        }, 0)
    };

    function v() {
        var a = u.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var w, ya = u.navigator;
    w = ya ? ya.userAgentData || null : null;

    function za(a) {
        if (!oa || !w) return !1;
        for (var b = 0; b < w.brands.length; b++) {
            var c = w.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function z(a) {
        return v().indexOf(a) != -1
    };

    function A() {
        return oa ? !!w && w.brands.length > 0 : !1
    }

    function Aa() {
        return A() ? !1 : z("Opera")
    }

    function Ba() {
        return z("Firefox") || z("FxiOS")
    }

    function Ca() {
        return A() ? za("Chromium") : (z("Chrome") || z("CriOS")) && !(A() ? 0 : z("Edge")) || z("Silk")
    };

    function B() {
        return oa ? !!w && !!w.platform : !1
    }

    function Da() {
        return z("iPhone") && !z("iPod") && !z("iPad")
    }

    function Ea() {
        Da() || z("iPad") || z("iPod")
    };
    Aa();
    A() || z("Trident") || z("MSIE");
    z("Edge");
    !z("Gecko") || v().toLowerCase().indexOf("webkit") != -1 && !z("Edge") || z("Trident") || z("MSIE") || z("Edge");
    v().toLowerCase().indexOf("webkit") != -1 && !z("Edge") && z("Mobile");
    B() || z("Macintosh");
    B() || z("Windows");
    (B() ? w.platform === "Linux" : z("Linux")) || B() || z("CrOS");
    B() || z("Android");
    Da();
    z("iPad");
    z("iPod");
    Ea();
    v().toLowerCase().indexOf("kaios");
    Ba();
    Da() || z("iPod");
    z("iPad");
    !z("Android") || Ca() || Ba() || Aa() || z("Silk");
    Ca();
    !z("Safari") || Ca() || (A() ? 0 : z("Coast")) || Aa() || (A() ? 0 : z("Edge")) || (A() ? za("Microsoft Edge") : z("Edg/")) || (A() ? za("Opera") : z("OPR")) || Ba() || z("Silk") || z("Android") || Ea();
    var Fa = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Ga(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Ha = Ga("jas", void 0, !0),
        Ia = Ga(void 0, "0actk"),
        Ja = Ga("m_m", "C", !0);
    var Ka = {
            B: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        La = Object.defineProperties,
        C = Fa ? Ha : "B",
        Ma, Na = [];
    D(Na, 7);
    Ma = Object.freeze(Na);

    function Oa(a, b) {
        Fa || C in a || La(a, Ka);
        a[C] |= b
    }

    function D(a, b) {
        Fa || C in a || La(a, Ka);
        a[C] = b
    };
    var Pa = {};

    function Qa(a, b) {
        return b === void 0 ? a.h !== E && !!(2 & (a.i[C] | 0)) : !!(2 & b) && a.h !== E
    }
    var E = {};

    function Ra(a) {
        return a
    };
    var Sa = void 0;

    function Ta(a) {
        if (typeof a !== "boolean") {
            var b = Error;
            var c = typeof a;
            c = c != "object" ? c : a ? Array.isArray(a) ? "array" : c : "null";
            throw b("Expected boolean but got " + c + ": " + a);
        }
        return a
    };

    function Ua(a, b, c, e) {
        var d = e !== void 0;
        e = !!e;
        var h = [],
            f = a.length,
            l = 4294967295,
            n = !1,
            x = !!(b & 64),
            t = x ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var p = f && a[f - 1];
            p != null && typeof p === "object" && p.constructor === Object ? (f--, l = f) : p = void 0;
            if (x && !(b & 128) && !d) {
                n = !0;
                var y;
                l = ((y = Va) != null ? y : Ra)(l - t, t, a, p, void 0) + t
            }
        }
        b = void 0;
        for (d = 0; d < f; d++)
            if (y = a[d], y != null && (y = c(y, e)) != null)
                if (x && d >= l) {
                    var Ub = d - t,
                        ab = void 0;
                    ((ab = b) != null ? ab : b = {})[Ub] = y
                } else h[d] = y;
        if (p)
            for (var qa in p) a = p[qa], a != null && (a = c(a, e)) != null && (f = +qa, d = void 0, x && !Number.isNaN(f) &&
                (d = f + t) < l ? h[d] = a : (f = void 0, ((f = b) != null ? f : b = {})[qa] = a));
        b && (n ? h.push(b) : h[l] = b);
        return h
    }

    function Wa(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return (ra ? a >= ta && a <= va : a[0] === "-" ? wa(a, sa) : wa(a, ua)) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    var b = a[C] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Ua(a, b, Wa)
                }
                if (a != null && a[Ja] === Pa) return Xa(a);
                return
        }
        return a
    }
    var Va;

    function Xa(a) {
        a = a.i;
        return Ua(a, a[C] | 0, Wa)
    };

    function Ya(a, b, c, e) {
        e = e === void 0 ? 0 : e;
        if (a == null) {
            var d = 32;
            c ? (a = [c], d |= 128) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            d = a[C] | 0;
            if (pa && 1 & d) throw Error("rfarr");
            2048 & d && !(2 & d) && Za();
            if (d & 256) throw Error("farr");
            if (d & 64) return (d | e) !== d && D(a, d | e), a;
            if (c && (d |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;d |= 64;
                var h = c.length;
                if (h) {
                    var f = h - 1,
                        l = c[f];
                    if (l != null && typeof l === "object" && l.constructor === Object) {
                        b = d & 128 ? 0 : -1;
                        f -= b;
                        if (f >= 1024) throw Error("pvtlmt");
                        for (var n in l) h = +n, h < f && (c[h + b] = l[n], delete l[n]);
                        d = d & -16760833 | (f & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    n = Math.max(b, h - (d & 128 ? 0 : -1));
                    if (n > 1024) throw Error("spvt");
                    d = d & -16760833 | (n & 1023) << 14
                }
            }
        }
        D(a, d | 64 | e);
        return a
    }

    function Za() {
        if (pa) throw Error("carr");
        if (Ia != null) {
            var a;
            var b = (a = Sa) != null ? a : Sa = {};
            a = b[Ia] || 0;
            a >= 5 || (b[Ia] = a + 1, b = Error(), b.__closure__error__context__984382 || (b.__closure__error__context__984382 = {}), b.__closure__error__context__984382.severity = "incident", xa(b))
        }
    };

    function $a(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[C] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = F(a, c, !1, b && !(c & 16)) : (Oa(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[Ja] === Pa) return b = a.i, c = b[C] | 0, Qa(a, c) ? a : bb(a, b, c) ? cb(a, b) : F(b, c)
    }

    function cb(a, b, c) {
        a = new a.constructor(b);
        c && (a.h = E);
        a.A = E;
        return a
    }

    function F(a, b, c, e) {
        e != null || (e = !!(34 & b));
        a = Ua(a, b, $a, e);
        e = 32;
        c && (e |= 2);
        b = b & 16769217 | e;
        D(a, b);
        return a
    }

    function db(a) {
        if (a.h === E) {
            var b = a.i;
            b = F(b, b[C] | 0);
            Oa(b, 2048);
            a.i = b;
            a.h = void 0;
            a.A = void 0;
            b = !0
        } else b = !1;
        if (!b && Qa(a, a.i[C] | 0)) throw Error();
    }

    function bb(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (D(b, c | 2), a.h = E, !0) : !1
    };
    var fb = function(a, b, c) {
        db(a);
        var e = a.i;
        eb(e, e[C] | 0, b, c);
        return a
    };

    function eb(a, b, c, e) {
        var d = c + -1,
            h = a.length - 1;
        if (h >= 0 && d >= h) {
            var f = a[h];
            if (f != null && typeof f === "object" && f.constructor === Object) return f[c] = e, b
        }
        if (d <= h) return a[d] = e, b;
        if (e !== void 0) {
            var l;
            h = ((l = b) != null ? l : b = a[C] | 0) >> 14 & 1023 || 536870912;
            c >= h ? e != null && (d = {}, a[h + -1] = (d[c] = e, d)) : a[d] = e
        }
        return b
    }
    var G = function(a, b, c) {
        if (c != null && typeof c !== "string") throw Error();
        return fb(a, b, c)
    };
    var H = function(a, b, c) {
        this.i = Ya(a, b, c, 2048)
    };
    H.prototype.toJSON = function() {
        return Xa(this)
    };
    H.prototype.clone = function() {
        var a = this.i,
            b = a[C] | 0;
        return bb(this, a, b) ? cb(this, a, !0) : new this.constructor(F(a, b, !1))
    };
    H.prototype[Ja] = Pa;
    H.prototype.toString = function() {
        return this.i.toString()
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var gb = globalThis.trustedTypes,
        hb;

    function ib() {
        var a = null;
        if (!gb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = gb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function jb() {
        hb === void 0 && (hb = ib());
        return hb
    };
    var kb = function(a) {
        this.h = a
    };
    kb.prototype.toString = function() {
        return this.h + ""
    };

    function I(a) {
        var b = jb();
        a = b ? b.createScriptURL(a) : a;
        return new kb(a)
    }

    function J(a) {
        if (a instanceof kb) return a.h;
        throw Error("");
    };
    var lb = r([""]),
        mb = q(["\x00"], ["\\0"]),
        nb = q(["\n"], ["\\n"]),
        ob = q(["\x00"], ["\\u0000"]);

    function K(a) {
        return a.toString().indexOf("`") === -1
    }
    K(function(a) {
        return a(lb)
    }) || K(function(a) {
        return a(mb)
    }) || K(function(a) {
        return a(nb)
    }) || K(function(a) {
        return a(ob)
    });
    var qb = function() {
        this.h = pb
    };
    qb.prototype.toString = function() {
        return this.h + ""
    };

    function rb(a) {
        return v().indexOf(a) != -1
    }
    var sb = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }(function() {
        var a = Math.random;
        return ["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"].some(rb) || a() < 1E-4
    });

    function tb() {
        if (!globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function ub(a) {
        var b = a.split(/[?#]/),
            c = /[?]/.test(a) ? "?" + b[1] : "";
        return {
            o: b[0],
            v: c,
            fragment: /[#]/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    }

    function vb(a) {
        var b = ka.apply(1, arguments);
        if (b.length === 0) return I(a[0]);
        for (var c = a[0], e = 0; e < b.length; e++) c += encodeURIComponent(b[e]) + a[e + 1];
        return I(c)
    }

    function wb() {
        function a(f, l) {
            f != null && (Array.isArray(f) ? f.forEach(function(n) {
                return a(n, l)
            }) : (c += h + encodeURIComponent(l) + "=" + encodeURIComponent(f), h = "&"))
        }
        var b = xb.o,
            c = xb.v,
            e = xb.fragment,
            d = {
                rxp: "107x108"
            },
            h = c.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(function(f) {
            return a(f[1], f[0])
        }) : d.forEach(a);
        return I(b + c + e)
    };
    var yb = function(a, b) {
        if (!sb()) {
            var c = Math.random();
            if (c < b) return c = tb(), a[Math.floor(c * a.length)]
        }
        return null
    };
    var zb = function(a) {
        this.i = Ya(a, void 0, void 0, 2048)
    };
    ia(zb, H);
    var Ab = function(a) {
        this.i = Ya(a, void 0, void 0, 2048)
    };
    ia(Ab, H);
    var Bb = function(a, b) {
            return G(a, 2, b)
        },
        Cb = function(a, b) {
            return G(a, 3, b)
        },
        Db = function(a, b) {
            return G(a, 4, b)
        },
        Eb = function(a, b) {
            return G(a, 5, b)
        },
        Fb = function(a, b) {
            return G(a, 9, b)
        },
        Gb = function(a, b) {
            var c = b;
            db(a);
            b = a.i;
            var e = b[C] | 0;
            if (c == null) eb(b, e, 10);
            else {
                for (var d = c === Ma ? 7 : c[C] | 0, h = d, f = !!(2 & d) && !!(4 & d) || !!(256 & d), l = f || Object.isFrozen(c), n = !0, x = !0, t = 0; t < c.length; t++) {
                    var p = c[t];
                    f || (p = Qa(p), n && (n = !p), x && (x = p))
                }
                f || (d = n ? 13 : 5, d = x ? d & -4097 : d | 4096);
                l && d === h || (c = Array.prototype.slice.call(c), h = 0, d = (2 & e ? d | 2 : d &
                    -3) & -273);
                d !== h && D(c, d);
                e = eb(b, e, 10, c);
                2 & d || !(4096 & d || 16 & d) || (c = e, c === void 0 && (c = b[C] | 0), c & 32 && !(c & 4096) && D(b, c | 4096))
            }
            return a
        },
        Hb = function(a, b) {
            return fb(a, 11, b == null ? b : Ta(b))
        },
        Ib = function(a, b) {
            return G(a, 1, b)
        },
        Jb = function(a, b) {
            return fb(a, 7, b == null ? b : Ta(b))
        };
    var Kb = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Lb() {
        var a;
        return (a = u.google_tag_data) != null ? a : u.google_tag_data = {}
    }

    function Mb() {
        var a, b;
        return typeof((a = u.navigator) == null ? void 0 : (b = a.userAgentData) == null ? void 0 : b.getHighEntropyValues) === "function"
    }

    function Nb() {
        if (!Mb()) return null;
        var a = Lb();
        if (a.uach_promise) return a.uach_promise;
        var b = u.navigator.userAgentData.getHighEntropyValues(Kb).then(function(c) {
            a.uach != null || (a.uach = c);
            return c
        });
        return a.uach_promise = b
    }

    function Ob(a) {
        var b;
        return Hb(Gb(Eb(Bb(Ib(Db(Jb(Fb(Cb(new Ab, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var e = new zb;
            e = G(e, 1, c.brand);
            return G(e, 2, c.version)
        })) || []), a.wow64 || !1)
    };
    var Pb = function(a) {
            try {
                for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                    case "https:":
                        return !0;
                    case "file:":
                        return !0;
                    case "http:":
                        return !1
                }
            } catch (c) {}
            return !0
        }(u) ? "https:" : "http:",
        Qb = {},
        Rb = (Qb[1] = "A4A26Ymj79UVY7C7JGUS4BG1s7MdcDokAQf/RP0paks+RoTYbXHxceT/5L4iKcsleFCngi75YfNRGW2+SpVv1ggAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", Qb);
    var L = [],
        Sb = function(a) {
            this.id = a.id;
            this.j = a.j;
            this.l = a.l;
            L.push(this)
        },
        Tb = new Sb({
            id: 1,
            j: {
                u: "40004000",
                m: "40004001"
            },
            l: 1
        }),
        M = new Sb({
            id: 4,
            j: {
                u: "40004006",
                m: "40004007"
            },
            l: 4
        }),
        Vb = new Sb({
            id: 5,
            j: {
                u: "40004008",
                m: "40004009"
            },
            l: 4
        });

    function Wb() {
        var a = {};
        a[Tb.id] = .5;
        a[M.id] = .02;
        a[Vb.id] = .001;
        return a
    }

    function Xb() {
        var a = Yb,
            b = typeof a;
        if ((b != "object" || a == null) && b != "function") return !1;
        if (b = typeof Symbol != "undefined" && Symbol.iterator && L[Symbol.iterator]) b = b.call(L);
        else if (typeof L.length == "number") b = {
            next: ja(L)
        };
        else throw Error(String(L) + " is not an iterable or ArrayLike");
        var c = b.next();
        try {
            for (; !c.done; c = b.next()) {
                var e = a[c.value.id];
                if (typeof e !== "number" || e < 0 || e > 1) return !1
            }
        } finally {
            var d;
            c && !c.done && (d = b["return"]) && d.call(b)
        }
        return !0
    };
    var Zb = r(["https://www.googletagservices.com/dcm/"]),
        $b = r(["http://www.googletagservices.com/dcm/"]),
        ac = r(["./"]),
        bc = vb(Zb),
        cc = vb($b);
    vb(ac);

    function dc() {
        if (!u.dcmads.uach) {
            var a = Nb();
            a && (u.dcmads.uachp = a.then(function(b) {
                b.bitness && (b.bitness = String(b.bitness));
                var c = u.dcmads;
                b = Ob(b);
                b = JSON.stringify(Xa(b));
                c.uach = b
            }))
        }
    };
    try {
        u.dcmads = u.dcmads || {};
        u.dcmads.startTime = (new Date).getTime();
        var ec = u.dcmads,
            N = u.dcmads.version,
            O = {
                loader: 319
            };
        if (N)
            if (O.experiment = N.experiment, N.number == 107 || N.number == "p") O.number = 107;
            else if (N.number == 108 || N.number == "c") O.number = 108;
        if (!O.number) {
            var fc = yb([107, 108], .2);
            O.experiment = !!fc;
            O.number = fc || 107
        }
        ec.version = O;
        var hc = u.dcmads,
            ic, Yb = u.dcmads.expts,
            P;
        P = P === void 0 ? Wb : P;
        ic = Xb() ? Yb : P();
        hc.expts = ic;
        var jc = u.dcmads,
            kc;
        var lc = u.dcmads;
        if (lc.eids != null) kc = lc.eids;
        else {
            var mc = [],
                nc = u.navigator;
            if (nc.connection && nc.connection.saveData) {
                var oc = yb(Object.values(M.j), lc.expts[M.id]);
                oc && mc.push(M.l + "|" + oc)
            }
            kc = mc.join(",")
        }
        jc.eids = kc;
        u.dcmads.ots = Rb;
        dc();
        var pc = new RegExp("4\\|" + M.j.m),
            qc = u.dcmads.version,
            rc = qc.number,
            sc, tc = u.document,
            uc = tc.currentScript || Array.from(tc.getElementsByTagName("script")).pop();
        sc = (uc && uc.src || "").indexOf("http:") == 0 ? "http:" : "https:";
        var Q, vc = "impl_v" + rc + ".js",
            R = ub(J(sc === "http:" ? cc : bc).toString()),
            wc = R.o.slice(-1) === "/" ? "" : "/",
            xc = R.o + wc + encodeURIComponent(vc);
        Q =
            I(xc + R.v + R.fragment);
        if (qc.experiment && rc == 107) {
            var xb = ub(J(Q).toString());
            Q = wb()
        }
        var yc = Q;
        if (pc.test(u.dcmads.eids)) {
            var zc = u.document,
                S, T = zc;
            T = T === void 0 ? document : T;
            S = T.createElement("script");
            S.src = J(yc);
            var Ac, U = S.ownerDocument;
            U = U === void 0 ? document : U;
            var Bc, Cc, Dc = (Cc = (Bc = U).querySelector) == null ? void 0 : Cc.call(Bc, "script[nonce]");
            (Ac = Dc == null ? "" : Dc.nonce || Dc.getAttribute("nonce") || "") && S.setAttribute("nonce", Ac);
            var V = zc.getElementsByTagName("script")[0];
            V && V.parentNode && V.parentNode.insertBefore(S,
                V)
        } else {
            var Ec = u.document,
                Fc, Gc = '<script src="' + J(yc).toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;") + '">\x3c/script>',
                Hc = jb(),
                pb = Hc ? Hc.createHTML(Gc) : Gc;
            Fc = new qb;
            var Ic = Ec.write,
                Jc;
            if (Fc instanceof qb) Jc = Fc.h;
            else throw Error("");
            Ic.call(Ec, Jc)
        }
    } catch (a) {
        if (Math.random() < .01) {
            var Kc = "";
            try {
                var W, X = a,
                    Y = X.toString();
                X.name && Y.indexOf(X.name) == -1 && (Y += ": " + X.name);
                X.message && Y.indexOf(X.message) == -1 && (Y += ": " + X.message);
                if (X.stack) a: {
                    var Z =
                        X.stack,
                        Lc = Y;
                    try {
                        Z.indexOf(Lc) == -1 && (Z = Lc + "\n" + Z);
                        for (var Mc; Z != Mc;) Mc = Z, Z = Z.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                        Y = Z.replace(RegExp("\n *", "g"), "\n");
                        break a
                    } catch (b) {
                        Y = Lc;
                        break a
                    }
                    Y = void 0
                }
                W = Y;
                W = W.substring(0, 1024);
                Kc = encodeURIComponent(W)
            } catch (b) {
                Kc = "extr"
            }
            var Nc = u.dcmads.eids,
                Oc = document.createElement("img");
            Oc.src = Pb + "//pagead2.googlesyndication.com/pagead/gen_204?id=dcmads-err&ver=319&context=554" + ((Nc ? "&eids=" + Nc : "") + "&msg=" + Kc);
            (u.google_image_requests = u.google_image_requests || []).push(Oc)
        }
    };
}).call(this);
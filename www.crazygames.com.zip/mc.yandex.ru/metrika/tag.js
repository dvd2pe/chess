(function() {
    var aa;

    function ba(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    var ca = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function da(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var fa = da(this);

    function ha(a, b) {
        if (b) a: {
            for (var c = fa, d = a.split("."), e = 0; e < d.length - 1; e++) {
                var f = d[e];
                if (!(f in c)) break a;
                c = c[f]
            }
            d = d[d.length - 1];e = c[d];f = b(e);f != e && null != f && ca(c, d, {
                configurable: !0,
                writable: !0,
                value: f
            })
        }
    }
    ha("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.xd = f;
            ca(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.xd
        };
        var d = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            e = 0;
        return b
    });
    ha("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = fa[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ca(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ia(ba(this))
                }
            })
        }
        return a
    });

    function ia(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    }

    function n(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: ba(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function ja(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    }

    function ka(a) {
        return a instanceof Array ? a : ja(n(a))
    }
    var la = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ma;
    if ("function" == typeof Object.setPrototypeOf) ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var qa = ma;

    function ra(a, b) {
        a.prototype = la(b.prototype);
        a.prototype.constructor = a;
        if (qa) qa(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Ve = b.prototype
    }

    function sa() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    var ta = {
            construct: "Metrika2",
            callbackPostfix: "2",
            version: "4tvkupd2vg89dwekd16jpvfdqys7vf",
            host: "mc.yandex.com"
        },
        ua = {
            206555165: 1,
            655012937: 1,
            1269618038: 1,
            1676263684: 1
        };

    function r() {}
    var va = [];

    function wa(a, b) {
        if (!b || "function" !== typeof b) return !1;
        try {
            var c = "" + b
        } catch (h) {
            return !1
        }
        var d = c.length;
        if (d > 35 + a.length) return !1;
        for (var e = d - 13, f = 0, g = 8; g < d; g += 1) {
            f = "[native code]" [f] === c[g] || 7 === f && "-" === c[g] ? f + 1 : 0;
            if (12 === f) return !0;
            if (!f && g > e) break
        }
        return !1
    }

    function xa(a, b) {
        var c = wa(a, b);
        b && !c && va.push([a, b]);
        return c
    }

    function ya(a, b) {
        return xa(b, a) && a
    }
    var za = /\./g;

    function u(a) {
        return "string" === typeof a
    }
    var Aa = ya(String.prototype.indexOf, "indexOf");

    function Ba(a, b) {
        for (var c = 0, d = a.length - b.length, e = 0; e < a.length; e += 1) {
            c = a[e] === b[c] ? c + 1 : 0;
            if (c === b.length) return e - b.length + 1;
            if (!c && e > d) break
        }
        return -1
    }
    var Ca = Aa ? function(a, b) {
        return Aa.call(a, b)
    } : Ba;

    function Da(a, b) {
        return Ca(a, b)
    }
    var Ea = ya(String.prototype.lastIndexOf, "lastIndexOf");

    function Fa(a, b) {
        var c = b.length,
            d = a.length;
        if (0 === c) return d;
        for (d -= c; 0 <= d; --d) {
            for (var e = !0, f = 0; f < c; f += 1)
                if (a[d + f] !== b[f]) {
                    e = !1;
                    break
                }
            if (e) return d
        }
        return -1
    }
    var Ga = Ea ? function(a, b) {
        return Ea.call(a, b)
    } : Fa;

    function Ha(a, b) {
        return Ga(a, b)
    }

    function Ia(a, b) {
        return !(!a || -1 === Ca(a, b))
    }

    function Ja(a) {
        return "" + a
    }

    function Ka(a) {
        return a.replace(/\^/g, "\\^").replace(/\$/g, "\\$").replace(za, "\\.").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\|/g, "\\|").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/\?/g, "\\?").replace(/\*/g, "\\*").replace(/\+/g, "\\+").replace(/\{/g, "\\{").replace(/\}/g, "\\}")
    }

    function La(a) {
        return "[object Array]" === Object.prototype.toString.call(a)
    }
    var Ma = ya(Array.isArray, "isArray"),
        w = Ma ? function(a) {
            return Ma(a)
        } : La;

    function Na(a) {
        return function(b) {
            return function(c) {
                return a(b, c)
            }
        }
    }

    function Oa(a) {
        return function(b) {
            return function(c) {
                return a(c, b)
            }
        }
    }
    var Pa = Na(function(a, b) {
            return a === b
        }),
        Qa = Na(function(a, b) {
            a(b);
            return b
        }),
        Ra = Na(function(a, b) {
            return b(a)
        }),
        Sa = Pa(null);

    function y(a) {
        return "function" === typeof a
    }
    var z = Pa(void 0);

    function A(a) {
        return z(a) || Sa(a)
    }

    function B(a) {
        return !Sa(a) && !z(a) && "[object Object]" === Object.prototype.toString.call(a)
    }
    var Ta = ya(Array.from, "from");

    function Ua(a) {
        for (var b = a.length, c = [], d = 0; d < b; d += 1) c.push(a[d]);
        return c
    }

    function Va(a) {
        if (Ta) try {
            return Ta(a)
        } catch (b) {}
        return Ua(a)
    }

    function Wa(a, b, c) {
        b = void 0 === b ? [] : b;
        c = c || {};
        var d = b.length,
            e = a;
        y(e) && (e = "d", c[e] = a);
        var f;
        d ? 1 === d ? f = c[e](b[0]) : 2 === d ? f = c[e](b[0], b[1]) : 3 === d ? f = c[e](b[0], b[1], b[2]) : 4 === d && (f = c[e](b[0], b[1], b[2], b[3])) : f = c[e]();
        return f
    }
    var Xa = ya(Function.prototype.bind, "bind");

    function Ya() {
        var a = n(arguments),
            b = a.next().value,
            c = a.next().value,
            d = ja(a);
        return function() {
            var e = [].concat(ka(d), ka(arguments));
            if (Function.prototype.call) return Function.prototype.call.apply(b, [c].concat(e));
            if (c) {
                for (var f = "_b"; c[f];) f += "_" + f.length;
                c[f] = b;
                e = c[f] && Wa(f, e, c);
                delete c[f];
                return e
            }
            return Wa(b, e)
        }
    }
    var D = Xa ? function() {
        var a = Va(arguments),
            b = n(a);
        a = b.next().value;
        var c = b.next().value;
        b = ja(b);
        return Xa.apply(a, [c].concat(b))
    } : Ya;

    function F(a, b) {
        return D.apply(null, [b, null].concat(ka(a)))
    }

    function G(a, b) {
        return D(b, null, a)
    }

    function Za(a, b) {
        return D(b[a], b)
    }

    function $a(a) {
        return Za("test", a)
    }
    var ab = ya(Array.prototype.reduce, "reduce");

    function bb(a, b, c) {
        for (var d = 0, e = c.length; d < e;) b = a(b, c[d], d), d += 1;
        return b
    }
    var H = ab ? function(a, b, c) {
        return ab.call(c, a, b)
    } : bb;

    function cb(a, b) {
        return F([a, b], H)
    }
    var db = Object.prototype.hasOwnProperty;

    function I(a, b) {
        return A(a) ? !1 : db.call(a, b)
    }

    function J(a, b) {
        if (!a) return null;
        var c = b.split("."),
            d = c.length,
            e = a,
            f = 0;
        try {
            for (; f < d;) {
                if (null === e || void 0 === e) return e;
                e = e[c[f]];
                f += 1
            }
        } catch (g) {
            return null
        }
        return e
    }
    var K = Oa(J),
        eb = K("length");

    function fb(a) {
        var b = void 0 === b ? {} : b;
        if (!a || 1 > a.length) return b;
        H(function(c, d, e) {
            if (e === a.length - 1) return c;
            e === a.length - 2 ? c[d] = a[e + 1] : I(c, d) || (c[d] = {});
            return c[d]
        }, b, a);
        return b
    }

    function gb(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (b[c] === a) return c;
        return -1
    }
    var hb;

    function ib(a) {
        if (hb) return hb;
        var b = !1;
        try {
            b = [].indexOf && 0 === [void 0].indexOf(void 0)
        } catch (d) {}
        var c = a.Array && a.Array.prototype && ya(a.Array.prototype.indexOf, "indexOf");
        return hb = a = b && c ? function(d, e) {
            return c.call(e, d)
        } : gb
    }
    var jb = ib(window),
        kb = Oa(jb);

    function lb(a) {
        return a
    }

    function mb(a, b) {
        return b
    }

    function nb(a) {
        return !a
    }

    function L(a, b) {
        var c = [],
            d = [];
        var e = b ? b : lb;
        return function() {
            var f = Va(arguments),
                g = e.apply(null, ka(f)),
                h = jb(g, d);
            if (-1 !== h) return c[h];
            f = a.apply(null, ka(f));
            c.push(f);
            d.push(g);
            return f
        }
    }
    var ob = L(function(a) {
        a = J(a, "navigator") || {};
        var b = J(a, "userAgent") || "";
        return {
            Jc: -1 < Ca(J(a, "vendor") || "", "Apple"),
            ud: b
        }
    });

    function pb(a, b) {
        return -1 !== (J(b, "navigator.userAgent") || "").toLowerCase().search(a)
    }
    var qb = L(K("navigator.userAgent"));

    function rb(a, b) {
        return a.isFinite(b) && !a.isNaN(b) && "[object Number]" === Object.prototype.toString.call(b)
    }

    function sb(a) {
        try {
            return parseInt(a, 10)
        } catch (b) {
            return null
        }
    }
    var tb = Oa(parseInt),
        ub = tb(10),
        vb = tb(2),
        wb = /Firefox\/([0-9]+)/i,
        xb = L(function(a) {
            var b = J(a, "document.documentElement.style"),
                c = J(a, "InstallTrigger");
            a = pb(wb, a);
            wb.lastIndex = 0;
            return !(!(b && "MozAppearance" in b) || A(c)) || a
        });

    function yb(a) {
        return xb(a) ? (a = qb(a).match(wb)) && a.length ? ub(a[1]) : 1 : 0
    }

    function zb(a, b) {
        var c = J(b, a),
            d = J(b, "constructor.prototype." + a) || c;
        try {
            if (d && d.apply) return function() {
                return d.apply(b, arguments)
            }
        } catch (e) {
            return c
        }
        return d
    }

    function Ab() {
        var a = Array.prototype.map;
        if (!xb(window)) return !0;
        try {
            a.call({
                0: !0,
                length: -Math.pow(2, 32) + 1
            }, function() {
                throw 1;
            })
        } catch (b) {
            return !1
        }
        return !0
    }
    var Bb = ya(Array.prototype.map, "map");

    function Cb(a, b) {
        return H(function(c, d, e) {
            c.push(a(d, e));
            return c
        }, [], b)
    }
    var M = Bb && Ab() ? function(a, b) {
            return b && 0 < b.length ? Bb.call(b, a) : []
        } : Cb,
        Db = ya(Array.prototype.flatMap, "flatMap");

    function Eb(a, b) {
        return H(function(c, d, e) {
            d = a(d, e);
            return c.concat(w(d) ? d : [d])
        }, [], b)
    }
    var Fb = Db ? function(a, b) {
            return Db.call(b, a)
        } : Eb,
        Gb = Na(M),
        Hb = Na(M),
        Ib = Oa(M);

    function N() {
        var a = arguments,
            b = a[0];
        return function() {
            for (var c = b.apply(null, arguments), d = a.length, e = 1; e < d;) c = a[e](c), e += 1;
            return c
        }
    }
    var Jb = Na(F);

    function Kb(a, b, c) {
        return c ? a : b
    }
    var Lb = F([1, null], Kb),
        Mb = F([1, 0], Kb),
        Nb = Boolean,
        Ob = ya(Array.prototype.filter, "filter");

    function Pb(a, b) {
        return bb(function(c, d, e) {
            a(d, e) && c.push(d);
            return c
        }, [], b)
    }
    var Qb = Ob ? function(a, b) {
            return Ob.call(b, a)
        } : Pb,
        Rb = G(Nb, Qb),
        Sb = Na(Qb),
        Tb = ya(Array.prototype.includes, "includes");

    function Ub(a, b) {
        return 1 <= Pb(Pa(a), b).length
    }
    var O = Tb ? function(a, b, c) {
            return Tb.call(b, a, c)
        } : Ub,
        Vb = Oa(O),
        Wb = ya(Array.prototype.every, "every");

    function Xb(a, b) {
        return H(function(c, d, e) {
            return c ? !!a(d, e) : !1
        }, !0, b)
    }
    var Yb = Wb ? function(a, b) {
        return Wb.call(b, a)
    } : Xb;

    function Zb(a, b) {
        return Sa(b) || z(b) || rb(a, b) || u(b) || !!b === b
    }
    var $b = ya(Object.keys, "keys");

    function ac(a) {
        var b = [],
            c;
        for (c in a) I(a, c) && b.push(c);
        return b
    }
    var bc = ya(Object.entries, "entries");

    function cc(a) {
        return z(a) ? [] : bb(function(b, c) {
            b.push([c, a[c]]);
            return b
        }, [], ac(a))
    }
    var dc = bc ? function(a) {
            return a ? bc(a) : []
        } : cc,
        ec = $b ? function(a) {
            return $b(a)
        } : ac,
        fc = ya(Object.values, "values"),
        gc = N(cc, G(K("1"), Cb)),
        hc = fc ? function(a) {
            return fc(a)
        } : gc;

    function ic() {
        var a = Va(arguments),
            b = n(a);
        a = b.next().value;
        for (b = ja(b); b.length;) {
            var c = b.shift(),
                d;
            for (d in c) I(c, d) && (a[d] = c[d]);
            I(c, "toString") && (a.toString = c.toString)
        }
        return a
    }
    var P = Object.assign || ic,
        jc = Na(function(a, b) {
            return P({}, a, b)
        });

    function kc(a) {
        var b = this;
        this.W = [];
        this.size = 0;
        a && M(function(c) {
            b.add(c)
        }, a)
    }
    aa = kc.prototype;
    aa.add = function(a) {
        -1 === jb(a, this.W) && (this.W.push(a), this.size = this.W.length);
        return this
    };
    aa.has = function(a) {
        return -1 !== jb(a, this.W)
    };
    aa["delete"] = function(a) {
        a = jb(a, this.W);
        if (-1 === a) return !1;
        this.W.splice(a, 1);
        this.size = this.W.length;
        return !0
    };
    aa.clear = function() {
        this.W = [];
        this.size = 0
    };
    aa.forEach = function(a) {
        var b = this;
        M(function(c) {
            a(c, c, b)
        }, this.W)
    };

    function lc(a) {
        var b = [];
        a.forEach(function(c) {
            b.push(c)
        });
        return b
    }

    function mc(a) {
        if (!a) return [];
        if (w(a)) return a;
        if (a instanceof kc) return a.W.slice();
        if (Ta) try {
            return Ta(a)
        } catch (b) {}
        return "number" === typeof a.size && y(a.add) ? lc(a) : "number" === typeof a.length && 0 <= a.length ? Ua(a) : []
    }
    var nc = L(ib),
        oc = K("0");

    function pc(a) {
        return a.splice(0, a.length)
    }
    var qc = ya(Array.prototype.some, "some");

    function rc(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (c in b && a.call(b, b[c], c)) return !0;
        return !1
    }
    var sc = qc ? function(a, b) {
            return qc.call(b, a)
        } : rc,
        tc = L(N(K("String.fromCharCode"), G("fromCharCode", xa), nb)),
        uc = L(N(qb, $a(/ipad|iphone|ipod/i))),
        vc = L(function(a) {
            return J(a, "navigator.platform") || ""
        }),
        wc = L(function(a) {
            a = ob(a);
            var b = a.ud;
            return a.Jc && !b.match("CriOS")
        }),
        xc = $a(/Android.*Version\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]|Android.*Version\/[0-9][0-9.]*\s(?:Mobile\s)?Safari\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]*|; wv\).*Chrome\/[0-9][0-9.]*\sMobile/),
        yc = $a(/; wv\)/),
        zc = L(function(a) {
            a = qb(a);
            return yc(a) ||
                xc(a)
        }),
        Ac = /Chrome\/(\d+)\./,
        Bc = L(function(a) {
            return (a = (J(a, "navigator.userAgent") || "").match(Ac)) && a.length ? 76 <= ub(a[1]) : !1
        }),
        Cc = L(function(a) {
            a = (qb(a) || "").toLowerCase();
            return Ia(a, "android") && Ia(a, "mobile")
        }),
        Dc = "other none unknown wifi ethernet bluetooth cellular wimax mixed".split(" "),
        Ec = L(function(a) {
            var b = J(a, "navigator.connection.type");
            if (z(b)) return null;
            a = nc(a)(b, Dc);
            return -1 === a ? b : "" + a
        }),
        Fc = L(N(K("document.addEventListener"), nb)),
        Gc = L(function(a) {
            var b = J(a, "navigator") || {};
            return H(function(c,
                d) {
                return c || J(b, d)
            }, "", ["language", "userLanguage", "browserLanguage", "systemLanguage"])
        }),
        Hc = L(function(a) {
            var b = J(a, "navigator") || {};
            a = Gc(a);
            u(a) || (a = "", b = J(b, "languages.0"), u(b) && (a = b));
            return a.toLowerCase().split("-")[0]
        }),
        Ic = L(function(a) {
            return (J(a, "top") || a) !== a
        }),
        Jc = L(K("top.contentWindow")),
        Kc = L(function(a) {
            var b = !1;
            try {
                b = a.navigator.javaEnabled()
            } catch (c) {}
            return b
        }),
        Lc = L(function(a) {
            var b = "__webdriver_evaluate __selenium_evaluate __webdriver_script_function __webdriver_script_func __webdriver_script_fn __fxdriver_evaluate __driver_unwrapped __webdriver_unwrapped __driver_evaluate __selenium_unwrapped __fxdriver_unwrapped".split(" "),
                c = J(a, "external");
            c = -1 !== Ca(J(c, "toString") ? "" + c.toString() : "", "Sequentum");
            var d = J(a, "document.documentElement"),
                e = ["selenium", "webdriver", "driver"];
            return !!(sc(G(a, J), ["_selenium", "callSelenium", "_Selenium_IDE_Recorder"]) || sc(G(J(a, "document"), J), b) || c || d && sc(D(d.getAttribute, d), e))
        }),
        Mc = L(function(a) {
            return !!(sc(G(a, J), ["_phantom", "__nightmare", "callPhantom"]) || /(PhantomJS)|(HeadlessChrome)/.test(qb(a)) || J(a, "navigator.webdriver") || J(a, "isChrome") && !J(a, "chrome"))
        }),
        Nc = L(function(a) {
            return !(!J(a,
                "ia_document.shareURL") || !J(a, "ia_document.referrer"))
        });

    function Oc(a) {
        return J(a, "document.prerendering") || "prerender" === J(a, "document.webkitVisibilityState") || "prerender" === J(a, "document.visibilityState")
    }
    var Pc = L(function(a) {
            var b = qb(a) || "",
                c = b.match(/Mac OS X ([0-9]+)_([0-9]+)/);
            c = c ? [+c[1], +c[2]] : [0, 0];
            b = b.match(/iPhone OS ([1-9]+)_([0-9]+)/);
            return 14 <= (b ? +b[1] : 0) ? !0 : (uc(a) || 10 < c[0] || 10 === c[0] && 13 <= c[1]) && wc(a)
        }),
        Qc = /Edg\/(\d+)\./;

    function Rc(a) {
        return (a = qb(a)) && (a = a.match(Qc)) && 1 < a.length ? 79 <= ub(a[1]) : !1
    }
    var Sc = L(function(a) {
            return Pc(a) || 68 <= yb(a) || Rc(a)
        }),
        Tc = L(function(a) {
            a = !(!a.addEventListener || !a.removeEventListener);
            return {
                ve: a,
                C: a ? "addEventListener" : "attachEvent",
                qa: a ? "removeEventListener" : "detachEvent"
            }
        });

    function Uc(a, b, c, d, e, f) {
        a = Tc(a);
        var g = a.C,
            h = a.qa;
        f = f ? h : g;
        if (b[f])
            if (a.ve)
                if (e) b[f](c, d, e);
                else b[f](c, d);
        else b[f]("on" + c, d)
    }
    var Vc = L(function(a) {
            var b = !1;
            if (!a.addEventListener) return b;
            try {
                var c = Object.defineProperty({}, "passive", {
                    get: function() {
                        b = !0;
                        return 1
                    }
                });
                a.addEventListener("test", r, c)
            } catch (d) {}
            return b
        }),
        Wc = Na(function(a, b) {
            if (null !== b) return a ? P({
                capture: !0,
                passive: !0
            }, b || {}) : !!b
        }),
        Xc = L(function(a) {
            var b = Vc(a),
                c = Wc(b),
                d = {};
            return P(d, {
                C: function(e, f, g, h) {
                    M(function(k) {
                        var l = c(h);
                        Uc(a, e, k, g, l, !1)
                    }, f);
                    return D(d.ua, d, e, f, g, h)
                },
                ua: function(e, f, g, h) {
                    M(function(k) {
                        var l = c(h);
                        Uc(a, e, k, g, l, !0)
                    }, f)
                }
            })
        }),
        Yc = ["webkitvisibilitychange",
            "visibilitychange", "prerenderingchange"
        ];

    function Zc(a) {
        return {
            K: function(b, c) {
                var d = a.document,
                    e = b.G;
                if (e && Oc(a)) {
                    var f = Xc(a),
                        g = function(h) {
                            Oc(a) || (f.ua(d, Yc, g), c());
                            return h
                        };
                    f.C(d, Yc, g);
                    e.B("pr", "1")
                } else c()
            }
        }
    }

    function $c(a, b) {
        M(N(lb, Za("push", a)), b);
        return a
    }

    function ad(a) {
        a = a.Ya = a.Ya || {};
        var b = a._metrika = a._metrika || {};
        return {
            V: function(c, d) {
                I(b, c) || (b[c] = d);
                return this
            },
            B: function(c, d) {
                b[c] = d;
                return this
            },
            o: function(c, d) {
                var e = b[c];
                return I(b, c) || z(d) ? e : d
            }
        }
    }
    var Q = L(ad);

    function bd(a, b, c) {
        return function() {
            var d = Q(arguments[0]),
                e = c ? "global" : "m2710",
                f = d.o(e, {}),
                g = J(f, a);
            g || (g = L(b), f[a] = g, d.B(e, f));
            return g.apply(null, arguments)
        }
    }
    var R = L(function(a) {
            return a.id + ":" + a.M
        }),
        cd = Vb([26812653]),
        dd = L(N(K("id"), cd), R),
        ed = "hash host hostname href pathname port protocol search".split(" ");

    function T(a) {
        return H(function(b, c) {
            var d = J(a, "location." + c);
            b[c] = d ? "" + d : "";
            return b
        }, {}, ed)
    }
    var fd = "ru by kz az kg lv md tj tm uz ee fr lt com co.il com.ge com.am com.tr com.ru".split(" "),
        gd = /(?:^|\.)(?:(ya\.ru)|(?:yandex)\.(\w+|com?\.\w+))$/;

    function hd(a) {
        if (a = a.match(gd)) {
            var b = n(a);
            b.next();
            a = b.next().value;
            if (b = b.next().value) return O(b, fd) ? b : !1;
            if (a) return fd[0]
        }
        return !1
    }
    var id = L(function(a) {
            return (a ? a.replace(/^www\./, "") : "").toLowerCase()
        }),
        jd = L(function(a) {
            a = T(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(gd));
            return b
        }),
        kd = N(T, K("protocol"), Pa("https:")),
        ld = L(function(a) {
            return Bc(a) && kd(a) ? "SameSite=None;Secure;" : ""
        });

    function md(a, b) {
        for (var c = "", d = 0; d < b.length; d += 1) c += "" + (d ? a : "") + b[d];
        return c
    }
    var nd = ya(Array.prototype.join, "join"),
        U = nd ? function(a, b) {
            return nd.call(b, a)
        } : md,
        od = Na(U);

    function pd(a) {
        try {
            return encodeURIComponent(a)
        } catch (b) {}
        a = U("", Qb(function(b) {
            return 55296 >= b.charCodeAt(0)
        }, a.split("")));
        return encodeURIComponent(a)
    }

    function qd(a) {
        var b = "";
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    }

    function rd(a) {
        return a ? N(Gb(function(b) {
            var c = n(b.split("="));
            b = c.next().value;
            c = c.next().value;
            return [b, A(c) ? void 0 : qd(c)]
        }), cb(function(b, c) {
            var d = n(c),
                e = d.next().value;
            d = d.next().value;
            b[e] = d;
            return b
        }, {}))(a.split("&")) : {}
    }

    function sd(a) {
        return a ? N(dc, cb(function(b, c) {
            var d = n(c),
                e = d.next().value;
            d = d.next().value;
            z(d) || A(d) || b.push(e + "=" + pd(d));
            return b
        }, []), od("&"))(a) : ""
    }
    var td = /^\s+|\s+$/g,
        ud = ya(String.prototype.trim, "trim");

    function vd(a, b) {
        if (a) {
            var c = ud ? ud.call(a) : ("" + a).replace(td, "");
            return b && c.length > b ? c.substring(0, b) : c
        }
        return ""
    }
    var wd = Na(function(a, b) {
            return b.replace(a, "")
        }),
        xd = wd(/\s/g),
        yd = wd(/\D/g),
        zd = wd(/\d/g),
        Ad = ["metrika_enabled"],
        Bd = [];

    function Cd(a, b) {
        var c = Dd;
        return !Bd.length || O(b, Ad) ? !0 : H(function(d, e) {
            return d && e(a, c, b)
        }, !0, Bd)
    }

    function Ed(a) {
        try {
            var b = a.document.cookie;
            if (!A(b)) {
                var c = {};
                M(function(d) {
                    var e = n(d.split("="));
                    d = e.next().value;
                    e = e.next().value;
                    d = vd(d);
                    e = vd(qd(e));
                    if (I(c, d)) {
                        var f = c[d];
                        w(f) ? f.push(e) : c[d] = [f, e]
                    } else c[d] = e
                }, (b || "").split(";"));
                return c
            }
        } catch (d) {}
        return null
    }
    var Fd = bd("gsc", Ed);

    function Dd(a, b, c) {
        a = Fd(a);
        if (!a || !I(a, b)) return null;
        b = a[b];
        if (!w(b)) return c ? [b] : b;
        if (c) return b;
        c = b[b.length - 1];
        return A(c) ? null : c
    }
    var Gd = /:\d+$/;

    function Hd(a, b, c, d, e, f, g) {
        g = void 0 === g ? !1 : g;
        if (Cd(a, b)) {
            c = b + "=" + encodeURIComponent(c) + ";";
            c += "" + ld(a);
            if (d) {
                var h = new Date;
                h.setTime(h.getTime() + 6E4 * d);
                c += "expires=" + h.toUTCString() + ";"
            }
            e && (d = e.replace(Gd, ""), c += "domain=" + d + ";");
            try {
                if (a.document.cookie = c + ("path=" + (f || "/")), !g) {
                    var k = Fd(a);
                    if (k) {
                        var l = Ed(a);
                        l && (I(l, b) ? k[b] = l[b] : delete k[b])
                    }
                }
            } catch (m) {}
        }
    }
    var Id = L(function(a) {
        var b = (T(a).host || "").split(".");
        return 1 === b.length ? b[0] : H(function(c, d, e) {
            e += 1;
            2 <= e && !c && (e = U(".", b.slice(-e)), Hd(a, "metrika_enabled", "1", 0, e, void 0, !0), (d = (d = Ed(a)) && d.metrika_enabled) && Hd(a, "metrika_enabled", "", -100, e, void 0, !0), d && (c = e));
            return c
        }, "", b)
    });

    function Jd(a, b, c) {
        b = void 0 === b ? "_ym_" : b;
        c = void 0 === c ? "" : c;
        var d = Id(a),
            e = 1 === (d || "").split(".").length ? d : "." + d,
            f = c ? "_" + c : "";
        return {
            wa: function(g, h, k) {
                Hd(a, "" + b + g + f, "", -100, h || e, k, !1);
                return this
            },
            o: function(g, h) {
                return Dd(a, "" + b + g + f, h)
            },
            B: function(g, h, k, l, m) {
                Hd(a, "" + b + g + f, h, k, l || e, m);
                return this
            }
        }
    }
    var Kd = L(Jd),
        Ld = L(function(a) {
            var b = Kd(a),
                c = "1" === b.o("debug"),
                d = -1 < Da(T(a).href, "_ym_debug=1") || -1 < Da(T(a).href, "_ym_debug=2"),
                e = a._ym_debug;
            !e && !d || c || (a = T(a), b.B("debug", "1", void 0, a.host));
            return !!(c || e || d)
        });

    function Md() {
        return {}
    }

    function Nd() {
        return []
    }
    var Od = bd("debuggerEvents", Nd, !0);

    function Pd(a, b) {
        if (Ld(a)) {
            var c = b.counterKey;
            if (c) {
                var d = n(c.split(":"));
                c = d.next().value;
                d = d.next().value;
                c = cd(sb(c));
                if ("1" === d || c) return
            }
            c = Od(a);
            1E3 === c.length && c.shift();
            c.push(b)
        }
    }
    var Qd = ta.construct,
        Rd = ta.host,
        Sd = ["http.0.st..rt.", "network error occurred", "send beacon", "Content Security Policy", "DOM Exception 18"];

    function Td(a) {
        throw a;
    }
    var Ud;

    function Vd(a) {
        this.message = a
    }
    var Wd = function(a) {
        return function(b, c) {
            c = void 0 === c ? !1 : c;
            if (Ud) var d = new Ud(b);
            else xa("Error", a.Error) ? (Ud = a.Error, d = new a.Error(b)) : (Ud = Vd, d = new Ud(b));
            c && (d.unk = !0);
            return d
        }
    }(window);

    function Xd(a) {
        return Wd("http." + a.status + ".st." + a.statusText + ".rt." + ("" + a.responseText).substring(0, 50))
    }
    var Yd = $a(RegExp("^http."));

    function Zd(a) {
        var b = "";
        w(a) ? b = U(".", a) : u(a) && (b = a);
        return Wd("err.kn(2710)" + b)
    }

    function $d() {
        var a = Va(arguments);
        Td(Zd(a))
    }
    var ae = $a(RegExp("^err.kn"));

    function be(a, b) {
        return b ? a(b) : a()
    }
    var ce = N(lb, be),
        de = [];

    function ee(a, b, c) {
        var d = "u.a.e",
            e = "";
        c && ("object" === typeof c ? (c.unk && Td(c), d = c.message, e = "string" === typeof c.stack && c.stack.replace(/\n/g, "\\n") || "n.s.e.s") : d = "" + c);
        ae(d) || sc(G(d, Ia), Sd) || Yd(d) && .1 <= a.Math.random() || M(N(lb, Jb(["jserrs", d, b, e]), be), de)
    }

    function fe(a) {
        return J(a, "performance") || J(a, "webkitPerformance")
    }

    function ge(a) {
        a = fe(a);
        var b = J(a, "timing.navigationStart"),
            c = J(a, "now");
        c && (c = D(c, a));
        return [b, c]
    }

    function he(a, b) {
        var c = n(b || ge(a)),
            d = c.next().value;
        c = c.next().value;
        return !isNaN(d) && y(c) ? Math.round(c() + d) : a.Date.now ? a.Date.now() : (new a.Date).getTime()
    }

    function ie() {
        var a = [];
        return {
            Ke: a,
            push: function() {
                var b = a.push.apply(a, ka(sa.apply(0, arguments)));
                100 < a.length && a.splice(0, a.length - 100);
                return b
            },
            flush: function() {
                return a.splice(0, a.length)
            },
            slice: function(b, c) {
                return a.slice(b, c)
            }
        }
    }
    var je = ie();

    function V(a, b, c, d) {
        var e = c || Td;
        return function() {
            var f = d;
            try {
                f = e.apply(null, arguments)
            } catch (g) {
                ee(a, b, g)
            }
            return f
        }
    }

    function W(a, b, c) {
        return function() {
            return V(arguments[0], a, b, c).apply(this, arguments)
        }
    }
    var ke = Na(function(a, b) {
            var c = b || {};
            return {
                l: G(c, lb),
                o: function(d, e) {
                    var f = c[d];
                    return z(f) && !z(e) ? e : f
                },
                B: function(d, e) {
                    c[d] = e;
                    return this
                },
                wb: function(d, e) {
                    return "" === e || A(e) ? this : this.B(d, e)
                },
                ra: G(c, a)
            }
        }),
        le = ke(function(a) {
            a = dc(a);
            return U("", M(function(b) {
                var c = n(b);
                b = c.next().value;
                c = c.next().value;
                return Sa(c) ? "" : b + "(" + c + ")"
            }, a))
        });

    function me(a, b, c) {
        c = void 0 === c ? null : c;
        a.ba || (a.ba = le());
        b && a.ba.wb(b, c);
        return a.ba
    }
    var ne = "A B BIG BODY BUTTON DD DIV DL DT EM FIELDSET FORM H1 H2 H3 H4 H5 H6 HR I IMG INPUT LI OL P PRE SELECT SMALL SPAN STRONG SUB SUP TABLE TBODY TD TEXTAREA TFOOT TH THEAD TR U UL ABBR AREA BLOCKQUOTE CAPTION CENTER CITE CODE CANVAS DFN EMBED FONT INS KBD LEGEND LABEL MAP OBJECT Q S SAMP STRIKE TT ARTICLE AUDIO ASIDE FOOTER HEADER MENU METER NAV PROGRESS SECTION TIME VIDEO NOINDEX NOBR MAIN svg circle clippath ellipse defs foreignobject g glyph glyphref image line lineargradient marker mask path pattern polygon polyline radialgradient rect set text textpath title".split(" "),
        oe = [],
        pe = /^\s*(data|javascript):/i,
        qe = new RegExp(U("", ["\\.(" + U("|", "3gp 7z aac ac3 acs ai avi ape apk asf bmp bz2 cab cdr crc32 css csv cue divx dmg djvu? doc(x|m|b)? emf eps exe flac? flv iso swf gif t?gz jpe?g? js m3u8? m4a mp(3|4|e?g?) m4v md5 mkv mov msi ods og(g|m|v) psd rar rss rtf sea sfv sit sha1 svg tar tif?f torrent ts txt vob wave? wma wmv wmf webm ppt(x|m|b)? xls(x|m|b)? pdf phps png xpi g?zip".split(" ")) + ")$"]), "i"),
        re = {},
        se = (re.hit = "h", re.params = "p", re.reachGoal = "g", re.userParams = "up",
            re.trackHash = "th", re.accurateTrackBounce = "atb", re.notBounce = "nb", re.addFileExtension = "fe", re.extLink = "el", re.file = "fc", re.trackLinks = "tl", re.destruct = "d", re.setUserID = "ui", re.getClientID = "ci", re.clickmap = "cm", re),
        te = Pa("1");

    function ue(a, b, c, d) {
        var e = {};
        return B(a) ? a : (e.id = a, e.type = c, e.defer = d, e.params = b, e)
    }

    function ve(a) {
        return H(function(b, c) {
            var d = n(c),
                e = d.next().value,
                f = d.next().value;
            d = f.rb;
            f = a[f.T];
            b[e] = d ? d(f) : f;
            return b
        }, {}, dc(we))
    }
    var xe = N(R, L(function() {
            var a = 0;
            return function() {
                return a += 1
            }
        }), be),
        ye = {
            mc: function(a) {
                a = ad(a).o("mt", {});
                a = dc(a);
                return a.length ? H(function(b, c, d) {
                    var e = n(c);
                    c = e.next().value;
                    e = e.next().value;
                    return "" + b + (d ? "-" : "") + c + "-" + e
                }, "", a) : null
            },
            clc: function(a) {
                var b = Q(a).o("cls", {
                        fb: 0,
                        x: 0,
                        y: 0
                    }),
                    c = b.fb,
                    d = b.x;
                b = b.y;
                return c ? c + "-" + a.Math.floor(d / c) + "-" + a.Math.floor(b / c) : c + "-" + d + "-" + b
            },
            rqnt: function(a, b, c) {
                a = c.D;
                return !a || a.nohit ? null : xe(b)
            }
        };

    function ze(a, b) {
        if (!b) return null;
        try {
            return a.JSON.parse(b)
        } catch (c) {
            return null
        }
    }

    function Ae(a, b) {
        try {
            return a.JSON.stringify(b, null, void 0)
        } catch (c) {
            return null
        }
    }

    function Be(a) {
        try {
            return a.localStorage
        } catch (b) {}
        return null
    }

    function Ce(a, b) {
        var c = Be(a);
        try {
            c.removeItem(b)
        } catch (d) {}
    }

    function De(a, b) {
        var c = Be(a);
        try {
            return ze(a, c.getItem(b))
        } catch (d) {}
        return null
    }

    function Ee(a, b, c) {
        var d = Be(a);
        a = Ae(a, c);
        if (!Sa(a)) try {
            d.setItem(b, a)
        } catch (e) {}
    }
    var Fe = L(function(a) {
        Ee(a, "_ymBRC", "1");
        var b = "1" !== De(a, "_ymBRC");
        b || Ce(a, "_ymBRC");
        return b
    });

    function Ge(a, b, c) {
        var d = "" + (void 0 === c ? "_ym" : c) + (void 0 === b ? "" : b);
        d && (d += "_");
        return {
            Lb: Fe(a),
            o: function(e, f) {
                var g = De(a, "" + d + e);
                return Sa(g) && !z(f) ? f : g
            },
            B: function(e, f) {
                Ee(a, "" + d + e, f);
                return this
            },
            wa: function(e) {
                Ce(a, "" + d + e);
                return this
            }
        }
    }
    var He = L(Ge),
        Ie = L(Ge, function(a, b, c) {
            return "" + b + c
        }),
        Je = ya(Array.prototype.find, "find");

    function Ke(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (a.call(b, b[c], c)) return b[c]
    }
    var Le = Je ? function(a, b) {
        return Je.call(b, a)
    } : Ke;

    function Me(a) {
        if (A(a)) return !1;
        a = a.nodeType;
        return 3 === a || 8 === a
    }

    function Ne(a) {
        return a ? a.innerText || "" : ""
    }
    var Oe = L(function(a) {
            a = J(a, "document") || {};
            return ("" + (a.characterSet || a.charset || "")).toLowerCase()
        }),
        Pe = L(N(K("document"), G("createElement", zb)));

    function Qe(a) {
        var b = a && a.parentNode;
        b && b.removeChild(a)
    }

    function Re(a, b) {
        var c;
        try {
            if (c = b.target || b.srcElement) !c.ownerDocument && c.documentElement ? c = c.documentElement : c.ownerDocument !== a.document && (c = null)
        } catch (d) {}
        return c
    }

    function Se(a, b) {
        try {
            return (new RegExp("(?:^|\\s)" + a + "(?:\\s|$)")).test(b.className)
        } catch (c) {
            return !1
        }
    }
    var Te = L(function(a) {
        var b = J(a, "Element.prototype");
        return b ? (a = Le(function(c) {
            var d = b[c];
            return !!d && xa(c, d)
        }, ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"])) ? b[a] : null : null
    });

    function Ue(a) {
        a = J(a, "document");
        try {
            return a.getElementsByTagName("body")[0]
        } catch (b) {
            return null
        }
    }

    function Ve(a) {
        var b = J(a, "document") || {},
            c = b.documentElement;
        return "CSS1Compat" === b.compatMode ? c : Ue(a) || c
    }

    function We(a) {
        var b = J(a, "visualViewport.width"),
            c = J(a, "visualViewport.height");
        a = J(a, "visualViewport.scale");
        return A(b) || A(c) ? null : [Math.floor(b), Math.floor(c), a]
    }

    function Xe(a) {
        var b = We(a);
        if (b) {
            var c = n(b);
            b = c.next().value;
            var d = c.next().value;
            c = c.next().value;
            return [a.Math.round(b * c), a.Math.round(d * c)]
        }
        b = Ve(a);
        return [J(b, "clientWidth") || a.innerWidth, J(b, "clientHeight") || a.innerHeight]
    }

    function Ye(a) {
        var b = Ue(a),
            c = J(a, "document");
        return {
            x: a.pageXOffset || c.documentElement && c.documentElement.scrollLeft || b && b.scrollLeft || 0,
            y: a.pageYOffset || c.documentElement && c.documentElement.scrollTop || b && b.scrollTop || 0
        }
    }

    function Ze(a) {
        var b = Ve(a),
            c = n(Xe(a));
        a = c.next().value;
        c = c.next().value;
        return [Math.max(b.scrollWidth, a), Math.max(b.scrollHeight, c)]
    }

    function $e(a) {
        try {
            return a.getBoundingClientRect && a.getBoundingClientRect()
        } catch (b) {
            return a = b, "object" === typeof a && null !== a && 16389 === (a.ee && a.ee & 65535) ? {
                top: 0,
                bottom: 0,
                left: 0,
                width: 0,
                height: 0,
                right: 0
            } : null
        }
    }

    function af(a, b, c) {
        c = zb("dispatchEvent", c || a.document);
        var d = null,
            e = J(a, "Event.prototype.constructor");
        if (e && (xa("(Event|Object|constructor)", e) || Fc(a) && "[object Event]" === "" + e)) try {
            d = new a.Event(b)
        } catch (f) {
            if ((a = zb("createEvent", J(a, "document"))) && y(a)) {
                try {
                    d = a(b)
                } catch (g) {}
                d && d.initEvent && d.initEvent(b, !1, !1)
            }
        }
        d && c(d)
    }

    function bf(a) {
        if (a) try {
            var b = a.nodeName;
            if (u(b)) return b;
            b = a.tagName;
            if (u(b)) return b
        } catch (c) {}
    }
    var cf = Pa("INPUT"),
        df = N(bf, cf);

    function ef(a, b, c) {
        var d = z(c);
        z(b) && d ? (d = 1, b = 1073741824) : d ? d = 1 : (d = b, b = c);
        return a.Math.floor(a.Math.random() * (b - d)) + d
    }

    function ff(a) {
        return (10 > a ? "0" : "") + a
    }

    function gf(a) {
        var b = a.kc;
        return 0 !== b ? b : he(a.l, a.sb)
    }

    function hf(a) {
        return Math.floor(gf(a) / 1E3 / 60)
    }

    function jf(a) {
        return Math.round(gf(a) / 1E3)
    }

    function kf(a) {
        var b = n(a.sb),
            c = b.next().value;
        b = b.next().value;
        a = c && b ? b() : gf(a) - a.kb;
        return Math.round(a)
    }
    var X = L(function(a) {
            var b = Xc(a),
                c = ge(a),
                d = {
                    l: a,
                    kc: 0,
                    sb: c,
                    kb: he(a, c)
                },
                e = n(c);
            c = e.next().value;
            e = e.next().value;
            c && e || b.C(a, ["beforeunload", "unload"], function() {
                0 === d.kc && (d.kc = he(a, d.sb))
            });
            return Ra(d)
        }),
        lf = /\/$/;

    function mf(a) {
        var b = Q(a),
            c = b.o("hitId");
        c || (c = ef(a), b.B("hitId", c));
        return c
    }

    function nf(a, b) {
        var c = He(a),
            d = Kd(a),
            e = b.Qb || "uid";
        return [c.o(e), d.o(e)]
    }
    var of = bd("r", function(a, b) {
        var c = n(nf(a, b)),
            d = c.next().value;
        return !c.next().value && d
    });

    function pf(a, b) {
        return !b.Aa && of (a, b)
    }

    function qf(a, b) {
        var c = b.Qb,
            d = c || "uid";
        c = c ? a.location.hostname : void 0;
        var e = Kd(a),
            f = He(a),
            g = X(a)(jf),
            h = n(nf(a, b)),
            k = h.next().value;
        h = h.next().value;
        var l = e.o("d"); of (a, b);
        var m = !1;
        !h && k && (h = k, m = !0);
        if (!h) h = U("", [g, ef(a, 1E6, 999999999)]), m = !0;
        else if (!l || 15768E3 < g - ub(l)) m = !0;
        m && !b.Aa && (e.B(d, h, 525600, c), e.B("d", "" + g, 525600, c));
        f.B(d, h);
        return h
    }

    function rf(a, b, c) {
        return zb("setTimeout", a)(b, c)
    }

    function sf(a, b) {
        return zb("clearTimeout", a)(b)
    }

    function tf(a, b, c, d) {
        return rf(a, V(a, d + ".d.err", b), c)
    }

    function uf(a, b, c, d) {
        return a.setInterval(V(a, d + ".i.err", b), c)
    }

    function vf(a, b) {
        return a.clearInterval(b)
    }

    function wf(a, b) {
        return function(c) {
            return c(a, b)
        }
    }
    var xf = Na(function(a, b) {
        return Ra(function(c, d) {
            return b(c, function(e) {
                try {
                    a(e)(wf(c, d))
                } catch (f) {
                    c(f)
                }
            })
        })
    });

    function yf(a) {
        return Ra(function(b, c) {
            a.then(c, b)
        })
    }

    function zf(a) {
        return Ra(function(b, c) {
            c(a)
        })
    }

    function Af(a, b) {
        function c(f) {
            J(d, e) && (d.nodeType ? d.src === J(d, "contentDocument.URL") : 1) ? f() : tf(a, G(f, c), 100, b + ".wfb")
        }
        var d = void 0 === d ? a : d;
        var e = (d.nodeType ? "contentWindow." : "") + "document.body";
        return Ra(function(f, g) {
            c(g)
        })
    }

    function Bf(a) {
        var b = [],
            c = {
                ae: b
            };
        c.C = N(Za("push", b), G(c, lb));
        c.qa = N(Oa(ib(a))(b), Oa(Za("splice", b))(1), G(c, lb));
        c.trigger = N(lb, Oa(be), Ib(b));
        return c
    }

    function Cf(a, b) {
        var c = {};
        return {
            C: function(d, e) {
                M(function(f) {
                    J(c, f) || (c[f] = Bf(a));
                    c[f].C(e)
                }, d);
                return this
            },
            qa: function(d, e) {
                M(function(f) {
                    J(c, f) && c[f].qa(e)
                }, d);
                return this
            },
            trigger: function(d, e) {
                return J(c, d) ? V(a, b + ".emt." + d, c[d].trigger, [])(e) : []
            }
        }
    }
    var Df = L(function() {
            return {
                ga: {},
                pending: {},
                children: {}
            }
        }),
        Ef = K("postMessage");

    function Ff(a, b) {
        return function(c, d) {
            var e = X(a)(gf),
                f;
            if (f = a.crypto && ya(a.crypto.getRandomValues, "getRandomValues")) {
                var g = new Uint32Array(1);
                f.call(a.crypto, g);
                f = g[0] / 4294967296
            } else f = a.Math.random();
            e = {
                Cb: e,
                key: f,
                dir: 0
            };
            c.length && (e.Cb = ub(c[0]), e.key = parseFloat(c[1]), e.dir = ub(c[2]));
            P(d, b);
            f = {};
            f = (f.data = d, f.__yminfo = U(":", ["__yminfo", e.Cb, e.key, e.dir]), f);
            return {
                oa: e,
                hd: Ae(a, f) || ""
            }
        }
    }
    var Gf = W("s.f", function(a, b, c, d, e) {
        b = b(d);
        var f = Df(a),
            g = U(":", [b.oa.Cb, b.oa.key]);
        if (Ef(c)) {
            f.pending[g] = e;
            try {
                c.postMessage(b.hd, "*")
            } catch (h) {
                delete f.pending[g];
                return
            }
            tf(a, function() {
                delete f.pending[g]
            }, 5E3, "if.s")
        }
    });

    function Hf(a) {
        if (xa("MutationObserver", a.MutationObserver)) {
            var b = Df(a).children,
                c = new a.MutationObserver(function() {
                    M(function(d) {
                        J(b[d], "window.window") || delete b[d]
                    }, ec(b))
                });
            Af(a, "if.wf")(wf(r, function() {
                c.observe(a.document.body, {
                    subtree: !0,
                    childList: !0
                })
            }))
        }
    }

    function If(a, b) {
        var c = Df(a);
        b.C(["initToParent"], function(d) {
            var e = n(d);
            d = e.next().value;
            e = e.next().value;
            window.window && (c.children[e.counterId] = {
                info: e,
                window: d.source
            })
        }).C(["initToChild"], function(d) {
            var e = n(d);
            d = e.next().value;
            e = e.next().value;
            d.source === a.parent && b.trigger("parentConnect", [d, e])
        }).C(["parentConnect"], function(d) {
            var e = n(d);
            d = e.next().value;
            e = e.next().value;
            e.counterId && (c.ga[e.counterId] = {
                info: e,
                window: d.source
            })
        })
    }
    var Jf = W("s.fh", function(a, b, c, d, e, f) {
            var g = null,
                h = null,
                k = Df(a),
                l = null;
            try {
                g = ze(a, f.data), h = g.__yminfo, l = g.data
            } catch (m) {
                return
            }
            if (!A(h) && h.substring && "__yminfo" === h.substring(0, 8) && !A(l) && (a = h.split(":"), 4 === a.length))
                if (g = b.id, h = n(a), h.next(), b = h.next().value, a = h.next().value, h = h.next().value, !w(l) && l.type && "0" === h && l.counterId) {
                    if (!l.toCounter || l.toCounter == g) {
                        k = null;
                        try {
                            k = f.source
                        } catch (m) {}!Sa(k) && Ef(k) && (f = d.trigger(l.type, [f, l]), e = M(N(lb, jc(e)), f.concat([void 0])), l = c([b, a, l.counterId], e),
                            k.postMessage(l.hd, "*"))
                    }
                } else h === "" + g && w(l) && Qb(function(m) {
                    return !(!m.hid || !m.counterId)
                }, l).length === l.length && (c = k.pending[U(":", [b, a])]) && c.apply(null, [f].concat(l))
        }),
        Kf = L(function(a, b) {
            var c = zb("getElementsByTagName", J(a, "document")),
                d = Df(a),
                e = Ef(a),
                f = Cf(a, "ifc"),
                g = Xc(a);
            if (!c || !e) return null;
            c = c.call(a.document, "iframe");
            e = {};
            e = (e.counterId = b.id, e.hid = "" + mf(a), e);
            Sc(a) && (e.duid = qf(a, b));
            If(a, f);
            Hf(a);
            var h = Ff(a, e),
                k = F([a, G([], h)], Gf);
            M(function(l) {
                var m = null;
                try {
                    m = l.contentWindow
                } catch (p) {}
                m &&
                    k(m, {
                        type: "initToChild"
                    }, function(p, q) {
                        f.trigger("initToParent", [p, q])
                    })
            }, c);
            Ic(a) && k(a.parent, {
                type: "initToParent"
            }, function(l, m) {
                f.trigger("parentConnect", [l, m])
            });
            g.C(a, ["message"], F([a, b, h, f, e], Jf));
            return {
                ca: f,
                ga: d.ga,
                children: d.children,
                bc: k
            }
        }, N(mb, R)),
        Lf = L(function(a, b) {
            if (!Sc(a) || !Ic(a)) return qf(a, b);
            var c = Kf(a, b);
            return c && c.ga[b.id] ? c.ga[b.id].info.duid || qf(a, b) : qf(a, b)
        }, function(a, b) {
            return "" + b.Qb + b.Aa
        }),
        Mf = L(N(X, Ra(function(a) {
            return -(new a.l.Date).getTimezoneOffset()
        }))),
        Nf = N(X, Ra(function(a) {
            a =
                new a.l.Date;
            return U("", M(ff, [a.getFullYear(), a.getMonth() + 1, a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds()]))
        })),
        Of = N(X, Ra(jf)),
        Pf = N(X, Ra(gf)),
        Qf = L(N(X, Ra(function(a) {
            return n(a.sb).next().value
        }))),
        Rf = L(function(a) {
            a = Q(a);
            var b = a.o("counterNum", 0) + 1;
            a.B("counterNum", b);
            return b
        }, N(mb, R)),
        Sf = {},
        Tf = (Sf.vf = G(ta.version, lb), Sf.nt = Ec, Sf.fu = function(a, b, c) {
            var d = c.D;
            if (!d) return null;
            b = (J(a, "document.referrer") || "").replace(lf, "");
            c = (d["page-ref"] || "").replace(lf, "");
            d = d["page-url"];
            a = T(a).href !==
                d;
            b = b !== c;
            c = 0;
            a && b ? c = 3 : b ? c = 1 : a && (c = 2);
            return c
        }, Sf.en = Oe, Sf.la = Gc, Sf.ut = function(a, b, c) {
            var d = c.H;
            c = c.D;
            d = d && d.qb;
            c && (jd(a) || b.oc || d) && (c.ut = "noindex");
            return null
        }, Sf.v = G("2710", lb), Sf.cn = Rf, Sf.dp = function(a) {
            var b = Q(a),
                c = b.o("bt", {});
            if (z(b.o("bt"))) {
                var d = J(a, "navigator.getBattery");
                try {
                    c.p = d && d.call(a.navigator)
                } catch (e) {}
                b.B("bt", c);
                c.p && c.p.then && c.p.then(V(a, "bi:dp.p", function(e) {
                    c.De = J(e, "charging") && 0 === J(e, "chargingTime")
                }))
            }
            return Mb(c.De)
        }, Sf.ls = L(function(a, b) {
            var c = Ie(a, b.id),
                d = X(a),
                e = c.o("lsid");
            return +e ? e : (d = ef(a, 0, d(gf)), c.B("lsid", d), d)
        }, mb), Sf.hid = mf, Sf.phid = function(a, b) {
            if (!Ic(a)) return null;
            var c = Kf(a, b);
            if (!c) return null;
            var d = ec(c.ga);
            return d.length ? c.ga[d[0]].info.hid : null
        }, Sf.z = Mf, Sf.i = Nf, Sf.et = Of, Sf.etms = Pf, Sf.c = N(K("navigator.cookieEnabled"), Lb), Sf.rn = N(lb, ef), Sf.rqn = function(a, b, c) {
            c = c.D;
            if (!c || c.nohit) return null;
            b = R(b);
            a = Ie(a, b);
            b = (a.o("reqNum", 0) || 0) + 1;
            a.B("reqNum", b);
            if (a.o("reqNum") === b) return b;
            a.wa("reqNum");
            return null
        }, Sf.u = Lf, Sf.w = function(a) {
            var b =
                n(Xe(a));
            a = b.next().value;
            b = b.next().value;
            return a + "x" + b
        }, Sf.s = function(a) {
            return (a = J(a, "screen")) ? U("x", [J(a, "width"), J(a, "height"), J(a, "colorDepth") || J(a, "pixelDepth")]) : null
        }, Sf.sk = K("devicePixelRatio"), Sf.ifr = N(Ic, Lb), Sf.j = N(Kc, Lb), Sf.sti = function(a) {
            return Ic(a) && Jc(a) ? "1" : null
        }, Sf),
        Uf = L(function() {
            return $c(ec(Tf), ec(ye))
        });

    function Vf(a) {
        return function(b, c) {
            return {
                K: function(d, e) {
                    var f = d.G,
                        g = d.D;
                    f && g && M(function(h) {
                        var k = Tf[h],
                            l = "bi",
                            m = f;
                        k || (k = ye[h], l = "tel", m = me(d));
                        k && (k = W(l + ":" + h, k, null)(b, c, d), m.wb(h, k))
                    }, a || Uf());
                    e()
                }
            }
        }
    }

    function Wf(a, b) {
        return {
            K: function(c, d) {
                var e = c.G;
                if (e && (!b || b.Zc)) {
                    var f = a.document.title;
                    c.H && c.H.title && (f = c.H.title);
                    var g = zb("getElementsByTagName", a.document);
                    "string" !== typeof f && g && (f = g("title"), f = (f = J(f, "0.innerHtml")) ? f : "");
                    f = f.slice(0, Fc(a) ? 100 : 400);
                    e.B("t", f)
                }
                d()
            }
        }
    }
    var Xf = L(Md, R);

    function Yf(a, b, c) {
        if (Sc(a) && Ic(a)) {
            var d = Xf(b);
            if (!d.Xd) {
                d.Xd = !0;
                b = Kf(a, b);
                if (!b) {
                    c();
                    return
                }
                d.Y = [];
                var e = function() {
                    d.Y && (M(be, d.Y), d.Y = null)
                };
                tf(a, e, 3E3, "w.p.d.p");
                b.ca.C(["initToChild"], e)
            }
            d.Y ? d.Y.push(c) : c()
        } else c()
    }
    var Zf = L(function() {
        return {
            Gc: null,
            Y: []
        }
    }, R);

    function $f(a) {
        return (a = a.G) && a.o("pv") && !a.o("ar")
    }

    function ag(a, b, c) {
        var d = a.G;
        d ? $f(a) ? (b.Gc = d, c()) : b.Y ? b.Y.push(c) : c() : c()
    }

    function bg(a, b) {
        return {
            K: function(c, d) {
                var e = Zf(b);
                e = F([c, e, d], ag);
                Yf(a, b, e)
            },
            S: function(c, d) {
                var e = c.G,
                    f = Zf(b);
                if (e) {
                    var g = f.Y;
                    f.Gc === e && g && (M(be, g), f.Y = null)
                }
                d()
            }
        }
    }
    var cg = /^[a-z][\w.+-]+:/i;

    function dg(a, b) {
        var c = T(a),
            d = c.href,
            e = c.host,
            f = -1;
        if (!u(b) || z(b)) return d;
        c = b.replace(td, "");
        if (-1 !== c.search(cg)) return c;
        var g = c.charAt(0);
        if ("?" === g && (f = d.search(/\?/), -1 === f) || "#" === g && (f = d.search(/#/), -1 === f)) return d + c;
        if (-1 !== f) return d.substr(0, f) + c;
        if ("/" === g) {
            if (f = Ca(d, e), -1 !== f) return d.substr(0, f + e.length) + c
        } else return d = d.split("/"), d[d.length - 1] = c, U("/", d);
        return ""
    }

    function eg(a) {
        return {
            K: function(b, c) {
                var d = b.D;
                if (!b.G || !d) return c();
                var e = d["page-ref"],
                    f = d["page-url"];
                e && f !== e ? d["page-ref"] = dg(a, e) : delete d["page-ref"];
                e = Fc(a) ? 512 : 2048;
                d["page-url"] = dg(a, f).slice(0, e);
                return c()
            }
        }
    }

    function fg(a, b, c) {
        for (var d = [b, c], e = -1E4, f = 0; f < a.length; f += 1) {
            var g = n(a[f]),
                h = g.next().value;
            g = g.next().value;
            if (c === g && h === b) return;
            if (c < g && c >= e) {
                a.splice(f, 0, d);
                return
            }
            e = g
        }
        a.push(d)
    }
    var gg = [
            [eg, -100],
            [Zc, 1],
            [bg, 2],
            [Vf(), 3],
            [Wf, 4]
        ],
        hg = gg.slice(),
        ig = [],
        jg = G(gg, fg),
        kg = {},
        lg = (kg.h = hg, kg),
        Y = G(lg, function(a, b, c, d) {
            a[b] || (a[b] = []);
            c && !A(d) && fg(a[b], c, d)
        });

    function mg(a, b, c) {
        b = w(b) ? b : lg[b] || gg;
        var d = M(oc, b);
        M(function(e) {
            return d.unshift(e)
        }, ig);
        return M(N(Jb([a, c]), be), d)
    }
    var ng = [],
        og = [],
        pg = [],
        qg = [],
        rg = [],
        sg = [],
        tg = setTimeout;

    function ug() {}

    function vg(a, b) {
        return function() {
            a.apply(b, arguments)
        }
    }

    function wg(a) {
        if (!(this instanceof wg)) throw new TypeError("Promises must be constructed via new");
        if ("function" !== typeof a) throw new TypeError("not a function");
        this.ia = 0;
        this.rc = !1;
        this.va = void 0;
        this.Oa = [];
        xg(a, this)
    }

    function yg(a, b) {
        for (; 3 === a.ia;) a = a.va;
        0 === a.ia ? a.Oa.push(b) : (a.rc = !0, wg.sc(function() {
            var c = 1 === a.ia ? b.ge : b.ie;
            if (null === c)(1 === a.ia ? zg : Ag)(b.promise, a.va);
            else {
                try {
                    var d = c(a.va)
                } catch (e) {
                    Ag(b.promise, e);
                    return
                }
                zg(b.promise, d)
            }
        }))
    }

    function zg(a, b) {
        try {
            if (b === a) throw new TypeError("A promise cannot be resolved with itself.");
            if (b && ("object" === typeof b || "function" === typeof b)) {
                var c = b.then;
                if (b instanceof wg) {
                    a.ia = 3;
                    a.va = b;
                    Bg(a);
                    return
                }
                if ("function" === typeof c) {
                    xg(vg(c, b), a);
                    return
                }
            }
            a.ia = 1;
            a.va = b;
            Bg(a)
        } catch (d) {
            Ag(a, d)
        }
    }

    function Ag(a, b) {
        a.ia = 2;
        a.va = b;
        Bg(a)
    }

    function Bg(a) {
        2 === a.ia && 0 === a.Oa.length && wg.sc(function() {
            a.rc || wg.zd(a.va)
        });
        for (var b = 0, c = a.Oa.length; b < c; b++) yg(a, a.Oa[b]);
        a.Oa = null
    }

    function Cg(a, b, c) {
        this.ge = "function" === typeof a ? a : null;
        this.ie = "function" === typeof b ? b : null;
        this.promise = c
    }

    function xg(a, b) {
        var c = !1;
        try {
            a(function(d) {
                c || (c = !0, zg(b, d))
            }, function(d) {
                c || (c = !0, Ag(b, d))
            })
        } catch (d) {
            c || (c = !0, Ag(b, d))
        }
    }
    wg.prototype["catch"] = function(a) {
        return this.then(null, a)
    };
    wg.prototype.then = function(a, b) {
        var c = new this.constructor(ug);
        yg(this, new Cg(a, b, c));
        return c
    };
    wg.prototype["finally"] = function(a) {
        var b = this.constructor;
        return this.then(function(c) {
            return b.resolve(a()).then(function() {
                return c
            })
        }, function(c) {
            return b.resolve(a()).then(function() {
                return b.reject(c)
            })
        })
    };
    wg.all = function(a) {
        return new wg(function(b, c) {
            function d(h, k) {
                try {
                    if (k && ("object" === typeof k || "function" === typeof k)) {
                        var l = k.then;
                        if ("function" === typeof l) {
                            l.call(k, function(m) {
                                d(h, m)
                            }, c);
                            return
                        }
                    }
                    e[h] = k;
                    0 === --f && b(e)
                } catch (m) {
                    c(m)
                }
            }
            if (!a || "undefined" === typeof a.length) return c(new TypeError("Promise.all accepts an array"));
            var e = Array.prototype.slice.call(a);
            if (0 === e.length) return b([]);
            for (var f = e.length, g = 0; g < e.length; g++) d(g, e[g])
        })
    };
    wg.resolve = function(a) {
        return a && "object" === typeof a && a.constructor === wg ? a : new wg(function(b) {
            b(a)
        })
    };
    wg.reject = function(a) {
        return new wg(function(b, c) {
            c(a)
        })
    };
    wg.race = function(a) {
        return new wg(function(b, c) {
            if (!a || "undefined" === typeof a.length) return c(new TypeError("Promise.race accepts an array"));
            for (var d = 0, e = a.length; d < e; d++) wg.resolve(a[d]).then(b, c)
        })
    };
    wg.sc = "function" === typeof setImmediate && function(a) {
        setImmediate(a)
    } || function(a) {
        tg(a, 0)
    };
    wg.zd = function(a) {
        "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", a)
    };
    var Z = window.Promise,
        Dg = ya(Z, "Promise"),
        Eg = ya(J(Z, "resolve"), "resolve"),
        Fg = ya(J(Z, "reject"), "reject"),
        Gg = ya(J(Z, "all"), "all");
    if (Dg && Eg && Fg && Gg) {
        var Hg = function(a) {
            return new Promise(a)
        };
        Hg.resolve = D(Eg, Z);
        Hg.reject = D(Fg, Z);
        Hg.all = D(Gg, Z);
        Z = Hg
    } else Z = wg;

    function Ig(a) {
        return a.dc || a.za.length <= a.$
    }

    function Jg(a) {
        a.$ = a.za.length
    }

    function Kg(a) {
        a.dc = !0
    }

    function Mg(a) {
        a.dc = !1
    }

    function Ng(a) {
        Ig(a) && Td(Wd("i"));
        var b = a.Ob(a.za[a.$]);
        a.$ += 1;
        return b
    }
    var Og = Na(function(a, b) {
            for (var c = []; !Ig(b);) {
                var d = Ng(b);
                a(d, function(e) {
                    return e(b)
                });
                c.push(d)
            }
            return c
        }),
        Pg = Na(function(a, b) {
            for (var c; b.za.length && !Ig(b);) c = b.za.pop(), c = b.Ob(c, b.za), a(b);
            return c
        });

    function Qg(a, b) {
        return function(c) {
            var d = X(a),
                e = d(gf);
            return Pg(function(f) {
                d(gf) - e >= b && Kg(f)
            })(c)
        }
    }

    function Rg(a, b) {
        return function(c) {
            var d = X(a),
                e = d(gf);
            return Og(function(f, g) {
                d(gf) - e >= b && g(Kg)
            })(c)
        }
    }

    function Sg(a) {
        for (var b = !0, c = {}; !Ig(a) && b; c = {
                Vb: void 0
            }) b = !1, c.Vb = function() {
            b = !0;
            a.$ += 1
        }, a.Ob(a.za[a.$], function(d) {
            return function() {
                (0, d.Vb)()
            }
        }(c)), b || (a.$ += 1, c.Vb = G(a, Sg))
    }

    function Tg(a, b) {
        return Ra({
            za: a,
            Ob: b || lb,
            dc: !1,
            $: 0
        })
    }

    function Ug(a, b, c) {
        c = void 0 === c ? !1 : c;
        return new Z(function(d, e) {
            function f(k, l) {
                l();
                d()
            }
            var g = a.slice();
            g.push({
                K: f,
                S: f
            });
            var h = Tg(g, function(k, l) {
                var m = c ? k.K : k.S;
                if (m) try {
                    m(b, l)
                } catch (p) {
                    h(Jg), e(p)
                } else l()
            });
            h(Sg)
        })
    }

    function Vg(a, b, c) {
        var d = ef(a),
            e = c.N,
            f = c.O,
            g = c.Ca,
            h = c.Da;
        c = c.ab;
        var k = {},
            l = {},
            m = {};
        Pd(a, (m.name = "request", m.data = (l.url = b, l.requestId = d, l.senderParams = (k.rBody = f, k.debugStack = e, k.rHeaders = g, k.rQuery = h, k.verb = c, k), l), m));
        return d
    }
    var Wg = ke(function(a) {
        var b = "";
        a = H(function(c, d) {
            var e = n(d),
                f = e.next().value;
            e = e.next().value;
            e = "" + f + ":" + e;
            "t" === f ? b = e : c.push(e);
            return c
        }, [], dc(a));
        b && a.push(b);
        return U(":", a)
    });

    function Xg(a, b, c) {
        var d = P({}, b.D);
        a = X(a);
        b.G && (d["browser-info"] = Wg(b.G.l()).B("st", a(jf)).ra());
        !d.t && (b = b.ba) && (b.B("ti", c), d.t = b.ra());
        return d
    }

    function Yg(a, b, c, d, e, f) {
        e = void 0 === e ? 0 : e;
        f = void 0 === f ? 0 : f;
        var g = P({
                N: []
            }, d.J),
            h = n(b[f]),
            k = h.next().value;
        h = h.next().value;
        var l = c[e];
        if ((!g.Ca || !g.Ca["Content-Type"]) && g.O) {
            var m = {};
            g.Ca = P({}, g.Ca, (m["Content-Type"] = "application/x-www-form-urlencoded", m));
            g.O = "site-info=" + pd(g.O)
        }
        g.ab || (g.ab = g.O ? "POST" : "GET");
        g.Da = Xg(a, d, k);
        g.U = (d.ha || {}).U;
        g.N.push(k);
        P(d.J, g);
        k = "" + l + (d.ub && d.ub.de ? "/1" : "");
        var p = 0;
        p = Vg(a, k, g);
        return h(k, g).then(function(q) {
            var v = p,
                t = {},
                x = {};
            Pd(a, (x.name = "requestSuccess", x.data =
                (t.body = q, t.requestId = v, t), x));
            return {
                Ea: q,
                rd: e
            }
        })["catch"](function(q) {
            var v = p,
                t = {},
                x = {};
            Pd(a, (x.name = "requestFail", x.data = (t.error = q, t.requestId = v, t), x));
            v = f + 1 >= b.length;
            t = e + 1 >= c.length;
            v && t && Td(q);
            return Yg(a, b, c, d, !t && v ? e + 1 : e, v ? 0 : f + 1)
        })
    }

    function Zg(a, b) {
        return function(c, d) {
            return Yg(a, b, d, c)
        }
    }
    var $g = {
            id: "id",
            oc: "ut",
            M: "type",
            Qb: "ldc",
            Aa: "nck",
            Ga: "url",
            Hb: "referrer"
        },
        ah = /^\d+$/,
        bh = {
            id: function(a) {
                a = "" + (a || "0");
                ah.test(a) || (a = "0");
                try {
                    var b = ub(a)
                } catch (c) {
                    b = 0
                }
                return b
            },
            M: function(a) {
                return "" + (a || 0 === a ? a : "0")
            },
            Aa: Nb,
            oc: Nb
        };
    $g.Ra = "defer";
    bh.Ra = Nb;
    $g.L = "params";
    bh.L = function(a) {
        return B(a) || w(a) ? a : null
    };
    $g.nc = "userParams";
    $g.nd = "triggerEvent";
    bh.nd = Nb;
    $g.Zc = "sendTitle";
    bh.Zc = function(a) {
        return !!a || z(a)
    };
    $g.hc = "trackHash";
    bh.hc = Nb;
    $g.md = "trackLinks";
    var we = H(function(a, b) {
        var c = n(b),
            d = c.next().value;
        c = c.next().value;
        a[d] = {
            T: c,
            rb: bh[d]
        };
        return a
    }, {}, dc($g));

    function ch(a) {
        return H(function(b, c) {
            var d = n(c),
                e = d.next().value;
            d = d.next().value;
            b[we[e].T] = d;
            return b
        }, {}, dc(a))
    }
    var dh = {},
        eh = (dh.w = [
            [function(a, b) {
                return {
                    K: function(c, d) {
                        var e = c.D,
                            f = {};
                        e = (f["page-url"] = e && e["page-url"] || "", f.charset = "utf-8", f);
                        "0" !== b.M && (e["cnt-class"] = b.M);
                        c.G || (c.G = Wg());
                        f = c.G;
                        e = {
                            ha: {
                                U: "watch/" + b.id
                            },
                            J: P(void 0 === c.J ? {} : c.J, {
                                Fa: !!f.o("pv") && !f.o("wh")
                            }),
                            D: P(c.D || {}, e)
                        };
                        P(c, e);
                        d()
                    }
                }
            }, 1]
        ], dh);

    function fh(a, b, c) {
        var d = Zg(a, b);
        return function(e) {
            return Ug(c, e, !0).then(function() {
                var f = e.ha || {},
                    g = void 0 === f.Ud ? "" : f.Ud,
                    h = void 0 === f.U ? "" : f.U;
                f = M(function(k) {
                    return "https://" + ("" + g + k || Rd) + "/" + h
                }, void 0 === f.Hc ? [Rd] : f.Hc);
                return d(e, f)
            }).then(function(f) {
                var g = f.Ea;
                f = f.rd;
                e.Zb = g;
                e.Re = f;
                return Ug(c, e).then(G(g, lb))
            })
        }
    }

    function gh(a) {
        return function(b, c, d) {
            return function(e, f) {
                var g = M(N(oc, Jb([b, f]), be), eh[a] || []);
                g = $c(g, d);
                return fh(b, c, g)(e)
            }
        }
    }
    var hh = gh("w");

    function ih(a, b, c, d) {
        return new Z(function(e, f) {
            if (!J(a, "navigator.onLine")) return f();
            var g = {};
            g = P(d.Da, (g["force-urlencoded"] = 1, g));
            g = c + "?" + sd(g) + (d.O ? "&" + d.O : "");
            return 2E3 < g.length ? f(Zd("sb.tlq")) : b(g) ? e("") : f()
        })
    }

    function jh(a, b) {
        var c = Pe(a);
        if (c) {
            var d = a.document,
                e = c("script");
            b.crossOrigin && (e.crossOrigin = "anonymous");
            e.src = b.src;
            e.type = b.type || "text/javascript";
            e.charset = b.charset || "utf-8";
            e.async = b.async || !0;
            b.wc && P(e.dataset, b.wc);
            try {
                var f = d.getElementsByTagName("head")[0];
                if (!f) {
                    var g = d.getElementsByTagName("html")[0];
                    f = c("head");
                    g && g.appendChild(f)
                }
                f.insertBefore(e, f.firstChild);
                return e
            } catch (h) {}
        }
    }
    var kh = L(function(a) {
        if (a = Pe(a)) return a("a")
    });

    function lh(a, b) {
        var c = kh(a);
        return c ? (c.href = b, {
            protocol: c.protocol,
            host: c.host,
            port: c.port,
            hostname: c.hostname,
            hash: c.hash,
            search: c.search,
            query: c.search.replace(/^\?/, ""),
            pathname: c.pathname || "/",
            path: (c.pathname || "/") + c.search,
            href: c.href
        }) : {}
    }

    function mh(a) {
        return (a.split(":")[1] || "").replace(/^\/*/, "").replace(/^www\./, "").split("/")[0]
    }

    function nh(a, b) {
        if (!b || !b.length) return a;
        var c = n(a.split("#")),
            d = c.next().value;
        c = ja(c);
        c = (c = U("#", c)) ? "#" + c : "";
        return Ia(a, "?") ? d + "&" + b + c : d + "?" + b + c
    }

    function oh(a, b, c) {
        (c = sd(c)) && (a = nh(a, c));
        b.O && (a = nh(a, b.O));
        return a
    }

    function ph(a, b) {
        try {
            delete a[b]
        } catch (c) {
            a[b] = void 0
        }
    }

    function qh(a, b, c) {
        return new Z(function(d, e) {
            var f = "_ymjsp" + ef(a),
                g = {};
            g = P((g.callback = f, g), c.Da);
            var h = F([a, f], ph);
            a[f] = function(l) {
                try {
                    h(), Qe(k), d(l)
                } catch (m) {
                    e(m)
                }
            };
            g.wmode = "5";
            f = {};
            var k = jh(a, (f.src = oh(b, c, g), f));
            if (!k) return h(), e(Wd("jp.s"));
            f = G(k, Qe);
            f = N(f, G(Zd(c.N), e));
            g = rf(a, f, c.sa || 1E4);
            g = F([a, g], sf);
            k.onload = g;
            k.onerror = N(h, g, f)
        })
    }

    function rh(a, b, c, d) {
        b = b ? new b : void 0;
        var e = {};
        e = P(d.Fa ? (e.wmode = "7", e) : {}, d.Da);
        var f = b || {
                signal: void 0,
                abort: r
            },
            g = a.fetch(nh(c, sd(e)), {
                method: d.ab,
                body: d.O,
                credentials: !1 === d.qc ? "omit" : "include",
                headers: d.Ca,
                signal: f.signal,
                cache: d.cache
            }),
            h = G(d.N, Zd),
            k = G(d.N.concat("timeout"), Zd);
        return new Z(function(l, m) {
            var p;
            d.sa && (p = rf(a, function() {
                try {
                    f.abort()
                } catch (q) {}
                m(k())
            }, d.sa));
            return g.then(function(q) {
                if (!q.ok) {
                    if (d.Uc) return Td(Xd(q));
                    $d(d.N)
                }
                return d.Uc ? q.text() : d.Fa ? q.json() : null
            }).then(l)["catch"](G(h(),
                m)).then(function() {
                p && sf(a, p)
            })
        })
    }
    var sh = /[^a-z0-9.:-]/;

    function th(a, b, c, d, e, f, g, h) {
        if (4 === b.readyState)
            if (200 === b.status || e || g(c), e) 200 === b.status ? f(b.responseText) : g(Xd(b));
            else {
                e = null;
                if (d) try {
                    (e = ze(a, b.responseText)) || g(c)
                } catch (k) {
                    g(c)
                }
                f(e)
            }
        return h
    }

    function uh(a, b, c) {
        var d = new a.XMLHttpRequest,
            e = c.O,
            f = {},
            g = P(c.Fa ? (f.wmode = "7", f) : {}, c.Da);
        return new Z(function(h, k) {
            d.open(c.ab || "GET", nh(b, sd(g)), !0);
            d.withCredentials = !1 !== c.qc;
            c.sa && (d.timeout = c.sa);
            N(dc, Gb(function(m) {
                var p = n(m);
                m = p.next().value;
                p = p.next().value;
                d.setRequestHeader(m, p)
            }))(c.Ca);
            var l = F([a, d, Zd(c.N), c.Fa, c.Uc, h, k], th);
            d.onreadystatechange = l;
            try {
                d.send(e)
            } catch (m) {}
        })
    }

    function vh(a, b, c, d) {
        return new Z(function(e, f) {
            var g = Ve(a),
                h = b("img"),
                k = N(G(h, Qe), G(Zd(d.N), f)),
                l = rf(a, k, d.sa || 3E3);
            h.onerror = k;
            h.onload = N(G(h, Qe), G(null, e), F([a, l], sf));
            k = P({}, d.Da);
            delete k.wmode;
            h.src = oh(c, d, k);
            wc(a) && (P(h.style, {
                position: "absolute",
                visibility: "hidden",
                width: "0px",
                height: "0px"
            }), g.appendChild(h))
        })
    }
    var wh = {},
        xh = (wh.x = {
            id: 2,
            check: function(a) {
                var b;
                if (b = J(a, "XMLHttpRequest"))
                    if (b = "withCredentials" in new a.XMLHttpRequest) {
                        a: {
                            if (sh.test(a.location.host) && a.opera && y(a.opera.version) && (b = a.opera.version(), "string" === typeof b && "12" === b.split(".")[0])) {
                                b = !0;
                                break a
                            }
                            b = !1
                        }
                        b = !b
                    }
                return b ? G(a, uh) : !1
            }
        }, wh.i = {
            id: 4,
            check: function(a) {
                var b = Pe(a);
                return b ? F([a, b], vh) : !1
            }
        }, wh);
    xh.f = {
        id: 1,
        check: function(a) {
            return a.fetch ? F([a, J(a, "AbortController")], rh) : !1
        }
    };
    xh.b = {
        id: 0,
        check: function(a) {
            if (zc(a)) a = !1;
            else {
                var b = J(a, "navigator.sendBeacon");
                a = b && xa("sendBeacon", b) ? F([a, D(b, J(a, "navigator"))], ih) : !1
            }
            return a
        }
    };
    xh.j = {
        id: 3,
        check: function(a) {
            return Pe(a) ? G(a, qh) : !1
        }
    };
    var yh = {};

    function zh(a) {
        if (a) return H(function(b, c) {
            var d = xh[c];
            d && b.push(d);
            return b
        }, [], a)
    }

    function Ah(a) {
        return yh["*"] ? zh(yh["*"]) : a ? zh(yh[a]) : void 0
    }
    var Bh = ["b", "f", "x", "j", "i"],
        Ch = ["x"];
    Ch.unshift("f");
    Ch.push("j");
    var Dh = ["i"],
        Eh = ["f", "i"],
        Fh = {},
        Gh = (Fh.h = Ch, Fh),
        Hh = L(function(a, b, c, d) {
            (d = Ah(c) || zh(d)) || (d = zh(c ? Gh[c] : Bh));
            c = H(function(e, f) {
                var g = f.check,
                    h = f.id;
                (g = g(a, b)) && e.push([h, g]);
                return e
            }, [], d || []);
            c.length || $d();
            return c
        }, function(a, b, c) {
            return c
        }),
        Ih = D(Z.reject, Z, Zd()),
        Jh = {},
        Kh = (Jh.h = hh, Jh),
        Lh = W("g.sen", function(a, b, c) {
            var d = Hh(a, c, b);
            c = mg(a, b, c);
            var e = Kh[b],
                f = e ? e(a, d, c) : hh(a, d, c);
            return function() {
                var g = n(Va(arguments)),
                    h = g.next().value;
                g = ja(g);
                h = P(h, {
                    J: P(void 0 === h.J ? {} : h.J, {
                        N: [b]
                    })
                });
                return f.apply(null, [h].concat(g))
            }
        }, Ih);

    function Mh(a, b, c) {
        try {
            if (y(b)) {
                var d = n(Va(arguments));
                d.next();
                d.next();
                d.next();
                var e = ja(d);
                b.apply(A(c) ? null : c, e)
            }
        } catch (f) {
            rf(a, G(f, Td), 0)
        }
    }

    function Nh(a, b, c, d, e) {
        var f = F([a, d, e], Mh);
        return c.then(f, function(g) {
            f();
            ee(a, b, g)
        })
    }

    function Oh(a, b) {
        function c(d, e, f) {
            var g = {},
                h = {};
            Pd(a, (h.name = "log", h.counterKey = b, h.data = (g.args = w(e) ? e : [e], g.type = d, g.variables = f, g), h))
        }
        return {
            log: G("log", c),
            error: G("error", c),
            warn: G("warn", c)
        }
    }
    var Ph = L(W("dc.init", function(a, b) {
        return b && cd(sb(b.split(":")[0])) ? {
            log: r,
            warn: r,
            error: r
        } : Oh(a, b)
    }), mb);

    function Qh(a, b, c, d) {
        Ph(a, b).log(c, d)
    }

    function Rh(a, b, c, d, e) {
        return F([a, R(b), e ? [c + ".p", e] : c, d], Qh)
    }
    var Sh = L(Md, R);

    function Th(a, b) {
        var c = Q(a).o("counters", {}),
            d = R(b);
        return c[d]
    }
    var Uh = /^[a-zA-Z0-9'!#$%&*+-/=?^_`{|}~]+$/;

    function Vh(a) {
        var b = a.length;
        return 1 > b || 64 < b ? !1 : Yb(function(c) {
            var d = c.length;
            if (1 > d) c = !1;
            else if ('"' === c[0] && '"' === c[d - 1] && 2 < d) a: {
                for (d = 1; d + 2 < c.length; d += 1) {
                    var e = c.charCodeAt(d);
                    if (32 > e || 34 === e || 126 < e) {
                        c = !1;
                        break a
                    }
                    if (92 === e) {
                        if (d + 2 === c.length || 32 > c.charCodeAt(d + 1)) {
                            c = !1;
                            break a
                        }
                        d += 1
                    }
                }
                c = !0
            }
            else c = Uh.test(c) ? !0 : !1;
            return c
        }, a.split("."))
    }

    function Wh(a) {
        var b = a.length;
        return 5 > b || 100 < b ? void 0 : a
    }

    function Xh(a) {
        var b = vd(a).replace(/^\++/gm, "").toLowerCase(),
            c = b.lastIndexOf("@");
        if (-1 === c) return Wh(b);
        a = b.substr(0, c);
        c = b.substr(c + 1);
        if (!c || !Vh(a)) return Wh(b);
        c = c.replace("googlemail.com", "gmail.com");
        hd(c) && (c = "yandex.ru");
        "yandex.ru" === c ? a = a.replace(za, "-") : "gmail.com" === c && (a = a.replace(za, ""));
        b = Ca(a, "+"); - 1 !== b && (a = a.slice(0, b));
        return Wh(a + "@" + c)
    }
    var Yh = /^[0-9()\-+\s]+$/;

    function Zh(a, b) {
        var c = yd(b),
            d = c.length,
            e = b[0],
            f = c[0];
        if (!(10 > d || 13 < d || "0" === f) && Yh.test(b)) {
            if (10 === d && "+" !== e) return "7" + c;
            if (11 === d) {
                if ("+" === e && "8" === f) return;
                if ("8" === f) return "7" + c.slice(1)
            }
            if (!(12 <= d && "+" === e && "7" === f)) return c
        }
    }
    var $h = L(function(a) {
        return !!J(a, "crypto.subtle.digest") && !!J(a, "TextEncoder") && !!J(a, "FileReader") && !!J(a, "Blob")
    });

    function ai(a, b) {
        return new Z(function(c, d) {
            var e = (new a.TextEncoder).encode(b);
            a.crypto.subtle.digest("SHA-256", e).then(function(f) {
                f = new a.Blob([f], {
                    type: "application/octet-binary"
                });
                var g = new a.FileReader;
                g.onload = function(h) {
                    h = J(h, "target.result") || "";
                    var k = Ca(h, ","); - 1 !== k ? c(h.substring(k + 1)) : d(Wd("fpm.i"))
                };
                g.readAsDataURL(f)
            }, d)
        })
    }
    var bi = ["yandex_cid", "yandex_public_id"];

    function ci(a, b, c) {
        c = void 0 === c ? 0 : c;
        b = dc(b);
        b = H(function(d, e) {
            var f = n(e),
                g = f.next().value;
            f = f.next().value;
            var h = B(f);
            if (!h && (rb(a, f) && (f = "" + f), !u(f))) return d;
            if (h) f = ci(a, f, c + 1);
            else if (!c && O(g, bi)) f = Z.resolve(f);
            else {
                "phone_number" === g ? f = Zh(a, f) : "email" === g && (f = Xh(f));
                if (!f) return d;
                f = ai(a, f)
            }
            d.push(f.then(function(k) {
                return [g, k]
            }));
            return d
        }, [], b);
        return Z.all(b)
    }
    var di = W("fpm", function(a, b) {
        if (!kd(a)) return r;
        var c = R(b);
        if (!$h(a)) return Qh(a, c, "ns"), r;
        var d = Th(a, b);
        return d ? function(e) {
            return (new Z(function(f, g) {
                return B(e) ? ec(e).length ? f(ci(a, e).then(function(h) {
                    if (h && h.length) {
                        var k = {},
                            l = {};
                        d.params((l.__ym = (k.fpp = h, k), l))
                    }
                }, r)) : g(Zd("fpm.l")) : g(Zd("fpm.o"))
            }))["catch"](V(a, "fpm.en"))
        } : r
    });

    function ei(a, b) {
        return H(function(c, d) {
            var e = n(d),
                f = e.next().value,
                g = e.next().value;
            e = g;
            g = B(g);
            if (!g && (rb(a, e) && (e = "" + e), !u(e))) return c;
            e = g ? ei(a, e) : e;
            eb(e) && c.push([f, e]);
            return c
        }, [], dc(b))
    }

    function fi(a, b) {
        return function(c) {
            var d = Th(a, b);
            if (d) {
                var e = Ph(a, R(b));
                if (B(c))
                    if (eb(ec(c))) {
                        if ((c = ei(a, c)) && eb(c)) {
                            e = {};
                            var f = {};
                            d.params((f.__ym = (e.fpmh = c, e), f))
                        }
                    } else e.log("fpeo");
                else e.log("fpno")
            }
        }
    }

    function gi(a, b, c, d) {
        var e = se[c];
        return e ? function() {
            var f = Va(arguments);
            f = d.apply(null, ka(f));
            var g = Q(a);
            g.V("mt", {});
            g = g.o("mt");
            var h = g[e];
            g[e] = h ? h + 1 : 1;
            return f
        } : d
    }

    function hi(a) {
        a = Q(a);
        var b = a.o("dsjf") || Ra({});
        a.V("dsjf", b);
        return b
    }

    function ii(a, b, c) {
        hi(a)(function(d) {
            d[b] = P(d[b] || {}, c)
        })
    }

    function ji(a, b) {
        hi(a)(function(c) {
            delete c[b]
        })
    }

    function ki(a, b) {
        return function(c) {
            ii(a, b, c)
        }
    }
    var li = Na(function(a, b) {
            var c = {};
            hi(a)(function(d) {
                c = d[b] || {}
            });
            return c
        }),
        mi = W("c.c.cc", function(a) {
            var b = Q(a),
                c = N(li(a), function(d) {
                    var e = {};
                    e = (e.clickmap = !!d.clickmap, e);
                    return P({}, d, e)
                });
            return V(a, "g.c.cc", N(D(b.o, b, "counters", {}), ec, Gb(c)))
        }),
        ni = W("gt.c.rs", function(a, b) {
            var c = R(b),
                d = b.id,
                e = b.M,
                f = b.Ed,
                g = b.hc,
                h = F([a, c], ji),
                k = {};
            ii(a, c, (k.id = d, k.type = +e, k.clickmap = f, k.trackHash = !!g, k));
            return h
        }),
        oi = {};

    function pi(a, b) {
        var c = R(a),
            d = J(b, "__ym.turbo_page"),
            e = J(b, "__ym.turbo_page_id");
        oi[c] || (oi[c] = {});
        if (d || e) oi[c].ye = d, oi[c].ze = e
    }

    function qi(a) {
        a = R(a);
        return oi[a] && oi[a].ye
    }
    var ri = L(Nd);

    function si(a, b) {
        return {
            K: function(c, d) {
                var e = (c.H || {}).L,
                    f = void 0 === c.J ? {} : c.J;
                if (e && (pi(b, e), !f.O && c.G && c.D)) {
                    var g = Ae(a, e),
                        h = ri(a),
                        k = c.G.o("pv");
                    if (g && !c.D.nohit) {
                        var l = {},
                            m = {};
                        Pd(a, (m.counterKey = R(b), m.name = "params", m.data = (l.val = e, l), m));
                        k ? encodeURIComponent(g).length > (Fc(a) ? 512 : 2048) ? h.push([c.G, e]) : c.D["site-info"] = g : (f.O = g, c.J = f, c.ub || (c.ub = {}), c.ub.de = !0)
                    }
                }
                d()
            },
            S: function(c, d) {
                var e = ri(a),
                    f = Th(a, b),
                    g = f && f.params;
                g && (f = Qb(N(oc, Pa(c.G)), e), M(function(h) {
                    var k = n(h);
                    k.next();
                    k = k.next().value;
                    g(k);
                    h = nc(a)(h, e);
                    e.splice(h, 1)
                }, f));
                d()
            }
        }
    }

    function ti(a) {
        var b = r,
            c = null,
            d = a.length;
        if (0 !== a.length && a[0]) {
            var e = a.slice(-1)[0];
            y(e) && (b = e, d = a.length + -1);
            var f = a.slice(-2)[0];
            y(f) && (b = f, c = e, d = a.length + -2);
            d = a.slice(0, d);
            return {
                Jd: c,
                eb: b,
                L: 1 === d.length ? a[0] : fb(d)
            }
        }
    }
    var ui = W("pa.int", function(a, b) {
        var c = {};
        return c.params = function() {
            var d = Va(arguments),
                e = ti(d);
            if (!e) return null;
            d = e.Jd;
            var f = e.L;
            e = e.eb;
            if (!B(f) && !w(f)) return null;
            var g = Lh(a, "1", b),
                h = Sh(b).url,
                k = !dd(b),
                l = "pa",
                m = {};
            m = (m.id = b.id, m);
            var p = f,
                q = "";
            if (q = J(f, "__ym.user_id")) l = "pau", m.uid = q;
            O("__ymu", ec(f)) && (l = "paup");
            p.__ym && (p = P({}, f), p.__ym = H(function(v, t) {
                var x = J(f, "__ym." + t);
                x && (v[t] = x);
                return v
            }, {}, oe), ec(p.__ym).length || delete p.__ym, k = !!ec(p).length);
            p = q ? void 0 : Ae(a, p);
            l = Rh(a, b, l, m, p);
            m = {};
            p = {};
            g = g({
                H: {
                    L: f
                },
                G: Wg((m.pa = 1, m.ar = 1, m)),
                D: (p["page-url"] = h || T(a).href, p)
            }, b).then(k ? l : r);
            return Nh(a, "p.s", g, e, d)
        }, c
    });

    function vi(a, b, c, d, e) {
        return (new Z(function(f, g) {
            var h = ec(c),
                k = N(d.resolve || lb, Qa(f)),
                l = N(d.reject || lb, Qa(g));
            d.resolve = k;
            d.reject = l;
            M(function(m) {
                d.jc.push(+m);
                var p = c[m],
                    q = tf(a, G(Zd(), l), 5100, "is.m"),
                    v = {};
                b(p.window, P(e, (v.toCounter = ub(m), v)), function(t, x) {
                    sf(a, q);
                    d.cd.push(m);
                    d.resolve && d.resolve(x)
                })
            }, h)
        }))["catch"](V(a, "if.b"))
    }

    function wi(a, b, c) {
        b = Qb(function(d) {
            return !O(c.info.counterId, d.jc)
        }, b);
        M(function(d) {
            if (c.info.counterId) {
                var e = {};
                a((e[c.info.counterId] = c, e), d, d.data)
            }
        }, b)
    }

    function xi(a, b) {
        var c = Kf(a, b);
        if (!c) return null;
        var d = [],
            e = [],
            f = F([a, c.bc], vi),
            g = G(f, wi);
        c.ca.C(["initToParent"], function(h) {
            h = n(h);
            h.next();
            h = h.next().value;
            g(d, c.children[h.counterId])
        }).C(["parentConnect"], function(h) {
            h = n(h);
            h.next();
            h = h.next().value;
            g(e, c.ga[h.counterId])
        });
        return {
            ca: c.ca,
            Se: function(h, k) {
                return new Z(function(l, m) {
                    c.bc(h, k, function(p, q) {
                        l([p, q])
                    });
                    tf(a, G(Zd(), m), 5100, "is.o")
                })
            },
            $c: function(h) {
                var k = {
                    cd: [],
                    jc: [],
                    data: h
                };
                d.push(k);
                return f(c.children, k, h)
            },
            ad: function(h) {
                var k = {
                    cd: [],
                    jc: [],
                    data: h
                };
                e.push(k);
                return f(c.ga, k, h)
            }
        }
    }
    var yi = L(xi, N(mb, R));

    function zi(a, b) {
        if (!O(b, M(K("ymetrikaEvent.type"), a))) {
            var c = {},
                d = {};
            a.push((d.ymetrikaEvent = (c.type = b, c), d))
        }
    }

    function Ai(a) {
        a = Q(a);
        var b = a.o("dataLayer", []);
        a.B("dataLayer", b);
        return b
    }

    function Bi(a, b, c, d) {
        c = void 0 === c ? r : c;
        d = void 0 === d ? !1 : d;
        var e = Bf(a);
        if (b && y(b.push)) {
            var f = b.push;
            b.push = function() {
                var g = Va(arguments),
                    h = n(g).next().value;
                d && e.trigger(h);
                g = f.apply(b, g);
                d || e.trigger(h);
                return g
            };
            a = {
                Ba: e,
                unsubscribe: function() {
                    b.push = f
                }
            };
            c(a);
            M(e.trigger, b);
            return a
        }
    }

    function Ci(a, b) {
        var c = J(b, "ymetrikaEvent");
        c && a.trigger(J(c, "type"), c)
    }

    function Di(a, b, c) {
        c = void 0 === c ? lb : c;
        var d = Cf(a, "idlo");
        c(d);
        var e = G(d, Ci);
        Bi(a, b, function(f) {
            f.Ba.C(e)
        });
        return d
    }

    function Ei(a, b, c, d) {
        var e = Th(a, c);
        if (e) {
            a = d.data;
            c = "" + c.id;
            var f = d.sended || [];
            d.sended || (d.sended = f);
            O(c, f) || !e.params || d.counter && "" + d.counter !== c || (e.params(a), f.push(c), d.parent && (d = {}, b.ad((d.type = "params", d.data = a, d))))
        }
    }
    var Fi = W("y.p", function(a, b) {
        var c = xi(a, b);
        if (c) {
            var d = Ai(a),
                e = F([a, c, b], Ei);
            Di(a, d, function(f) {
                f.C(["params"], e)
            });
            c.ca.C(["params"], N(K("1"), e))
        }
    });

    function Gi(a, b, c, d) {
        var e = T(a),
            f = e.hostname;
        e = e.href;
        if (b = Sh(b).url) a = lh(a, b), f = a.hostname, e = a.href;
        return [d + "://" + f + "/" + c, e || ""]
    }
    var Hi = {
            Pe: $a(/[/&=?#]/)
        },
        Ii = W("go.in", function(a, b, c, d) {
            c = void 0 === c ? "goal" : c;
            var e = {};
            return e.reachGoal = function(f, g, h, k) {
                if (!f || Hi[c] && Hi[c](f)) return null;
                var l = g,
                    m = h || r;
                y(g) && (m = g, l = void 0, k = h);
                g = {};
                var p = Rh(a, b, "gr", (g.id = b.id, g.goal = f, g), l),
                    q = "goal" === c;
                g = Lh(a, "g", b);
                var v = n(Gi(a, b, f, c));
                h = v.next().value;
                v = v.next().value;
                var t = {},
                    x = {};
                g = g({
                    H: {
                        L: l
                    },
                    G: Wg((t.ar = 1, t)),
                    D: (x["page-url"] = h, x["page-ref"] = v, x)
                }, b).then(function() {
                    q && p();
                    var E = {},
                        C = {};
                    Pd(a, (C.counterKey = R(b), C.name = "event", C.data = (E.schema =
                        c, E.name = f, E.params = l, E), C));
                    d && d()
                });
                return Nh(a, "g.s", g, m, k)
            }, e
        }),
        Ji = W("guid.int", function(a, b) {
            var c = {};
            return c.getClientID = function(d) {
                var e = qf(a, b);
                d && Mh(a, d, null, e);
                return e
            }, c
        }),
        Ki;

    function Li(a) {
        return (a = T(a).hash.split("#")[1]) ? a.split("?")[0] : ""
    }

    function Mi(a, b) {
        var c = Li(a);
        Ki = uf(a, function() {
            var d = Li(a);
            d !== c && (b(), c = d)
        }, 200, "t.h");
        return D(vf, null, a, Ki)
    }

    function Ni(a, b, c, d) {
        var e = b.M,
            f = b.oc,
            g = b.Ga,
            h = Q(a),
            k = {};
        k = Wg((k.wh = 1, k.pv = 1, k));
        var l = J(d, "isTrusted");
        d && !A(l) && k.B("ite", Mb(l));
        te(e) && a.Ya && a.Ya.Direct && k.B("ad", "1");
        f && k.B("ut", "1");
        e = h.o("lastReferrer");
        d = T(a).href;
        f = {};
        g = {
            D: (f["page-url"] = g || d, f["page-ref"] = e, f),
            G: k
        };
        c(g, b)["catch"](V(a, "g.s"));
        h.B("lastReferrer", d)
    }
    var Oi = W("th.e", function(a, b) {
        function c() {
            f || (h = I(a, "onhashchange") ? Xc(a).C(a, ["hashchange"], g) : Mi(a, g))
        }
        var d = Lh(a, "t", b),
            e = ki(a, R(b)),
            f = !1,
            g = V(a, "h.h.ch", D(Ni, null, a, b, d)),
            h = r;
        b.hc && (c(), f = !0);
        d = {};
        return d.trackHash = V(a, "tr.hs.h", function(k) {
            k ? c() : h();
            f = !!k;
            k = {};
            e((k.trackHash = f, k))
        }), d.u = h, d
    });

    function Pi(a) {
        var b = null;
        try {
            b = a.target || a.srcElement
        } catch (c) {}
        if (b) {
            3 === b.nodeType && (b = b.parentNode);
            for (a = b && b.nodeName && ("" + b.nodeName).toLowerCase(); J(b, "parentNode.nodeName") && ("a" !== a && "area" !== a || !b.href && !b.getAttribute("xlink:href"));) a = (b = b.parentNode) && b.nodeName && ("" + b.nodeName).toLowerCase();
            return b.href ? b : null
        }
        return null
    }

    function Qi(a, b) {
        var c = {};
        c = (c.string = !0, c.object = !0, c["boolean"] = b, c)[typeof b] || !1;
        var d = {};
        a((d.trackLinks = c, d))
    }

    function Ri(a, b, c) {
        var d = Wg();
        void 0 !== c.pb && d.B("ite", Mb(c.pb));
        c.mb && d.B("dl", 1);
        c.Ja && d.B("ln", 1);
        var e = c.vd || {},
            f = {};
        d = {
            G: d,
            H: {
                title: e.title || c.title,
                qb: !!c.qb,
                L: e.params
            },
            D: (f["page-url"] = c.url, f["page-ref"] = b.Ga || T(a).href, f)
        };
        f = "Link";
        c.mb ? f = c.Ja ? "Ext link - File" : "File" : c.Ja && (f = "Ext link");
        var g = {},
            h = {};
        Pd(a, (h.counterKey = R(b), h.name = "event", h.data = (g.schema = "Link click", g.name = (c.Ja ? "external" : "internal") + " url: " + c.url, g), h));
        g = {};
        b = c.sender(d, b).then(Rh(a, b, "lcl", (g.prefix = f, g.id = b.id,
            g.url = c.url, g), c.vd));
        Nh(a, "cl.p.s", b, e.callback || r, e.ctx)
    }

    function Si(a, b) {
        if (a.Ae()) {
            var c = Pi(b);
            if (c && !Se("ym-disable-tracklink", c)) {
                var d = a.l,
                    e = a.Hd,
                    f = a.Id,
                    g = a.sender,
                    h = a.Od,
                    k = f.Ga,
                    l = c.href;
                var m = vd(c.innerHTML && c.innerHTML.replace(/<\/?[^>]+>/gi, ""));
                m || (m = (m = c.querySelector("img")) ? vd(m.getAttribute("title") || m.getAttribute("alt")) : "");
                m = l === m ? "" : m;
                var p = J(b, "isTrusted");
                if (Se("ym-external-link", c)) Ri(d, f, {
                    url: l,
                    Ja: !0,
                    title: m,
                    pb: p,
                    sender: g
                });
                else {
                    k = k ? lh(d, k).hostname : T(d).hostname;
                    h = RegExp("\\.(" + U("|", M(Ka, h)) + ")$", "i");
                    var q = c.protocol + "//" + c.hostname +
                        c.pathname;
                    h = qe.test(q) || qe.test(l) || h.test(l) || h.test(q);
                    c = c.hostname;
                    id(k) === id(c) ? h ? Ri(d, f, {
                        url: l,
                        mb: !0,
                        pb: p,
                        title: m,
                        sender: g
                    }) : m && e.B("il", vd(m).slice(0, 100)) : l && pe.test(l) || Ri(d, f, {
                        url: l,
                        qb: !0,
                        Ja: !0,
                        mb: h,
                        pb: p,
                        title: m,
                        sender: g
                    })
                }
            }
        }
    }
    var Ti = Na(function(a, b) {
        u(b) ? a.push(b) : M(N(lb, Za("push", a)), b)
    });

    function Ui(a, b) {
        return function(c) {
            var d = c[a];
            d ? (d.Yb = !0, d.Xb(b)) : c[a] = {
                promise: Z.resolve(b),
                Yb: !0,
                Xb: r
            }
        }
    }
    var Vi = Na(function(a, b) {
            if (!b[a]) {
                var c, d = new Z(function(e) {
                    c = e
                });
                b[a] = {
                    Xb: c,
                    promise: d,
                    Yb: !1
                }
            }
            return b[a].promise
        }),
        Wi = L(N(Md, Ra)),
        Xi = L(Md);

    function Yi(a, b, c) {
        b = R(b);
        Xi(b).Pd = X(a)(gf);
        c = P({}, c);
        var d = {},
            e = {};
        Pd(a, (e.counterKey = b, e.name = "counterSettings", e.data = (d.settings = c, d), e));
        return Wi()(Ui(b, c))
    }

    function Zi(a, b) {
        var c = R(a);
        return Wi()(Vi(c)).then(b)
    }

    function $i(a, b, c) {
        if (a.postMessage && !a.attachEvent) {
            var d = Xc(a),
                e = "__ym__promise_" + ef(a) + "_" + ef(a),
                f = r;
            f = d.C(a, ["message"], V(a, c, function(g) {
                try {
                    var h = g.data
                } catch (k) {
                    return
                }
                h === e && (f(), g.stopPropagation && g.stopPropagation(), b())
            }));
            a.postMessage(e, "*")
        } else tf(a, b, 0, c)
    }
    var aj = [],
        bj = !1,
        cj = !1;

    function dj(a, b) {
        if (aj.length) {
            var c = aj.shift();
            cj ? c() : tf(a, c, 100, b + ".ei.rnt")
        } else bj = !1
    }

    function ej(a, b, c, d, e) {
        d = void 0 === d ? 1 : d;
        e = void 0 === e ? Rg : e;
        cj = Infinity === d;
        return Ra(function(f, g) {
            function h() {
                try {
                    var l = b(e(a, d));
                    k = k.concat(l)
                } catch (m) {
                    return f(m)
                }
                b(Mg);
                if (b(Ig)) return g(k), dj(a, c);
                cj ? (b(e(a, 1E4)), g(k), dj(a, c)) : tf(a, h, 100, c + ".ei")
            }
            var k = [];
            bj ? aj.push(h) : (bj = !0, h())
        })
    }

    function fj(a, b, c, d, e, f) {
        e = void 0 === e ? 1 : e;
        f = void 0 === f ? r : f;
        b = Tg(b, c);
        ej(a, b, d + ".itc", e)(wf(V(a, d), f))
    }

    function gj(a, b, c) {
        function d(g) {
            var h = {
                    id: g.counterId,
                    M: g.M
                },
                k = {
                    J: {
                        O: g.je
                    },
                    G: Wg(g.Bd),
                    D: g.L,
                    H: {
                        Za: g.Za
                    },
                    ha: {
                        U: g.U
                    }
                };
            g.ba && (k.ba = le(g.ba));
            return f(k, h).then(r, e)
        }
        var e = V(a, "rts.p"),
            f = Lh(a, "r", b);
        return Zi(b, function() {
            $i(a, F([a, c, d, "rts.a", 1], fj), "rts.mr")
        }).then(r, e)
    }
    var hj = N(Da, Pa(0)),
        ij = Oa(hj),
        jj = [ij("watch"), ij("clmap")],
        kj = bd("retryReqs", function(a) {
            return He(a).o("retryReqs", {})
        }, !0);

    function lj(a, b) {
        He(a).B("retryReqs", b)
    }

    function mj(a, b) {
        var c = {
            protocol: b.protocol,
            host: b.host,
            U: b.resource,
            je: b.postParams,
            L: b.params,
            Bd: b.browserInfo,
            Ne: b.ghid,
            time: b.time,
            Za: ub(a),
            counterId: b.counterId,
            M: b.counterType
        };
        b.telemetry && (c.ba = b.telemetry);
        return c
    }

    function nj(a) {
        var b = kj(a);
        return {
            add: function(c) {
                for (var d = 1; b[d];) d += 1;
                b[d] = c;
                lj(a, b);
                return d
            },
            "delete": function(c) {
                delete b[c];
                lj(a, b)
            },
            Ce: function(c, d) {
                var e = b[c];
                e && e.browserInfo && (e.browserInfo.rqnl = d, lj(a, b))
            },
            Rd: W("g.r", function() {
                var c = X(a)(gf),
                    d = mf(a);
                return H(function(e, f) {
                    var g = n(f),
                        h = g.next().value;
                    (g = g.next().value) && sc(Ra(g.resource), jj) && !g.d && g.ghid && g.ghid !== d && g.time && 500 < c - g.time && g.time + 864E5 > c && g.browserInfo.rqnl && 2 >= g.browserInfo.rqnl && (g.d = 1, h = mj(h, g), e.push(h));
                    return e
                }, [], dc(b))
            }),
            Dd: function() {
                var c = X(a)(gf);
                M(function(d) {
                    var e = n(d);
                    d = e.next().value;
                    e = e.next().value;
                    (!e || !e.time || e.time + 864E5 < c || e.browserInfo.rqnl && 2 <= e.browserInfo.rqnl) && delete b[d]
                }, dc(b));
                lj(a, b)
            },
            length: function() {
                return ec(b).length
            },
            clear: function() {
                lj(a, {});
                return H(function(c, d) {
                    var e = n(d),
                        f = e.next().value;
                    e = e.next().value;
                    c.push(mj(f, e));
                    delete b[f];
                    return c
                }, [], dc(b))
            }
        }
    }

    function oj(a, b, c, d) {
        b.G && b.H && (d["delete"](b.H.Za), 100 <= d.length() && (b = d.clear(), gj(a, c, b)))
    }

    function pj(a, b) {
        var c = nj(a);
        return {
            K: function(d, e) {
                var f = d.G,
                    g = d.ba,
                    h = d.D,
                    k = void 0 === d.J ? {} : d.J;
                if (f && h) {
                    var l = X(a);
                    f.wb("rqnl", 1);
                    var m = {};
                    f = (m.protocol = "https:", m.host = Rd, m.resource = d.ha.U, m.postParams = k.O, m.time = l(gf), m.counterType = b.M, m.params = h, m.browserInfo = f.l(), m.counterId = b.id, m.ghid = mf(a), m);
                    g && (f.telemetry = g.l());
                    g = c.add(f);
                    d.H || (d.H = {});
                    d.H.Za = g
                }
                e()
            },
            S: function(d, e) {
                oj(a, d, b, c);
                e()
            }
        }
    }

    function qj(a, b, c) {
        function d() {
            v || (q = !0, t = !1, v = !0, f())
        }

        function e() {
            m = !0;
            k(!1);
            b()
        }

        function f() {
            sf(a, l);
            if (m) k(!1);
            else {
                var S = Math.max(0, c - (t ? x : x + p(gf) - E));
                S ? l = tf(a, e, S, "u.t.d.c") : e()
            }
        }

        function g() {
            t = q = v = !0;
            x += p(gf) - E;
            E = p(gf);
            f()
        }

        function h() {
            q || v || (x = 0);
            E = p(gf);
            q = v = !0;
            t = !1;
            f()
        }

        function k(S) {
            S = S ? C.C : C.ua;
            S(a, ["blur"], g);
            S(a, ["focus"], h);
            S(a.document, ["click", "mousemove", "keydown", "scroll"], d)
        }
        var l = 0,
            m = !1;
        if (Fc(a)) return l = tf(a, b, c, "u.t.d"), F([a, l], sf);
        var p = X(a),
            q = !1,
            v = !1,
            t = !0,
            x = 0,
            E = p(gf),
            C = Xc(a);
        k(!0);
        f();
        return function() {
            sf(a, l);
            k(!1)
        }
    }
    var rj = W("nb.p", function(a, b) {
        function c(q) {
            h() || (q = "number" === typeof q ? q : 15E3, p = qj(a, d(!1), q), l())
        }

        function d(q) {
            return function(v) {
                var t = {};
                v = void 0 === v ? (t.ctx = {}, t.callback = r, t) : v;
                if (q || !m && !g.Lb) {
                    m = !0;
                    l();
                    p && p();
                    var x = X(a)(gf);
                    t = (ub(g.o("lastHit")) || 0) < x - 18E5;
                    var E = .1 > Math.random();
                    g.B("lastHit", x);
                    var C = Xi(f);
                    x = C.kb;
                    C = C.Pd;
                    var S = {};
                    x = Wg((S.nb = 1, S.cl = rb(a, C) && rb(a, x) ? C - x : 0, S.ar = 1, S));
                    C = Sh(b);
                    S = {};
                    x = {
                        D: (S["page-url"] = C.url || T(a).href, S),
                        G: x,
                        H: {
                            force: q
                        }
                    };
                    C = Ph(a, R(b)).warn;
                    !v.callback && v.ctx && C("nbnc");
                    (t = q || t || E) || (t = a.location.href, E = a.document.referrer, t = !(t && E ? mh(t) === mh(E) : !t && !E));
                    if (t) return t = e(x, b), Nh(a, "l.o.l", t, v.callback, v.ctx)
                }
                return null
            }
        }
        var e = Lh(a, "n", b),
            f = R(b),
            g = Ie(a, b.id),
            h = G(G(f, li(a)), N(be, K("accurateTrackBounce"))),
            k = {},
            l = G((k.accurateTrackBounce = !0, k), ki(a, f)),
            m = !1,
            p;
        b.tc && c(b.tc);
        k = {};
        k = (k.notBounce = d(!0), k.u = p, k);
        k.accurateTrackBounce = c;
        return k
    });

    function sj(a) {
        return !(!xa("querySelectorAll", J(a, "Element.prototype.querySelectorAll")) || !a.document.querySelectorAll)
    }

    function tj(a, b) {
        if (!b || !b.querySelectorAll) return [];
        var c = b.querySelectorAll(a);
        return c ? mc(c) : []
    }

    function uj(a, b) {
        if (b.querySelector) return b.querySelector(a);
        var c = tj(a, b);
        return c && c.length ? c[0] : null
    }
    var vj;
    var wj = window.Set;
    if (ya(wj, "Set")) {
        var xj = ya(J(wj.prototype, "add"), "add"),
            yj = ya(J(wj.prototype, "has"), "has"),
            zj = ya(J(wj.prototype, "delete"), "delete"),
            Aj = ya(J(wj.prototype, "clear"), "clear"),
            Bj = ya(J(wj.prototype, "forEach"), "forEach");
        vj = xj && yj && zj && Aj && Bj ? Set : kc
    } else vj = kc;
    var Cj = vj;

    function Dj(a, b, c) {
        if (!(b && b.Element && b.Element.prototype && b.document && c)) return null;
        if (b.Element.prototype.closest && xa("closest", b.Element.prototype.closest) && c.closest) return c.closest(a);
        var d = Te(b);
        if (d) {
            for (; c && 1 === c.nodeType && !d.call(c, a);) c = c.parentElement || c.parentNode;
            return c && 1 === c.nodeType ? c : null
        }
        if (sj(b)) {
            for (a = new Cj(mc((b.document || b.ownerDocument).querySelectorAll(a))); c && 1 === c.nodeType && !a.has(c);) c = c.parentElement || c.parentNode;
            return c && 1 === c.nodeType ? c : null
        }
        return null
    }

    function Ej(a, b) {
        return I(b, "isConnected") ? !b.isConnected : Dj("html", a, b) !== a.document.documentElement
    }

    function Fj(a, b) {
        var c = b,
            d = J(a, "document"),
            e = bf(c);
        if (!c || !c.ownerDocument || "PARAM" === e || c === Ue(a) || c === d.documentElement) return {
            left: 0,
            top: 0
        };
        if (d = $e(c)) return c = Ye(a), {
            left: Math.round(d.left + c.x),
            top: Math.round(d.top + c.y)
        };
        for (e = d = 0; c;) d += c.offsetLeft, e += c.offsetTop, c = c.offsetParent;
        return {
            left: d,
            top: e
        }
    }

    function Gj(a, b) {
        var c = J(a, "document");
        return b === Ue(a) || b === c.documentElement ? Ze(a) : (c = $e(b)) ? [c.width, c.height] : [b.offsetWidth, b.offsetHeight]
    }
    var Hj = L(function() {
        for (var a = 59, b = {}, c = 0; c < ne.length; c += 1) b[ne[c]] = String.fromCharCode(a), a += 1;
        return b
    });

    function Ij(a, b, c) {
        for (var d = "", e = Hj(), f = bf(b) || "*"; b && b.parentNode && !O(f, ["BODY", "HTML"]);) {
            d += e[f] || "*";
            a: {
                f = J(a, "document");
                if (f = b && b !== f.documentElement ? b === Ue(a) ? f.documentElement : J(b, "parentNode") : null) {
                    f = f.childNodes;
                    for (var g = b && b.nodeName, h = 0, k = 0; k < f.length; k += 1)
                        if (g === (f[k] && f[k].nodeName)) {
                            if (b === f[k]) {
                                f = h;
                                break a
                            }
                            c && f[k] === c || (h += 1)
                        }
                }
                f = 0
            }
            d += f || "";
            b = b.parentElement;
            f = bf(b) || "*"
        }
        return vd(d, 128)
    }

    function Jj(a, b) {
        var c = Ve(a),
            d = Ye(a);
        return {
            x: b.pageX || b.clientX + d.x - (c.clientLeft || 0) || 0,
            y: b.pageY || b.clientY + d.y - (c.clientTop || 0) || 0
        }
    }

    function Kj(a) {
        var b = a.which;
        a = a.button;
        return b || void 0 === a ? b : 1 === a || 3 === a ? 1 : 2 === a ? 3 : 4 === a ? 2 : 0
    }
    var Lj = Na(Se)("(ym-disable-clickmap|ym-clickmap-ignore)");

    function Mj(a, b, c, d, e) {
        if (I(a, "ymDisabledClickmap") || !b || !b.element) return !1;
        a = bf(b.element);
        if (e && !e(b.element, a) || O(b.button, [2, 3]) && "A" !== a || sc(Pa(a), d)) return !1;
        d = b.element;
        if (b && c) {
            if (50 > b.time - c.time) return !1;
            e = Math.abs(c.position.x - b.position.x);
            a = Math.abs(c.position.y - b.position.y);
            b = b.time - c.time;
            if (c.element === d && 2 > e && 2 > a && 1E3 > b) return !1
        }
        for (; d;) {
            if (Lj(d)) return !1;
            d = d.parentElement
        }
        return !0
    }

    function Nj(a, b, c, d, e) {
        var f = "clmap/" + e.id,
            g = {};
        b = (g["page-url"] = b, g["pointer-click"] = c, g);
        f = {
            G: Wg(),
            D: b,
            ha: {
                U: f
            }
        };
        d(f, e)["catch"](V(a, "c.s.c"))
    }
    var Oj = W("clm.p", function(a, b) {
            if (tc(a)) return r;
            var c = Lh(a, "m", b),
                d = R(b),
                e = X(a),
                f = e(gf),
                g = G(G(d, li(a)), N(be, K("clickmap"))),
                h, k = null;
            d = V(a, "clm.p.c", function(l) {
                var m = g();
                if (m) {
                    var p = Q(a),
                        q = p.o("cls", {
                            fb: 0,
                            x: 0,
                            y: 0
                        });
                    p.B("cls", {
                        fb: q.fb + 1,
                        x: q.x + l.clientX,
                        y: q.y + l.clientY
                    });
                    p = "object" === typeof m ? m : {};
                    q = p.filter;
                    m = p.isTrackHash || !1;
                    var v = M(function(x) {
                        return ("" + x).toUpperCase()
                    }, p.ignoreTags || []);
                    z(h) && (h = p.quota || null);
                    var t = !!p.quota;
                    l = {
                        element: Re(a, l),
                        position: Jj(a, l),
                        button: Kj(l),
                        time: e(gf)
                    };
                    p = T(a).href;
                    if (Mj(a, l, k, v, q)) {
                        if (t) {
                            if (!h) return;
                            --h
                        }
                        v = n(Gj(a, l.element));
                        q = v.next().value;
                        v = v.next().value;
                        t = Fj(a, l.element);
                        q = ["rn", ef(a), "x", Math.floor(65535 * (l.position.x - t.left) / (q || 1)), "y", Math.floor(65535 * (l.position.y - t.top) / (v || 1)), "t", Math.floor((l.time - f) / 100), "p", Ij(a, l.element), "X", l.position.x, "Y", l.position.y];
                        q = U(":", q);
                        m && (q += ":wh:1");
                        Nj(a, p, q, c, b);
                        k = l
                    }
                }
            });
            return Xc(a).C(J(a, "document"), ["click"], d)
        }),
        Pj = W("trigger.in", function(a, b) {
            b.nd && $i(a, F([a, "yacounter" + b.id + "inited"], af), "t.i")
        });

    function Qj(a, b) {
        var c = {};
        a((c.clickmap = z(b) ? !0 : b, c))
    }
    var Rj = W("c.m.p", function(a, b) {
        var c = R(b),
            d = {};
        return d.clickmap = G(ki(a, c), Qj), d
    });

    function Sj(a) {
        a = "" + a;
        for (var b = 2166136261, c = a.length, d = 0; d < c; d += 1) b ^= a.charCodeAt(d), b += (b << 1) + (b << 4) + (b << 7) + (b << 8) + (b << 24);
        return b >>> 0
    }
    var Tj = {},
        Uj = {};
    Tj.p = 500;
    var Vj = {
        i: "id",
        n: "name",
        h: "href",
        ty: "type"
    };
    Uj.h = !0;
    Uj.c = !0;
    var Wj = {
        p: function(a, b, c) {
            if (b && Ej(a, b) && b._ymp) return b._ymp;
            a = Ij(a, b, c);
            b && (b._ymp = a);
            return a
        },
        c: function(a, b, c) {
            (a = vd(J(b, "textContent"))) && c && (c = c(b), c.length && sc(N(K("textContent"), vd, Pa(a)), c) && (a = ""));
            df(b) && (a = vd(b.getAttribute && b.getAttribute("value") || a));
            return a
        }
    };

    function Xj(a, b, c, d) {
        return H(function(e, f) {
            var g = null;
            f in Vj ? g = b.getAttribute && b.getAttribute(Vj[f]) : f in Wj && (g = "p" === f ? Wj[f](a, b, void 0) : "c" === f ? Wj[f](a, b, d) : Wj[f](a, b));
            g && (g = g.slice(0, Tj[f] || 100), e[f] = Uj[f] ? "" + Sj(g) : g);
            return e
        }, {}, c)
    }
    var Yj = G("form", Dj),
        Zj = L(N(mb, Oa(Zi)(K("settings.form_goals"))), mb);

    function ak(a, b, c, d) {
        return Zj(a, b).then(N(F([Rh(a, b, c, d), r], Kb), be))
    }

    function bk(a, b, c, d, e, f) {
        var g = ib(b)(e, d),
            h = -1 !== g;
        if (a || h) h && d.splice(g, 1), a = Xj(b, e, ["i", "n", "p"]), a = "?" + sd(a), d = {}, d = F([b, c, "fg", (d.id = c.id, d.query = a, d)], ak), A(f) ? f = void 0 : (e = {}, g = {}, f = (g.__ym = (e.ite = Mb(f), e), g)), Ii(b, c, "form", d).reachGoal(a, f)
    }

    function ck(a, b, c, d) {
        var e = J(d, "target");
        e && (d = J(d, "isTrusted"), (e = Dj("button,input", a, e)) && "submit" === e.type && (e = Yj(a, e))) && (c.push(e), tf(a, F([!1, a, b, c, e, d], bk), 300, "s.t.s"))
    }
    var dk = W("s.f.i", function(a, b) {
        var c = [],
            d = [],
            e = Xc(a);
        c.push(e.C(a, ["click"], V(a, "s.f.c", F([a, b, d], ck))));
        c.push(e.C(a, ["submit"], V(a, "s.f.e", function(f) {
            bk(!0, a, b, d, J(f, "target"), J(f, "isTrusted"))
        })));
        e = {};
        ak(a, b, "fgi", (e.id = b.id, e));
        return F([ce, c], M)
    });

    function ek(a, b, c, d) {
        return function() {
            if (Th(a, b)) {
                var e = Va(arguments);
                return d.apply(null, ka(e))
            }
        }
    }
    var fk = "button," + U(",", M(function(a) {
            return 'input[type="' + a + '"]'
        }, ["button", "submit", "reset", "file"])) + ",a",
        gk = G(fk, tj),
        hk = {},
        ik = (hk.A = "h", hk.BUTTON = "i", hk.DIV = "i", hk.INPUT = "ty", hk);

    function jk(a, b, c) {
        var d = J(c, "target");
        if (d) {
            var e = Dj(fk, a, d);
            e || (d = Dj("div", a, d)) && (tj(fk + ",div", d).length || (e = d));
            if (e = (d = bf(e)) && Xj(a, e, Rb(["p", ik[d], "c"]), gk)) {
                e = "?" + sd(e);
                d = {};
                d = Rh(a, b, "gbn", (d.id = b.id, d.query = e, d));
                c = J(c, "isTrusted");
                if (A(c)) c = void 0;
                else {
                    var f = {},
                        g = {};
                    c = (g.__ym = (f.ite = Mb(c), f), g)
                }
                Ii(a, b, "btn", d).reachGoal(e, c)
            }
        }
    }
    var kk = W("s.f.i", function(a, b) {
            return Zi(b, function(c) {
                if (J(c, "settings.button_goals")) {
                    c = Xc(a).C(a, ["click"], V(a, "c.t.c", N(F([a, b], ek(a, b, "", jk)))));
                    var d = {};
                    Rh(a, b, "gbi", (d.id = b.id, d))();
                    return c
                }
            })
        }),
        lk = {},
        mk = (lk.transaction_id = "id", lk.item_brand = "brand", lk.index = "position", lk.item_variant = "variant", lk.value = "revenue", lk.item_category = "category", lk.item_list_name = "list", lk),
        nk = {},
        ok = (nk.item_id = "id", nk.item_name = "name", nk.promotion_name = "coupon", nk),
        pk = {},
        qk = (pk.promotion_name = "name", pk),
        rk = {},
        sk = (rk.promotion_name = "name", rk.promotion_id = "id", rk.item_id = "product_id", rk.item_name = "product_name", rk),
        tk = "currencyCode add delete remove purchase checkout detail impressions click promoView promoClick".split(" "),
        uk = {},
        vk = (uk.view_item = {
            event: "detail",
            fa: ok,
            ta: "products"
        }, uk.add_to_cart = {
            event: "add",
            fa: ok,
            ta: "products"
        }, uk.remove_from_cart = {
            event: "remove",
            fa: ok,
            ta: "products"
        }, uk.begin_checkout = {
            event: "checkout",
            fa: ok,
            ta: "products"
        }, uk.purchase = {
            event: "purchase",
            fa: ok,
            ta: "products"
        }, uk.view_item_list = {
            event: "impressions",
            fa: ok
        }, uk.select_item = {
            event: "click",
            ta: "products",
            fa: ok
        }, uk.view_promotion = {
            event: "promoView",
            ta: "promotions",
            fa: sk
        }, uk.select_promotion = {
            event: "promoClick",
            ta: "promotions",
            fa: sk
        }, uk);

    function wk(a, b) {
        var c = {};
        M(function(d) {
            var e = a[d] || mk[d] || d; - 1 !== Ca(d, "item_category") ? (e = mk.item_category, c[e] = c[e] ? c[e] + ("/" + b[d]) : b[d]) : c[e] = b[d]
        }, ec(b));
        return c
    }

    function xk(a, b) {
        var c = u(a) ? vk[a] : a;
        if (c) {
            var d = c.event,
                e = c.ta,
                f = void 0 === c.Sd ? "items" : c.Sd,
                g = b.purchase || b,
                h = g[f];
            if (h) {
                c = M(G(c.fa, wk), h);
                h = {};
                var k = {},
                    l = (k[d] = e ? (h[e] = c, h) : c, k);
                c = ec(g);
                e && 1 < c.length && (l[d].actionField = H(function(m, p) {
                    if (p === f) return m;
                    if ("currency" === p) return l.currencyCode = g.currency, m;
                    m[qk[p] || mk[p] || p] = g[p];
                    return m
                }, {}, c));
                return l
            }
        }
    }
    var yk = W("dl.w", function(a, b, c) {
        function d() {
            var g = J(a, b);
            (e = w(g) && Bi(a, g, c)) || (f = tf(a, d, 1E3, "ec.dl"))
        }
        var e, f = 0;
        d();
        return function() {
            return sf(a, f)
        }
    });

    function zk(a) {
        var b = J(a, "ecommerce");
        if (B(b)) return a = Qb(Vb(tk), ec(b)), a = H(function(c, d) {
            c[d] = b[d];
            return c
        }, {}, a), 0 === ec(a).length ? void 0 : a
    }

    function Ak(a, b) {
        return function(c) {
            var d = Th(a, b);
            if (d && (d = d.params)) {
                var e = J(c, "ecommerce") || {};
                var f = J(c, "event") || "";
                e = B(e) && u(f) ? xk(f, e) : void 0;
                if (!e) a: {
                    e = c;!w(c) && rb(a, eb(c)) && (e = Va(e));
                    if (w(e)) {
                        var g = n(e);
                        e = g.next().value;
                        f = g.next().value;
                        g = g.next().value;
                        if (u(f) && B(g) && "event" === e) {
                            e = xk(f, g);
                            break a
                        }
                    }
                    e = void 0
                }
                if (c = e || zk(c)) e = {}, Pd(a, (e.counterKey = R(b), e.name = "ecommerce", e.data = c, e)), e = {}, f = {}, d((f.__ym = (e.ecommerce = [c], e), f))
            }
        }
    }

    function Bk(a, b, c) {
        var d;
        a = [yk(a, b, function(e) {
            d = e;
            e.Ba.C(c)
        }), function() {
            d && d.unsubscribe()
        }];
        return F([ce, a], M)
    }
    var Ck = W("p.e", function(a, b) {
        if (Th(a, b)) {
            var c = Q(a),
                d = V(a, "h.ee", Ak(a, b));
            return b.Db ? (c.B("ecs", 0), Bk(a, b.Db, d)) : Zi(b, function(e) {
                if ((e = J(e, "settings.ecommerce")) && u(e)) return c.B("ecs", 1), Bk(a, e, d)
            })
        }
    });

    function Dk(a, b, c, d, e, f) {
        e = void 0 === e ? -1 : e;
        f = void 0 === f ? !1 : f;
        d = y(d) ? d(b) ? a.NodeFilter.FILTER_ACCEPT : a.NodeFilter.FILTER_REJECT : a.NodeFilter.FILTER_ACCEPT;
        if (y(c) && (f || d === a.NodeFilter.FILTER_ACCEPT) && (d && c(b), !Me(b)))
            for (a = a.document.createTreeWalker(b, e, null, !1); a.nextNode() && !1 !== c(a.currentNode););
    }
    var Ek = L(function(a) {
            a = T(a);
            a = rd(a.search.substring(1));
            return {
                id: ub(a["_ym_status-check"] || ""),
                lang: a._ym_lang || "ru"
            }
        }),
        Fk = bd("giss", Md);

    function Gk(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = Fk(a);
        d[b] || (d[b] = {
            qe: jh(a, P(c, {
                src: b
            })),
            state: 0
        });
        return d[b]
    }

    function Hk(a, b, c, d, e) {
        function f() {
            h.state = 1;
            c()
        }

        function g() {
            h.state = 2;
            d && d()
        }
        e = void 0 === e ? {} : e;
        var h = Gk(a, b, e);
        b = h.qe;
        e = h.state;
        b && 2 !== e ? 1 === e ? f() : (a = Xc(a), a.C(b, ["load"], f), a.C(b, ["error"], g)) : g()
    }
    var Ik = W("suid.int", function(a, b) {
        var c = {};
        return c.setUserID = function(d, e, f) {
            if (u(d) || rb(a, d)) {
                var g = Th(a, b);
                d = fb(["__ym", "user_id", d]);
                g.params(d, e || r, f)
            } else Ph(a, R(b)).error("wuid")
        }, c
    });

    function Jk(a, b) {
        return {
            S: function(c, d) {
                var e = Th(a, b);
                e = e && e.userParams;
                var f = (c.H || {}).nc;
                e && f && e(f);
                d()
            }
        }
    }
    var Kk = W("up.int", function(a, b) {
            var c = {};
            return c.userParams = V(a, "up.c", function(d, e, f) {
                var g = Th(a, b),
                    h = Ph(a, R(b)).warn;
                g ? B(d) ? (h = {}, d = (h.__ymu = d, h), (g = g.params) && g(d, e || r, f)) : h("wup") : h("nci")
            }), c
        }),
        Lk = /[\*\.\?\(\)]/g,
        Mk = L(function(a, b, c) {
            try {
                var d = c.replace("\\s", " ").replace(Lk, "");
                b = {};
                Ph(a, "").warn("nnw", (b.name = d, b))
            } catch (e) {}
        }, mb),
        Nk = W("r.nn", function(a) {
            Ld(a) && Bi(a, va, function(b) {
                b.Ba.C(function(c) {
                    var d = n(c);
                    c = d.next().value;
                    d = d.next().value;
                    Mk(a, d, c);
                    va.splice(100)
                })
            })
        });

    function Ok(a, b) {
        return {
            K: function(c, d) {
                $f(c) ? d() : Zi(b, function(e) {
                    if (e = J(e, "settings.hittoken")) {
                        var f = {};
                        e = (f.hittoken = e, f);
                        c.D = P(c.D || {}, e)
                    }
                    d()
                })
            }
        }
    }
    var Pk = L(Md, R),
        Qk = W("fpi", function(a) {
            var b = fe(a);
            if (b && !a.document.hidden) {
                var c = Q(a).V;
                c("fpe", 1);
                var d = Xc(a).C(a, ["visibilitychange", "webkitvisibilitychange"], function() {
                    a.document.hidden && (c("fht", b.now()), d())
                })
            }
        }),
        Rk = L(function(a) {
            a = J(a, "console");
            var b = J(a, "log");
            b = wa("log", b) ? D(b, a) : r;
            var c = J(a, "warn");
            c = wa("warn", c) ? D(c, a) : b;
            var d = J(a, "error");
            a = wa("error", d) ? D(d, a) : b;
            return {
                log: b,
                error: a,
                warn: c
            }
        }),
        Sk = W("p.cd", function(a) {
            if (Cc(a) || uc(a)) {
                var b = He(a);
                if (A(b.o("jn"))) {
                    b.B("jn", !1);
                    var c = a.chrome ||
                        wc(a) ? function() {} : /./;
                    a = Rk(a);
                    c.toString = function() {
                        b.B("jn", !0);
                        return "Yandex.Metrika counter is initialized"
                    };
                    a.log("%c%s", "color: inherit", c)
                }
            }
        });

    function Tk(a, b) {
        return Array.prototype.sort.call(b, a)
    }
    var Uk = L(function(a) {
            a = J(a, "navigator.plugins");
            return !!(a && eb(a) && sc(N(K("name"), $a(/Chrome PDF Viewer/)), a))
        }),
        Vk = Na(function(a, b) {
            return Q(b).o(a, null)
        }),
        Wk = {
            "*": "+",
            "-": "/",
            Je: "=",
            "+": "*",
            "/": "-",
            "=": "_"
        };

    function Xk(a) {
        return a ? a.replace(/[+/=]/g, function(b) {
            return Wk[b] || b
        }) : ""
    }

    function Yk(a) {
        var b = "",
            c = 0;
        if (!a) return "";
        for (; a.length % 4;) a += "=";
        do {
            var d = Da("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                e = Da("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                f = Da("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                g = Da("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++));
            if (0 > d || 0 > e || 0 > f || 0 > g) return "";
            var h = d << 18 | e << 12 | f << 6 | g;
            d = h >> 16 & 255;
            e = h >> 8 &
                255;
            h &= 255;
            b = 64 === f ? b + String.fromCharCode(d) : 64 === g ? b + String.fromCharCode(d, e) : b + String.fromCharCode(d, e, h)
        } while (c < a.length);
        return b
    }

    function Zk(a) {
        var b = void 0 === b ? !1 : b;
        for (var c = a.length, d = c - c % 3, e = [], f = 0; f < d; f += 3) {
            var g = (a[f] << 16) + (a[f + 1] << 8) + a[f + 2];
            e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 18 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g & 63])
        }
        switch (c - d) {
            case 1:
                a = a[d] << 4;
                e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [a >>
                    6 & 63
                ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [a & 63], "=", "=");
                break;
            case 2:
                a = (a[d] << 10) + (a[d + 1] << 2), e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [a >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [a >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [a & 63], "=")
        }
        e = U("", e);
        return b ? Xk(e) : e
    }

    function $k(a) {
        for (var b = "", c = 0; c < a.length;) {
            var d = a.charCodeAt(c);
            128 > d ? (b += String.fromCharCode(d), c++) : 191 < d && 224 > d ? (b += String.fromCharCode((d & 31) << 6 | a.charCodeAt(c + 1) & 63), c += 2) : (b += String.fromCharCode((d & 15) << 12 | (a.charCodeAt(c + 1) & 63) << 6 | a.charCodeAt(c + 2) & 63), c += 3)
        }
        return b
    }

    function al(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            128 > d ? b.push(d) : (127 < d && 2048 > d ? b.push(d >> 6 | 192) : (b.push(d >> 12 | 224), b.push(d >> 6 & 63 | 128)), b.push(d & 63 | 128))
        }
        return b
    }

    function bl(a) {
        return a ? Zk(al(a)) : null
    }
    var cl = L(function(a) {
        return pb(/tizen/i, a)
    });

    function dl(a) {
        if (!cl(a)) return null;
        a = J(a, "webapis.adinfo.getTIFA");
        if (y(a)) try {
            return bl(a())
        } catch (b) {}
        return null
    }

    function el(a) {
        if (!cl(a)) return null;
        a = J(a, "tizen.systeminfo.getCapability");
        if (y(a)) try {
            return bl(a("http://tizen.org/system/tizenid"))
        } catch (b) {}
        return null
    }

    function fl(a) {
        if (!cl(a)) return null;
        a = J(a, "tizen.systeminfo.getCapabilities");
        try {
            if (y(a)) return bl(J(a(), "duid"))
        } catch (b) {}
        return null
    }
    var gl = L(function(a) {
        return pb(/webos|web0s/i, a)
    });

    function hl(a) {
        var b = J(a, "webOS.service.request");
        return y(b) ? new Z(function(c) {
            var d = {},
                e = {};
            b("luna://com.webos.service.sm", (e.method = "deviceid/getIDs", e.parameters = (d.idType = ["LGUDID"], d), e.onSuccess = function(f) {
                c(bl(J(f, "idList.0.idValue")))
            }, e))
        }) : Z.resolve(null)
    }

    function il(a, b) {
        try {
            var c = b.localStorage.getItem(a);
            return c && Zk(al(c))
        } catch (d) {}
        return null
    }
    var jl = L(G("panoramaId", il)),
        kl = L(function(a) {
            return il("pubcid.org", a) || il("_pubCommonId", a)
        }),
        ll = L(G("_sharedid", il)),
        ml = L(function(a, b) {
            if (b.Aa) return null;
            var c = Jd(a, "").o("_ga");
            return c && Zk(al(c))
        }, N(mb, R)),
        nl = [
            ["domainLookupEnd", "domainLookupStart"],
            ["connectEnd", "connectStart"],
            ["responseStart", "requestStart"],
            ["responseEnd", "responseStart"],
            ["fetchStart", "navigationStart"],
            ["redirectEnd", "redirectStart"],
            [function(a, b) {
                return J(b, "redirectCount") || J(a, "navigation.redirectCount")
            }],
            ["domInteractive",
                "domLoading"
            ],
            ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
            ["domComplete", "navigationStart"],
            ["loadEventStart", "navigationStart"],
            ["loadEventEnd", "loadEventStart"],
            ["domContentLoadedEventStart", "navigationStart"]
        ],
        ol = [
            ["domainLookupEnd", "domainLookupStart"],
            ["connectEnd", "connectStart"],
            ["responseStart", "requestStart"],
            ["responseEnd", "responseStart"],
            ["fetchStart"],
            ["redirectEnd", "redirectStart"],
            ["redirectCount"],
            ["domInteractive", "responseEnd"],
            ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
            ["domComplete"],
            ["loadEventStart"],
            ["loadEventEnd", "loadEventStart"],
            ["domContentLoadedEventStart"]
        ],
        pl = {},
        ql = (pl.responseEnd = 1, pl.domInteractive = 1, pl.domContentLoadedEventStart = 1, pl.domContentLoadedEventEnd = 1, pl.domComplete = 1, pl.loadEventStart = 1, pl.loadEventEnd = 1, pl.unloadEventStart = 1, pl.unloadEventEnd = 1, pl.secureConnectionStart = 1, pl),
        rl = L(Nd);

    function sl(a, b, c) {
        return M(function(d) {
            var e = n(d),
                f = e.next().value;
            e = e.next().value;
            if (y(f)) return f(a, b) || null;
            if (1 === d.length) return b[f] ? Math.round(b[f]) : null;
            var g;
            !(g = b[f] && b[e]) && (g = 0 === b[f] && 0 === b[e]) && (g = n(d), d = g.next().value, g = g.next().value, g = !(ql[d] || ql[g]));
            if (!g) return null;
            f = Math.round(b[f]) - Math.round(b[e]);
            return 0 > f || 36E5 < f ? null : f
        }, c)
    }

    function tl(a, b) {
        var c = a.length ? M(function(d, e) {
            var f = b[e];
            return f === d ? null : f
        }, a) : b;
        a.length = 0;
        M(N(lb, Za("push", a)), b);
        return Qb(Pa(null), c).length === a.length ? null : c
    }

    function ul(a, b, c) {
        if ((void 0 === c.D ? {} : c.D).nohit) return null;
        a = fe(a);
        if (!a) return null;
        var d = c = null;
        J(a, "getEntriesByType") && (d = J(a.getEntriesByType("navigation"), "0")) && (c = ol);
        if (!c) {
            var e = J(a, "timing");
            e && (c = nl, d = e)
        }
        if (!c) return null;
        a = sl(a, d, c);
        b = R(b);
        b = rl(b);
        return (b = tl(b, a)) && U(",", b)
    }
    var vl = L(Md),
        wl = L(function(a) {
            var b = J(a, "webkitRequestFileSystem");
            if (y(b) && !Cc(a)) return (new Z(D(b, a, 0, 0))).then(function() {
                var d = J(a, "navigator.storage") || {};
                return d.estimate ? d.estimate() : {}
            }).then(function(d) {
                return (d = d.quota) && 12E7 > d ? !0 : !1
            })["catch"](G(!0, lb));
            if (xb(a)) return Z.resolve(z(J(a, "navigator.serviceWorker")));
            b = J(a, "openDatabase");
            if (wc(a) && y(b)) {
                var c = !1;
                try {
                    b(null, null, null, null)
                } catch (d) {
                    c = !0
                }
                return Z.resolve(c)
            }
            return Z.resolve(!J(a, "indexedDB") && (J(a, "PointerEvent") || J(a, "MSPointerEvent")))
        });

    function xl(a) {
        if (zc(a)) return null;
        var b = vl(a),
            c = b.Tc;
        z(c) && (b.Tc = null, wl(a).then(function(d) {
            b.Tc = d
        }));
        return c ? 1 : null
    }
    var yl = /(\?|&)turbo_uid=([\w\d]+)($|&)/,
        zl = L(function(a, b) {
            var c = Kd(a),
                d = T(a).search.match(yl);
            return d && 2 <= d.length ? (d = n(d), d.next(), d.next(), d = d.next().value, b.Aa || c.B("turbo_uid", d), d) : (c = c.o("turbo_uid")) ? c : ""
        });

    function Al(a) {
        return !A(a) && 1 === a.nodeType
    }

    function Bl(a, b) {
        if (A(b)) return !1;
        if (Me(b)) return Bl(a, b.parentNode);
        if (!Al(b)) return !1;
        var c = Te(a);
        if (!c) return !1;
        var d = c.call(b, ".ym-hide-content,.ym-hide-content *");
        return d && c.call(b, ".ym-show-content,.ym-hide-content .ym-show-content *") ? !1 : d
    }
    var Cl = ["password", "passwd", "pswd"],
        Dl = ya(String.prototype.repeat, "repeat");

    function El(a, b) {
        for (var c = "", d = 0; d < b; d += 1) c += a;
        return c
    }
    var Fl = Dl ? function(a, b) {
            return Dl.call(a, b)
        } : El,
        Gl = G(!0, function(a, b, c, d) {
            c = b.length && (c - d.length) / b.length;
            if (0 >= c) return d;
            b = Fl(b, c);
            return a ? b + d : d + b
        });

    function Hl(a, b, c) {
        xa("requestIdleCallback", a.requestIdleCallback) && xa("cancelIdleCallback", a.cancelIdleCallback) ? a.requestIdleCallback(V(a, c + ".sdl.ric", b), {
            timeout: 1E3
        }) : tf(a, b, 1E3, c + ".sdl")
    }
    var Il = W("pa.plgn", function(a, b) {
            var c = yi(a, b);
            c && c.ca.C(["pluginInfo"], V(a, "c.plgn", function() {
                var d = Q(a);
                d.B("cmc", d.o("cmc", 0) + 1);
                return ch(b)
            }))
        }),
        Jl = L(function(a) {
            return {
                Me: a,
                Ha: null,
                Ka: []
            }
        });

    function Kl(a, b, c, d) {
        var e = Ll;
        if (J(d, "settings.ifd")) return a = Q(a), e = a.o("ifdp", {}), c = R(c), e[c] || (e[c] = 1, a.B("ifdp", e)), null;
        c = Jl(e);
        O(b, c.Ka) || c.Ka.push(b);
        if (Sa(c.Ha)) {
            b = Pe(a);
            if (!b) return null;
            b = b("iframe");
            P(b.style, {
                display: "none",
                width: "1px",
                height: "1px",
                visibility: "hidden"
            });
            b.src = e;
            a = Ve(a);
            if (!a) return null;
            a.appendChild(b);
            c.Ha = b
        } else(a = J(c.Ha, "contentWindow")) && a.postMessage("frameReinit", "*");
        return c.Ha
    }

    function Ml(a) {
        var b = Jl(Ll);
        O(a, b.Ka) && (b.Ka = Qb(N(Pa(a), nb), b.Ka), b.Ka.length || (Qe(b.Ha), b.Ha = null))
    }
    var Nl = N(u, F([1, null], Kb)),
        Ol = /^https?:\/\//,
        Pl = {
            1882689622: 1,
            2318205080: 1,
            3115871109: 1,
            1996539654: 1,
            2065498185: 1,
            823651274: 1,
            12282461: 1,
            1555719328: 1,
            1417229093: 1,
            138396985: 1
        };

    function Ql(a) {
        a = n(a.replace(Ol, "").split("?")).next().value;
        var b = a + "?",
            c = Sj(b);
        if (ua[c]) return [b, c, !0];
        b = Sj(a);
        return ua[b] ? [a, b, !0] : [a, b, !1]
    }
    var Rl = L(function(a) {
        a = fe(a);
        if (!a || !y(a.getEntriesByType)) return null;
        a = a.getEntriesByType("resource");
        return (a = Le(N(K("name"), Ql, K("2")), a)) ? Mb(a.transferSize) : null
    });

    function Sl(a, b) {
        var c = Tk(function(d, e) {
            return d[1].T > e[1].T ? 1 : -1
        }, dc(we));
        c = M(function(d) {
            var e = n(d);
            d = e.next().value;
            var f = e.next().value.rb;
            e = I(b, d) && !A(b[d]);
            d = b[d] !== (f || lb)(void 0);
            return Mb(e && d)
        }, c);
        return vb(U("", c))
    }
    var Tl = {},
        Ul = (Tl.navigate = 0, Tl.reload = 1, Tl.back_forward = 2, Tl.prerender = 3, Tl),
        Vl = L(function(a) {
            var b = fe(a);
            if (!b) return null;
            var c = y(b.getEntriesByType) ? b.getEntriesByType("navigation")[0] : null;
            if (c) return (a = J(c, "type")) && I(Ul, a) ? Ul[a] : null;
            b = J(b, "navigation.type");
            return rb(a, b) && 2 >= b ? b : null
        }),
        Wl = "ar:1:pv:1:v:2710:vf:" + ta.version;

    function Xl(a, b, c) {
        var d = "https://" + Rd + "/watch/" + c;
        try {
            var e = n(b),
                f = n(e.next().value);
            f.next();
            var g = f.next().value
        } catch (h) {
            return function() {
                return Z.resolve()
            }
        }
        return function(h) {
            var k = {};
            k = (k["browser-info"] = Wl, k["page-url"] = a.location && "" + a.location.href, k);
            return g && (h = Ae(a, h)) ? g(d, {
                Da: k,
                N: [],
                O: "site-info=" + pd(h)
            })["catch"](r) : Z.resolve()
        }
    }
    var Yl = {};

    function Zl(a, b) {
        return {
            K: function(c, d) {
                var e = c.D,
                    f = c.G;
                !Yl[b.id] && f.o("pv") && b.exp && !e.nohit && (e.exp = b.exp, Yl[b.id] = !0);
                d()
            }
        }
    }
    var $l = W("exps.int", function(a, b) {
            var c = {};
            return c.experiments = function(d, e, f) {
                if (u(d) && !(0 >= d.length)) {
                    var g = Lh(a, "e", b),
                        h = Sh(b).url,
                        k = {},
                        l = {};
                    d = g({
                        G: Wg((k.ex = 1, k.ar = 1, k)),
                        D: (l["page-url"] = h || T(a).href, l.exp = d, l)
                    }, b);
                    return Nh(a, "exps.s", d, e || r, f)
                }
            }, c
        }),
        am = [],
        bm = W("p.fh", function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = He(a),
                d = X(a),
                e = c.o("wasSynced"),
                f = {
                    id: 3,
                    M: "0"
                };
            if (b && e && e.time + 864E5 > d(gf)) return Z.resolve(e);
            e = {};
            var g = {};
            return Lh(a, "f", f)({
                G: Wg((e.pv = 1, e)),
                D: (g["page-url"] = T(a).href, g["page-ref"] = a.document.referrer,
                    g)
            }, f).then(function(h) {
                var k = {};
                h = (k.time = d(gf), k.params = J(h, "settings"), k);
                c.B("wasSynced", h);
                return h
            })["catch"](V(a, "f.h"))
        }),
        cm = Na(function(a, b) {
            var c, d = new Z(function(f) {
                    c = f
                }),
                e = {};
            d = (e[a] = {
                Xb: c,
                promise: d,
                Yb: !1
            }, e);
            b[a] = d[a];
            return Ra(d)
        });

    function dm(a, b) {
        Wi("hidv2")(Vi(R(a))).then(b)
    }

    function em(a, b) {
        return {
            K: function(c, d) {
                dm(b, function(e) {
                    if (e) {
                        c.D || (c.D = {});
                        var f = {};
                        P(c.D, (f.hidv2 = e, f))
                    }
                    d()
                })
            }
        }
    }

    function fm(a, b) {
        return {
            K: function(c, d) {
                c.H || (c.H = {});
                var e = c.H;
                var f = Wi("hidv2")(cm(R(b)));
                e.Td = f;
                d()
            },
            S: function(c, d) {
                var e = J(c.Zb, "settings.hidv2"),
                    f = c.H.Td;
                f(Ui(R(b), e));
                d()
            }
        }
    }
    var gm = "et etms w v z i u vf".split(" "),
        hm = Na(function(a, b) {
            0 === parseFloat(J(b, "settings.c_recp")) && (a.Rb.B("ymoo" + a.X, a.ld(hf)), a.Bb && a.Bb.destruct && a.Bb.destruct())
        });

    function im(a, b) {
        return {
            K: function(c, d) {
                var e = c.D;
                e.wmode = "0";
                e["wv-hit"] = e["wv-hit"] || "" + mf(a);
                e["page-url"] = e["page-url"] || T(a).href;
                var f = {};
                e = {
                    ha: {
                        U: "webvisor/" + b.id
                    },
                    J: P(c.J || {}, {
                        Ca: (f["Content-Type"] = "text/plain", f),
                        ab: "POST"
                    }),
                    D: e
                };
                P(c, e);
                d()
            }
        }
    }

    function jm(a, b, c) {
        var d = Hh(a, b, "p", ["f", "x"]);
        b = mg(a, c || "p", b);
        var e = fh(a, d, b);
        return function(f) {
            f = P({
                J: {
                    N: ["mms.p"]
                }
            }, f);
            return e(f)
        }
    }
    var km = "resize scroll mousemove mousedown click windowfocus keydown orientationchange change focus touchmove touchstart".split(" "),
        lm = "id pageTitle stamp chars authors updateDate publicationDate pageUrlCanonical topics rubric".split(" ");

    function mm(a, b, c, d, e) {
        var f = this;
        this.ob = !1;
        this.oa = {};
        this.scroll = {
            x: 0,
            y: 0
        };
        this.lb = this.Oc = 0;
        this.Ub = this.Sc = "";
        this.P = [];
        this.cc = this.yb = 0;
        this.Na = {
            jb: 0,
            w: 0
        };
        this.buffer = [];
        this.yd = lm;
        this.flush = function() {
            f.cc = tf(f.l, f.flush, 2500, "pub.f");
            var g = f.Ib();
            if (f.buffer.length || g) {
                var h = pc(f.buffer);
                g && h.push(g);
                f.Sc = f.Ub;
                f.te.ra(h)(wf(V(f.l, "p.b.st"), function(k) {
                    k && f.se(k)
                }))
            }
        };
        this.se = d;
        this.te = c;
        this.bb = D(this.bb, this);
        this.Ib = D(this.Ib, this);
        this.flush = D(this.flush, this);
        this.l = a;
        this.X = e;
        this.vb =
            b;
        this.Pb = "pai" + b.id;
        nm(this);
        this.Bc = Xc(this.l);
        this.time = X(this.l);
        om(this);
        this.Jb = Q(this.l);
        this.lc = null
    }
    aa = mm.prototype;
    aa.start = function() {
        this.cc = tf(this.l, this.flush, 2500, "pub.s");
        if (!this.ob) {
            this.Bc.C(this.l, km, this.bb);
            var a = this.Jb.o(this.Pb, []),
                b = !a.length;
            a.push(D(this.Zd, this));
            this.Jb.V(this.Pb, a);
            b && this.Vc();
            this.lc = Xc(this.l).C(this.l, ["click"], D(this.ue, this));
            this.bb({
                type: "page",
                target: this.l
            })
        }
    };
    aa.stop = function() {
        this.lc && this.lc();
        this.Bc.ua(this.l, km, this.bb);
        this.ob = !0;
        this.flush();
        sf(this.l, this.cc)
    };
    aa.Vc = function() {
        var a = this;
        V(this.l, "p.ic" + this.vb.id, function() {
            if (!a.ob) {
                var b = a.Jb.o(a.Pb),
                    c = pm(a.vb);
                M(function(d) {
                    var e = M(function(f) {
                        return P({}, f)
                    }, c);
                    y(d) && d(e)
                }, b);
                a.yb = tf(a.l, D(a.Vc, a), 1E3, "p")
            }
        })()
    };
    aa.Zd = function(a) {
        this.ob || (qm(this, a), rm(this), sm(this))
    };
    aa.Fd = function(a, b) {
        return (a.ac || 0) <= (b.ac || 0) ? b : a
    };
    aa.ue = function(a) {
        if (this.P.length) {
            a = Pi(a);
            var b = T(this.l).hostname;
            a && id(a.hostname) === id(b) && (a = H(this.Fd, this.P[0], this.P).id, b = mf(this.l), Ie(this.l, this.X.split(":")[0]).B("pai", a + "-" + b))
        }
    };
    aa.bb = function(a) {
        var b = this;
        V(this.l, "p.ec." + this.vb.id, function() {
            try {
                var c = a.type;
                var d = a.target
            } catch (h) {
                return
            }
            var e = "page" === c;
            ("scroll" === c || e) && O(d, [b.l, b.l.document, b.l.document.documentElement, Ue(b.l)]) && nm(b);
            ("resize" === c || e) && om(b);
            c = b.time(gf);
            var f = Math.min(c - b.Oc, 5E3);
            b.lb += Math.round(f);
            b.Oc = c;
            if (b.oa && b.scroll && b.Na) {
                var g = b.Na.jb * b.Na.w;
                b.P = M(function(h) {
                    var k = P({}, h),
                        l = b.oa[k.id],
                        m = $e(h.Qa);
                    if (!l || Dj("html", b.l, k.element) !== b.l.document.documentElement || !m) return k;
                    h = b.l.Math;
                    l = h.max((b.scroll.y + b.Na.jb - l.y) / l.height, 0);
                    var p = m.height * m.width,
                        q = b.Na,
                        v = m.top,
                        t = m.bottom,
                        x = m.left,
                        E = q.w;
                    q = q.jb;
                    var C = b.l.Math;
                    m = C.min(C.max(m.right, 0), E) - C.min(C.max(x, 0), E);
                    m *= C.min(C.max(t, 0), q) - C.min(C.max(v, 0), q);
                    k.ac = m / g;
                    k.visibility = m / p;
                    if (.9 <= k.visibility || .1 <= k.ac) k.involvedTime += f;
                    k.maxScrolled = h.round(1E4 * l) / 1E4;
                    return k
                }, b.P);
                c = {};
                d = {};
                Pd(b.l, (d.name = "publishers", d.counterKey = b.X, d.data = (c.involvedTime = b.lb, c.contentItems = M(function(h) {
                        var k = {};
                        return P((k.contentElement = h.Qa, k), h)
                    },
                    b.P), c), d))
            }
        })()
    };

    function qm(a, b) {
        var c = M(function(d) {
            return d.id
        }, a.P);
        a.P = a.P.concat(Qb(function(d) {
            return !O(d.id, c)
        }, b))
    }

    function om(a) {
        var b = n(We(a.l) || Xe(a.l)),
            c = b.next().value;
        b = b.next().value;
        a.Na = {
            w: c,
            jb: b
        }
    }

    function rm(a) {
        V(a.l, "p.um." + a.vb.id, function() {
            var b = [];
            nm(a);
            a.oa = H(function(c, d) {
                if (Dj("html", a.l, d.element) !== a.l.document.documentElement) return b.push(d), delete c[d.id], c;
                var e = {};
                e = (e.id = d.id, e.involvedTime = Math.max(d.involvedTime, 0), e.maxScrolled = d.maxScrolled || 0, e.chars = d.update ? d.update("chars") || 0 : 0, e);
                if (d.Qa) {
                    var f = $e(d.Qa);
                    f && (e.x = Math.max(Math.round(f.left) + a.scroll.x, 0), e.y = Math.max(Math.round(f.top) + a.scroll.y, 0), e.width = Math.round(f.width), e.height = Math.round(f.height))
                }
                c[d.id] =
                    e;
                return c
            }, {}, a.P);
            M(function(c) {
                c = nc(a.l)(c, a.P);
                a.P.splice(c, 1)
            }, b)
        })()
    }
    aa.Ib = function() {
        var a = M(G(this.oa, J), ec(this.oa));
        if (a.length && (this.Ub = Ae(this.l, a), this.Sc !== this.Ub)) {
            var b = {},
                c = {};
            return c.type = "publishersHeader", c.data = (b.articleMeta = a || [], b.involvedTime = this.lb, b), c
        }
        return null
    };

    function sm(a) {
        if (a.P.length) {
            var b = M(function(c) {
                var d = H(function(f, g) {
                    c[g] && (f[g] = c[g]);
                    return f
                }, {}, a.yd);
                c.bd = !0;
                var e = {};
                return e.type = "articleInfo", e.stamp = d.stamp, e.data = d, e
            }, Qb(function(c) {
                return !c.bd
            }, a.P));
            b.length && (a.buffer = a.buffer.concat(b), Qh(a.l, a.X, ["pdf", b]))
        }
    }

    function nm(a) {
        a.scroll = {
            x: a.l.pageXOffset || J(a.l, "document.documentElement.scrollLeft") || 0,
            y: a.l.pageYOffset || J(a.l, "document.documentElement.scrollLeft") || 0
        }
    }
    var tm = {},
        um = (tm[1] = 500, tm[2] = 500, tm[3] = 0, tm);

    function vm(a, b, c) {
        var d = b.getAttribute("itemtype");
        c = tj('[itemprop~="' + c + '"]', b);
        return d ? Qb(function(e) {
            return e.parentNode && Dj("[itemtype]", a, e.parentNode) === b
        }, c) : c
    }

    function wm(a, b, c) {
        return (a = vm(a, b, c)) && a.length ? a[0] : null
    }

    function xm(a) {
        if (!a) return "";
        a = w(a) ? a : [a];
        return a.length ? a[0].getAttribute("content") || Ne(a[0]) : ""
    }

    function zm(a) {
        return a ? a.attributes && a.getAttribute("datetime") ? a.getAttribute("datetime") : xm(a) : ""
    }
    var Am = ["topics", "rubric", "authors"];

    function Bm(a, b) {
        var c = this;
        this.id = "a";
        this.Kb = !1;
        this.Ta = {};
        this.Ma = {
            "schema.org": "Article NewsArticle Movie BlogPosting Review Recipe Answer".split(" "),
            Qc: ["article"]
        };
        var d = {};
        this.$a = (d.Answer = 3, d.Review = 2, d);
        this.Ec = L(function(e, f, g) {
            var h = {};
            Qh(c.l, c.X, "pfi", (h.field = e, h.itemField = f, h.value = g, h))
        }, function(e, f, g) {
            return "" + e + f + g
        });
        this.Ee = function(e) {
            M(function(f) {
                e[f] && (e[f] = H(function(g, h) {
                    var k = h.name,
                        l = h.position;
                    if (!k) return c.Ec(f, "name", k), g;
                    if ("string" === typeof l) {
                        k = sb(l);
                        if (null ===
                            k || c.l.isNaN(k)) return c.Ec(f, "position", l), g;
                        h.position = k
                    }
                    g.push(h);
                    return g
                }, [], e[f]))
            }, Am);
            return e
        };
        this.Gd = L(function(e, f) {
            var g = {};
            Qh(c.l, c.X, ["pcs", f], (g.chars = f.chars, g.limit = um[f.type], g))
        });
        this.l = a;
        this.root = Ve(a);
        this.X = b
    }
    Bm.prototype.ma = function(a) {
        return a.element
    };

    function Cm(a, b, c) {
        var d;
        V(a.l, "P.s." + c, function() {
            d = a.Ta[c].call(a, b)
        })();
        return d
    }

    function Dm(a, b) {
        var c = P({}, b);
        if (a.Kb && !c.id && O(b.type, [3, 2])) {
            var d = U(", ", M(K("name"), c.authors || []));
            c.pageTitle = d + ": " + c.pageTitle
        }
        if (!c.pageTitle) {
            a: {
                d = c.Qa;
                for (var e = 1; 5 >= e; e += 1) {
                    var f = xm(uj("h" + e, d));
                    if (f) {
                        d = f;
                        break a
                    }
                }
                d = void 0
            }
            c.pageTitle = d
        }
        c.pageUrlCanonical || (d = c.id, d = ("string" !== typeof d ? 0 : /^(https?:)\/\//.test(d)) ? c.id : (d = uj('[rel="canonical"]', a.root)) ? d.href : void 0, c.pageUrlCanonical = d);
        c.id || (c.id = c.pageTitle || c.pageUrlCanonical);
        return c
    }
    Bm.prototype.ea = function(a) {
        var b = this,
            c = {},
            d = this.ma(a);
        if (!d) return null;
        c.type = a.type;
        M(function(f) {
            c[f] = Cm(b, a, f)
        }, ec(this.Ta));
        var e = X(this.l);
        c.stamp = e(kf);
        c.element = a.element;
        c.Qa = d;
        c = this.Ee(Dm(this, c));
        c.id = c.id ? Sj(c.id) : 1;
        c.update = function(f) {
            return b.ma(a) ? Cm(b, a, f) : void 0
        };
        return c
    };
    Bm.prototype.getType = function() {
        return 1
    };
    Bm.prototype.ib = function() {
        return []
    };

    function pm(a) {
        var b = a.ib(),
            c = 1;
        return H(function(d, e) {
            var f = a.ea({
                element: e,
                type: a.getType(e)
            }) || [];
            w(f) || (f = [f]);
            f = H(function(g, h) {
                var k = g.values,
                    l = g.Ic;
                h && h.chars > um[h.type] && !O(h.id, l) ? (k.push(h), l.push(h.id)) : h && h.chars <= um[h.type] && a.Gd(h.id, h);
                return {
                    values: k,
                    Ic: l
                }
            }, {
                values: [],
                Ic: M(K("id"), d)
            }, f).values;
            return d.concat(M(function(g) {
                var h = {};
                g = P((h.index = c, h.bd = !1, h.involvedTime = 0, h), g);
                c += 1;
                return g
            }, f))
        }, [], b)
    }

    function Em() {
        Bm.apply(this, arguments);
        this.id = "j";
        this.Kb = !0;
        this.xc = U(",", ['script[type="application/ld+json"]', 'script[type="application/json+ld"]', 'script[type="ld+json"]', 'script[type="json+ld"]']);
        var a = {};
        this.Ta = (a.id = function(b) {
            var c = b.data["@id"];
            b = b.data.mainEntity || b.data.mainEntityOfPage;
            !c && B(b) && (c = b["@id"]);
            return c
        }, a.chars = function(b) {
            var c = b.data;
            return u(c.text) ? c.text.length : Ne(this.ma(b)).length
        }, a.authors = function(b) {
            b = b.data;
            var c = [];
            c = c.concat(Fm(b, "author"));
            c = c.concat(Fm(b.mainEntity,
                "author"));
            return c.concat(Fm(b.mainEntityOfPage, "author"))
        }, a.pageTitle = function(b) {
            var c = b.data,
                d = c.headline || "";
            c.alternativeHeadline && (d += " " + c.alternativeHeadline);
            "" === d && (c.name ? d = c.name : c.itemReviewed && (d = c.itemReviewed));
            3 === b.type && B(c.parentItem) && (d = c.parentItem.text);
            return d
        }, a.updateDate = function(b) {
            return b.data.dateModified || ""
        }, a.publicationDate = function(b) {
            return b.data.datePublished || ""
        }, a.pageUrlCanonical = function(b) {
            return b.data.url
        }, a.topics = function(b) {
            return Fm(b.data, "about", ["name", "alternateName"])
        }, a.rubric = function(b) {
            var c = this,
                d = this.ma(b);
            b = Rb(M(function(e) {
                e = ze(c.l, Ne(e));
                if (B(e) || w(e)) {
                    var f = Gm(e);
                    if (f) return H(function(g, h) {
                        return g ? g : B(h) && "BreadcrumbList" === h["@type"] ? h : g
                    }, null, f);
                    if ("BreadcrumbList" === e["@type"]) return e
                }
                return null
            }, [b.element].concat(tj(this.xc, this.l.document.body === d ? this.l.document.documentElement : d))));
            return b.length && (b = b[0].itemListElement, w(b)) ? Rb(M(function(e) {
                return B(e) && e.item && B(e.item) && !c.l.isNaN(e.position) ? {
                    name: e.item.name ||
                        e.name,
                    position: e.position
                } : null
            }, b)) : []
        }, a)
    }
    ra(Em, Bm);

    function Fm(a, b, c) {
        c = void 0 === c ? ["name"] : c;
        if (!B(a) || !a[b]) return [];
        a = a[b];
        a = w(a) ? a : [a];
        a = Rb(M(function(d) {
            return d ? "string" === typeof d ? d : B(d) ? H(function(e, f) {
                return e || "" + d[f]
            }, "", c) : null : null
        }, a));
        return M(function(d) {
            var e = {};
            return e.name = d, e
        }, a)
    }
    Em.prototype.ma = function(a) {
        var b = a.element,
            c = a.data || {};
        a = c["@id"];
        var d = c.url;
        c = null;
        d && u(d) && (c = Hm(this, d));
        !c && a && u(a) && (c = Hm(this, a));
        c || (c = a = b.parentNode, !Dj("head", this.l, b) && a && 0 !== Ne(a).length) || (c = this.l.document.body);
        return c
    };

    function Hm(a, b) {
        try {
            var c = lh(a.l, b).hash;
            if (c) {
                var d = a.l.document.getElementById(c.slice(1));
                if (d) return d
            }
        } catch (e) {}
        return null
    }
    Em.prototype.ea = function(a) {
        var b = this,
            c = a.element,
            d = a.data;
        if (!d && (d = ze(this.l, Ne(c)), !d || !/schema\.org/.test(d["@context"]) && !w(d))) return null;
        var e = Gm(d);
        if (e) return M(function(g) {
            return B(g) && O(g["@type"], b.Ma["schema.org"]) ? Bm.prototype.ea.call(b, {
                element: c,
                data: g,
                type: b.$a[g["@type"]] || 1
            }) : null
        }, e);
        a.data = d;
        if ("QAPage" === a.data["@type"]) {
            var f = a.data.mainEntity || a.data.mainEntityOfPage;
            if (!f) return null
        }
        "Question" === a.data["@type"] && (f = a.data);
        return f ? (a = Fb(G(f, J), ["acceptedAnswer", "suggestedAnswer"]),
            M(function(g) {
                if (!B(g) || !O(g["@type"], b.Ma["schema.org"])) return null;
                var h = {};
                g = {
                    element: c,
                    type: b.$a[g["@type"]] || 1,
                    data: P((h.parentItem = f, h), g)
                };
                return Bm.prototype.ea.call(b, g)
            }, a)) : O(a.data["@type"], this.Ma["schema.org"]) ? Bm.prototype.ea.call(this, P(a, {
            type: this.$a[a.data["@type"]] || 1
        })) : null
    };
    Em.prototype.ib = function() {
        return tj(this.xc, this.root)
    };

    function Gm(a) {
        if (w(a)) return a;
        if (a && w(a["@graph"])) return a["@graph"]
    }

    function Im() {
        Bm.apply(this, arguments);
        this.id = "s";
        this.Kb = !0;
        this.Be = Za("exec", new RegExp("schema.org\\/(" + U("|", ec(this.$a)) + ")$"));
        var a = {};
        this.Ta = (a.id = function(b) {
            b = b.element;
            var c = wm(this.l, b, "identifier");
            return c ? xm(c) : (c = wm(this.l, b, "mainEntityOfPage")) && c.getAttribute("itemid") ? c.getAttribute("itemid") : null
        }, a.chars = function(b) {
            var c = 0;
            b = b.element;
            for (var d = ["articleBody", "reviewBody", "recipeInstructions", "description", "text"], e = 0; e < d.length; e += 1) {
                var f = wm(this.l, b, d[e]);
                if (f) {
                    c = xm(f).length;
                    break
                }
            }
            b = Ne(b);
            0 === c && b && (c += b.length);
            return c
        }, a.topics = function(b) {
            var c = this,
                d = vm(this.l, b.element, "about");
            return M(function(e) {
                var f = {
                    name: xm(e)
                };
                if (d = wm(c.l, e, "name")) f.name = xm(d);
                return f
            }, d)
        }, a.rubric = function(b) {
            var c = this;
            (b = uj('[itemtype$="schema.org/BreadcrumbList"]', b.element)) || (b = uj('[itemtype$="schema.org/BreadcrumbList"]', this.root));
            return b ? M(function(d) {
                return {
                    name: xm(wm(c.l, d, "name")),
                    position: xm(wm(c.l, d, "position"))
                }
            }, vm(this.l, b, "itemListElement")) : []
        }, a.updateDate = function(b) {
            return (b =
                wm(this.l, b.element, "dateModified")) ? zm(b) : ""
        }, a.publicationDate = function(b) {
            return (b = wm(this.l, b.element, "datePublished")) ? zm(b) : ""
        }, a.pageUrlCanonical = function(b) {
            b = vm(this.l, b.element, "url");
            if (b.length) {
                var c = b[0];
                return c.href ? c.href : xm(b)
            }
            return null
        }, a.pageTitle = function(b) {
            var c = "",
                d = b.element,
                e = wm(this.l, d, "headline");
            e && (c += xm(e));
            (e = wm(this.l, d, "alternativeHeadline")) && (c += " " + xm(e));
            "" === c && ((e = wm(this.l, d, "name")) || (e = wm(this.l, d, "itemReviewed")), e && (c += xm(e)));
            3 === b.type && (b = Dj('[itemtype$="schema.org/Question"]',
                this.l, d)) && (b = wm(this.l, b, "text")) && (c += xm(b));
            return c
        }, a.authors = function(b) {
            var c = this;
            b = vm(this.l, b.element, "author");
            return M(function(d) {
                var e = {};
                e = (e.name = "", e);
                if (/.+schema.org\/(Person|Organization)/.test(d.getAttribute("itemtype") || "")) {
                    var f = wm(c.l, d, "name");
                    f && (e.name = xm(f))
                }
                e.name || (e.name = d.getAttribute("content") || Ne(d) || d.getAttribute("href"));
                return e
            }, b)
        }, a)
    }
    ra(Im, Bm);
    Im.prototype.getType = function(a) {
        a = a.getAttribute("itemtype") || "";
        return (a = this.Be(a)) ? this.$a[a[1]] : 1
    };
    Im.prototype.ea = function(a) {
        return a.element && Ne(a.element).length ? Bm.prototype.ea.call(this, a) : null
    };
    Im.prototype.ib = function() {
        var a = U(",", M(function(b) {
            return '[itemtype$="schema.org/' + b + '"]'
        }, this.Ma["schema.org"]));
        return tj(a, this.root)
    };

    function Jm(a, b) {
        Bm.call(this, a, b);
        this.id = "o";
        var c = {};
        this.Ta = (c.chars = function(d) {
            d = this.ma(d);
            return Ne(d).length
        }, c.authors = function(d) {
            return Km(d.data.author)
        }, c.pageTitle = function(d) {
            return Lm(d.data.title) || ""
        }, c.updateDate = function(d) {
            return Lm(d.data.modified_time)
        }, c.publicationDate = function(d) {
            return Lm(d.data.published_time)
        }, c.pageUrlCanonical = function(d) {
            return Lm(d.data.url)
        }, c.rubric = function(d) {
            return Km(d.data.section)
        }, c.topics = function(d) {
            return Km(d.data.tag)
        }, c);
        this.Nd = new RegExp("^(og:)?((" +
            U("|", this.Ma.Qc) + "):)?")
    }
    ra(Jm, Bm);

    function Km(a) {
        if (a) {
            if (w(a)) return M(function(c) {
                var d = {};
                return d.name = c ? "" + c : null, d
            }, a);
            var b = {};
            return [(b.name = a ? "" + a : null, b)]
        }
        return []
    }

    function Lm(a) {
        return w(a) ? a.length ? "" + a[0] : null : a ? "" + a : null
    }
    Jm.prototype.ib = function() {
        var a = tj('meta[property="og:type"]', this.l.document.body);
        return [this.l.document.head].concat(a)
    };

    function Mm(a, b) {
        var c = b.element,
            d = {},
            e = a.ma(b);
        c = tj("meta[property]", c === a.l.document.head ? c : e);
        if (c.length) M(function(f) {
            try {
                if (f.parentNode === e || f.parentNode === a.l.document.head) {
                    var g = f.getAttribute("property").replace(a.Nd, ""),
                        h = xm(f);
                    d[g] ? w(d[g]) ? d[g].push(h) : d[g] = [d[g], h] : d[g] = h
                }
            } catch (k) {
                ee(a.l, "og.ed", k)
            }
        }, c);
        else return null;
        return O(d.type, a.Ma.Qc) ? P(b, {
            data: d
        }) : null
    }
    Jm.prototype.ma = function(a) {
        a = a.element;
        var b = this.l.document;
        return a === b.head ? b.body : a.parentNode
    };
    Jm.prototype.ea = function(a) {
        return (a = Mm(this, a)) ? Bm.prototype.ea.call(this, a) : null
    };

    function Nm(a) {
        this.l = a;
        this.type = "8"
    }
    Nm.isEnabled = function(a) {
        return !!a.JSON
    };
    Nm.prototype.ra = function(a) {
        return zf(Ae(this.l, a))
    };
    var Om = {};
    Em && (Om.json_ld = Em);
    Im && (Om.schema = Im, Om.microdata = Im);
    Jm && (Om.opengraph = Jm);
    var Pm = W("p.p", function(a, b) {
            var c = new Nm(a);
            if (xa("querySelectorAll", a.document.querySelectorAll) && c) {
                var d = [
                    [im, 0],
                    [Vf(gm), 1],
                    [bg, 2]
                ];
                d.push([em, 3]);
                var e = jm(a, b, d);
                d = Wg();
                var f = Ie(a, b.id),
                    g = f.o("pai");
                g && (f.wa("pai"), d.B("pai", g));
                f = {};
                var h = {
                        D: (f["wv-type"] = c.type, f),
                        G: d,
                        J: {}
                    },
                    k = function(l) {
                        for (var m = P({}, h), p = l.length, q = 0, v = 255, t = 255, x, E, C; p;) {
                            x = 21 < p ? 21 : p;
                            p -= x;
                            do E = "string" === typeof l ? l.charCodeAt(q) : l[q], q += 1, 255 < E && (C = E >> 8, E &= 255, E ^= C), v += E, t += v; while (--x);
                            v = (v & 255) + (v >> 8);
                            t = (t & 255) + (t >> 8)
                        }
                        p =
                            (v & 255) + (v >> 8) << 8 | (t & 255) + (t >> 8);
                        m.D["wv-check"] = "" + (65535 === p ? 0 : p);
                        m.J.O = l;
                        return e(m)["catch"](V(a, "s.ww.p"))
                    };
                yf(Zi(b, K("settings")))(wf(V(a, "ps.s"), V(a, "ps.sh", function(l) {
                    if (l = J(l, "publisher.schema")) {
                        qi(b) && (l = "microdata");
                        var m = Om[l];
                        if (m && c) {
                            var p = R(b);
                            m = new m(a, p);
                            m = new mm(a, m, c, k, p);
                            m.start();
                            var q = {};
                            Qh(a, p, "ps", (q.schema = l, q));
                            return D(m.stop, m)
                        }
                    }
                })))
            }
        }),
        Qm = ya(Array.prototype.reverse, "reverse");

    function Rm(a) {
        for (var b = [], c = a.length - 1; 0 <= c; --c) b[a.length - 1 - c] = a[c];
        return b
    }
    var Sm = Qm ? function(a) {
        return Qm.call(a)
    } : Rm;

    function Tm() {
        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
    }

    function Um() {
        return Tm() + Tm() + "-" + Tm() + "-" + Tm() + "-" + Tm() + "-" + Tm() + Tm() + Tm()
    }
    var Vm = Na(function(a, b) {
        var c = Math.pow(10, a);
        return Math.round(b * c) / c
    });

    function Wm(a, b, c, d) {
        var e = null;
        return {
            fn: function() {
                var f = sa.apply(0, arguments);
                Sa(e) || sf(a, e);
                e = tf(a, function() {
                    b.apply(null, ka(f));
                    e = null
                }, c, d + ".deb")
            },
            clear: function() {
                Sa(e) || (sf(a, e), e = null)
            }
        }
    }
    var Xm = W("fbq.o", function(a, b, c) {
            var d = J(a, "fbq");
            if (d && d.callMethod) {
                var e = function() {
                    var g = arguments,
                        h = d.apply(null, ka(g));
                    b(g);
                    return h
                };
                P(e, d);
                c && M(b, c);
                a.fbq = e
            } else {
                c = J(d, "queue");
                var f = tf(a, F([a, b, c && mc(c)], Xm), 1E3, "fbq.d")
            }
            return D(sf, null, a, f)
        }),
        Ym = {},
        Zm = (Ym.add_to_wishlist = "add-to-wishlist", Ym.begin_checkout = "begin-checkout", Ym.generate_lead = "submit-lead", Ym.add_payment_info = "add-payment-info", Ym),
        $m = {},
        an = ($m.AddToCart = "add-to-cart", $m.Lead = "submit-lead", $m.InitiateCheckout = "begin-checkout",
            $m.Purchase = "purchase", $m.CompleteRegistration = "register", $m.Contact = "submit-contact", $m.AddPaymentInfo = "add-payment-info", $m.AddToWishlist = "add-to-wishlist", $m.Subscribe = "subscribe", $m),
        bn = {},
        cn = (bn["1"] = Zm, bn["2"] = Zm, bn["3"] = Zm, bn["0"] = an, bn),
        dn = [an.AddToCart, an.Purchase];

    function en(a, b) {
        return function(c) {
            if (c) {
                var d = c.version;
                (c = J(cn, d + "." + c.gb)) && (b && O(c, dn) || a("ym-" + c + "-" + d))
            }
        }
    }
    var fn = Na(function(a, b) {
            var c = J(b, "event") || "";
            if (!(c = J(b, "ecommerce") && c && {
                    version: "3",
                    gb: c
                })) a: {
                if (w(b) || eb(b)) {
                    var d = n(Va(b));
                    c = d.next().value;
                    d = d.next().value;
                    if ("event" === c && d) {
                        c = {
                            version: "2",
                            gb: d
                        };
                        break a
                    }
                }
                c = void 0
            }
            c || (c = (c = J(b, "ecommerce")) && {
                version: "1",
                gb: U(",", ec(c))
            });
            c && a(c)
        }),
        gn = Na(function(a, b) {
            if (b) {
                var c = n(Va(b)),
                    d = c.next().value;
                c = c.next().value;
                "track" === d && a({
                    version: "0",
                    gb: c
                })
            }
        });

    function hn(a, b) {
        if (!b) return "";
        var c = [],
            d = J(a, "document");
        Dk(a, b, function(e) {
            if (e.nodeType === d.TEXT_NODE) var f = e.textContent;
            else e instanceof a.HTMLImageElement ? f = e.alt : e instanceof a.HTMLInputElement && (f = e.value);
            (f = f && vd(f)) && c.push(f)
        });
        return 0 === c.length ? "" : U(" ", c)
    }
    var jn = /[^\d.,]/g,
        kn = /[.,]$/;

    function ln(a) {
        a = mc(Yk(a));
        return M(function(b) {
            b = b.charCodeAt(0).toString(2);
            return Gl("0", 8, b)
        }, a)
    }

    function mn(a, b) {
        var c = null;
        try {
            c = b ? uj(b, a) : c
        } catch (d) {}
        return c
    }

    function nn(a, b, c) {
        if (b = Th(a, b)) a = fb(["dr", c || "" + ef(a, 10, 99)]), b.params(fb(["__ym", a]))
    }
    var on = W("ep.pp", function(a, b) {
            if (!b) return 0;
            a: {
                var c = b.replace(jn, "").replace(kn, "");
                for (var d = "0" === c[c.length - 1], e = c.length; 0 < e && !(3 < c.length - e + 1 && d); --e) {
                    var f = c[e - 1];
                    if (O(f, [",", "."])) {
                        c = f;
                        break a
                    }
                }
                c = ""
            }
            c = (d = c) ? b.split(d) : [b];
            d = d ? c[1] : "00";
            c = parseFloat(yd(c[0]) + "." + yd(d));
            d = Math.pow(10, 8) - .01;
            a.isNaN(c) ? c = 0 : (c = a.Math.min(c, d), c = a.Math.max(c, 0));
            return c
        }),
        pn = [
            [
                ["EUR", "\u20ac"], "978"
            ],
            [
                ["USD", "\u0423\\.\u0415\\.", "\\$"], "840"
            ],
            [
                ["UAH", "\u0413\u0420\u041d", "\u20b4"], "980"
            ],
            ["\u0422\u0413 KZT \u20b8 \u0422\u04a2\u0413 TENGE \u0422\u0415\u041d\u0413\u0415".split(" "),
                "398"
            ],
            [
                ["GBP", "\u00a3", "UKL"], "826"
            ],
            ["RUR RUB \u0420 \u0420\u0423\u0411 \u20bd P \u0420UB P\u0423\u0411 P\u0423B PY\u0411 \u0420Y\u0411 \u0420\u0423B P\u0423\u0411".split(" "), "643"]
        ],
        qn = L(function(a) {
            return new RegExp(U("|", a), "i")
        }),
        rn = L(function() {
            function a() {
                var k = h + "0",
                    l = h + "1";
                f[k] ? f[l] ? (h = h.slice(0, -1), --g) : (e[l] = c(8), f[l] = 1) : (e[k] = c(8), f[k] = 1)
            }

            function b() {
                var k = h + "1";
                f[h + "0"] ? f[k] ? (h = h.slice(0, -1), --g) : (h += "1", f[h] = 1) : (h += "0", f[h] = 1)
            }

            function c(k) {
                k = void 0 === k ? 1 : k;
                var l = d.slice(g, g + k);
                g += k;
                return l
            }
            for (var d = U("", ln("Cy2FcreLJLpYXW3BXFJqldVsGMwDcBw2BGnHL5uj1TKstzse3piMo3Osz+EqDotgqs1TIoZvKtMKDaSRFztgUS8qkqZcaETgKWM54tCpTXjV5vW5OrjBpC0jF4mspUBQGd95fNSfv+vz+g+Hze33Hg8by+Yen1PP6zsdl7PQCwX9mf+f7FMb9x/Pw+v2Pp8Xy74eTwuBwTt913u4On1XW6hxOO5nIzFam00tC218S0kaeugpqST+XliLOlMoTpRQkuewUxoy4CT3efWtdFjSAAm+1BkjIhyeU4vGOf13a6U8wzNY4bGo6DIUemE7N3SBojDr7ezXahpWF022y8mma1NuTnZbq8XZZlPStejfG/CsbPhV6/bSnA==")), e = {}, f = {}, g = 1, h = ""; g < d.length - 1;)("0" === c() ? b : a)();
            return e
        }),
        sn = W("ep.dec", function(a, b) {
            if (!b ||
                tc(a)) return [];
            var c = n(ln(b)),
                d = c.next().value,
                e = c.next().value,
                f = c.next().value;
            c = ja(c);
            if (2 !== vb(d)) return [];
            d = rn();
            c = U("", c);
            e = vb(e + f);
            for (var g = f = "", h = 0; g.length < e && c[h];) f += c[h], d[f] && (g += String.fromCharCode(vb(d[f])), f = ""), h += 1;
            d = ze(a, $k(g));
            return w(d) ? M(Ja, d) : []
        }),
        tn = W("ep.ent", function(a, b, c) {
            a = "" + ef(a, 10, 99);
            c = "" + 100 * b + c + a;
            if (16 < eb(c)) return "";
            c = Gl("0", 16, c);
            b = c.slice(0, 8);
            c = c.slice(-8);
            b = (+b ^ 92844).toString(35);
            c = (+c ^ 92844).toString(35);
            return "" + b + "z" + c
        });

    function un(a, b) {
        var c = mn(a.document.body, b);
        return c ? hn(a, c) : ""
    }

    function vn(a, b) {
        var c = un(a, b);
        return on(a, c)
    }
    var wn = N(un, W("ep.cp", function(a) {
        if (!a) return "643";
        var b = xd(a);
        return (a = Le(function(c) {
            c = n(c).next().value;
            return qn(c).test(b)
        }, pn)) ? a[1] : "643"
    }));

    function xn(a, b, c, d) {
        (c = tn(a, d, c)) && nn(a, b, c)
    }
    var yn = W("ep.ctp", function(a, b, c, d) {
        var e = wn(a, c),
            f = vn(a, d);
        xn(a, b, e, f);
        xa("MutationObserver", a.MutationObserver) && (new a.MutationObserver(function() {
            var g = wn(a, c),
                h = vn(a, d);
            if (e !== g || f !== h) e = g, f = h, xn(a, b, e, f)
        })).observe(a.document.body, {
            attributes: !0,
            childList: !0,
            subtree: !0,
            characterData: !0
        })
    });

    function zn(a, b, c, d, e) {
        c = mn(a.document.body, c);
        d = mn(a.document.body, d);
        O(e.target, [c, d]) && nn(a, b)
    }
    var An = W("ep.chp", function(a, b, c, d, e) {
        c && nn(a, b);
        return d || e ? Xc(a).C(a.document, ["click"], V(a, "ep.chp.cl", F([a, b, d, e], zn))) : r
    });

    function Bn(a, b) {
        return Zi(b, function(c) {
            return {
                Md: sn(a, J(c, "settings.dr")),
                isEnabled: J(c, "settings.auto_goals")
            }
        })
    }

    function Cn(a, b) {
        if (!b) return !1;
        var c = T(a);
        return (new RegExp(b)).test("" + c.pathname + c.hash + c.search)
    }
    var Dn = W("ep.i", function(a, b) {
        if (sj(a)) return Bn(a, b).then(function(c) {
            var d = n(c.Md),
                e = d.next().value,
                f = d.next().value,
                g = d.next().value,
                h = d.next().value,
                k = d.next().value,
                l = d.next().value,
                m = d.next().value,
                p = d.next().value,
                q = d.next().value,
                v = d.next().value,
                t = d.next().value,
                x = d.next().value,
                E = d.next().value,
                C = d.next().value,
                S = d.next().value,
                ea = d.next().value;
            if (!c.isEnabled) return Z.resolve(r);
            var Lg = Cn(a, e),
                Oq = Cn(a, h),
                Pq = Cn(a, m),
                Qq = Cn(a, q),
                Rq = "" + e + f + g === "" + h + k + l;
            return new Z(function(Sq, Tq) {
                Af(a, "ecp")(wf(Tq,
                    function() {
                        Lg && yn(a, b, f, g, t, x, E);
                        Oq && !Rq && yn(a, b, k, l, C, S, ea);
                        Sq(An(a, b, Pq || Qq, p, v))
                    }))
            })
        })
    });

    function En(a, b) {
        var c = Re(a, b),
            d = ad(a);
        if (c && Se("ym-advanced-informer", c)) {
            var e = d.o("ifc", 0) + 1;
            d.B("ifc", e);
            e = c.getAttribute("data-lang");
            var f = ub(c.getAttribute("data-cid") || "");
            if (f || 0 === f) {
                var g = J(a, "Ya." + Qd + ".informer");
                g ? (d = {}, g((d.i = c, d.id = f, d.lang = e, d))) : d.B("ib", !0);
                c = b || window.event;
                c.preventDefault ? c.preventDefault() : c.returnValue = !1
            }
        }
    }

    function Fn(a) {
        var b = V(a, "i.clch", En);
        Xc(a).C(a.document, ["click"], G(a, b), {
            passive: !1
        });
        return function(c) {
            var d = a.Ya[Qd],
                e = !!d._informer;
            d._informer = P({
                domain: Rd
            }, c);
            e || Hk(a, "https://" + Rd + "/metrika/informer.js", r)
        }
    }
    var Gn = W("pr.p", function(a, b) {
            if (Oc(a)) {
                var c = Lh(a, "5", b),
                    d = {};
                d = Wg((d.pq = 1, d.ar = 1, d));
                var e = {};
                c({
                    G: d,
                    D: (e["page-url"] = T(a).href, e["page-ref"] = J(a, "document.referrer") || "", e)
                }, b)["catch"](V(a, "pr.p.s"))
            }
        }),
        Hn = !1;

    function In(a) {
        return {
            K: function(b, c) {
                if (!b.G) return c();
                var d = Q(a).o("fid");
                !Hn && d && (me(b, "fid", d), Hn = !0);
                return c()
            }
        }
    }
    var Jn = W("fid", function(a) {
            var b = r;
            if (!y(a.PerformanceObserver)) return b;
            var c = Q(a);
            if (c.o("fido")) return b;
            c.B("fido", !0);
            var d = new a.PerformanceObserver(V(a, "fid", function(f) {
                f = f.getEntries()[0];
                c.B("fid", a.Math.round(100 * (f.processingStart - f.startTime)));
                b()
            }));
            b = function() {
                return d.disconnect()
            };
            try {
                var e = {};
                d.observe((e.type = "first-input", e.buffered = !0, e))
            } catch (f) {}
            return b
        }),
        Kn = L(function(a) {
            var b = Q(a),
                c = b.o("isEU");
            if (z(c)) {
                var d = ub(Dd(a, "is_gdpr") || "");
                if (O(d, [0, 1])) b.B("isEU", d), c = !!d;
                else if (a =
                    He(a).o("wasSynced"), a = J(a, "params.eu")) b.B("isEU", a), c = !!a
            }
            return c
        }, function(a) {
            return Q(a).o("isEU")
        }),
        Ln = W("i.e", Kn),
        Mn = W("i.ep", function(a) {
            Kn(a)
        });

    function Nn(a, b, c, d, e) {
        if (!sj(a)) return r;
        var f = [],
            g = [],
            h = Xc(a),
            k;
        Af(a, "doe")(wf(r, function() {
            var l = tj(b, a.document.body);
            e && (l = Qb(e, l));
            M(function(p) {
                f.push(p);
                g.push(h.C(p, c, d))
            }, l);
            if (xa("MutationObserver", a.MutationObserver)) {
                var m = b.toUpperCase();
                l = new a.MutationObserver(V(a, "de.m", function(p) {
                    M(function(q) {
                        var v = q.addedNodes;
                        q = q.removedNodes;
                        v && v.length && M(function(t) {
                                Dk(a, t, function(x) {
                                    x.nodeName !== m || e && !e(x) || Le(Pa(x), f) || (f.push(x), g.push(h.C(x, c, d)))
                                }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                            },
                            v);
                        q && q.length && M(function(t) {
                            Dk(a, t, function(x) {
                                x.nodeName !== m || e && !e(x) || (x = nc(a)(x, f), -1 !== x && (g[x](), g.splice(x, 1), f.splice(x, 1)))
                            }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                        }, q)
                    }, p)
                }));
                l.observe(a.document.body, {
                    childList: !0,
                    subtree: !0
                });
                k = D(l.disconnect, l)
            }
        }));
        return function() {
            k && k();
            M(be, g);
            pc(g);
            pc(f)
        }
    }
    var On = "https://" + Rd + "/metrika",
        Ll = On + "/match.html",
        Pn = On + "/tag_phono.js",
        Qn = bd("appl", function(a) {
            return new Z(function(b, c) {
                Hk(a, Pn, b, c, {
                    crossOrigin: !0
                })
            })
        }, !0),
        Rn = ["cc-", "name", "shipping"];

    function Sn(a, b, c) {
        var d = c.Ia,
            e = vd(c.Ua);
        if (e && !(100 <= eb(e))) {
            var f = "tel" === J(d, "type"),
                g = 0 < Ca(e, "@") && !f,
                h = yd(e);
            h = eb(h);
            if (g || !g && (f || h))
                if (b = 1 === b ? ad(a).o("app") : Zh, a = g ? Xh(e) : b(a, e)) return {
                    Ia: d,
                    Yd: g,
                    Ua: a,
                    source: void 0,
                    isTrusted: J(c, "isTrusted"),
                    Nb: c.Nb
                }
        }
    }

    function Tn(a, b, c, d, e, f) {
        var g = b.Yd,
            h = b.Ua,
            k = b.source,
            l = b.isTrusted,
            m = b.Nb;
        b = b.Ia.readOnly;
        var p = {},
            q = {};
        c = (q.fi = le((p.a = g ? 1 : 0, p.b = c, p.c = f || 0, p.d = b ? 1 : null, p.e = m ? 1 : null, p)).ra(), q.fit = d, q);
        A(l) || (c.ite = Mb(l));
        e && (g ? (e = n(h.split("@")), g = e.next().value, h = e.next().value.split("."), e = h[h.length - 1], h = U(".", h.slice(0, -1)), d = eb(g), l = eb(h), g = 3 >= d ? "***" : 4 === d ? g[0] + "***" : g[0] + Fl("*", d - 2) + g[d - 1], 2 >= l ? h = Fl("*", l) : 3 === l ? h = h[0] + "**" : (l = Math.floor(l / 2) + l % 2, h = "" + h[0] + Fl("*", l) + h.slice(l + 1)), e = "e:" + (g + "@" + h + "." + e)) :
            (e = yd(h), g = e.slice(-4), e = "p:" + Gl("*", eb(e), g)), c.mfpd = e);
        A(k) || (c.pfv = k);
        k = {};
        a.params((k.__ym = c, k))
    }
    var Un = W("ice", function(a, b, c, d, e) {
            if (b = Th(a, b))
                if (e = Sn(a, d, e)) return a = Ij(a, e.Ia), Tn(b, e, a, d, !1), !0
        }),
        Vn = W("ice", function(a, b, c, d, e) {
            if (b = Th(a, b))
                if (e = Sn(a, d, e)) {
                    var f = Ij(a, e.Ia);
                    ai(a, e.Ua).then(F([b, e, f, d, c], Tn), V(a, "ice.s"));
                    return !0
                }
        });

    function Wn(a, b, c, d, e) {
        var f = e.target;
        a = ib(a)(f, c);
        f = -1 !== a;
        if (b || f) f && c.splice(a, 1), d(e)
    }

    function Xn(a, b, c, d, e) {
        var f = J(e, "target");
        e = J(e, "isTrusted") || !1;
        f && (f = Dj("button,input", a, f)) && "submit" === f.type && (f = Yj(a, f)) && (d = d(f), b.push(f), tf(a, F([a, !1, b, c, {
            target: f,
            isTrusted: e,
            formData: d
        }], Wn), 300, "i.c.l"))
    }

    function Yn(a, b) {
        var c = Zn,
            d = [],
            e = [];
        d.push(Nn(a, "form", ["submit"], V(a, "ltfs.s", function(f) {
            var g = J(f, "target");
            g && Wn(a, !0, e, b, {
                target: g,
                isTrusted: J(f, "isTrusted") || !1,
                formData: c(g)
            })
        })));
        d.push(Nn(a, "button", ["click"], V(a, "ltfs.bc", F([a, e, b, c], Xn))));
        d.push(Nn(a, "input", ["click"], V(a, "ltfs.ic", F([a, e, b, c], Xn)), function(f) {
            return "submit" === f.type
        }));
        return F([ce, d], M)
    }
    var $n = ["text", "email", "tel"];

    function Zn(a) {
        a = tj("input", a);
        return M(function(b) {
            return [b, b.value]
        }, a)
    }
    var ao = W("icei", function(a, b) {
            if ($h(a)) {
                var c = !1,
                    d = r,
                    e = r;
                Zi(b, function(f) {
                    if (!(Ln(a) || J(f, "settings.eu") || c)) {
                        var g = !!J(f, "settings.mcf");
                        (J(f, "settings.cf") ? yf(Qn(a).then(G(F([a, b, g, 1], Vn), lb), G(F([a, b, g, 2], Vn), lb))) : zf(F([a, b, g, 0], Un)))(wf(V(a, "ice.tt"), V(a, "ice.tc", function(h) {
                            if (!c) {
                                var k = function(l) {
                                    var m;
                                    if (m = O(l.type, $n))(m = df(l) ? "password" === l.type || l.name && O(l.name.toLowerCase(), Cl) || l.id && O(l.id.toLowerCase(), Cl) : !1) || (m = l && (Ia(l.className, "ym-disable-keys") || Ia(l.className, "-metrika-nokeys"))),
                                        m = !(m || Bl(a, l)) && !sc(Nb, M(G(l.autocomplete, Ia), Rn));
                                    return m
                                };
                                d = Nn(a, "input", ["blur"], function(l) {
                                    (l = J(l, "target")) && h({
                                        Ia: l,
                                        Ua: J(l, "value") || ""
                                    })
                                }, k);
                                e = Yn(a, function(l) {
                                    var m = l.isTrusted,
                                        p = 0;
                                    M(function(q) {
                                        var v = n(q);
                                        q = v.next().value;
                                        v = v.next().value;
                                        20 <= p || !k(q) || h({
                                            Ia: q,
                                            Ua: v,
                                            isTrusted: m,
                                            Nb: !0
                                        }) && (p += 1)
                                    }, l.formData)
                                })
                            }
                        })))
                    }
                })["catch"](V(a, "ice.t"));
                return function() {
                    c = !0;
                    d();
                    e()
                }
            }
        }),
        bo = "FB_IAB FBAV OKApp GSA/ yandex yango uber EatsKit YKeyboard iOSAppUslugi YangoEats PassportSDK".split(" "),
        co = L(function(a) {
            var b =
                ob(a);
            a = b.ud;
            if (!b.Jc) return !1;
            b = Za("indexOf", a);
            b = sc(N(b, Pa(-1), nb), bo);
            var c = /CFNetwork\/[0-9][0-9.]*.*Darwin\/[0-9][0-9.]*/.test(a),
                d = /YaBrowser\/[\d.]+/.test(a),
                e = /Mobile/.test(a);
            return b || c || d && e || !/Safari/.test(a) && e
        }),
        eo = L(function(a) {
            var b = qb(a);
            return b ? Ia(b, "YangoEats") || zc(a) : !1
        }),
        fo;

    function go(a, b, c) {
        var d = J(a, "AppMetricaInitializer"),
            e = J(d, "init");
        if (e) try {
            D(e, d)(Ae(a, b))
        } catch (f) {} else fo = tf(a, F([a, b, 2 * c], go), c, "ai.d");
        return function() {
            return sf(a, fo)
        }
    }
    var ho = W("p.ai", function(a, b) {
            if (zc(a) || co(a)) return Zi(b, function(c) {
                if (c = J(c, "settings.sbp")) {
                    var d = {};
                    return go(a, P({}, c, (d.c = b.id, d)), 10)
                }
            })
        }),
        io = "architecture bitness model platformVersion uaFullVersion fullVersionList".split(" "),
        jo = bd("uah", function(a) {
            if (!xa("getHighEntropyValues", J(a, "navigator.userAgentData.getHighEntropyValues"))) return Z.reject("0");
            try {
                return a.navigator.userAgentData.getHighEntropyValues(io).then(function(b) {
                    if (!B(b)) throw "2";
                    return b
                }, function() {
                    throw "1";
                })
            } catch (b) {
                return Z.reject("3")
            }
        }),
        ko = new RegExp(U("|", "yandex.com/bots;Googlebot;APIs-Google;Mediapartners-Google;AdsBot-Google;FeedFetcher-Google;Google-Read-Aloud;DuplexWeb-Google;Google Favicon;googleweblight;Lighthouse;Mail.RU_Bot;StackRambler;Slurp;msnbot;bingbot;www.baidu.com/search/spi_?der.htm".split(";")).replace(/[./]/g, "\\$&")),
        lo = L(function(a) {
            var b = qb(a);
            return (b = ko.test(b)) ? Z.resolve(b) : jo(a).then(function(c) {
                try {
                    return H(function(d, e) {
                        return d || ko.test(e.brand)
                    }, !1, c.brands)
                } catch (d) {
                    return !1
                }
            }, G(!1, lb))
        }),
        mo = ["default",
            "update"
        ],
        no = bd("ycs", function(a) {
            function b(e) {
                if ("region" === e) return !0;
                if (I(c, e)) {
                    e = c[e];
                    if (!z(e.current)) return e.current;
                    if (!z(e["default"])) return e["default"]
                }
                return !0
            }
            var c = {},
                d = Cf(a, "ytm.cs");
            a = {};
            return a.set = function(e, f) {
                if (O(e, mo) && B(f)) {
                    var g = I(f, "region") ? f.region : void 0,
                        h = u(g) && g ? ("" + g).toUpperCase() : void 0,
                        k;
                    M(function(l) {
                        var m = n(l);
                        l = m.next().value;
                        m = m.next().value;
                        if ("region" !== l && !h) {
                            var p = "granted" === m;
                            m = b(l);
                            var q = I(c, l) ? c[l] : {};
                            if ("default" === e) {
                                if (!z(q.current)) {
                                    k = "cdau";
                                    return
                                }
                                q["default"] =
                                    p
                            } else q.current = p;
                            c[l] = q;
                            p = b(l);
                            p !== m && d.trigger(l, [l, p])
                        }
                    }, dc(f));
                    return k
                }
            }, a.get = b, a.on = function(e, f) {
                d.C([e], function(g) {
                    var h = n(g);
                    g = h.next().value;
                    h = h.next().value;
                    return f(g, h)
                })
            }, a
        }, !0),
        oo = ["0", "1", "2", "3"],
        po = oo[0],
        qo = oo[1],
        ro = oo[2],
        so = ["GDPR-ok-view-detailed-0", "GDPR-ok-view-detailed-1", "GDPR-ok-view-detailed-2", "GDPR-ok-view-detailed-3"],
        to = ["GDPR-ok-view-default", "GDPR-ok-view-detailed"].concat(ka(so));

    function uo(a) {
        if (O(a, ["GDPR-ok-view-default", "GDPR-ok-view-detailed"])) return po;
        a = a.replace("GDPR-ok-view-detailed-", "");
        return O(a, oo) ? a : po
    }
    var vo = "GDPR-ok GDPR-cross GDPR-cancel 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 GDPR-settings GDPR-ok-view-default GDPR-ok-view-detailed 21 22 23".split(" ").concat(so).concat(["28", "29", "30", "31"]),
        wo = "3 13 14 31 15 16 17 28".split(" "),
        xo = N(Gb(K("ymetrikaEvent.type")), Sb(Vb(vo))),
        yo = "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz ar he sr uk zh".split(" ");

    function zo(a) {
        if (/(^|\w+\.)yango(\.yandex)?\.com$/.test(a) && !/(^|\w+\.)drive\.yango\.com$/.test(a)) return {
            url: "https://yastatic.net/s3/taxi-front/yango-gdpr-popup/",
            version: 2,
            Nc: yo,
            Rc: "_inversed_buttons"
        }
    }
    var Ao = RegExp("^(.*\\.)?((yandex(-team)?)\\.(com?\\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\\.ru|ya\\.(ru|cc)|yadi\\.sk|yastatic\\.net|.*\\.yandex|turbopages\\.org|turbo\\.site|diplodoc\\.(com|tech)|datalens\\.tech|white-label\\.yango-tech\\.com|al-sadhan\\.com|spar\\.sa|^order\\.grandhyper\\.com|^tst\\.order\\.grandhyper\\.com|^pre\\.order\\.grandhyper\\.com|^tuvio\\.kz|^pragmahome\\.kz|^commo\\.kz|^junion\\.kz|^nocord-tools\\.kz|^cubits\\.kz|drive\\.yango\\.com)$"),
        Bo = L(function(a) {
            a = T(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(Ao));
            return b
        });

    function Co(a, b) {
        var c = yi(a, b);
        c && c.ca.C(["isYandex"], function() {
            var d = {};
            return d.type = "isYandex", d.isYandex = Bo(a), d
        })
    }

    function Do(a, b, c) {
        var d = yi(a, c);
        return new Z(function(e) {
            if (d) {
                var f = d.ca,
                    g = N(G("4", b), G(null, e)),
                    h = tf(a, g, 2E3, "gdp.f.t"),
                    k = {};
                d.ad((k.type = "isYandex", k)).then(function(l) {
                    l.isYandex ? (b("5"), f.C(to, function(m) {
                        m = n(m);
                        m.next();
                        m = m.next().value.type;
                        e({
                            value: uo(m)
                        })
                    })) : (b("6"), e(null))
                })["catch"](g).then(F([a, h], sf))
            } else e({
                value: qo,
                Mb: !0
            })
        })
    }
    var Eo = {},
        Fo = (Eo["GDPR-ok"] = "ok", Eo["GDPR-ok-view-default"] = "ok-default", Eo["GDPR-ok-view-detailed"] = "ok-detailed", Eo["GDPR-ok-view-detailed-0"] = "ok-detailed-all", Eo["GDPR-ok-view-detailed-1"] = "ok-detailed-tech", Eo["GDPR-ok-view-detailed-2"] = "ok-detailed-tech-analytics", Eo["GDPR-ok-view-detailed-3"] = "ok-detailed-tech-other", Eo);

    function Go(a, b) {
        if (Bo(a)) {
            var c = Ai(a),
                d = Th(a, b);
            d = d && d.params;
            c = M(G(Fo, J), xo(c));
            d && c.length && d("gdpr", Rb(c))
        }
    }

    function Ho(a, b, c) {
        a = c || Hc(a);
        return O(a, b) ? a : "en"
    }
    var Io = {
            $d: !0,
            url: "https://yastatic.net/s3/gdpr/v3/gdpr",
            Rc: "",
            Nc: "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz cs da de el hr it nl pl sk sv".split(" ")
        },
        Jo = bd("gdpr", function(a, b, c, d, e) {
            function f(p) {
                b("10");
                c.C(to, function(q) {
                    q = q.type;
                    var v = {};
                    l.$c((v.type = q, v));
                    p({
                        value: uo(q)
                    })
                })
            }
            var g = void 0 === e ? Io : e;
            e = g.url;
            var h = g.Rc,
                k = g.$d;
            g = Ho(a, g.Nc, d.He);
            var l = yi(a, d);
            if (!l) return Z.resolve({
                value: po,
                Mb: !0
            });
            if (a._yaGdprLoaded) return new Z(function(p) {
                b("7");
                f(p)
            });
            var m = "" + e + (k ? "" : g) +
                h + ".js";
            return new Z(function(p) {
                b("7");
                Hk(a, m, G(p, f), function() {
                    b("9");
                    var q = {};
                    l.$c((q.type = "GDPR-ok-view-default", q));
                    p(null)
                })
            })
        }),
        Ko = [],
        Lo = Za("push", Ko),
        Mo = L(function(a, b) {
            var c = b("gdpr");
            return O(c, oo) ? a + "-" + c : a
        }),
        No = Rd.split("."),
        Oo = No.pop(),
        Po = U(".", No),
        Qo = /^([^.]+\.)?(boost|appmetrica|metrika|metrica|direct|ads)\.yandex\.([a-z.]+)$/,
        Ro = {},
        So = (Ro.brands = "chu", Ro.architecture = "cha", Ro.bitness = "chb", Ro.uaFullVersion = "chf", Ro.fullVersionList = "chl", Ro.mobile = "chm", Ro.model = "cho", Ro.platform = "chp",
            Ro.platformVersion = "chv", Ro);

    function To(a) {
        return u(a) ? a : w(a) ? U(",", M(function(b) {
            return '"' + b.brand + '";v="' + b.version + '"'
        }, a)) : A(a) ? "" : a ? "?1" : "?0"
    }

    function Uo(a) {
        return "che\n" + a
    }

    function Vo(a) {
        var b = H(function(c, d) {
            var e = n(d),
                f = e.next().value;
            e = e.next().value;
            (f = To(a[f])) && c.push("" + e + "\n" + f);
            return c
        }, [], dc(So));
        return U("\n", b)
    }
    var Wo = L(function(a) {
        return jo(a).then(Vo, Uo)
    });

    function Xo(a) {
        return {
            K: function(b, c) {
                Wo(a).then(function(d) {
                    b.D || (b.D = {});
                    b.D.uah = d;
                    c()
                }, c)
            }
        }
    }

    function Yo(a, b, c) {
        Af(a, "pbjs")(wf(r, function() {
            var d = M(function(g) {
                var h = {};
                h = (h.auc = g, h);
                g = uj("[id='" + g + "']", a.document.body) || uj("[id='" + g.slice(1) + "']", a.document.body);
                if (!g) return h;
                var k = $e(g);
                if (k) {
                    var l = {};
                    P(h, (l.y = "" + k.top, l.x = "" + k.left, l.w = "" + k.width, l.h = "" + k.height, l))
                }
                if (g = uj("iframe", g)) k = {}, P(h, (k.wi = g.width, k.hi = g.height, k.si = g.src, k));
                return h
            }, c);
            if (0 < d.length) {
                var e = {},
                    f = {};
                b((f.__ym = (e.adi = d, e), f))
            }
        }))
    }
    var Zo = "pbjsInit bidRequested bidAdjustment bidWon bidResponse bidTimeout auctionInit auctionEnd adRenderSucceeded adRenderFailed".split(" "),
        $o = ["cpm", "currency", "netRevenue", "requestTimestamp", "responseTimestamp"],
        ap = {},
        bp = (ap.netRevenue = function(a) {
            return u(a) ? "net" === a : !!a
        }, ap),
        cp = {},
        dp;

    function ep(a) {
        var b = cp[a],
            c = b.xb,
            d = b.Ac,
            e = b.pe;
        return M(function(f) {
            var g = n(f);
            f = g.next().value;
            g = g.next().value;
            var h = g.Sb,
                k = g.timeout,
                l = g.Sa,
                m = {};
            return P((m.renderState = g.Xa, m.mediaTypes = h, m.auctionId = a, m.adUnitCode = f, m.startStamp = c, m.endStamp = d, m.requestedBidders = e, m.bidTimeout = k, m), l)
        }, dc(b.tb))
    }

    function fp(a, b, c) {
        var d = cp[c];
        d.Yc = !1;
        d.yb && sf(a, d.yb);
        d.yb = tf(a, function() {
            var e = ep(c),
                f = {},
                g = {};
            b((g.__ym = (f.pbjsv = dp, f.pbjs = e, f), g));
            delete cp[c]
        }, 2E3, "pbjs.t")
    }

    function gp(a, b) {
        var c = Th(a, b);
        c && M(function(d) {
            cp[d].Yc && fp(a, c.params, d)
        }, ec(cp))
    }

    function hp(a, b) {
        a.tb[b] || (a.tb[b] = {
            Sa: {}
        });
        return a.tb[b]
    }

    function ip(a, b, c) {
        var d = c.adUnitCode,
            e = c.bidderCode || c.bidder;
        if (e && d) {
            var f = hp(b, d);
            !f.Sb && c.mediaTypes && (f.Sb = {}, M(function(g) {
                var h = n(g);
                g = h.next().value;
                h = h.next().value;
                var k;
                w(h) ? k = h : h.sizes ? k = h.sizes : h.playerSize && (k = h.playerSize);
                k && (f.Sb[g] = k)
            }, dc(c.mediaTypes)));
            "bidTimeout" === a ? (f.timeout || (f.timeout = {}), f.timeout[e] = !0) : (f.Sa[a] || (f.Sa[a] = {}), f.Sa[a][e] = H(function(g, h) {
                A(c[h]) || (g[h] = bp[h] ? bp[h](c[h]) : c[h]);
                return g
            }, {}, $o), b = J(c, "meta.advertiserDomains"), w(b) && (f.Sa[a][e].advertiserDomains =
                b))
        }
    }

    function jp(a, b, c) {
        var d = c.bid,
            e = d.bidderCode || d.bidder;
        d = d.adUnitCode;
        e && d && (b = hp(b, d), b.Xa || (b.Xa = {}), a = "adRenderSucceeded" === a, d = {}, b.Xa[e] = (d.success = a, d), a || (b.Xa[e].reason = c.reason, b.Xa[e].message = c.message))
    }

    function kp(a, b) {
        if (O(a, Zo))
            if ("pbjsInit" === a) dp = b.version;
            else {
                var c = J(b, "auctionId") || J(b, "bid.auctionId") || void 0;
                if (c) {
                    cp[c] || (cp[c] = {
                        tb: {}
                    });
                    c = cp[c];
                    var d = "auctionInit" === a,
                        e = "auctionEnd" === a,
                        f = "adRenderFailed" === a || "adRenderSucceeded" === a;
                    f || c.xb && !d || (c.xb = J(b, "auctionStart") || void 0, !c.xb && d && (c.xb = b.timestamp));
                    var g = F([a, c], ip);
                    "bidRequested" === a ? M(g, b.bids) : f ? jp(a, c, b) : e ? (c.Ac = b.auctionEnd || b.timestamp, c.pe = Qb(function(h, k, l) {
                            return jb(h, l) === k
                        }, M(K("bidderCode"), b.bidderRequests))) : d ||
                        g(b);
                    c.Ac && (c.Yc = !0)
                }
            }
    }

    function lp(a, b) {
        var c = !1;
        return function(d) {
            var e = Th(a, b);
            e && !c && (c = !0, d = F([a, e.params, d], Yo), tf(a, d, 5E3, "pbjs.fr"), tf(a, d, 2E4, "pbjs.sr"))
        }
    }

    function mp(a, b) {
        M(function(c) {
            var d = c.event,
                e = c.data,
                f = G(d, kp);
            "bidTimeout" === d ? M(f, e) : f(e);
            "auctionEnd" === d && (c = J(c, "data.adUnitCodes")) && b(c)
        }, a)
    }
    var np = W("pj", function(a, b) {
            var c = lp(a, b),
                d = {};
            return d.pbjs = function(e) {
                w(e) && (e = Qb(Nb, M(function(f) {
                    if (B(f) && f.data && f.event && (B(f.data) || w(f.data))) {
                        var g = J(f, "data.args");
                        return g ? {
                            event: f.event,
                            data: g
                        } : f
                    }
                }, e)), mp(e, c), gp(a, b))
            }, d
        }),
        op = L(function() {
            var a = Hj();
            return H(function(b, c) {
                b[a[c]] = c;
                return b
            }, {}, ec(a))
        }),
        pp = /(\D\d*)/g;

    function qp(a) {
        if (!a) return "";
        a = a.match(pp);
        if (!a || 0 === a.length) return "";
        var b = op();
        return "//HTML/BODY/" + H(function(c, d) {
            var e = d[0],
                f = ub(d.slice(1));
            return "/" + b[e] + (f ? "[" + (f + 1) + "]" : "") + c
        }, "", a)
    }

    function rp(a, b) {
        var c = qp(b);
        return c ? J(a, "document.evaluate") ? a.document.evaluate(c, a.document, null, a.XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue : null : null
    }
    var sp = L(Md);

    function tp(a) {
        return {
            ke: Ne(a.element),
            Gb: a.Gb
        }
    }

    function up(a, b) {
        var c = a.document.body;
        if (c) {
            var d = b.price_patterns,
                e = sp(b.id);
            if (e.Pa) {
                if (!Ej(a, e.Pa.element)) return tp(e.Pa);
                e.Pa = void 0
            }
            d = H(function(h, k) {
                var l = n(k),
                    m = l.next().value;
                l = l.next().value;
                h[m] = l;
                return h
            }, {}, d);
            var f = null,
                g = null;
            d.cs && sj(a) && (f = uj(d.cs, c), g = "c");
            d.p && !f && (f = rp(a, d.p), g = "x");
            if (f && g) return e.Pa = {
                element: f,
                Gb: g
            }, tp(e.Pa)
        }
    }

    function vp(a, b) {
        var c = a[b[0]];
        return !(!c || c !== b[1])
    }

    function wp(a, b) {
        var c = b.patterns;
        if (0 === c.length) return !1;
        if (1 === c.length) return vp(a, c[0]);
        c = H(function(f, g) {
            var h = n(g),
                k = h.next().value;
            h = h.next().value;
            var l = a[k];
            if (l === h) {
                if (f.Fb += 1, "i" === k || "c" === k) f.Kc = !0
            } else l && "p" === k && zd(l) === zd(h) && (f.Mc = !0);
            return f
        }, {
            Fb: 0,
            Kc: !1,
            Mc: !1
        }, c);
        var d = c.Kc,
            e = c.Mc;
        return 2 <= c.Fb || d && e
    }

    function xp(a, b) {
        var c = b.patterns;
        return 0 === c.length ? !1 : sc(G(a, vp), c)
    }

    function yp(a, b, c, d) {
        c = M(function(e) {
            if (!d(b, e)) return !1;
            var f = {};
            f = (f.rg = e.id, f);
            if (e = up(a, e)) f.gp = bl(e.ke), f.mg = e.Gb;
            return f
        }, c);
        return Rb(c)
    }
    var zp = Oa(hj)("btn:"),
        Ap = Oa(hj)("form:");

    function Bp(a) {
        var b = n(a),
            c = b.next().value;
        b = b.next().value;
        return "bp" === c ? ["p", $k(Yk(b))] : a
    }
    var Cp = Gb(function(a) {
        a.patterns = M(Bp, a.patterns);
        a.price_patterns = M(Bp, a.price_patterns);
        return a
    });

    function Dp(a, b) {
        var c = Wd(a);
        b && (c.yen = b);
        return c
    }

    function Ep(a) {
        return Dp(a, "yue")
    }

    function Fp(a, b) {
        if (A(b) || !!b === b || rb(a, b) || u(b)) return b
    }

    function Gp(a, b) {
        if (A(b)) return b;
        var c = Fp(a, b);
        if (!A(c)) return c;
        if (B(b)) return H(function(d, e) {
            var f = n(e),
                g = f.next().value;
            f = f.next().value;
            d[g] = Gp(a, f);
            return d
        }, {}, dc(b));
        if (w(b)) return M(G(a, Gp), b)
    }
    var Hp = "clientInformation globalThis this caches console cookieStore credentialless crypto customElements document documentPictureInPicture event external fence frameElement frames history indexedDB launchQueue localStorage location mozInnerScreenX mozInnerScreenY navigation navigator opener orientation origin originAgentCluster parent performance scheduler self sessionStorage sharedStorage speechSynthesis top trustedTypes visualViewport window alert atob back blur btoa cancelAnimationFrame cancelIdleCallback captureEvents clearImmediate clearInterval clearTimeout close confirm dump execScript fetch fetchLater find focus forward getComputedStyle getDefaultComputedStyle getScreenDetails getSelection matchMedia moveBy moveTo open postMessage print prompt queryLocalFonts queueMicrotask releaseEvents reportError requestAnimationFrame requestFileSystem requestIdleCallback resizeBy resizeTo scroll scrollBy scrollByLines scrollByPages scrollTo setImmediate setInterval setTimeout showDirectoryPicker showModalDialog showOpenFilePicker showSaveFilePicker sizeToContent stop structuredClone".split(" ");

    function Ip(a) {
        if (!u(a)) throw Ep("gppns");
        if (O(a.split(".")[0], Hp)) throw Ep("rwp");
        if (hj(a, "on")) throw Ep("rwp");
    }

    function Jp(a, b) {
        var c = b.split("."),
            d = c.pop();
        c = c.length ? J(a, U(".", c)) : a;
        if (!c) throw Ep("noma");
        return {
            value: J(c, d),
            parent: c,
            Wa: d
        }
    }
    var Kp = {},
        Lp = (Kp.akna = "The property of the value is not an array", Kp["ca.p.uns"] = "The url is not a string", Kp.noma = "Cannot access member of null or undefined object", Kp.rwp = "Access to restricted window property is denied", Kp.vnd = "Variable is not defined", Kp.tenf = "Called value is not a function", Kp.cva = "Cannot assign to constant variable", Kp.iat = "Invalid assignment target", Kp["ca.c.wenf"] = "Window element is not a function", Kp["ca.c.mann"] = "Cookie's max age is not a number", Kp["ca.c.ssuop"] = "SameSite cookie has an unknown option",
            Kp.gppns = "Window property path is not a string", Kp.vr = "Variable redeclaration", Kp.da = "Duplicate argument", Kp.stce = "Error creating script tag", Kp.wenf = "Window element is not a function", Kp.uns = "The url is not a string", Kp.ict = "Consent type is not a string", Kp.icl = "Consent listener is not a function", Kp["ca.akna"] = "The property of the value is not an array", Kp["ca.c.cinf"] = "Callback is not a function", Kp["ca.c.ia"] = "Invalid arguments", Kp.ies = "Invalid element selector", Kp["t.a.s.ev"] = "Element visibility tag was already started",
            Kp["t.a.s.g"] = "Group tag was already started", Kp["t.a.s.sd"] = "Scroll depth tag was already started", Kp["t.a.s.t"] = "Timer tag was already started", Kp.cdau = "Consent default arrived after the value was updated", Kp),
        Mp = {},
        Np = (Mp.c = "Container", Mp.t = "Tag", Mp.tr = "Trigger", Mp.v = "Variable", Mp);

    function Op(a) {
        if (!a) return "";
        var b = a.id;
        return "[" + Np[a.type] + (b ? ":" + b : "") + "]"
    }

    function Pp(a) {
        a = a.message;
        return u(a) ? Lp[a] || a : "Unknown error"
    }
    var Qp = r,
        Rp, Sp = L(function(a, b, c) {
            Qp = b;
            c && (Rp = c)
        });

    function Tp(a, b, c, d) {
        return function() {
            var e = b || Td;
            try {
                return e.apply(null, arguments)
            } catch (f) {
                e = y(d) ? d.apply(null, arguments) : d, Qp(a, f, e)
            }
            return c
        }
    }

    function Up(a, b) {
        return function(c) {
            Qp(a, c, b)
        }
    }

    function Vp(a, b, c) {
        c ? Sp(a, function(d, e, f) {
            A(e) || (Rk(a).error("[YTM Error]" + Op(f) + " " + Pp(e)), Rp && (d = {}, e = (d.event = "ee", d.m = Pp(e), d), f && (e.et = f.type, e.eid = f.eventId, f.id && (e.ei = f.id)), Rp(e)))
        }, c) : Sp(a, function(d, e, f) {
            d = "ytm." + d;
            A(e) || (I(e, "yen") ? (Rh(a, b, "[YTM Error]" + Op(f) + " " + Pp(e))(), "yme" === e.yen && M(N(lb, Jb(["mod", J(e, "message") || "ue", d, void 0]), be), de)) : ee(a, d, e))
        })
    }

    function Wp(a, b, c, d) {
        var e = Pe(a)("img");
        e.src = b;
        b = G(e, Qe);
        var f = G(void 0, lb);
        e.onerror = N(b, f, d);
        e.onload = N(b, f, c);
        wc(a) && (a = Ue(a), P(e.style, {
            position: "absolute",
            visibility: "hidden",
            width: "0px",
            height: "0px"
        }), a.appendChild(e))
    }
    var Xp = L(function(a, b) {
        return H(function(c, d) {
            c[d] = a[d];
            return c
        }, {}, b)
    });

    function Yp(a, b, c) {
        c = void 0 === c ? !0 : c;
        return H(function(d, e) {
            var f = n(e.split("=")),
                g = f.next().value;
            f = ja(f);
            vd(g) === b && (g = vd(U("=", f)), d.push(c ? qd(g) : g));
            return d
        }, [], a.document.cookie.split(";"))
    }

    function Zp(a, b) {
        if (z(b)) var c = "undefined";
        else if (Sa(b)) c = "null";
        else {
            try {
                c = rb(a, b)
            } catch (d) {
                c = !1
            }
            c = c ? "number" : u(b) ? "string" : !0 === b || !1 === b ? "boolean" : y(b) ? "function" : w(b) ? "array" : "object"
        }
        return c
    }

    function $p(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return "query" === b ? a.query : "queryVar" === b ? (a = c ? rd(a.query)[c] : void 0, a) : "protocol" === b ? a.protocol : "host" === b ? d ? id(a.host) : a.host : "port" === b ? (b = a.protocol, a = ub(a.port) ? a.port : "http:" === b ? "80" : "https:" === b ? "443" : void 0, a) : "path" === b ? a.pathname : "fragment" === b ? a.hash.replace("#", "") : "extension" === b ? (a = a.pathname.split("."), ((1 < a.length ? a.pop() : void 0) || "").split("/")[0]) : a.href
    }
    var aq = "protocol host port path query queryVar extension fragment href".split(" "),
        bq = L(function(a) {
            var b = T(a).search;
            b = rd(b.substring(1))._ytm_preview;
            var c = Jd(a, "");
            a = c.B;
            c = c.o;
            return b ? (a("_ytm_preview", b, 10), b) : c("_ytm_preview")
        });

    function cq(a) {
        switch (a) {
            case 2:
                return "read";
            case 1:
                return "write";
            default:
                throw Wd("usoc");
        }
    }

    function dq(a) {
        switch (a) {
            case "read":
                return 2;
            case "write":
                return 1;
            case "execute":
                return 4
        }
    }

    function eq(a, b, c, d, e) {
        if (!d) return !1;
        c = (a = "set_cookies" === c) ? 1 : 2;
        return a && !B(e) ? !1 : b.R({
            permissionType: "cookies",
            F: {
                name: d,
                operation: c,
                options: e
            }
        })
    }

    function fq(a, b, c, d) {
        if (!d) return !1;
        a = "iframe";
        "load_script" === c ? a = "loadScript" : "send_pixel" === c && (a = "pixel");
        return b.R({
            permissionType: a,
            F: {
                url: d
            }
        })
    }

    function gq(a, b, c, d, e) {
        return b.R({
            permissionType: "get_url" === c ? "url" : "referrer",
            F: {
                urlComponent: d || "href",
                variableName: u(e) ? e : void 0
            }
        })
    }
    var hq = {},
        iq = (hq.access_consent = function(a, b, c, d, e) {
            return d && u(d) && e && u(e) ? (a = dq(e)) && 4 !== a ? b.R({
                permissionType: "accessConsent",
                F: {
                    key: d,
                    operation: a
                }
            }) : !1 : !1
        }, hq.access_globals = function(a, b, c, d, e) {
            return d && u(d) && u(e) ? (a = dq(d)) ? b.R({
                permissionType: "globals",
                F: {
                    key: e,
                    operation: a
                }
            }) : !1 : !1
        }, hq.access_local_storage = function(a, b, c, d, e) {
            return d && u(d) && u(e) ? (a = dq(d)) && 4 !== a ? b.R({
                permissionType: "localStorage",
                F: {
                    key: e,
                    operation: a
                }
            }) : !1 : !1
        }, hq.access_template_storage = function(a, b) {
            return b.R({
                permissionType: "templateStorage",
                F: null
            })
        }, hq.get_cookies = eq, hq.get_referrer = gq, hq.get_url = gq, hq.inject_hidden_iframe = fq, hq.load_script = fq, hq.logging = function(a, b) {
            return b.R({
                permissionType: "log",
                F: {
                    logLevel: bq(a) ? 1 : 0
                }
            })
        }, hq.read_data_layer = function(a, b, c, d) {
            return d ? b.R({
                permissionType: "dataLayer",
                F: {
                    key: d,
                    operation: 2
                }
            }) : !1
        }, hq.read_title = function(a, b) {
            return b.R({
                permissionType: "readTitle",
                F: null
            })
        }, hq.send_pixel = fq, hq.set_cookies = eq, hq),
        jq = "protocol host port path query queryVar extension href".split(" "),
        kq = L(Md, function(a,
            b) {
            return a + "_" + b
        }),
        lq = /\+/g,
        mq = /^\?/,
        nq = /[/:]|^[#?]/;

    function oq(a) {
        return (a = a ? a.replace(mq, "") : "") ? H(function(b, c) {
            var d = n(c.split("=")),
                e = d.next().value;
            d = ja(d);
            d = U("=", d);
            e = qd(e.replace(lq, " "));
            d = qd(d.replace(lq, " "));
            if (I(b, e)) {
                var f = b[e];
                w(f) ? f.push(d) : b[e] = [f, d]
            } else b[e] = d;
            return b
        }, {}, a.split("&")) : {}
    }
    var pq = {},
        qq = (pq.callInWindow = function(a) {
            var b = a.l,
                c = a.I;
            return function(d) {
                var e = sa.apply(1, arguments);
                Ip(d);
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 4
                    }
                });
                var f = Jp(b, d),
                    g = f.value;
                f = f.parent;
                if (!y(g)) throw Ep("ca.c.wenf");
                e = g.apply(f, e);
                return Gp(b, e)
            }
        }, pq.callLater = function(a) {
            var b = a.l;
            return function(c) {
                if (!y(c)) throw Dp("ca.c.cinf");
                tf(b, c, 0, "cr.cl")
            }
        }, pq.copyFromDataLayer = function(a) {
            var b = a.l,
                c = a.I,
                d = a.event;
            return function(e) {
                if (!d) throw Dp("No dataLayer data");
                c.checkPermission({
                    permissionType: "dataLayer",
                    F: {
                        key: e,
                        operation: 2
                    }
                });
                return Gp(b, J(d, e))
            }
        }, pq.copyFromWindow = function(a) {
            var b = a.l,
                c = a.I;
            return function(d) {
                Ip(d);
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        operation: 2,
                        key: d
                    }
                });
                return Gp(b, J(b, d))
            }
        }, pq.createArgumentsQueue = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                function f() {
                    return g.push(arguments)
                }
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 2
                    }
                });
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 1
                    }
                });
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: e,
                        operation: 2
                    }
                });
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: e,
                        operation: 1
                    }
                });
                Ip(d);
                Ip(e);
                var g = [],
                    h = Jp(b, d);
                h.value || (h.parent[h.Wa] = f);
                h = Jp(b, e);
                if (h.value) {
                    if (!w(h.value)) throw Ep("ca.akna");
                    g = h.value
                } else h.parent[h.Wa] = g;
                return f
            }
        }, pq.createQueue = function(a) {
            var b = a.l,
                c = a.I;
            return function(d) {
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 2
                    }
                });
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 1
                    }
                });
                Ip(d);
                var e = Jp(b, d);
                d = e.value;
                var f = e.parent;
                e = e.Wa;
                if (!d) f[e] = [];
                else if (!w(d)) throw Ep("akna");
                return D(f[e].push, f[e])
            }
        }, pq.decodeUri = function(a) {
            var b = a.l;
            return function(c) {
                try {
                    return b.decodeURI(c)
                } catch (d) {}
            }
        }, pq.decodeUriComponent = function(a) {
            var b = a.l;
            return function(c) {
                try {
                    return b.decodeURIComponent(c)
                } catch (d) {}
            }
        }, pq.encodeUri = function(a) {
            var b = a.l;
            return function(c) {
                try {
                    return b.encodeURI(c)
                } catch (d) {}
            }
        }, pq.encodeUriComponent = function(a) {
            var b = a.l;
            return function(c) {
                try {
                    return b.encodeURIComponent(c)
                } catch (d) {}
            }
        }, pq.fromBase64 = function(a) {
            var b =
                a.l;
            return function(c) {
                try {
                    return b.atob(c)
                } catch (d) {}
            }
        }, pq.getCookieValues = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                c.checkPermission({
                    permissionType: "cookies",
                    F: {
                        name: d,
                        operation: 2
                    }
                });
                return Yp(b, d, e)
            }
        }, pq.getTimestamp = function(a) {
            var b = a.l;
            return function() {
                return X(b)(gf)
            }
        }, pq.getType = function(a) {
            return G(a.l, Zp)
        }, pq.getReferrerUrl = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                var f = O(d, jq) ? d : "href";
                c.checkPermission({
                    permissionType: "referrer",
                    F: {
                        urlComponent: f,
                        variableName: e
                    }
                });
                var g =
                    J(b, "document.referrer");
                if (g) return g = lh(b, g), $p(g, f, e)
            }
        }, pq.getUrl = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                var f = O(d, aq) ? d : "href";
                c.checkPermission({
                    permissionType: "url",
                    F: {
                        urlComponent: f,
                        variableName: e
                    }
                });
                var g = T(b);
                g.query = g.search.replace(/^\?/, "");
                return $p(g, f, e)
            }
        }, pq.injectHiddenIframe = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                e = void 0 === e ? r : e;
                c.checkPermission({
                    permissionType: "iframe",
                    F: {
                        url: d
                    }
                });
                var f = Pe(b)("iframe");
                P(f.style, {
                    display: "none",
                    width: "1px",
                    height: "1px",
                    visibility: "hidden"
                });
                f.src = d;
                f.onload = function() {
                    return e()
                };
                f.onerror = r;
                Ue(b).appendChild(f)
            }
        }, pq.JSON = function(a) {
            var b = a.l;
            return {
                parse: function(c) {
                    try {
                        return b.JSON.parse("" + c)
                    } catch (d) {}
                },
                stringify: function(c) {
                    try {
                        return b.JSON.stringify(c)
                    } catch (d) {}
                }
            }
        }, pq.loadScript = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e, f) {
                c.checkPermission({
                    permissionType: "loadScript",
                    F: {
                        url: d
                    }
                });
                Hk(b, d, y(e) ? Tp("ls.ol", function() {
                    return e.apply(null)
                }) : r, y(f) ? Tp("ls.oe", function() {
                    return f.apply(null)
                }) : void 0)
            }
        }, pq.localStorage = function(a) {
            var b =
                a.I,
                c = a.l.localStorage;
            return {
                getItem: function(d) {
                    b.checkPermission({
                        permissionType: "localStorage",
                        F: {
                            key: d,
                            operation: 2
                        }
                    });
                    return c.getItem(d)
                },
                setItem: function(d, e) {
                    b.checkPermission({
                        permissionType: "localStorage",
                        F: {
                            key: d,
                            operation: 1
                        }
                    });
                    c.setItem(d, e)
                },
                removeItem: function(d) {
                    b.checkPermission({
                        permissionType: "localStorage",
                        F: {
                            key: d,
                            operation: 1
                        }
                    });
                    c.removeItem(d)
                }
            }
        }, pq.logToConsole = function(a) {
            var b = a.l,
                c = a.I,
                d = Rk(b).log,
                e = bq(b) ? 1 : 0;
            return function() {
                var f = sa.apply(0, arguments);
                c.R({
                    permissionType: "log",
                    F: {
                        logLevel: e
                    }
                }) && d.apply(null, ka(f))
            }
        }, pq.makeNumber = function() {
            return function(a, b) {
                return z(a) ? +b : +a
            }
        }, pq.makeTableMap = function() {
            return function(a, b, c) {
                if (!w(a) || !u(b) || !u(c)) throw Ep("ca.c.ia");
                a = H(function(d, e) {
                    B(e) && I(e, b) && I(e, c) && (d["" + e[b]] = e[c]);
                    return d
                }, {}, a);
                return ec(a).length ? a : null
            }
        }, pq.Math = function(a) {
            return Xp(a.l.Math, "abs floor ceil round max min pow sqrt".split(" "))
        }, pq.Object = function(a) {
            var b = a.l;
            return {
                keys: ec,
                values: hc,
                freeze: function(c) {
                    return b.Object.freeze(c)
                },
                entries: dc,
                "delete": function(c, d) {
                    if (!c || !I(c, d) || w(c) || c === b) return !1;
                    try {
                        return delete c[d]
                    } catch (e) {
                        return !1
                    }
                }
            }
        }, pq.parseUrl = function(a) {
            var b = a.l;
            return function(c) {
                if (u(c) && c && nq.test(c)) {
                    c = lh(b, c);
                    var d = c.protocol,
                        e = c.host;
                    if (d && ":" !== d) return {
                        href: c.href,
                        origin: e ? d + "//" + e : "null",
                        protocol: d,
                        host: e || "",
                        hostname: c.hostname,
                        port: c.port,
                        pathname: c.pathname,
                        search: c.search,
                        searchParams: oq(c.search),
                        hash: c.hash
                    }
                }
            }
        }, pq.queryPermission = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e, f) {
                return (z(e) || u(e)) && I(iq,
                    d) ? (0, iq[d])(b, c, d, e, f) : !1
            }
        }, pq.readTitle = function(a) {
            var b = a.l,
                c = a.I;
            return function() {
                c.checkPermission({
                    permissionType: "readTitle",
                    F: null
                });
                return b.document.title
            }
        }, pq.sendPixel = function(a) {
            var b = a.I,
                c = a.l;
            return function(d, e, f) {
                e = void 0 === e ? r : e;
                f = void 0 === f ? r : f;
                if (!u(d)) throw Ep("ca.p.uns");
                b.checkPermission({
                    permissionType: "pixel",
                    F: {
                        url: d
                    }
                });
                Wp(c, d, e, f)
            }
        }, pq.setCookie = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e, f, g) {
                f = void 0 === f ? {} : f;
                g = void 0 === g ? !0 : g;
                c.checkPermission({
                    permissionType: "cookies",
                    F: {
                        name: d,
                        operation: 1,
                        options: f
                    }
                });
                e = g ? pd(e) : e;
                d = d + "=" + e + ";";
                if (f) {
                    I(f, "domain") && (d += " Domain=" + f.domain + ";");
                    I(f, "path") && (d += " Path=" + f.path + ";");
                    I(f, "expires") && (d += " Expires=" + f.expires + ";");
                    if (I(f, "max-age")) {
                        if (!rb(b, f["max-age"])) throw Ep("ca.c.mann");
                        d += " Max-Age=" + f["max-age"] + ";"
                    }
                    if (I(f, "sameSite")) {
                        if (!O(f.sameSite, ["Lax", "Strict", "None"])) throw Ep("ca.c.ssuop");
                        d += " Same-Site=" + f.sameSite + ";"
                    }
                    I(f, "secure") && f.secure && (d += " Secure;")
                }
                b.document.cookie = d
            }
        }, pq.setInWindow = function(a) {
            var b =
                a.l,
                c = a.I;
            return function(d, e, f) {
                f = void 0 === f ? !1 : f;
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        key: d,
                        operation: 1
                    }
                });
                Ip(d);
                try {
                    var g = Jp(b, d),
                        h = g.parent,
                        k = g.Wa;
                    if (!f && I(h, k)) return !1;
                    h[k] = e;
                    return !0
                } catch (l) {
                    return !1
                }
            }
        }, pq.checkInWindow = function(a) {
            var b = a.l,
                c = a.I;
            return function(d, e) {
                Ip(d);
                c.checkPermission({
                    permissionType: "globals",
                    F: {
                        operation: 2,
                        key: d
                    }
                });
                try {
                    var f = Jp(b, d),
                        g = f.value,
                        h = I(f.parent, f.Wa);
                    if (!e || !h) return h;
                    var k = Zp(b, g);
                    return h && k === e
                } catch (l) {
                    if ("noma" === J(l, "message")) return !1;
                    throw l;
                }
            }
        }, pq.templateStorage = function(a) {
            function b(e) {
                c.checkPermission({
                    permissionType: "templateStorage",
                    F: null
                });
                delete d[e]
            }
            var c = a.I,
                d = kq(a.containerId, a.le);
            return {
                getItem: function(e) {
                    c.checkPermission({
                        permissionType: "templateStorage",
                        F: null
                    });
                    return d[e]
                },
                setItem: function(e, f) {
                    c.checkPermission({
                        permissionType: "templateStorage",
                        F: null
                    });
                    d[e] = f
                },
                removeItem: b,
                clear: function() {
                    c.checkPermission({
                        permissionType: "templateStorage",
                        F: null
                    });
                    M(b, ec(d))
                }
            }
        }, pq);

    function rq(a) {
        return function(b) {
            var c = b.Wb,
                d = b.I;
            return function(e) {
                B(e) && (M(function(f) {
                    "region" !== f && d.checkPermission({
                        permissionType: "accessConsent",
                        F: {
                            key: f,
                            operation: 1
                        }
                    })
                }, ec(e)), c.cb({
                    event: "ytm.consent",
                    ytm: {
                        action: a,
                        La: e,
                        eventId: Um()
                    }
                }))
            }
        }
    }
    var sq = rq("default"),
        tq = rq("update");

    function uq(a) {
        if (!a) return a;
        if (!u(a) && "function" === typeof a[Symbol.iterator]) {
            var b = w(a) ? a : Ta(a);
            return M(uq, b)
        }
        if (B(a)) {
            var c = {};
            M(function(d) {
                c[d] = uq(a[d])
            }, ec(a));
            return c
        }
        return a
    }

    function vq(a) {
        return {
            compilerVersion: a.compilerVersion,
            containerId: a.containerId,
            containerVersion: a.containerVersion,
            counter: uq(a.counter),
            permissions: uq(a.permissions),
            tags: uq(a.tags),
            triggers: uq(a.triggers),
            variables: uq(a.variables)
        }
    }

    function wq(a) {
        a = I(qq, a) ? qq[a] : void 0;
        if (A(a)) throw Dp("uca");
        return a
    }

    function xq(a, b) {
        for (var c = a.length; 0 < c;) {
            var d = a[--c];
            if (I(d.pc, b)) return d.pc[b]
        }
    }

    function yq(a, b) {
        a = void 0 === a ? {} : a;
        b = void 0 === b ? {} : b;
        return {
            pc: a,
            methods: b,
            hb: !0
        }
    }

    function zq(a, b, c) {
        b = void 0 === b ? {} : b;
        c = void 0 === c ? {} : c;
        return a.concat(yq(b, c))
    }

    function Aq(a, b, c, d) {
        for (var e = a.length - 1; 0 <= e; --e) {
            var f = a[e];
            f.hb = !1;
            if (I(f.methods, b)) {
                f.methods[b](d ? d() : void 0);
                return
            }
        }
        throw Dp(c);
    }
    var Bq = "charAt concat indexOf lastIndexOf match replace search slice split substring toLowerCase toLocaleLowerCase toString toUpperCase toLocaleUpperCase trim toString".split(" "),
        Cq = ya(Array.prototype.reduceRight, "reduceRight");

    function Dq(a, b, c) {
        for (var d = c.length - 1; 0 <= d;) b = a(b, c[d], d), --d;
        return b
    }
    var Eq = Cq ? function(a, b, c) {
            return Cq.call(c, a, b)
        } : Dq,
        Fq = "concat every filter forEach indexOf join map pop push reduce reduceRight reverse shift slice some sort splice toString unshift".split(" ");

    function Gq(a, b) {
        var c = {};
        return (c.concat = D(Array.prototype.concat, a), c.every = Oa(Yb)(a), c.filter = Oa(Qb)(a), c.forEach = Oa(M)(a), c.indexOf = Oa(jb)(a), c.join = Oa(U)(a), c.map = Oa(M)(a), c.pop = D(Array.prototype.pop, a), c.push = D(Array.prototype.push, a), c.reduce = function(d, e) {
            return H(d, e, a)
        }, c.reduceRight = function(d, e) {
            return Eq(d, e, a)
        }, c.reverse = G(a, Sm), c.shift = D(Array.prototype.shift, a), c.slice = D(Array.prototype.slice, a), c.some = Oa(sc)(a), c.sort = Oa(Tk)(a), c.splice = D(Array.prototype.splice, a), c.toString = G(a,
            Ja), c.unshift = D(Array.prototype.unshift, a), c)[b]
    }

    function Hq(a) {
        return w(a) && 35 === a[0]
    }

    function Iq(a, b, c) {
        var d = n(b);
        d.next();
        b = d.next().value;
        d = d.next().value;
        b = Jq(a, b);
        a = Jq(a, d);
        if (A(b)) throw Ep("noma");
        if ("number" === typeof b) c = c && "toString" === a ? D(Number.prototype.toString, b) : void 0;
        else if (b === !!b) c = c && "toString" === a ? G(b, Ja) : void 0;
        else if (w(b)) c = c && O(a, Fq) ? Gq(b, a) : I(b, "" + a) ? b[a] : void 0;
        else if (u(b)) c && O(a, Bq) ? (c = {}, c = (c.charAt = D(String.prototype.charAt, b), c.concat = D(String.prototype.concat, b), c.indexOf = G(b, Da), c.lastIndexOf = G(b, Ha), c.match = D(String.prototype.match, b), c.replace =
            D(String.prototype.replace, b), c.search = D(String.prototype.search, b), c.slice = D(String.prototype.slice, b), c.split = D(String.prototype.split, b), c.substring = D(String.prototype.substring, b), c.toLocaleLowerCase = D(String.prototype.toLocaleLowerCase, b), c.toLocaleUpperCase = D(String.prototype.toLocaleUpperCase, b), c.toLowerCase = D(String.prototype.toLowerCase, b), c.toUpperCase = D(String.prototype.toUpperCase, b), c.trim = G(b, vd), c.toString = G(b, Ja), c)[a]) : c = I(b, "" + a) ? b[a] : void 0;
        else if (B(b)) a: {
            if (c) {
                if ("toString" ===
                    a) {
                    c = G(b, Ja);
                    break a
                }
                if ("hasOwnProperty" === a) {
                    c = G(b, I);
                    break a
                }
            }
            c = I(b, "" + a) ? b[a] : void 0
        }
        else c = b["" + a];
        return c
    }

    function Kq(a, b) {
        var c = n(b);
        c.next();
        var d = c.next().value,
            e = c.next().value,
            f = c.next().value,
            g = M(lb, a);
        return function() {
            var h = arguments,
                k = H(function(m, p, q) {
                    if (m[p]) throw Ep("da");
                    m[p] = {
                        kind: 1,
                        value: h[q]
                    };
                    return m
                }, {}, e);
            d && !O(d, e) && (k[d] = {
                kind: 0,
                value: d
            });
            var l;
            Lq(g, f, k, {
                "return": function(m) {
                    l = m
                }
            });
            return l
        }
    }

    function Mq(a) {
        return w(a) && 42 === a[0]
    }

    function Nq(a, b) {
        var c = n(b);
        c.next();
        c = ja(c);
        return H(function(d, e) {
            var f = n(e),
                g = f.next().value;
            f = f.next().value;
            g = Jq(a, g);
            f = Jq(a, f);
            d["" + g] = f;
            return d
        }, {}, c)
    }

    function Uq(a) {
        return w(a) && 40 === a[0]
    }

    function Vq(a, b) {
        var c = n(b);
        c.next();
        c = ja(c);
        return M(function(d) {
            return Jq(a, d)
        }, c)
    }

    function Wq(a, b) {
        var c = n(b);
        c.next();
        var d = c.next().value,
            e = c.next().value;
        c = c.next().value;
        e = Jq(a, e);
        c = Jq(a, c);
        switch (d) {
            case "==":
                return e == c;
            case "!=":
                return e != c;
            case "===":
                return e === c;
            case "!==":
                return e !== c;
            case "<":
                return e < c;
            case "<=":
                return e <= c;
            case ">":
                return e > c;
            case ">=":
                return e >= c;
            case "<<":
                return e << c;
            case ">>":
                return e >> c;
            case ">>>":
                return e >>> c;
            case "+":
                return e + c;
            case "-":
                return e - c;
            case "*":
                return e * c;
            case "/":
                return e / c;
            case "%":
                return e % c;
            case "|":
                return e | c;
            case "^":
                return e ^
                    c;
            case "&":
                return e & c;
            case "in":
                return e in c;
            case "instanceof":
                return e instanceof c;
            default:
                throw Dp("uo");
        }
    }

    function Xq(a, b) {
        var c = n(b);
        c.next();
        var d = c.next().value;
        c = c.next().value;
        c = Jq(a, c);
        switch (d) {
            case "+":
                return +c;
            case "!":
                return !c;
            case "-":
                return -c;
            case "~":
                return ~c;
            default:
                throw Dp("uo");
        }
    }

    function Yq(a, b, c) {
        c = void 0 === c ? [] : c;
        if (Uq(b)) {
            b = n(b);
            b.next();
            b = b.next().value;
            a = xq(a, b);
            if (!a) throw Ep("vnd");
            if (0 === a.kind && 0 === c.length) throw Ep("cva");
            return {
                me: c,
                Fe: a
            }
        }
        if (Hq(b)) {
            var d = n(b);
            d.next();
            b = d.next().value;
            d = d.next().value;
            d = Jq(a, d);
            c.unshift("" + d);
            return Yq(a, b, c)
        }
        throw Ep("iat");
    }

    function Zq(a, b, c, d) {
        b = Yq(a, b);
        a = b.Fe;
        var e = b.me;
        e.unshift("value");
        b = e.pop();
        a = H(function(f, g) {
            return f[g]
        }, a, e);
        switch (d) {
            case "=":
                return a[b] = c;
            case "+=":
                return a[b] += c;
            case "-=":
                return a[b] -= c;
            case "*=":
                return a[b] *= c;
            case "/=":
                return a[b] /= c;
            case "%=":
                return a[b] %= c;
            case "<<=":
                return a[b] <<= c;
            case ">>=":
                return a[b] >>= c;
            case ">>>=":
                return a[b] >>>= c;
            case "|=":
                return a[b] |= c;
            case "^=":
                return a[b] ^= c;
            case "&=":
                return a[b] &= c;
            default:
                throw Dp("uo");
        }
    }

    function $q(a, b) {
        var c = n(b);
        c.next();
        var d = c.next().value,
            e = c.next().value;
        c = c.next().value;
        c = Jq(a, c);
        return Zq(a, e, c, d)
    }

    function Jq(a, b) {
        if (u(b) || "[object Number]" === Object.prototype.toString.call(b) || !!b === b || Mq(b)) return Mq(b) ? null : b;
        if (Uq(b)) {
            var c = n(b);
            c.next();
            c = c.next().value;
            c = xq(a, c);
            if (!c) throw Ep("vnd");
            return c.value
        }
        if (w(b) && 37 === b[0]) {
            var d = n(b);
            d.next();
            c = d.next().value;
            d = ja(d);
            c = Hq(c) ? Iq(a, c, !0) : Jq(a, c);
            if (!y(c)) throw Ep("tenf");
            d = M(G(a, Jq), d);
            return c.apply(null, d)
        }
        if (w(b) && 24 === b[0]) return Kq(a, b);
        if (Hq(b)) return Iq(a, b);
        if (w(b) && 23 === b[0]) return Nq(a, b);
        if (w(b) && 22 === b[0]) return Vq(a, b);
        if (w(b) &&
            29 === b[0]) return Wq(a, b);
        if (w(b) && 25 === b[0]) return Xq(a, b);
        if (w(b) && 27 === b[0]) {
            d = n(b);
            d.next();
            var e = d.next().value;
            c = d.next().value;
            d = d.next().value;
            switch (e) {
                case "++":
                    e = "+=";
                    break;
                case "--":
                    e = "-=";
                    break;
                default:
                    throw Dp("uo");
            }
            c ? c = Zq(a, d, 1, e) : (c = Jq(a, d), Zq(a, d, 1, e));
            return c
        }
        if (w(b) && 31 === b[0]) return $q(a, b);
        if (w(b) && 33 === b[0]) {
            c = n(b);
            c.next();
            d = c.next().value;
            e = c.next().value;
            c = c.next().value;
            if ("&&" === d) c = (d = Jq(a, e)) ? Jq(a, c) : d;
            else if ("||" === d) c = (d = Jq(a, e)) ? d : Jq(a, c);
            else throw Dp("uo");
            return c
        }
        if (w(b) &&
            36 === b[0]) return e = n(b), e.next(), d = e.next().value, c = e.next().value, e = e.next().value, d = Jq(a, d), Jq(a, d ? c : e)
    }

    function ar(a) {
        return w(a) && (18 === a[0] || 19 === a[0])
    }

    function br(a, b) {
        var c = n(b),
            d = c.next().value;
        c = ja(c);
        var e = 18 === d;
        M(function(f) {
            var g = n(f),
                h = g.next().value;
            g = g.next().value;
            if (e && 1 === f.length) throw Dp("mca");
            f = a[a.length - 1].pc;
            if (I(f, h)) throw Ep("vr");
            g = z(g) ? g : Jq(a, g);
            f[h] = {
                kind: e ? 0 : 1,
                value: g
            }
        }, c)
    }

    function cr(a, b) {
        var c = n(b);
        c.next();
        var d = c.next().value;
        Aq(a, "return", "irs", function() {
            return z(d) ? d : Jq(a, d)
        })
    }

    function dr(a) {
        var b = {
            Ab: !1
        };
        a = zq(a, void 0, {
            "continue": function() {
                b.Ab = !0
            },
            "break": r
        });
        b.stack = a;
        b.vc = a[a.length - 1];
        return b
    }

    function er(a, b) {
        var c = a.vc;
        fr(a.stack, b);
        a.Ab && (c.hb = !0, a.Ab = !1);
        return c.hb
    }

    function gr(a, b) {
        b = void 0 === b ? !1 : b;
        if (A(a)) return [];
        var c = Qb(function(f) {
                return (f = Object.getOwnPropertyDescriptor(a, f)) ? f.enumerable : !1
            }, Object.getOwnPropertyNames(a)),
            d = Object.getPrototypeOf(a),
            e = d ? c.concat(gr(d, !0)) : c;
        return b ? e : Qb(function(f, g) {
            return jb(f, e) === g
        }, e)
    }

    function fr(a, b) {
        if (w(b) && 3 === b[0]) Lq(a, b);
        else if (ar(b)) br(a, b);
        else if (w(b) && 2 === b[0]) {
            var c = n(b);
            c.next();
            c = c.next().value;
            Jq(a, c)
        } else if (w(b) && 7 === b[0]) {
            var d = n(b);
            d.next();
            c = d.next().value;
            var e = d.next().value;
            d = d.next().value;
            Jq(a, c) ? fr(a, e) : d && fr(a, d)
        } else if (8 === b[0]) {
            c = n(b);
            c.next();
            var f = c.next().value;
            c = ja(c);
            d = e = !1;
            var g = [],
                h = [];
            f = Jq(a, f);
            for (var k = 0; k < c.length; k += 1) {
                var l = n(c[k]);
                l.next();
                var m = l.next().value;
                l = ja(l);
                var p = Sa(m);
                d = d || p;
                p || (e = e || Jq(a, m) === f);
                e && (g = g.concat(l));
                d && (h =
                    h.concat(l))
            }
            Lq(a, [3].concat(ka(e ? g : h)), {}, {
                "break": r
            })
        } else if (w(b) && 4 === b[0]) cr(a, b);
        else if (w(b) && 5 === b[0]) Aq(a, "break", "ibs");
        else if (w(b) && 6 === b[0]) Aq(a, "continue", "ics");
        else if (w(b) && 15 === b[0])
            for (g = n(b), g.next(), d = g.next().value, c = g.next().value, e = g.next().value, g = g.next().value, h = dr(a), d && (ar(d) ? br(h.stack, d) : Jq(h.stack, d)), d = !0; d && (!c || Jq(h.stack, c));) d = er(h, g), e && d && Jq(h.stack, e);
        else if (w(b) && 16 === b[0])
            for (e = n(b), e.next(), c = e.next().value, g = e.next().value, e = e.next().value, d = dr(a), g = Jq(d.stack,
                    g), g = gr(g), f = !0, h = 0; f && h < g.length; h += 1) f = g[h], ar(c) ? (k = yq(), 0 < h && d.stack.pop(), d.stack.push(k), d.vc = k, m = n(c), k = m.next().value, m = n(m.next().value).next().value, br(d.stack, [k, [m, f]])) : $q(d.stack, [31, "=", c, f]), f = er(d, e)
    }

    function Lq(a, b, c, d) {
        b = n(b);
        b.next();
        b = ja(b);
        a = zq(a, c, d);
        c = a[a.length - 1];
        for (d = 0; d < b.length && c.hb; d += 1) fr(a, b[d])
    }

    function hr(a, b, c, d, e) {
        b = n(b);
        b.next();
        var f = b.next().value;
        b = ja(b);
        a = {
            I: c.I,
            Wb: c.Wb,
            l: a,
            le: f,
            containerId: c.containerId,
            event: c.event
        };
        f = {};
        c = P(c.data, (f.ytmOnFailure = function() {
            return e()
        }, f.ytmOnSuccess = function() {
            return d()
        }, f));
        var g;
        f = {};
        c = zq([], (f.undefined = {
            kind: 0,
            value: void 0
        }, f.require = {
            kind: 0,
            value: N(wq, Oa(be)(a))
        }, f.data = {
            kind: 0,
            value: c
        }, f), {
            "return": function(h) {
                g = h
            }
        });
        Lq(c, [3].concat(ka(b)));
        return g
    }

    function ir(a, b, c, d) {
        var e = b.defaultValue,
            f = c(b.key);
        if (f) return d.checkPermission({
            ja: b,
            permissionType: "dataLayer",
            F: {
                key: f,
                operation: 2
            }
        }), a = J(a, f), A(a) ? e ? c(e) : void 0 : a
    }
    var jr = L(function(a, b, c) {
        b = void 0 === c.min ? 0 : c.min;
        b = a.Math.random() * ((void 0 === c.max ? 2147483647 : c.max) - b + 1) + b;
        return (void 0 === c.isInt ? 0 : c.isInt) ? a.Math.floor(b) : b
    }, mb);

    function kr(a, b) {
        var c = a(b);
        return A(c) ? void 0 : "" + c
    }
    var lr = /^[\s\xa0]+/g,
        mr = /[\s\xa0]+$/g,
        nr = /(\xa0+|\s{2,}|\n|\r|\t)/g;

    function or(a) {
        return (a = a.innerText || a.textContent || "") ? a.replace(lr, "").replace(mr, "").replace(nr, " ") : a
    }

    function pr(a, b) {
        try {
            return tj(a, b)
        } catch (c) {
            throw Ep("ies");
        }
    }

    function qr(a, b, c) {
        var d = b.multi,
            e = b.dataType,
            f = c(b.selector);
        if (!f) return null;
        a = pr(f, a.document);
        a = M(function(g) {
            if ("text" === e) return or(g);
            var h = c(b.attr);
            return h ? g.getAttribute && g.getAttribute(h) : or(g)
        }, a);
        return d ? a : a.length ? a[0] : null
    }

    function rr(a, b) {
        return b.length > a.length ? !1 : a.substring(a.length - b.length) === b
    }

    function sr(a, b) {
        return u(a) && u(b) ? rr(a, b) : !1
    }

    function tr(a, b) {
        return a === b
    }

    function ur(a, b) {
        return w(a) ? O(b, a) : u(a) ? Ia(a, "" + b) : !1
    }

    function vr(a, b, c) {
        return Zb(a, b) && Zb(a, c) ? b < c : !1
    }

    function wr(a, b, c) {
        a = Te(a);
        if (!a || !u(c) || !Al(b)) return !1;
        try {
            return a.call(b, c)
        } catch (d) {
            return !1
        }
    }

    function xr(a, b, c) {
        return Zb(a, b) && Zb(a, c) ? b > c : !1
    }

    function yr(a, b, c) {
        if (!u(b) || !u(c)) return !1;
        try {
            return (new RegExp(c, a ? "i" : "")).test(b)
        } catch (d) {
            return !1
        }
    }

    function zr(a, b) {
        return u(a) && u(b) ? hj(a, b) : !1
    }

    function Ar(a, b) {
        if ("eq" === b) return tr;
        if ("more" === b) return G(a, xr);
        if ("less" === b) return G(a, vr);
        if ("regex" === b) return G(!1, yr);
        if ("iRegex" === b) return G(!0, yr);
        if ("css" === b) return G(a, wr);
        if ("inc" === b) return ur;
        if ("start" === b) return zr;
        if ("end" === b) return sr;
        throw Wd("fn: " + b);
    }

    function Br(a) {
        return xa("escape", CSS.escape) ? "#" + CSS.escape(a) : "[id='" + a + "']"
    }

    function Cr(a, b) {
        if (a.document.hidden) return !1;
        var c = $e(b);
        if (A(c) || c.top === c.bottom || c.left === c.right || !a.getComputedStyle) return !1;
        var d = a.getComputedStyle(b);
        if ("hidden" === d.visibility) return !1;
        for (c = b; c;) {
            if ("none" === d.display || "0" === d.opacity || "0%" === d.opacity) return !1;
            (c = c.parentElement) && (d = a.getComputedStyle(c))
        }
        return !0
    }

    function Dr(a, b) {
        var c = $e(b);
        if (A(c)) return 0;
        var d = c.right - c.left,
            e = c.bottom - c.top;
        if (!d || !e) return 0;
        var f = n(Xe(a)),
            g = f.next().value;
        f = f.next().value;
        return (1 - Math.min((Math.max(0 - c.left, 0) + Math.max(c.right - g, 0)) / d, 1)) * (1 - Math.min((Math.max(0 - c.top, 0) + Math.max(c.bottom - f, 0)) / e, 1))
    }

    function Er(a) {
        try {
            return parseFloat(a)
        } catch (b) {
            return null
        }
    }

    function Fr(a) {
        var b = [],
            c = [],
            d = !1;
        return {
            cb: function(e) {
                c.push(e)
            },
            add: function(e) {
                b.push(e)
            },
            aa: function() {
                if (!d) {
                    d = !0;
                    for (var e; e = 0 < c.length ? c.shift() : b.shift();) a(e);
                    d = !1
                }
            }
        }
    }
    var Hr = Tp("v.e.r", function(a, b, c, d) {
        var e = a.l,
            f = a.I,
            g = a.Tb,
            h = G(c, kr);
        if ("event" === d.type) return ir(b, {
            type: "dataLayer",
            key: "event",
            permissions: d.permissions
        }, h, f);
        if ("dataLayer" === d.type) return ir(b, d, h, f);
        if ("cnst" === d.type) return c(d.value);
        if ("counterId" === d.type) return a.counterId;
        if ("rand" === d.type) return jr(e, b, d);
        if ("url" === d.type || "ref" === d.type) {
            a: {
                a = !1;b = d.component;
                var k = "url" === d.type ? (k = d.urlSource) ? h(k) : J(e, "location.href") : J(e, "document.referrer");
                if (k) {
                    if ("queryVar" === b) {
                        var l = h(d.key);
                        if (!l) {
                            d = void 0;
                            break a
                        }
                    }
                    "host" === b && (a = d.Ue);
                    f.checkPermission({
                        ja: d,
                        permissionType: "url" === d.type ? "url" : "referrer",
                        F: {
                            urlComponent: b,
                            variableName: l
                        }
                    });
                    d = lh(e, k);
                    d = $p(d, b, l, a)
                } else d = void 0
            }
            return d
        }
        if ("cookie" === d.type) return "null" === e.origin ? d = "" : (h = h(d.cookieName)) ? (f.checkPermission({
            ja: d,
            permissionType: "cookies",
            F: {
                name: h,
                operation: 2
            }
        }), d = Yp(e, h, d.decode)[0] || "") : d = "", d;
        if ("js" === d.type) return (h = h(d.key)) ? (f.checkPermission({
                ja: d,
                permissionType: "globals",
                F: {
                    key: h,
                    operation: 2
                }
            }), d = J(e, h)) : d =
            void 0, d;
        if ("dom" === d.type) return qr(e, d, h);
        if ("pro" === d.type) {
            e = g.gd();
            try {
                return k = Gr(a, b, d, {
                    cb: r,
                    add: r,
                    aa: r
                }, r, G(Dp("v.e.of"), Td)), e("success"), k
            } catch (m) {
                throw e("failure"), m;
            }
        }
        if ("table" === d.type) {
            a: {
                f = h(d.input);l = d.rows;
                for (a = 0; a < l.length; a += 1)
                    if (b = l[a], k = h(b.target), Ar(e, b.fn)(f, k)) {
                        d = h(b.output);
                        break a
                    }
                d = h(d["default"])
            }
            return d
        }
        if ("ev" === d.type) {
            a: {
                f = d.ot;
                if ("id" === d.sm) {
                    l = h(d.id);
                    if (!u(l) || !l) {
                        d = void 0;
                        break a
                    }
                    l = Br(l)
                } else if (l = h(d.selector), !u(l) || !l) {
                    d = void 0;
                    break a
                }(l = uj(l, e.document)) &&
                Cr(e, l) ? (l = Math.round(1E4 * Dr(e, l)) / 100, "b" === f ? (f = null, d = h(d.srp), A(d) || (f = Er(d), f = !rb(e, f) || 0 > f || 100 < f ? null : f), d = l >= (f || 50)) : d = l) : d = void 0
            }
            return d
        }
        if ("contDbm" === d.type) return !0 === a.config.isPreview
    }, void 0, function(a, b, c, d) {
        b = {
            type: "v",
            eventId: b.ytm.eventId
        };
        !0 === a.config.isPreview && (b.id = d.id);
        return b
    });

    function Ir(a, b, c) {
        var d = a.config.variables[c];
        if (!d) throw Dp("var: " + c);
        c = F([a, b], Jr);
        return Hr(a, b, c, d)
    }
    var Kr = /^(?!-*(?:expression|(?:moz-)?binding))(?:\s*|(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[a-z]{1,4}|%)?|[a-z-]+\([^)]*\)|"[^"]*"|'[^']*')(?:\s*!important)?)$/i,
        Lr = /[\x00\x08-\x0d\x22\x26-\x2a/\x3a-\x3e@\\\x7b\x7d\x85\xa0\u2028\u2029]/g,
        Mr = {
            "\x00": "\\0 ",
            "\b": "\\8 ",
            "\t": "\\9 ",
            "\n": "\\a ",
            "\v": "\\b ",
            "\f": "\\c ",
            "\r": "\\d ",
            '"': "\\22 ",
            "&": "\\26 ",
            "'": "\\27 ",
            "(": "\\28 ",
            ")": "\\29 ",
            "*": "\\2a ",
            "/": "\\2f ",
            ":": "\\3a ",
            ";": "\\3b ",
            "<": "\\3c ",
            "=": "\\3d ",
            ">": "\\3e ",
            "@": "\\40 ",
            "\\": "\\5c ",
            "{": "\\7b ",
            "}": "\\7d ",
            "\u0085": "\\85 ",
            "\u00a0": "\\a0 ",
            "\u2028": "\\2028 ",
            "\u2029": "\\2029 "
        };

    function Nr(a) {
        return a.replace(Lr, function(b) {
            return Mr[b]
        })
    }
    var Or = /[\x00\x09-\x0d\x22\x26\x27\x2d\x2f\x3c\x3e\x3d\x60\x85\xa0\u2028\u2029]/g,
        Pr = {
            "\x00": "&#0;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "<": "&lt;",
            ">": "&gt;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            "-": "&#45;",
            "/": "&#47;",
            "=": "&#61;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };

    function Qr(a) {
        return a.replace(Or, function(b) {
            return Pr[b]
        })
    }
    var Rr = /[\x00\x08-\x0d\x22\x24\x26-\x29\x2a-\x2e/\x3a\x3c-\x3f\x5b-\x5e\x7b-\x7d\\\x85\u2028\u2029]/g,
        Sr = {
            "\x00": "\\x00",
            "\b": "\\x08",
            "\t": "\\t",
            "\n": "\\n",
            "\v": "\\x0b",
            "\f": "\\f",
            "\r": "\\r",
            '"': "\\x22",
            "&": "\\x26",
            "'": "\\x27",
            "/": "\\/",
            "<": "\\x3c",
            "=": "\\x3d",
            ">": "\\x3e",
            "\\": "\\\\",
            "\u0085": "\\x85",
            "\u2028": "\\u2028",
            "\u2029": "\\u2029",
            Ie: "\\x24",
            "(": "\\x28",
            ")": "\\x29",
            "*": "\\x2a",
            "+": "\\x2b",
            ",": "\\x2c",
            "-": "\\x2d",
            ".": "\\x2e",
            ":": "\\x3a",
            "?": "\\x3f",
            "[": "\\x5b",
            "]": "\\x5d",
            "^": "\\x5e",
            "{": "\\x7b",
            "|": "\\x7c",
            "}": "\\x7d"
        };

    function Tr(a) {
        return a.replace(Rr, function(b) {
            return Sr[b]
        })
    }
    var Ur = /['()]/g;

    function Vr(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }
    var Wr = /^(?:(?:https?|mailto|tel):|[^&:/?#]*(?:[/?#]|$))/i,
        Xr = /[\x00-\x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Yr = {
            "\x00": "%00",
            "\u0001": "%01",
            "\u0002": "%02",
            "\u0003": "%03",
            "\u0004": "%04",
            "\u0005": "%05",
            "\u0006": "%06",
            "\u0007": "%07",
            "\b": "%08",
            "\t": "%09",
            "\n": "%0A",
            "\v": "%0B",
            "\f": "%0C",
            "\r": "%0D",
            "\u000e": "%0E",
            "\u000f": "%0F",
            "\u0010": "%10",
            "\u0011": "%11",
            "\u0012": "%12",
            "\u0013": "%13",
            "\u0014": "%14",
            "\u0015": "%15",
            "\u0016": "%16",
            "\u0017": "%17",
            "\u0018": "%18",
            "\u0019": "%19",
            "\u001a": "%1A",
            "\u001b": "%1B",
            "\u001c": "%1C",
            "\u001d": "%1D",
            "\u001e": "%1E",
            "\u001f": "%1F",
            " ": "%20",
            '"': "%22",
            "'": "%27",
            "(": "%28",
            ")": "%29",
            "<": "%3C",
            ">": "%3E",
            "\\": "%5C",
            "{": "%7B",
            "}": "%7D",
            "\u007f": "%7F",
            "\u0085": "%C2%85",
            "\u00a0": "%C2%A0",
            "\u2028": "%E2%80%A8",
            "\u2029": "%E2%80%A9",
            "\uff01": "%EF%BC%81",
            "\uff03": "%EF%BC%83",
            "\uff04": "%EF%BC%84",
            "\uff06": "%EF%BC%86",
            "\uff07": "%EF%BC%87",
            "\uff08": "%EF%BC%88",
            "\uff09": "%EF%BC%89",
            "\uff0a": "%EF%BC%8A",
            "\uff0b": "%EF%BC%8B",
            "\uff0c": "%EF%BC%8C",
            "\uff0f": "%EF%BC%8F",
            "\uff1a": "%EF%BC%9A",
            "\uff1b": "%EF%BC%9B",
            "\uff1d": "%EF%BC%9D",
            "\uff1f": "%EF%BC%9F",
            "\uff20": "%EF%BC%A0",
            "\uff3b": "%EF%BC%BB",
            "\uff3d": "%EF%BC%BD"
        };

    function Zr(a) {
        Wr.lastIndex = 0;
        return Wr.test(a) ? a.replace(Xr, function(b) {
            return Yr[b]
        }) : "#sYTMs"
    }

    function Jr(a, b, c) {
        if (w(c)) {
            if ("template" === c[0]) return U("", M(function(e) {
                return Jr(a, b, e)
            }, c.slice(1)));
            if ("var" === c[0]) return c = n(c), c.next(), c = c.next().value, Ir(a, b, c);
            if ("escape" === c[0]) {
                var d = n(c);
                d.next();
                c = d.next().value;
                d = ja(d);
                c = Jr(a, b, c);
                return H(function(e, f) {
                    if (7 === f) var g = a.Eb(e);
                    else g = "" + e, 4 === f ? g = Tr(g) : 3 === f ? g = Qr(g) : 2 === f ? g = Zr(g) : 6 === f ? A(e) ? g = "" : (g = "" + e, g = Kr.test(g) ? g : "sYTMs") : 5 === f ? g = Nr(g) : 1 === f && (g = pd(g), Ur.lastIndex = 0, g = Ur.test(g) ? g.replace(Ur, Vr) : g);
                    return g
                }, c, d)
            }
            if ("table" ===
                c[0]) return c = n(c), c.next(), c = ja(c), M(function(e) {
                return H(function(f, g) {
                    f[g] = Jr(a, b, e[g]);
                    return f
                }, {}, ec(e))
            }, c);
            if ("list" === c[0]) return c = n(c), c.next(), c = ja(c), M(function(e) {
                return Jr(a, b, e)
            }, c)
        } else return c
    }

    function $r(a, b) {
        return {
            checkPermission: function(c) {
                b.checkPermission(P({
                    ja: a
                }, c))
            },
            R: function(c) {
                return b.R(P({
                    ja: a
                }, c))
            }
        }
    }

    function Gr(a, b, c, d, e, f) {
        var g = a.l,
            h = a.config,
            k = a.I,
            l = c.data;
        if (!w(l)) {
            if (!I(h, "code") || !w(h.code) || !h.code[l]) throw Wd("mp");
            l = h.code[l]
        }
        k = $r(c, k);
        c = H(function(m, p) {
            var q = n(p),
                v = q.next().value;
            q = q.next().value;
            q = Jr(a, b, q);
            m[v] = Gp(g, q);
            return m
        }, {}, dc(c.settings || {}));
        return hr(g, l, {
            containerId: h.containerId,
            I: k,
            Wb: d,
            data: c,
            event: b
        }, e, f)
    }

    function as(a, b) {
        var c = P({}, b, {
            eventId: Um()
        });
        return {
            event: a,
            ytm: c
        }
    }

    function bs(a) {
        var b = H(function(e, f) {
                return e + f
            }, 0, hc(a.data.tm)),
            c = P({}, a.data.tm),
            d = b;
        return {
            update: function(e) {
                if (!I(c, "" + e)) return !1;
                var f = c[e];
                if (0 >= f) return !1;
                c[e] = f - 1;
                --d;
                return 0 === d
            },
            reset: function() {
                c = P({}, a.data.tm);
                d = b
            }
        }
    }

    function cs(a, b, c) {
        a = a.qd;
        var d = bs(c);
        a.C(function(e) {
            d.update(e) && (b(as("ytm.group", {
                trigger: c.data.trigger
            })), d.reset())
        })
    }
    var ds = L(Md),
        es = {},
        fs = (es.group = function(a, b, c, d, e, f) {
            b = c.data.trigger;
            var g = ds(a);
            if (g[b]) f(Ep("t.a.s.g"));
            else {
                try {
                    cs(a, N(d.cb, d.aa), c)
                } catch (h) {
                    f(h);
                    return
                }
                g[b] = !0;
                e()
            }
        }, es.paused = r, es.pro = Gr, es);

    function gs(a, b, c, d) {
        return new Z(function(e, f) {
            if (I(fs, c.type))(0, fs[c.type])(a, b, c, d, e, f);
            else f(Dp("y.u.t." + c.type, "yme"))
        })
    }

    function hs(a, b, c, d, e) {
        var f = a.config,
            g = a.Tb,
            h = !0 === f.isPreview;
        c = M(function(k) {
            function l() {
                return Z.all(M(function(q) {
                    return gs(a, b, f.tags[q], e)
                }, m.ft || []))
            }
            var m = f.tags[k];
            if (!m) return Z.reject(Wd("i.conf." + f.containerVersion + "-" + k));
            var p = g.ed(m.type, m.id);
            return gs(a, b, m, e).then(function() {
                p("success");
                return Z.all(M(function(q) {
                    return gs(a, b, f.tags[q], e)
                }, m.ct || []))
            }, function(q) {
                p("failure");
                var v = {
                    eventId: b.ytm.eventId,
                    type: "t"
                };
                h && (v.id = m.id);
                Up("t.e.r", v)(q)
            }).then(l, l)
        }, Tk(function(k, l) {
            return k -
                l
        }, c));
        M(Tp("t.e.m", ce), d);
        Z.all(c)["catch"](Up("t.e", {
            type: "c",
            eventId: b.ytm.eventId
        }))
    }
    var is = ["ytm.consent", "consent"],
        js = ["default", "update"];

    function ks(a) {
        var b = Ta(a.classList),
            c = or(a),
            d = a.getAttribute("id");
        var e = a.getAttribute("formAction") || a.getAttribute("action") || a.getAttribute("href") || a.getAttribute("src") || a.getAttribute("code") || a.getAttribute("codebase") || "";
        return {
            element: a,
            elementClasses: b,
            elementText: c,
            elementId: d,
            elementUrl: e,
            elementTarget: a.getAttribute("formTarget") || a.getAttribute("target") || ""
        }
    }
    var ls = ["ytm.click", "ytm.linkClick", "ytm.formSubmit"];

    function ms(a, b, c) {
        return O(b, ls) && c ? as(b, ks(c)) : "ytm.init" === b || "ytm.init_consent" === b ? as(b, {
            timestamp: X(a)(gf)
        }) : as(b, {})
    }

    function ns(a, b) {
        var c = a.data;
        c = "id" === c.Xc ? Br(c.id) : c.selector;
        var d = [];
        Al(b) && b.matches(c) && d.push(b);
        return d.concat(pr(c, b))
    }

    function os() {
        return {
            na: !1,
            ya: !1,
            Z: null,
            zb: 0
        }
    }

    function ps(a, b, c) {
        function d(t, x, E) {
            var C = ks(t);
            x = as("ytm.elementVisibility", {
                element: t,
                elementClasses: C.elementClasses,
                elementText: C.elementText,
                elementId: C.elementId,
                visibleRatioPercent: Math.round(1E4 * x) / 100,
                visibleDuration: E / 1E3,
                trigger: c.data.trigger
            });
            E = g(t);
            "opp" === p ? E.ya || (q.disconnect(), h && h.disconnect(), E.ya = !0, E.na = !1, b(x)) : "ope" === p ? E.na && !E.ya && (q.unobserve(t), E.ya = !0, E.na = !1, b(x)) : b(x)
        }

        function e(t) {
            q.unobserve(t);
            t = g(t);
            t.Z && (f.clearInterval(t.Z), t.Z = null);
            t.na = !1
        }
        var f = a.l;
        a = a.uc;
        var g = L(os),
            h = null,
            k = c.data,
            l = k.Wc,
            m = k.$b,
            p = k.Fc;
        k = k.Pc;
        var q = new f.IntersectionObserver(V(f, "ytm.ev.ioc", function(t) {
                return M(function(x) {
                    var E = x.target;
                    x = x.intersectionRatio;
                    var C = g(E);
                    C.Z && (f.clearInterval(C.Z), C.Z = null);
                    if (!(x < m / 100 || !C.na || C.ya))
                        if (0 === l) d(E, x, 0);
                        else {
                            var S = C.zb,
                                ea = X(f)(gf);
                            C.Z = uf(f, function() {
                                var Lg = X(f)(gf);
                                C.zb = S + Lg - ea;
                                C.zb < l || ("mpe" === p ? (C.zb = 0, ea = X(f)(gf)) : C.Z && (f.clearInterval(C.Z), C.Z = null), C.ya || d(E, Dr(f, E), l))
                            }, 100, "yt.ev")
                        }
                }, t)
            }), {
                threshold: [c.data.$b / 100]
            }),
            v = Hb(function(t) {
                var x =
                    g(t);
                x.ya || x.na || (q.observe(t), x.na = !0)
            });
        v(ns(c, f.document));
        k && xa("MutationObserver", f.MutationObserver) && (h = new f.MutationObserver(V(f, "c.io.ev", function(t) {
            return M(function(x) {
                    switch (x.type) {
                        case "childList":
                            M(function(ea) {
                                Al(ea) && v(ns(c, ea))
                            }, x.addedNodes);
                            M(function(ea) {
                                Al(ea) && (ea = ns(c, ea), M(e, ea))
                            }, x.removedNodes);
                            break;
                        case "attributes":
                            var E = x.target,
                                C = x.attributeName;
                            x = x.oldValue;
                            if (Al(E) && C && x !== E.getAttribute(C)) {
                                var S = ns(c, E);
                                v(S);
                                Dk(f, E, function(ea) {
                                    Al(ea) && g(ea).na && !O(ea, S) && e(ea)
                                })
                            }
                    }
                },
                t)
        })), h.observe(f.document.body, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeOldValue: !0
        }));
        a(function() {
            q.disconnect();
            h && h.disconnect()
        })
    }

    function qs(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        var e = a.l,
            f = null;
        A(c) || (a = "" + Jr(a, b, c), f = d ? Er(a) : sb(a), rb(e, f) || (f = null));
        return f
    }
    var rs = L(Md),
        ss = L(function(a) {
            return (a = J(a, "trustedTypes")) ? a.createPolicy("ytm#policy", {
                createHTML: lb,
                createScript: lb,
                createScriptURL: lb
            }) : null
        });

    function ts(a) {
        for (var b = []; a.firstChild;) b.push(a.removeChild(a.firstChild));
        return b
    }

    function us(a) {
        return (a = Le(function(b) {
            return !!b.nonce
        }, tj("style, link, script", a.document))) ? a.nonce : void 0
    }

    function vs(a, b, c, d, e, f, g) {
        b = b("script");
        b.type = "text/javascript";
        b.async = g.async;
        g.src && (b.src = c ? c.createScriptURL(g.src) : g.src, b.onload = function() {
            return e()
        });
        g.text && (b.text = c ? c.createScript(g.text) : g.text);
        sj(a) && (a = us(a)) && b.setAttribute("nonce", a);
        b.charset = g.charset;
        b.id = g.id;
        b.onerror = function() {
            return f()
        };
        d(b, null);
        A(g.src) && e()
    }

    function ws(a, b, c, d, e) {
        try {
            if (0 === b.length) d();
            else {
                var f = b.shift();
                if (f) {
                    var g = zb("insertBefore", a);
                    if (Sa(g)) e();
                    else {
                        var h = F([a, b, c, d, e], ws);
                        if ("SCRIPT" === bf(f) && "text/ytmscript" === f.type) c(g, h, e, {
                            text: f.text || f.textContent || f.innerText || "",
                            charset: f.charset || "",
                            async: !1,
                            id: f.id,
                            src: f.getAttribute("data-ytmsrc")
                        });
                        else if (f.innerHTML && -1 < Ca(f.innerHTML.toLowerCase(), "<script")) {
                            var k = ts(f);
                            g(f, null);
                            ws(f, k, c, h, e)
                        } else g(f, null), h()
                    }
                } else e()
            }
        } catch (l) {
            e()
        }
    }

    function xs(a, b, c, d) {
        u(b) ? Af(a, "ytm")(wf(d, function() {
            var e = "<div>" + b + "</div>",
                f = Pe(a),
                g = f("div"),
                h = ss(a);
            g.innerHTML = h ? h.createHTML(e) : e;
            A(g.lastChild) ? c() : (e = ts(g.lastChild), f = F([a, f, h], vs), ws(a.document.body, e, f, c, d))
        })) : d()
    }

    function ys(a) {
        return u(a) ? H(function(b, c) {
            var d = sb(c);
            !A(d) && 0 <= d && 100 >= d && b.push(d);
            return b
        }, [], a.split(",")) : []
    }
    var zs = L(Md),
        As = L(function(a, b) {
            function c() {
                M(function(t) {
                    t = +t;
                    if (!(t > k)) {
                        var x = h[t];
                        x && b(as("ytm.scrollDepth", {
                            direction: "vertical",
                            units: "percent",
                            threshold: t,
                            tags: x
                        }));
                        delete h[t]
                    }
                }, ec(h));
                0 === ec(h).length && e()
            }

            function d() {
                var t = f.scrollY,
                    x = n(Xe(f));
                x.next();
                x = x.next().value;
                var E = n(Ze(f));
                E.next();
                x = E.next().value - x;
                0 >= x || !f.isFinite(x) || (t = Math.max(0, Math.min(100, Math.round(t / x * 100))), t > k && (k = t), c())
            }

            function e() {
                m.ua(f, [q], v);
                m.ua(f, ["resize"], d);
                l = !1
            }
            var f = a.l,
                g = a.uc,
                h = {},
                k = 0,
                l = !1,
                m = Xc(f),
                p = I(f, "onscrollend"),
                q = p ? "scrollend" : "scroll",
                v = p ? d : Wm(f, d, 100, "ytm.sd").fn;
            g(e);
            return function(t, x) {
                M(function(E) {
                    I(h, "" + E) || (h[E] = []);
                    (E = h[E]) && !O(t, E) && E.push(t)
                }, x);
                !l && 0 < ec(h).length && (m.C(f, [q], v), m.C(f, ["resize"], d), l = !0);
                d()
            }
        });

    function Bs(a, b) {
        var c = a.l,
            d = a.dispatchEvent;
        if (b.limit && b.sequence >= b.limit && b.id) c.clearInterval(b.id);
        else {
            b.sequence += 1;
            c = X(c)(gf);
            var e = {};
            c = as("ytm.timer", (e.id = +b.id, e.sequence = b.sequence, e.interval = b.interval, e.limit = b.limit, e.startTime = b.startTime, e.currentTime = c, e.elapsedTime = c - b.startTime, e.timer = b.xe, e));
            d(c)
        }
    }
    var Cs = L(Md);

    function Ds(a, b, c, d) {
        if (!I(b, c)) return !1;
        a = b[c];
        if (I(a, "allKeys") && a.allKeys & d.operation) return !0;
        if (!I(a, "keys")) return !1;
        a = a.keys;
        b = d.key;
        return I(a, b) ? !!(a[b] & d.operation) : !1
    }

    function Es(a, b, c, d) {
        if (!I(b, c)) return !1;
        b = b[c];
        if (I(b, "allUrls")) return !!b.allUrls;
        if (!I(b, "allow")) return !1;
        var e = d.url;
        return sc(function(f) {
            var g = lh(a, e);
            if (!g.protocol || "https:" !== g.protocol) return !1;
            f = lh(a, f);
            return g.host && f.host && (hj(f.host, "*.") ? rr(g.host, f.host.substring(2)) : g.host === f.host) ? "/" === f.pathname ? !0 : rr(f.pathname, "/*") ? hj(g.pathname, f.pathname.substring(0, f.pathname.length - 2)) : f.pathname === g.pathname : !1
        }, b.allow)
    }

    function Fs(a, b, c, d) {
        if (!I(b, c)) return !1;
        a = b[c];
        b = d.urlComponent;
        if ("queryVar" === b) {
            if (I(a, "query") && a.query) return !0;
            d = d.variableName;
            return I(a, "queryVars") && d ? O(d, a.queryVars) : !1
        }
        return !!a[b]
    }
    var Gs = {},
        Hs = (Gs.cookies = function(a, b, c, d) {
            if (!I(b, "cookies")) return !1;
            b = b.cookies;
            a = d.operation;
            if (I(b, "allKeys") && 2 === a) return !!(b.allKeys.access & a);
            if (!I(b, "keys")) return !1;
            c = b.keys;
            var e = d.name;
            b = I(c, e) ? c[e] : {
                access: 0
            };
            if (2 === a) return !!(b.access & a);
            if (1 === a) {
                d = d.options;
                if (!I(c, e) || !d) return !1;
                c = b.access;
                e = b.domain;
                var f = b.path,
                    g = b.secure,
                    h = b.Te,
                    k = !A(d.expires) || !A(d["max-age"]);
                if (I(b, "session") && h)
                    if (1 === h) {
                        if (k) return !1
                    } else if (!k) return !1;
                return !(c & a) || I(b, "domain") && e !== d.domain || I(b, "path") &&
                    f !== d.path || I(b, "secure") && (1 === g && !d.secure || 2 === g && d.secure) ? !1 : !0
            }
            return !1
        }, Gs.dataLayer = Ds, Gs.globals = Ds, Gs.iframe = Es, Gs.loadScript = Es, Gs.localStorage = Ds, Gs.log = function(a, b, c, d) {
            return I(b, "log") ? d.logLevel >= b.log : !1
        }, Gs.pixel = Es, Gs.readTitle = function(a, b) {
            return I(b, "readTitle") ? b.readTitle : !1
        }, Gs.referrer = Fs, Gs.templateStorage = function(a, b) {
            return I(b, "templateStorage") ? !!b.templateStorage : !1
        }, Gs.url = Fs, Gs);

    function Is(a, b, c) {
        var d = a.permissionType,
            e = a.F;
        a = {
            counterId: b,
            containerId: c,
            permissionType: a.permissionType
        };
        if ("globals" === d) {
            d = e.key;
            a: switch (e.operation) {
                case 2:
                    e = "read";
                    break a;
                case 1:
                    e = "write";
                    break a;
                case 4:
                    e = "execute";
                    break a;
                default:
                    throw Wd("uvac");
            }
            return P(a, {
                data: {
                    key: d,
                    operation: e
                }
            })
        }
        return "dataLayer" === d || "localStorage" === d ? P(a, {
            data: {
                key: e.key,
                operation: cq(e.operation)
            }
        }) : "url" === d || "referrer" === d ? P(a, {
            data: "queryVar" === e.urlComponent ? {
                component: e.urlComponent,
                key: e.variableName
            } : {
                component: e.urlComponent
            }
        }) : "iframe" === d || "loadScript" === d || "pixel" === d ? P(a, {
            data: {
                url: e.url
            }
        }) : "cookies" === d ? (d = cq(e.operation), b = e.name, c = e.options, e = 1 === e.operation && c ? {
            operation: d,
            name: b,
            options: P({}, c)
        } : {
            operation: d,
            name: b
        }, P(a, {
            data: e
        })) : P(a, {
            data: null
        })
    }
    var Js = "cookies dataLayer globals iframe loadScript localStorage log pixel readTitle referrer url html".split(" "),
        Ks = L(function() {
            var a = {};
            return {
                Ad: function(b, c) {
                    O(b, Js) && y(c) && (I(a, b) || (a[b] = []), a[b].push(c))
                },
                Cd: function(b, c, d) {
                    var e = I(a, b.permissionType) && a[b.permissionType];
                    if (!e) return !0;
                    var f = Is(b, c, d);
                    return !sc(function(g) {
                        try {
                            return !1 === g(f)
                        } catch (h) {
                            return !0
                        }
                    }, e)
                }
            }
        }),
        Ls = On + "-tags/_/ytm-debugger.js",
        Ms = /(?:^|\.)dzen\.ru$/,
        Ns = L(function(a) {
            a = T(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(Ms));
            return b
        }),
        Os = /(?:^|\.)vk\.link$/,
        Ps = L(function(a) {
            a = T(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(Os));
            return b
        }),
        Qs = RegExp("^(.*\\.)?((yandex(-team)?)\\.(?:\\w+|com?\\.\\w+)|ya\\.(ru|cc)|dzen\\.ru|vk\\.(ru|com)|ok\\.ru|pikabu\\.ru|vc\\.ru|avito\\.ru)$"),
        Rs = L(function(a) {
            a = T(a).hostname;
            return !!a && -1 !== a.search(Qs)
        });

    function Ss(a, b) {
        var c = Q(a),
            d = {};
        d = c.o("ydeb", (d.ctydl = [], d.ypc = b, d));
        c.B("ydeb", d);
        return d
    }
    var Ts = W("ytm.d.dl", function(a, b) {
        var c = vq(b),
            d = Ss(a, c);
        return {
            trigger: V(a, "ytm.d.tr", function(e) {
                100 <= d.ctydl.length && pc(d.ctydl);
                d.ctydl.push(e)
            })
        }
    });

    function Us(a, b) {
        var c = Ie(a, "", "ytm-debugger");
        b ? c.o("nonce") !== b && (c.B("nonce", b), c.wa("data")) : (c.wa("nonce"), c.wa("data"))
    }
    var Vs = "ytm.init_consent ytm.init ytm.js ytm.dom ytm.load ytm.click ytm.linkClick ytm.formSubmit ytm.timer ytm.scrollDepth ytm.elementVisibility ytm.group ytm.historyChange ytm.consent".split(" "),
        Ws = ["ytm.js"],
        Xs = ["ytm.js", "ytm.dom", "ytm.load"];

    function Ys(a) {
        a = J(a, "id");
        return !(!a || "ytm-debugger-script-root" !== a)
    }

    function Zs(a, b) {
        return Xc(a).C(a.document, ["click"], function(c) {
            (c = Pi(c)) && !Ys(c) && b(ms(a, "ytm.linkClick", c))
        })
    }

    function $s(a, b, c, d, e) {
        e = void 0 === e ? a.document : e;
        return Xc(a).C(e, d, function(f) {
            Ys(f.target) || b(ms(a, c, f.target))
        })
    }

    function at(a, b, c) {
        return O(a.document.readyState, ["complete", "interactive"]) ? (b(ms(a, c)), r) : $s(a, b, c, ["DOMContentLoaded"])
    }

    function bt(a) {
        var b = n(a.split("#"));
        a = b.next().value;
        b = b.next().value;
        if (b) try {
            var c = decodeURIComponent(b)
        } catch (d) {
            c = b
        } else c = "";
        return [a || "", c]
    }

    function ct(a, b, c) {
        var d = J(a, "history." + b);
        if (y(d)) {
            var e = V(a, "p.h.m." + ("pushState" === b ? "ps" : "rs"), function(f) {
                var g = n(bt(a.location.href)),
                    h = g.next().value;
                g = g.next().value;
                c({
                    source: "pushState" === b ? "pushState" : "replaceState",
                    state: f,
                    url: h,
                    xa: g
                })
            });
            try {
                a.history[b] = function(f, g, h) {
                    d.call(a.history, f, g, h);
                    e(f)
                }
            } catch (f) {}
        }
    }
    var dt = L(function(a) {
        var b = Bf(a),
            c = Xc(a);
        ct(a, "pushState", b.trigger);
        ct(a, "replaceState", b.trigger);
        c.C(a, ["hashchange"], V(a, "ho.hc", function(d) {
            var e = n(bt(J(d, "target.location.href") || a.location.href));
            d = e.next().value;
            e = e.next().value;
            b.trigger({
                source: "hashchange",
                state: null,
                url: d,
                xa: e
            })
        }));
        c.C(a, ["popstate"], V(a, "ho.ps", function(d) {
            var e = n(bt(J(d, "target.location.href") || a.location.href)),
                f = e.next().value;
            e = e.next().value;
            b.trigger({
                source: "popstate",
                state: d.state,
                url: f,
                xa: e
            })
        }));
        return b
    });

    function et(a, b) {
        var c = n(bt(a.location.href)),
            d = c.next().value;
        c = c.next().value;
        var e = {
            source: null,
            state: a.history.state,
            url: d,
            xa: c
        };
        d = Wm(a, function(f) {
                var g = "popstate" === e.source || "popstate" === f.source,
                    h = "hashchange" === e.source || "hashchange" === f.source;
                if (e.xa !== f.xa || !g || !h) {
                    g = P({}, e);
                    e = f;
                    h = f.source;
                    if (Sa(h)) throw Dp("m.e.hc");
                    f = as("ytm.historyChange", {
                        historyChangeSource: h,
                        oldUrlFragment: g.xa,
                        newUrlFragment: f.xa,
                        oldHistoryState: g.state,
                        newHistoryState: f.state,
                        oldUrl: g.url,
                        newUrl: f.url
                    });
                    b(f)
                }
            },
            50, "hc").fn;
        c = dt(a);
        c.C(d);
        return G(d, c.qa)
    }

    function ft(a, b, c) {
        if ("ytm.linkClick" === b) return Zs(a, c);
        if ("ytm.js" === b) return at(a, c, "ytm.js");
        if ("ytm.dom" === b) return at(a, c, "ytm.dom");
        if ("ytm.load" === b) return "complete" === a.document.readyState ? (c(ms(a, "ytm.load")), a = r) : a = $s(a, c, "ytm.load", ["load"], a), a;
        if ("ytm.click" === b) return $s(a, c, "ytm.click", ["click"]);
        if ("ytm.formSubmit" === b) return $s(a, c, "ytm.formSubmit", ["submit"], a);
        if ("ytm.historyChange" === b) return et(a, c)
    }

    function gt(a, b) {
        var c = a[b["var"]];
        c = c && "event" === c.type;
        var d = "regex" === b.fn || "eq" === b.fn;
        if (u(b.target) && c && d) return b
    }

    function ht(a) {
        return Fb(N(K("conditions"), Gb(G(a.variables, gt)), Rb), a.triggers)
    }

    function it(a, b, c) {
        var d = void 0 === d ? "dataLayer" : d;
        c = ht(c);
        var e = H(function(h, k) {
                var l = k.target;
                "eq" === k.fn && O(l, Vs) && -1 === jb(l, h) && h.push(l);
                return h
            }, [], c),
            f = H(function(h, k) {
                var l = k.target;
                "eq" === k.fn ? h.push(G(l, tr)) : Tp("dl.ee", function() {
                    h.push($a(new RegExp(l)))
                })();
                return h
            }, [], Qb(function(h) {
                h = h.target;
                return !O(h, Vs) || O(h, Ws)
            }, c)),
            g = [];
        M(function(h) {
            (h = ft(a, h, N(b.add, b.aa))) && g.push(h)
        }, Tk(function(h, k) {
            var l = nc(a)(h, Xs),
                m = nc(a)(k, Xs);
            return -1 === l ? 1 : -1 === m ? -1 : l - m
        }, e));
        c = J(a, d);
        c || (c = [], a[d] =
            c);
        Bi(a, c, function(h) {
            h.Ba.C(function(k) {
                var l = J(k, "event");
                if (B(k) && l && sc(Ra(l), f)) l = b.add, B(k) && (B(k.ytm) ? k.ytm.eventId = Um() : k.ytm = {
                    eventId: Um()
                }), l.call(b, k), b.aa();
                else if (k) {
                    var m = n(Va(k));
                    k = m.next().value;
                    l = m.next().value;
                    m = m.next().value;
                    "consent" === k && O(l, mo) && B(m) && (b.cb({
                        event: "consent",
                        ytm: {
                            action: l,
                            La: m,
                            eventId: Um()
                        }
                    }), b.aa())
                }
            });
            g.push(h.unsubscribe)
        });
        return function() {
            return M(be, g)
        }
    }

    function jt(a, b) {
        var c = ec(b);
        return H(function(d, e) {
            d[e] = a(b[e]);
            return d
        }, {}, c)
    }

    function kt(a, b) {
        return M(function(c) {
            if ("pro" === c.type) return c = c.settings, A(c) ? {} : jt(a, c);
            c = c.data;
            return B(c) ? jt(a, c) : {}
        }, b)
    }

    function lt(a, b) {
        return M(function(c) {
            return a(c.target)
        }, b.conditions)
    }
    var mt = Tp("d.t.ve", function(a, b, c) {
            var d = {};
            return d.i = c, d.ct = lt(a, b), d
        }),
        nt = Tp("d.t.ie", function(a, b, c, d) {
            var e = H(function(g, h, k) {
                    b(h) && g.push(k);
                    return g
                }, [], c.conditions),
                f = {};
            return f.i = d, f.ct = lt(a, c), f.fci = e, f
        });

    function ot(a, b, c) {
        return M(Tp("d.ev.e", function(d) {
            return "generated" === J(d, "source") ? "" : "" + Hr(b, c, a, d)
        }, "Error during value computation"), b.config.variables)
    }
    var pt = Tp("c.ch", function(a, b, c) {
        var d = a.l,
            e = Ir(a, b, c["var"]),
            f = c.target,
            g = c.not;
        c = Ar(d, c.fn);
        a = Jr(a, b, f);
        return g ? !c(e, a) : c(e, a)
    }, !1, function(a, b) {
        return {
            type: "tr",
            eventId: b.ytm.eventId
        }
    });

    function qt(a, b, c) {
        return (c = a.config.tags[c].fc) && c.length ? Yb(function(d) {
            return pt(a, b, d)
        }, c) : !0
    }

    function rt(a) {
        var b = a.Tb,
            c = a.Kd,
            d = a.qd,
            e = a.config.triggers,
            f = Fr(function(g) {
                var h = Tp("d.ev.c", F([a, g], Jr)),
                    k = new Cj,
                    l = H(function(v, t, x) {
                        var E = !sc(function(S) {
                            return !pt(a, g, S)
                        }, t.conditions);
                        if (c)
                            if (E) {
                                var C = mt(h, t, x);
                                v.ic.Cc.push(C)
                            } else C = nt(h, F([a, g], pt), t, x), v.ic.Dc.push(C);
                        E && (E = b.fd(g.event, t.tags), v.od.push(E), M(function(S) {
                            k.has(S) || (qt(a, g, S) && v.kd.push(S), k.add(S))
                        }, t.tags), d.trigger(x));
                        return v
                    }, {
                        kd: [],
                        od: [],
                        ic: {
                            Cc: [],
                            Dc: []
                        }
                    }, e),
                    m = l.kd,
                    p = l.od;
                l = l.ic;
                if (c) {
                    var q = {};
                    l = (q.event = "t", q.ev =
                        g.event, q.e = l.Cc, q.vv = ot(h, a, g), q.ne = l.Dc, q.et = kt(h, a.config.tags), q.fe = g, q.eid = g.ytm.eventId, q);
                    c.trigger(l)
                }
                m.length && hs(a, g, m, p, f)
            });
        return f
    }
    var st = Tp("p.ss", function(a) {
        var b = .99 >= a.Math.random(),
            c = Hh(a, {
                id: 102974846,
                M: "0"
            }, "er"),
            d = Xl(a, c, 102974846);
        return [b, function(e, f) {
            var g = {},
                h = {};
            if ("tgExec" === e) {
                var k = {};
                var l = {},
                    m = {};
                k = (m[f.status] = (l[f.tagType] = (k[f.counterId] = f, k), l), m)
            } else "trExec" === e ? (k = {}, l = {}, k = (l[f.event] = (k[f.counterId] = f, k), l)) : (k = {}, l = {}, k = (l[f.status] = (k[f.counterId] = f, k), l));
            g = (h[e] = (g["2710"] = k, g), h);
            d(g)
        }]
    });

    function tt(a) {
        if (a = fe(a)) {
            var b = J(a, "timing.navigationStart") || J(a, "timeOrigin");
            if (!A(b)) {
                var c = ya(a.now, "now");
                if (y(c)) return c = D(c, a), [b, c]
            }
        }
    }

    function ut(a) {
        if (!a) return 0;
        var b = n(a);
        a = b.next().value;
        b = b.next().value;
        return Math.round(b() + a)
    }

    function vt(a, b, c, d) {
        function e(m) {
            k(m.type, m.La)
        }
        var f = Cf(a, "ytm.mon"),
            g = n(st(a)),
            h = g.next().value,
            k = g.next().value;
        if (h || d) return {
            ed: function() {
                return r
            },
            fd: function() {
                return r
            },
            gd: function() {
                return r
            },
            zc: r
        };
        var l = tt(a);
        f.C(["PRIVATE"], e);
        return {
            ed: function(m, p) {
                var q = {
                    start: ut(l),
                    tagType: m,
                    We: p,
                    counterId: b,
                    containerId: c.containerId,
                    containerVersion: c.containerVersion,
                    compilerVersion: c.compilerVersion
                };
                return function(v) {
                    v = P(q, {
                        status: v,
                        finish: ut(l)
                    });
                    f.trigger("PRIVATE", {
                        type: "tgExec",
                        La: v
                    })
                }
            },
            fd: function(m, p) {
                var q = {
                    start: ut(l),
                    tags: p,
                    counterId: b,
                    containerId: c.containerId,
                    containerVersion: c.containerVersion,
                    compilerVersion: c.compilerVersion,
                    event: m.slice(0, 150)
                };
                return function() {
                    var v = P(q, {
                        finish: ut(l)
                    });
                    f.trigger("PRIVATE", {
                        type: "trExec",
                        La: v
                    })
                }
            },
            gd: function() {
                var m = {
                    start: ut(l),
                    counterId: b,
                    containerId: c.containerId,
                    containerVersion: c.containerVersion,
                    compilerVersion: c.compilerVersion
                };
                return function(p) {
                    p = P(m, {
                        status: p,
                        finish: ut(l)
                    });
                    f.trigger("PRIVATE", {
                        type: "varExec",
                        La: p
                    })
                }
            },
            zc: F([
                ["PRIVATE"],
                e
            ], f.qa)
        }
    }

    function wt(a, b, c, d) {
        function e(g) {
            var h;
            if (h = f(g, c, d)) {
                h = g.permissionType;
                if (!I(Hs, h)) throw Dp("y.u.p." + h);
                var k = g.ja;
                g = g.F;
                k = !z(k.permissions) && I(b, "" + k.permissions) ? b[k.permissions] : {};
                h = (0, Hs[h])(a, k, h, g)
            }
            return h
        }
        var f = Ks(a).Cd;
        return {
            checkPermission: function(g) {
                if (!e(g)) {
                    g = Is(g, c, d);
                    var h = Dp("Permission denied for " + g.permissionType, "yue");
                    h.cause = g;
                    Td(h)
                }
            },
            R: e
        }
    }

    function xt(a, b) {
        var c = Q(a),
            d = {};
        c.V("ytm_s", (d.cm = {}, d));
        var e = 0,
            f = c.o("ytm_s").cm;
        return {
            Eb: function(g) {
                if (I(f, b)) f[b][e] = g;
                else {
                    var h = {};
                    f[b] = (h[e] = g, h)
                }
                g = 'Ya["_metrika"]["ytm_s"]["cm"]["' + b + '"][' + e + "]";
                e += 1;
                return g
            }
        }
    }
    var yt = N(ec, oc);

    function zt(a, b) {
        return b.Ld || Ns(a) || Ps(a) ? zf(!1) : yf(Zi(b, K("settings.aytm")))
    }
    var At = L(Md, R);

    function Bt(a, b, c, d) {
        var e = At(c).oe;
        if (!e) throw Wd("im.no");
        Hk(a, On + "/" + b + ".js?ver=2710&b=e", function() {
            var f = Q(a).o("ytmm");
            (f = J(f, b + ".init")) && f(e, d, "2710")
        })
    }
    var Ct = W("p.ips", function(a, b) {
            Zi(b, function(c) {
                (J(c, "settings.phchange") || J(c, "settings.phhide")) && Bt(a, "tag_phone", b, c)
            })
        }),
        Dt = W("p.tv", function(a) {
            if (gl(a)) {
                var b = Q(a);
                hl(a).then(function(c) {
                    b.B("lgguid", c)
                }, V(a, "p.tv.p"))
            }
        }),
        Et = {},
        Ft = L(Md),
        Gt = N(Za("exec", /counterID=(\d+)/), K("1")),
        Ht = Na(function(a, b) {
            var c = mc(b),
                d = n(c),
                e = d.next().value;
            d = ja(d);
            var f = "" + e;
            var g = Gt(f);
            g ? f = {
                id: g,
                M: "0"
            } : -1 === Ca(f, ":") ? f = (f = ub(f)) ? {
                id: f,
                M: "0"
            } : void 0 : (g = n(f.split(":")), f = g.next().value, g = g.next().value, f = (f = ub(f)) ? {
                id: f,
                M: te(g) ? "1" : "0"
            } : void 0);
            g = a.Ya[Qd];
            if (f) {
                var h = n(c);
                h.next();
                d = h.next().value;
                h = ja(h);
                if (d) {
                    var k = Th(a, f),
                        l = R(f),
                        m = Ft(a);
                    m[l] || (m[l] = {});
                    l = m[l];
                    if (!b.ym_xqd) {
                        if (m = Et[d])
                            for (var p = 0; p < m.length; p += 1)
                                if ((0, m[p])(a, f, h, k)) return;
                        "init" === d ? (b.ym_xqd = !0, k ? (c = {}, Qh(a, "" + e, "dc", (c.key = e, c))) : a["yaCounter" + f.id] = new g(P({}, h[0], f))) : k && k[d] && l.Vd ? (k[d].apply(k, ka(h)), b.ym_xqd = !0) : (e = l.dd, e || (e = [], l.dd = e), e.push(c))
                    }
                }
            } else c = Q(a).o("staticMethods", {})[e], y(c) && c.apply(null, ka(d))
        }),
        It = "telefone phone phone_number customer_phone mobile_phone cell_phone contact_phone phone_contact primary_phone telephone user_mobile customer_contact_number mobile_number user_telephone phone_no contact_number subscriber_phone clientPhone tel".split(" "),
        Jt = "email_name user_email email email_address customer_email contact_email primary_email emailID user_emailID mail user_mail subscriber_email user_contact_email clientEmail".split(" "),
        Kt = ["visitorContactInfo"];

    function Lt(a, b, c) {
        (a = Zh(a, b)) && c.push(["phone", a]);
        return a
    }

    function Mt(a, b, c) {
        M(function(d) {
            u(d) && !Lt(a, d, c) && (d = Xh(d)) && c.push(["email", d])
        }, b)
    }

    function Nt(a, b, c, d) {
        c = void 0 === c ? [] : c;
        d = void 0 === d ? 1 : d;
        if (!(3 < d) && B(b)) return b = dc(b), M(function(e) {
            var f = n(e);
            e = f.next().value;
            f = f.next().value;
            u(f) ? O(e, It) ? Lt(a, f, c) : O(e, Jt) && (e = c, (f = Xh(f)) && e.push(["email", f])) : w(f) && O(e, Kt) ? Mt(a, f, c) : B(f) && Nt(a, f, c, d + 1)
        }, b), c
    }

    function Ot(a, b, c) {
        b && B(c) && (c = Nt(a, c) || [], M(function(d) {
            d = n(d);
            var e = d.next().value;
            d = d.next().value;
            return ai(a, d).then(function(f) {
                var g = {},
                    h = {},
                    k = {};
                return b((k.__ym = (h.fpdlh = le((g.a = "email" === e ? 1 : 0, g.c = f || 0, g)).ra(), h), k))
            })
        }, c))
    }
    var Pt = W("fpdlc", function(a, b) {
            var c = Th(a, b);
            if (c && $h(a)) return Zi(b, function(d) {
                if (J(d, "settings.cf")) {
                    var e = c.params,
                        f;
                    d = [yk(a, "dataLayer", function(g) {
                        f = g;
                        g.Ba.C(F([a, e], Ot))
                    }), function() {
                        f && f.unsubscribe()
                    }];
                    return F([ce, d], M)
                }
            })
        }),
        Qt = W("ymc.g", function(a, b) {
            var c = {};
            return c.getYmclid = function(d) {
                d && Zi(b, function(e) {
                    Mh(a, d, null, J(e, "settings.ymclid"))
                })
            }, c
        }),
        Rt = On + "-tags/_/tag_ec.js",
        St = On + "-tags/_/tag_ec_test.js",
        Tt = W("ecl.h", function(a, b) {
            return Zi(b, function(c) {
                var d = J(c, "settings.zero_code"),
                    e = ze(a, d);
                if (B(e) && (I(e, "ec") || I(e, "ect"))) {
                    c = Q(a);
                    var f = c.o("ecrs", []),
                        g = {};
                    f.push((g.counterKey = R(b), g.settings = d, g));
                    c.B("ecrs", f);
                    d = e.em;
                    A(d) || (f = c.o("ecmv", {}), g = R(b), f[g] = d, c.B("ecmv", f));
                    d = !!e.ec;
                    e = !!e.ect;
                    !c.o("ecl") && d && (c.B("ecl", !0), Hk(a, Rt, r));
                    !c.o("ectl") && e && (c.B("ectl", !0), Hk(a, St, r))
                }
            })["catch"](V(a, "ecl.hs"))
        }),
        Ut = W("rsa.i", function(a, b) {
            if (!Rs(a)) return Zi(b, function(c) {
                var d = J(c, "settings.rspi");
                J(c, "settings.rse") && d && (Hk(a, "https://yandex.ru/ads/system/context.js", r, V(a, "rsa.cl")),
                    c = {}, d = (c.pageId = d, c), Hk(a, "https://yandex.ru/ads/system/ap-loader.js", r, V(a, "rsa.apl"), {
                        wc: d
                    }))
            })["catch"](V(a, "rsa.hs"))
        }),
        Vt = W("wm.p", function(a) {
            var b = Q(a),
                c = {},
                d = Bf(a);
            b.B("wmg", {
                add: function(e, f, g, h, k) {
                    k = void 0 === k ? !1 : k;
                    if (!c[e]) {
                        var l = function(m) {
                            m.wd !== e && (m.Lc ? f(m.yc) : g())
                        };
                        c[e] = function() {
                            d.qa(l)
                        };
                        d.C(l);
                        k && d.trigger({
                            wd: e,
                            Lc: k,
                            yc: h
                        })
                    }
                },
                remove: function(e) {
                    var f = c[e];
                    f && f();
                    delete c[e]
                },
                update: function(e, f, g) {
                    c[e] && d.trigger({
                        wd: e,
                        yc: g,
                        Lc: f
                    })
                }
            })
        });

    function Wt(a, b) {
        var c = r;
        Oc(a) ? c = Xc(a).C(a, ["prerenderingchange"], b, !0) : b();
        return c
    }

    function Xt(a, b, c) {
        var d = J(c, "scripts");
        if (!A(d) && 0 !== d.length) {
            var e = Vm(3);
            M(function(f) {
                if (!(300 >= f.duration || .999 >= a.Math.random())) {
                    var g = f.sourceURL;
                    g && mh(g) === ta.host && (g = {}, f = (g.d = e(f.duration), g.st = e(f.startTime), g.pd = e(f.pauseDuration), g.scp = f.sourceCharPosition, g.sfn = f.sourceFunctionName, g.td = e(c.blockingDuration), g.fut = e(c.firstUIEventTimestamp), g.rs = e(c.renderStart), g.sls = e(c.styleAndLayoutStart), g.e = [], g.f = [], g), b.push(f))
                }
            }, d)
        }
    }

    function Yt(a, b, c) {
        b = c.flush();
        if (0 !== b.length) {
            var d = je.slice();
            M(function(e) {
                var f = e.st,
                    g = e.st + e.d,
                    h = new Cj;
                M(function(l) {
                    l.startTime < g && l.endTime > f && h.add(l.scope)
                }, d);
                if (0 !== h.size) {
                    var k = {};
                    P(e, (k.f = lc(h), k));
                    M(N(lb, Jb(["longtask", Ae(a, e) || "uns", "laf", void 0]), be), de)
                }
            }, b)
        }
    }

    function Zt(a, b, c, d) {
        "long-animation-frame" === d.entryType && Xt(a, c, d)
    }
    var $t = W("lt", function(a) {
        var b = [],
            c = F([be, b], M);
        if (y(a.PerformanceObserver)) {
            var d = ie(),
                e = ie(),
                f = function(h) {
                    $i(a, F([a, h.getEntries(), F([a, d, e], Zt), "lt.i", 50, F([a, d, e], Yt)], fj), "lt.r")
                },
                g = Wt(a, V(a, "lt.a", function() {
                    var h = new a.PerformanceObserver(V(a, "lt.p", f));
                    b.push(function() {
                        return h.disconnect()
                    });
                    try {
                        I(a, "PerformanceLongAnimationFrameTiming") && h.observe({
                            type: "long-animation-frame",
                            buffered: !0
                        }), I(a, "PerformanceEventTiming") && h.observe({
                            type: "event",
                            buffered: !0,
                            Le: 300
                        })
                    } catch (k) {}
                }));
            b.push(g);
            return c
        }
    });

    function au(a) {
        return {
            K: function(b, c) {
                var d = b.G;
                if (d) {
                    var e = Q(a).o("adBlockEnabled");
                    e && d.B("adb", e)
                }
                c()
            }
        }
    }

    function bu(a, b) {
        var c = a.document;
        if (O(c.readyState, ["interactive", "complete"])) $i(a, b, "adb.r.cor");
        else {
            var d = Xc(a),
                e = d.C,
                f = d.ua,
                g = function() {
                    f(c, ["DOMContentLoaded"], g);
                    f(a, ["load"], g);
                    b()
                };
            e(c, ["DOMContentLoaded"], g);
            e(a, ["load"], g)
        }
    }
    var cu = G("9-d5ve+.r%7", lb),
        du = W("adb", function(a, b) {
            if (!b.Aa) {
                var c = Q(a);
                if (!c.o("adBlockEnabled")) {
                    var d = function(m) {
                            O(m, ["2", "1"]) && c.B("adBlockEnabled", m)
                        },
                        e = Kd(a),
                        f = e.o("isad");
                    if (f) d(f);
                    else {
                        var g = G("adStatus", c.B),
                            h = function(m) {
                                m = m ? "1" : "2";
                                d(m);
                                g("complete");
                                e.B("isad", m, 1200);
                                return m
                            },
                            k = Lh(a, "adb", b);
                        if (!c.o("adStatus")) {
                            g("process");
                            var l = "metrika/a" + cu().replace(/[^a-v]+/g, "") + "t.gif";
                            bu(a, function() {
                                return k({
                                    ha: {
                                        U: l
                                    }
                                }).then(G(!1, h))["catch"](G(!0, h))
                            })
                        }
                    }
                }
            }
        });
    G(Zd("ccf"), Td);
    var eu = /\sYptp\/\d\.(\d+)\s/,
        fu = L(function(a) {
            var b;
            a: {
                if ((b = qb(a)) && (b = eu.exec(b)) && 1 < b.length) {
                    b = ub(b[1]);
                    break a
                }
                b = 0
            }
            return 50 <= b && 99 >= b || Rc(a) ? !1 : !Pc(a) || co(a)
        });

    function gu(a, b, c, d, e, f, g, h) {
        var k = c.o(f);
        A(k) && (c.B(f, g), e(a, b, c, d), k = c.o(f, g));
        z(h) || h.wb(f, "" + k);
        return k
    }
    var hu = L(function(a) {
        return y(J(a, "yandex.getSiteUid")) ? a.yandex.getSiteUid() : null
    });

    function iu(a, b) {
        var c = He(a),
            d = c.o,
            e = c.B;
        if ("" === d("cc")) {
            e("cc", 0);
            var f = X(a),
                g = Q(a);
            Lh(a, "6", b)({
                J: {
                    Fa: !0,
                    qc: !1
                }
            }, ["https://mc.yandex.md/cc"]).then(function(h) {
                h = J(h.Ea, "c");
                e("cc", h + "&" + f(hf));
                g.B("cc", h)
            })["catch"](function(h) {
                var k = f(hf);
                e("cc", "&" + k);
                ee(a, "cc", h)
            })
        }
    }
    var ju = W("cc.i", function(a, b) {
        var c = F([a, b], iu);
        c = F([a, c, 300, void 0], tf);
        Zi(b, c)
    });

    function ku(a, b, c) {
        if ("complete" === J(a, "document.readyState")) b();
        else {
            var d = V(a, c + ".wfd.l", function() {
                Xc(a).ua(a, ["load"], d);
                b()
            });
            Xc(a).C(a, ["load"], d)
        }
    }
    var lu = {},
        mu = (lu.ka = "ge", lu.ro = "md", lu.tg = "tj", lu.tk = "tm", lu.et = "ee", lu.hy = "com.am", lu.he = "co.li", lu.ky = "kg", lu.be = "by", lu.tr = "com.tr", lu.kk = "kz", lu);

    function nu(a, b, c) {
        var d = !1;
        return function(e) {
            var f = e.data;
            e = e.source;
            if (u(f)) {
                var g = n(f.split("*"));
                f = g.next().value;
                var h = g.next().value,
                    k = g.next().value;
                g = g.next().value;
                "sc.frame" === f && e ? d || (d = !0, e.postMessage((b ? "sc.bl" : "sc.images") + "*" + a, "*")) : b ? "sc.blr" === f && h === a.split("?")[0] && c(k, u(g) ? $k(Yk(g)) : null) : "sc.image" === f && h === a && c(k, null)
            }
        }
    }

    function ou(a, b, c, d, e, f) {
        f = void 0 === f ? "isp" : f;
        return new Z(function(g, h) {
            Zi(e, function(k) {
                if (Kl(a, f, e, k)) {
                    var l = r;
                    k = function(m, p) {
                        "1" === m ? g({
                            Ea: p,
                            rd: 0
                        }) : h(m);
                        l();
                        Ml(f)
                    };
                    l = Xc(a).C(a, ["message"], V(a, d + ".m.mir", nu(b, c, k)));
                    tf(a, G("7", k), 3E3, d + ".t.mir")
                } else h(6)
            })["catch"](G(6, h))
        })
    }

    function pu(a, b, c, d, e, f) {
        return function(g, h) {
            return Zi(h, function(k) {
                var l = Q(g),
                    m = l.o,
                    p = l.B,
                    q = Jd(g, "");
                if (!m(c)) {
                    var v = J(k, "settings." + a);
                    if (v) return p(c, 1), p(b, 1), ku(g, function() {
                        Hl(g, function() {
                            ou(g, v, !0, d, h, e).then(V(g, d + ".pt", function() {
                                f && q.B("mdd", "1", 1440);
                                p(b, 2)
                            }))["catch"](V(g, d + ".pc", function(t) {
                                "7" === t || 6 === t ? p(b, 4) : (f && q.B("mdd", "0", 1440), p(b, 3))
                            }))
                        }, d)
                    }, d);
                    p(b, 0)
                }
            })["catch"](V(g, d))
        }
    }
    var qu = W("p.cac", pu("mdd", "cac", "cacp", "cac", "cac.mdd", !0)),
        ru = W("p.cac.e", pu("mdde", "cae", "caep", "cac.e", "cac.mdde", !1)),
        su = L(Md);

    function tu(a) {
        var b = su();
        b.jd || (b.jd = a)
    }
    var uu = L(Nd);

    function vu(a) {
        a = Hc(a);
        return mu[a] || "com"
    }
    var wu = L(function() {
        var a = H(function(b, c) {
            "ru" !== c && (b[c] = Po + "." + c);
            return b
        }, {}, fd);
        a.com = Po + ".com";
        return a
    });

    function xu(a, b) {
        var c = vu(a),
            d = [!0];
        d.push(c);
        d.unshift("com");
        var e = X(a);
        c = He(a);
        var f = c.o("synced", {});
        d = Qb(function(g) {
            if (b[g]) {
                var h = (f[g] || 1) + 1440 < e(hf);
                h && delete f[g];
                return h
            }
        }, d);
        c.B("synced", f);
        return M(function(g) {
            return {
                we: b[g],
                ce: g
            }
        }, d)
    }
    var yu = function(a, b) {
        return function(c, d) {
            if (Pc(c) || xb(c)) return {};
            var e = R(d);
            e = wu(e);
            var f = xu(c, e),
                g = Q(c),
                h = Ic(c);
            return {
                K: function(k, l) {
                    var m = k.G;
                    m = !(m && m.o("pv"));
                    if (h || m || !f.length) return l();
                    g.o("startSync") ? uu(c).push(l) : (g.B("startSync", !0), F([c, d, f, r, !1], a)().then(l, N(Qa(l), V(c, b)))["catch"](r))
                },
                S: function(k, l) {
                    if (!J(k.Zb, "settings.nss")) return l();
                    var m = k.G;
                    m = !(m && m.o("pv"));
                    if (h || m || !f.length) return l();
                    if (g.o("startSync")) uu(c).push(l);
                    else return g.B("startSync", !0), a(c, d, f, r, !0).then(l,
                        N(Qa(l), V(c, b)))
                }
            }
        }
    }(function(a, b, c, d, e) {
        var f = X(a),
            g = Q(a),
            h = He(a);
        d = Hh(a, b, "c");
        var k = Zg(a, d),
            l = Um();
        tu(l);
        return H(function(m, p) {
            function q() {
                var x = h.o("synced");
                g.B("startSync", !1);
                x && (x[p.ce] = v, h.B("synced", x));
                x = uu(a);
                M(be, x);
                pc(x)
            }
            var v, t = {};
            t = k({
                J: {
                    N: ["sync.cook"],
                    sa: 1500
                },
                D: (t.scid = l, t.cid = "" + b.id, t)
            }, ["https://" + p.we + "/sync_cookie_image_check" + (e ? "_secondary" : "")]).then(function() {
                v = f(hf);
                q()
            })["catch"](function() {
                v = f(hf) - 1435;
                q()
            });
            t = G(t, lb);
            return m.then(t)
        }, Z.resolve(), c)["catch"](V(a,
            "ctl"))
    }, "sy.c");

    function zu(a, b, c) {
        var d = J(a, "location.host");
        a = Lf(a, b);
        c.B("pu", "" + Sj(d) + a)
    }

    function Au(a, b, c) {
        var d = Kf(a, b);
        if (d) {
            d.ca.C(["gpu-get"], function() {
                var g = {};
                return g.type = "gpu-get", g.pu = c.o("pu"), g
            });
            var e = J(a, "opener");
            if (e) {
                var f = tf(a, F([a, b, c], zu), 200, "pu.m");
                b = {};
                d.bc(e, (b.type = "gpu-get", b), function(g, h) {
                    var k = J(h, "pu");
                    k && (sf(a, f), c.B("pu", k))
                })
            } else zu(a, b, c)
        }
    }
    var Bu = N(K("settings.pcs"), Pa("1"));

    function Cu(a, b, c, d) {
        return Zi(b, function(e) {
            if (!Bu(e) && !tc(a))
                if (e = d.o("zzlc"), z(e) || Sa(e) || "na" === e) {
                    var f = Pe(a);
                    if (f && (e = Ve(a))) {
                        var g = f("iframe");
                        P(g.style, {
                            display: "none",
                            width: "1px",
                            height: "1px",
                            visibility: "hidden"
                        });
                        f = 68 <= yb(a);
                        var h = Rc(a);
                        g.src = "https://mc.yandex." + (f || h ? "md" : "ru") + Yk("L21ldHJpa2EvenpsYy5odG1s");
                        e.appendChild(g);
                        var k = 0,
                            l = Xc(a).C(a, ["message"], V(a, "zz.m", function(m) {
                                (m = J(m, "data")) && m.substr && "__ym__zz" === m.substr(0, 8) && (Qe(g), m = m.substr(8), d.B("zzlc", m), c.B("zzlc", m), l(),
                                    sf(a, k))
                            }));
                        k = tf(a, N(l, G(g, Qe)), 3E3, "c.d.z")
                    }
                } else c.B("zzlc", e)
        })
    }

    function Du(a, b, c, d) {
        b = d.o("cc");
        d = F(["cc", ""], d.B);
        if (b) {
            var e = n(b.split("&"));
            b = e.next().value;
            (e = (e = e.next().value) && ub(e)) && 1440 < X(a)(hf) - e ? d() : c.B("cc", b)
        } else Pa(0)(b) || d()
    }
    var Eu = L(function(a, b) {
            var c = Q(a),
                d = He(a),
                e = [],
                f = F([a, b, c, d], gu),
                g = !fu(a) || 68 <= yb(a);
            g && e.push(F([Au, "pu", ""], f));
            !g || d.Lb || Pc(a) || (e.push(F([Cu, "zzlc", "na"], f)), e.push(F([Du, "cc", ""], f)));
            return e.length ? {
                S: function(h, k) {
                    if (0 === c.o("isEU")) try {
                        M(ce, e)
                    } catch (l) {}
                    k()
                },
                K: function(h, k) {
                    var l = h.G;
                    if (l && 0 === c.o("isEU")) try {
                        M(Ra(l), e)
                    } catch (m) {}
                    k()
                }
            } : {}
        }, N(mb, R)),
        Fu = N(ze, K("cid"));

    function Gu(a, b, c) {
        return function(d, e) {
            return Zi(e, function(f) {
                if (J(f, "settings." + a)) {
                    var g = Q(d),
                        h = g.o,
                        k = g.B;
                    if (z(h("oms"))) {
                        var l = Lf(d, e);
                        g = {};
                        var m = Ae(d, (g.counterId = e.id, g["cnt-class"] = e.M, g));
                        if (f = b(d, m, f, l)) return k("oms", 1), ou(d, f, !!c, "isp.stat", e).then(function(p) {
                            p = p.Ea;
                            if (u(p)) {
                                if (p = c && c(d, p)) {
                                    var q = Zk(al(p));
                                    k("oms", 8);
                                    p = {
                                        id: 99742118,
                                        M: "0"
                                    };
                                    var v = Lh(d, "pi", p),
                                        t = {};
                                    q = Wg((t[a] = q, t.u = l, t));
                                    t = {};
                                    t = (t["page-url"] = T(d).href, t["page-ref"] = d.document.referrer, t["site-info"] = m, t);
                                    return v({
                                        G: q,
                                        D: t
                                    }, p).then(F(["oms", 4], k), G(9, Td))
                                }
                                k("oms", 3)
                            } else k("oms", 2)
                        })["catch"](function(p) {
                            p = rb(d, p) || u(p) ? p : 5;
                            k("oms", p)
                        })
                    }
                }
            })["catch"](V(d, "l.isp." + a))
        }
    }

    function Hu() {
        return U("", M(function(a) {
            return String.fromCharCode(a.charCodeAt(0) + 15)
        }, $k(Yk("VCNUKCkkUiMeIlUjVx4lIydVHiohJyEeVyZWKFNVVSEmIyoj"))))
    }

    function Iu(a, b) {
        if ("https://oauth.yandex.ru" === J(b, "origin") && J(b, "source.window") && "_ym_uid_request" === J(b.data, "_ym")) {
            var c = b.source,
                d = {};
            d = (d._ym_uid = a, d);
            c.postMessage(d, "https://oauth.yandex.ru")
        }
    }
    var Ju = bd("ot", function(a, b) {
        if (Sc(a)) {
            var c = Xc(a);
            return Zi(b, V(a, "ot.s", function(d) {
                if (J(d, "settings.oauth")) {
                    var e = [],
                        f = Lf(a, b);
                    e.push(c.C(a, ["message"], V(a, "ot.m", G(f, Iu))));
                    Af(a, "ot")(wf(r, V(a, "ot.b", function() {
                        function g(p) {
                            var q = p.href;
                            if (q && hj(q, "https://oauth.yandex.ru/") && !Ia(q, "_ym_uid=")) {
                                q = Ia(q, "?") ? "&" : "?";
                                var v = {};
                                p.href += "" + q + sd((v._ym_uid = f, v.mc = "v", v));
                                c.C(p, ["click"], V(a, "ot.click", function() {
                                    var t = "et=" + k(gf);
                                    p.href += "&" + t
                                }))
                            }
                        }
                        var h = a.document.body,
                            k = X(a),
                            l = tj("a", h);
                        M(g, l);
                        if (xa("MutationObserver",
                                a.MutationObserver)) {
                            l = new a.MutationObserver(V(a, "ot.m", G(function(p) {
                                p = p.addedNodes;
                                for (var q = 0; q < p.length; q += 1) {
                                    var v = p[q];
                                    "A" === v.nodeName && g(v)
                                }
                            }, M)));
                            var m = {};
                            m = (m.childList = !0, m.subtree = !0, m);
                            l.observe(h, m);
                            e.push(D(l.disconnect, l))
                        }
                    })));
                    return F([ce, e], M)
                }
            }))
        }
    });

    function Ku(a, b, c) {
        if (J(c, "settings.ins")) {
            var d = Q(a);
            if (!d.o("scip")) {
                var e = He(a),
                    f = X(a)(hf);
                c = sb(e.o("sci"));
                if (!(c && 1440 >= f - c)) {
                    c = Lh(a, "ci", b);
                    var g = ["sync.cook.int"],
                        h = function(p) {
                            p = d.o("scip", "") + p;
                            d.B("scip", p)
                        },
                        k = G("a", h);
                    d.B("scip", "0");
                    var l = {};
                    l = (l.tag = "cm-urls", l.stage = "mc-yandex-com", l["mc-id"] = "" + b.id, l.duid = Lf(a, b), l);
                    var m = su().jd;
                    m && (l.scid = m);
                    return c({
                        J: {
                            N: g,
                            sa: 3E3,
                            Fa: !0
                        },
                        D: l
                    }, ["https://eu.asas.yango.com/mapuid"]).then(function(p) {
                        p = J(p.Ea, "CookieMatchUrls");
                        if (w(p) && eb(p)) {
                            h("1");
                            var q = Lh(a, "c", b);
                            p = M(function(v, t) {
                                return q({
                                    J: {
                                        N: g,
                                        sa: 3E3
                                    }
                                }, ["https://" + v]).then(N(G("c", h), G("" + t, h)))["catch"](N(G("b", h), G("" + t, h)))
                            }, Qb(u, p));
                            return Z.all(p)
                        }
                        k()
                    }, k).then(function() {
                        var p = d.o("scip");
                        !p || Ia(p, "a") || Ia(p, "b") || (e.B("sci", f), h("d"))
                    }, r)
                }
            }
        }
    }

    function Lu(a, b) {
        return W("p.suid", function(c) {
            var d = c.r;
            c = c.u;
            var e = {};
            d = (e.fsr = u(d) ? d : null, e.fsu = u(c) ? c : null, e);
            c = {};
            d = (c.__ym = d, c);
            (c = Th(a, b)) && c.params && c.params(d)
        })
    }
    var Mu = W("p.suic", function(a, b) {
        return Zi(b, function(c) {
            var d = Q(a),
                e = d.o,
                f = d.B;
            e = e("pic");
            d = Lu(a, b);
            if (y(e)) return e(d);
            if (c = J(c, "settings.pic")) {
                e = Bf(a);
                var g = e.C,
                    h = e.qa,
                    k = e.trigger;
                e = function(l) {
                    g(l);
                    return function() {
                        h(l)
                    }
                };
                f("pic", e);
                d = e(d);
                f("prs", 3);
                Lh(a, "pic", b)({
                    J: {
                        qc: !1,
                        N: ["pic"]
                    }
                }, [c]).then(function(l) {
                    l = l.Ea;
                    if (A(l)) f("prs", 5);
                    else if (B(l)) {
                        var m = l.h;
                        u(m) && m ? (Hd(a, "_ym_fa", m, 43200), f("prs", 8), k(l)) : f("prs", 7)
                    } else f("prs", 6)
                }, F(["prs", 4], f));
                return d
            }
            f("prs", 2)
        })["catch"](V(a, "pic"))
    });

    function Nu(a, b) {
        try {
            if (A(b)) return {
                location: 4,
                Va: null
            };
            if (I(b, "webdriver")) return {
                location: 1,
                Va: b
            };
            for (var c = J(a, "Navigator.prototype"), d = Object.getPrototypeOf(b); d;) {
                if (I(d, "webdriver")) return {
                    location: d === c ? 0 : 2,
                    Va: d
                };
                d = Object.getPrototypeOf(d)
            }
            return {
                location: 3,
                Va: null
            }
        } catch (e) {
            return {
                location: 4,
                Va: null
            }
        }
    }

    function Ou(a, b, c) {
        return new Z(function(d) {
            if (Kl(a, "wd", b, c)) {
                var e = r,
                    f = 0,
                    g = !1,
                    h = function(k) {
                        g || (g = !0, e(), sf(a, f), Ml("wd"), d(k))
                    };
                e = Xc(a).C(a, ["message"], function(k) {
                    var l = J(k, "data");
                    if (u(l))
                        if (l = l.split("*"), "sc.frame" === l[0] && k.source) k.source.postMessage("sc.wdp*2", "*");
                        else if ("sc.wdpr" === l[0]) {
                        var m = n(M(sb, l.slice(1)));
                        k = m.next().value;
                        l = m.next().value;
                        var p = m.next().value;
                        m = m.next().value;
                        k = 2 !== k || A(l) || A(p) || A(m) || !(0 <= k && 0 <= l && 0 <= p && 0 <= m) ? null : [k, l, p, m];
                        h(k)
                    }
                });
                f = tf(a, function() {
                        return h(null)
                    },
                    3E3, "wd")
            } else d(null)
        })
    }
    var Pu = W("p.wd", function(a, b) {
            if (kd(a)) return Zi(b, V(a, "wd.s", function(c) {
                if (J(c, "settings.ewd")) {
                    var d = Q(a),
                        e = d.o,
                        f = d.B;
                    e("wdsp", !1) || (f("wdsp", !0), Hl(a, function() {
                        Ou(a, b, c).then(V(a, "wd.p", function(g) {
                            if (kd(a)) {
                                var h = J(a, "navigator"),
                                    k = Nu(a, h);
                                var l = k.location;
                                k = k.Va;
                                if (A(h)) var m = 2;
                                else try {
                                    var p = h.webdriver;
                                    m = z(p) ? 2 : !0 === p ? 1 : !1 === p ? 0 : 4
                                } catch (v) {
                                    m = 3
                                }
                                h = m;
                                b: {
                                    try {
                                        var q = Sa(k) ? void 0 : Object.getOwnPropertyDescriptor(k, "webdriver")
                                    } catch (v) {
                                        q = null;
                                        break b
                                    }
                                    k = 0;z(q) ? k |= 2 : (I(q, "value") && (k |= 1), y(q.get) ||
                                        (k |= 2), y(q.set) && (k |= 4), !0 !== q.enumerable && (k |= 8), !0 !== q.configurable && (k |= 16));q = k
                                }
                                k = 5;
                                Sa(g) || (k = n(g), k.next(), g = k.next().value, k.next(), m = k.next().value, k = g, Sa(q) || q === m || (q |= 64));
                                l = U("-", [2, h, l, Sa(q) ? 0 : q, k])
                            } else l = null;
                            Sa(l) || f("wds", l)
                        }))["catch"](V(a, "wd"))
                    }, "wd.i"))
                }
            }))["catch"](V(a, "wd"))
        }),
        Qu = ["yandex_metrika_callback" + ta.callbackPostfix, "yandex_metrika_callbacks" + ta.callbackPostfix],
        Ru = W("cb.i", function(a) {
            var b = n(Qu),
                c = b.next().value,
                d = b.next().value;
            if (y(a[c])) a[c]();
            "object" === typeof a[d] &&
                M(function(e, f) {
                    a[d][f] = null;
                    Mh(a, e)
                }, a[d]);
            M(function(e) {
                try {
                    delete a[e]
                } catch (f) {
                    a[e] = void 0
                }
            }, Qu)
        }),
        Su = W("h.p", function(a, b) {
            var c = Lh(a, "h", b),
                d = b.Ga || "" + T(a).href,
                e = b.Hb || a.document.referrer,
                f = {},
                g = {};
            f = {
                G: Wg((f.pv = 1, f)),
                D: (g["page-url"] = d, g["page-ref"] = e, g),
                H: {}
            };
            var h = Xi(R(b));
            g = h.kb;
            h = h.Wd;
            var k = {};
            f.ba = le((k.clt = rb(a, h) && rb(a, g) ? g - h : null, k));
            f.H.L = b.L;
            f.H.nc = b.nc;
            b.Ra && f.D && (f.D.nohit = "1");
            return c(f, b).then(function(l) {
                if (l) {
                    if (!b.Ra) {
                        var m = {};
                        Rh(a, b, "h", (m.id = b.id, m.url = d, m.ref = e, m), b.L)()
                    }
                    $i(a,
                        F([a, b, l], Yi), "h.ss")
                }
            })["catch"](V(a, "h.g.s"))
        }),
        Tu = W("destruct.e", function(a, b, c) {
            return function() {
                var d = Q(a),
                    e = b.id;
                M(function(f, g) {
                    return y(f) && V(a, "dest.fr." + g, f)()
                }, c);
                delete d.o("counters")[R(b)];
                delete a["yaCounter" + e]
            }
        });

    function Uu(a, b, c, d, e) {
        if (!c.length) return e;
        c = M(function(f) {
            return F([a, b, d], f)
        }, c);
        return N.apply(null, ka(c))(e)
    }

    function Vu(a, b, c, d) {
        return V(a, "cm." + c, d)
    }

    function Wu(a, b, c, d) {
        return function() {
            var e = Va(arguments);
            e = d.apply(null, ka(e));
            return z(e) ? Th(a, b) : e
        }
    }
    var Xu = Q(window);
    Xu.V("hitParam", {});
    Xu.V("lastReferrer", window.location.href);
    pg.push(W("p.ar", function(a, b) {
        var c = Lh(a, "a", b),
            d = {};
        return d.hit = function(e, f, g, h, k, l) {
            var m = {};
            m = {
                D: {},
                G: Wg((m.pv = 1, m.ar = 1, m))
            };
            f = B(f) ? {
                title: f.title,
                referrer: f.referrer || f.referer,
                L: f.params,
                eb: f.callback,
                l: f.ctx
            } : {
                title: f,
                referrer: g,
                L: h,
                eb: k,
                l: l
            };
            h = Sh(b);
            g = T(a).href;
            k = b.Ra ? b.Ga || g : g;
            g = z(h.url) ? k : g;
            g = e || g;
            h.url !== g && (h.ref = h.url, h.url = e);
            e = b.Ra ? b.Hb || a.document.referrer : a.document.referrer;
            e = f.referrer || h.ref || e;
            h = {};
            h = Rh(a, b, "pv", (h.id = b.id, h.url = g, h.ref = e, h), f.L);
            k = P(m.H || {}, {
                L: f.L,
                title: f.title
            });
            l = {};
            m = c(P(m, {
                H: k,
                D: P(m.D || {}, (l["page-url"] = g, l["page-ref"] = e, l))
            }), b).then(h);
            return Nh(a, "p.ar.s", m, f.eb || r, f.l)
        }, d
    }));
    Kh.a = hh;
    lg.a = [
        [eg, -100],
        [Zc, 1],
        [bg, 2],
        [Vf(), 3],
        [Wf, 4]
    ];
    Gh.a = Ch;
    pg.push(function(a, b) {
        var c = {};
        return c.firstPartyParams = di(a, b), c.firstPartyParamsHashed = fi(a, b), c
    });
    oe.push("fpp");
    oe.push("fpmh");
    (function() {
        var a = Q(window);
        a.V("getCounters", mi(window));
        og.push(ni);
        se["counters.c"] = "cntc";
        se["counters.s"] = "cnts";
        rg.push(function(b, c, d) {
            var e = a.o("getCounters");
            e && (c.counters = gi(b, {}, "counters.c", e), d.counters = gi(b, {}, "counters.s", e))
        })
    })();
    Kh["1"] = hh;
    pg.push(ui);
    Gh["1"] = Bh;
    jg(si, -1);
    Y("h", si, -1);
    Y("a", si, -1);
    lg["1"] = [
        [si, -1],
        [Zc, 1],
        [bg, 2],
        [Vf(), 3],
        [eg, 4]
    ];
    pg.push(Fi);
    pg.push(Ii);
    Kh.g = hh;
    Gh.g = Bh;
    lg.g = gg;
    pg.push(Ji);
    pg.push(Oi);
    lg.t = gg;
    Kh.t = hh;
    Gh.t = Bh;
    pg.push(W("cl.p", function(a, b) {
        function c(p, q, v, t) {
            t = void 0 === t ? {} : t;
            v ? Ri(a, b, {
                url: v,
                Ja: !0,
                mb: p,
                qb: q,
                sender: d,
                vd: t
            }) : g.warn("clel")
        }
        var d = Lh(a, "2", b),
            e = [],
            f = R(b),
            g = Ph(a, f),
            h = V(a, "s.s.tr", G(ki(a, f), Qi));
        f = {
            l: a,
            Id: b,
            Od: e,
            sender: d,
            Oe: Q(a),
            Hd: Ie(a, b.id),
            Qe: mf(a),
            Ae: G(G(f, li(a)), N(be, K("trackLinks")))
        };
        f = V(a, "cl.p.c", G(f, Si));
        f = Xc(a).C(a, ["click"], f);
        b.md && h(b.md);
        var k = V(a, "file.clc", F([!0, !1], c)),
            l = V(a, "e.l.l.clc", F([!1, !0], c));
        e = V(a, "add.f.e.clc", Ti(e));
        var m = {};
        return m.file = k, m.extLink = l, m.addFileExtension =
            e, m.trackLinks = h, m.u = f, m
    }));
    lg["2"] = gg;
    Kh["2"] = hh;
    Gh["2"] = Bh;
    Kh.r = gh("r");
    Gh.r = ["f", "x", "j", "i"];
    qg.push(W("p.r", function(a, b) {
        var c = nj(a);
        c.Dd();
        return gj(a, b, c.Rd())
    }));
    Y("r", function(a, b) {
        var c = nj(a);
        return {
            K: function(d, e) {
                var f = void 0 === d.G ? Wg() : d.G,
                    g = d.H.Za,
                    h = f.o("rqnl", 0) + 1;
                f.B("rqnl", h);
                g && c.Ce(g, h);
                e()
            },
            S: function(d, e) {
                oj(a, d, b, c);
                e()
            }
        }
    }, 1);
    jg(pj, 100);
    Y("h", pj, 100);
    Y("a", pj, 100);
    Y("1", pj, 100);
    Y("n", pj, 100);
    Y("m", pj, 100);
    pg.push(rj);
    Y("n", Zc, 1);
    Y("n", bg, 2);
    Y("n", Vf(), 3);
    Y("n", eg, 3);
    Kh.n = hh;
    Gh.n = Bh;
    P(we, {
        tc: {
            T: "accurateTrackBounce"
        }
    });
    pg.push(Oj);
    Kh.m = gh("cm");
    Gh.m = Eh;
    Y("m", Vf(["u", "v", "vf"]), 1);
    P(we, {
        Ed: {
            T: "clickmap"
        }
    });
    pg.push(Pj);
    pg.push(Rj);
    pg.push(dk);
    pg.push(kk);
    qg.push(Ck);
    oe.push("ecommerce");
    P(we, {
        Db: {
            T: "ecommerce",
            rb: function(a) {
                if (a) return !0 === a ? "dataLayer" : "" + a
            }
        }
    });
    pg.push(Ik);
    oe.push("user_id");
    pg.push(Kk);
    jg(Jk, 0);
    Y("h", Jk, 0);
    Y("a", Jk, 0);
    Ad.push("_ym_debug");
    sg.unshift(Nk);
    var Yu = {},
        Zu = (Yu.tp = N(mb, qi, Lb), Yu.tpid = N(mb, function(a) {
            a = R(a);
            return oi[a] && oi[a].ze || null
        }), Yu);
    P(Tf, Zu);
    jg(Ok, 20);
    Y("h", Ok, 20);
    Y("a", Ok, 20);
    Y("n", Ok, 20);
    Y("1", Ok, 20);
    sg.unshift(Qk);
    Tf.fp = function(a, b, c) {
        if (c.D && c.D.nohit) return null;
        c = Q(a).o;
        if (!c("fpe")) return null;
        b = Pk(b);
        if (b.Qd) return null;
        c = c("fht", Infinity);
        a: {
            var d = J(a, "performance.getEntriesByType");
            if (y(d)) {
                if (a = Qb(N(lb, K("name"), Pa("first-contentful-paint")), d.call(a.performance, "paint")), a.length) {
                    a = a[0].startTime;
                    break a
                }
            } else {
                var e = J(a, "chrome.loadTimes");
                d = Qf(a);
                if (y(e) && (e = e.call(a.chrome), e = J(e, "firstPaintTime"), d && e)) {
                    a = 1E3 * e - d;
                    break a
                }
                if (a = J(a, "performance.timing.msFirstPaint")) {
                    a -= d;
                    break a
                }
            }
            a = void 0
        }
        return a &&
            c > a ? (b.Qd = a, Math.round(a)) : null
    };
    (function() {
        var a = {
                pri: xl,
                ds: ul,
                co: function(c) {
                    return Mb(Q(c).o("jn"))
                },
                td: zl
            },
            b = {};
        P(a, (b.iss = N(Lc, Lb), b.hdl = N(Mc, Lb), b.iia = N(Nc, Lb), b.cpf = N(Uk, Lb), b.ntf = L(function(c) {
            c = J(c, "Notification.permission");
            c = "denied" === c ? !1 : "granted" === c ? !0 : null;
            return Sa(c) ? null : c ? 2 : 1
        }), b.eu = Vk("isEU"), b.ns = Qf, b.np = function(c) {
            return ef(c, 0, 100) ? null : bl(vd(vc(c), 100))
        }, b));
        a.pani = jl;
        a.pci = kl;
        a.si = ll;
        a.gi = ml;
        a.stlgg = Vk("lgguid");
        a.sttdi = fl;
        a.stti = el;
        a.sttifa = dl;
        P(Tf, a)
    })();
    (function() {
        var a = {};
        a.oo = Vk("oo");
        a.pmc = Vk("cmc");
        a.re = N(pf, Lb);
        a.aw = function(b) {
            b = Le(N(A, nb), [b.document.hidden, b.document.msHidden, b.document.webkitHidden]);
            return A(b) ? null : Mb(!b)
        };
        a.nvt = Vl;
        a.rcm = Rl;
        a.yu = function(b) {
            return (b = Jd(b, "").o("yandexuid")) && b.substring(0, 25)
        };
        a.ifc = Vk("ifc");
        a.ifb = Vk("ifb");
        a.ecs = Vk("ecs");
        a.cdl = Vk("cdl");
        a.eco = L(Sl, N(mb, R));
        a.ucs = function(b) {
            return (b = Jd(b).o("ucs")) && b.substring(0, 25)
        };
        ye.ifd = function(b, c) {
            return Q(b).o("ifdp", {})[R(c)] || null
        };
        ye.rfs = function(b, c) {
            return Nl(c.Hb)
        };
        ye.ufs = function(b, c) {
            return Nl(c.Ga)
        };
        P(ye, a)
    })();
    Gh.er = Dh;
    (function() {
        var a = window;
        try {
            var b = Hh(a, {
                    id: 26302566,
                    M: "0"
                }, "er"),
                c = Xl(a, b, 26302566);
            de.push(function(d, e, f, g) {
                var h = {},
                    k = {},
                    l = {},
                    m = {},
                    p = {};
                c((p[d] = (m["2710"] = (l[e] = (k[f] = g ? (h[a.location.href] = g, h) : a.location.href, k), l), m), p))
            })
        } catch (d) {}
    })();
    ng.push(function(a, b) {
        if (J(a, "disableYaCounter" + b.id) || J(a, "Ya.disableMetrica")) {
            var c = R(b);
            delete Q(a).o("counters", {})[c];
            Td(Zd("oo.e"))
        }
    });
    ig.unshift(function(a) {
        return {
            K: function(b, c) {
                Q(a).o("oo") || c()
            }
        }
    });
    jg(Zl, -99);
    Y("h", Zl, -99);
    Y("a", Zl, -99);
    pg.push($l);
    lg.e = gg;
    Kh.e = hh;
    Gh.e = Bh;
    P(we, {
        exp: {
            T: "experiments"
        }
    });
    se.experiments = "ex";
    am.push(bm);
    Kh.f = hh;
    var $u = {};
    P(Gh, ($u.f = Ch, $u));
    Y("f", Vf(), 1);
    Y("f", Wf, 2);
    Y("f", Ok, 20);
    Y("h", fm, -10);
    Y("a", fm, -10);
    Y("1", em, 19);
    Y("n", em, 19);
    Y("m", em, 2);
    jg(em, 19);
    ng.push(function(a, b) {
        var c = {
                X: R(b),
                Bb: Th(a, b),
                ld: X(a),
                Rb: He(a)
            },
            d = c.ld(hf);
        if (!c.Rb.Lb) {
            var e = c.Rb.o("ymoo" + c.X);
            e && 30 > d - e ? (c = c.X, delete Q(a).o("counters", {})[c], Td(Zd("uws"))) : Zi(b, hm(c))["catch"](V(a, "d.f"))
        }
    });
    qg.push(Pm);
    pg.push(W("ag.e", function(a, b) {
        if (!te(R(b))) {
            var c = [];
            yf(Zi(b, K("settings")))(wf(V(a, "ag.s"), V(a, "ag.i", function(d) {
                if (J(d, "auto_goals") && Th(a, b) && (d = Ii(a, b, "autogoal").reachGoal)) {
                    d = en(d, !!b.Db);
                    var e = fn(d);
                    d = gn(d);
                    c.push(Xm(a, d));
                    c.push(yk(a, "dataLayer", function(f) {
                        f.Ba.C(e)
                    }))
                }
            })));
            return function() {
                return M(ce, c)
            }
        }
    }));
    pg.push(Dn);
    pg.push(Il);
    se["informer.c"] = "ifc";
    se["informer.s"] = "ifs";
    rg.push(function(a, b, c) {
        var d = Fn(a);
        b.informer = gi(a, {}, "informer.c", d);
        c.informer = gi(a, {}, "informer.s", d)
    });
    Gh["5"] = Bh;
    Kh["5"] = hh;
    pg.push(Gn);
    Y("5", eg, -100);
    Y("5", Vf(), 3);
    Y("5", Wf, 4);
    jg(In, 7);
    Y("h", In, 7);
    Y("a", In, 7);
    Y("n", In, 6);
    qg.push(Jn);
    Kh.d = hh;
    Y("d", Vf(["hid", "u", "v", "vf"]), 1);
    Gh.d = Dh;
    Y("n", function(a, b) {
        return {
            S: function(c, d) {
                if (!c.H || !c.H.force) {
                    var e = 24226447 === b.id ? 1 : .002,
                        f = fe(a);
                    if (f && y(f.getEntriesByType)) {
                        var g = .002 < Math.random(),
                            h = Math.random() > (void 0 === e ? 1 : e);
                        if (!g || !h) {
                            var k = f.getEntriesByType("resource"),
                                l = {},
                                m = {};
                            f = {};
                            e = T(a).href;
                            for (var p = 0; p < k.length; p += 1) {
                                var q = k[p],
                                    v = n(Ql(q.name)),
                                    t = v.next().value,
                                    x = v.next().value;
                                v = v.next().value;
                                var E = {};
                                E = (E.dns = Math.round(q.domainLookupEnd - q.domainLookupStart), E.tcp = Math.round(q.connectEnd - q.connectStart), E.duration = Math.round(q.duration),
                                    E.response = Math.round(q.responseEnd - q.requestStart), E);
                                if ("script" === q.initiatorType && !g) {
                                    var C = {};
                                    m[t] = P(E, (C.name = q.name, C.decodedBodySize = q.decodedBodySize, C.transferSize = Math.round(q.transferSize), C))
                                }!v && !Pl[x] || l[t] || h || (q = {}, l[t] = P(E, (q.pages = e, q)))
                            }
                            ec(l).length && (f.timings8 = l);
                            ec(m).length && (f.scripts = m);
                            ec(f).length && (g = {}, h = {}, Lh(a, "d", b)({
                                G: Wg((g.ar = 1, g.pv = 1, g)),
                                J: {
                                    O: Ae(a, f) || void 0
                                },
                                D: (h["page-url"] = e, h)
                            }, {
                                id: 51533966,
                                M: "0"
                            })["catch"](V(a, "r.tim.ng2")))
                        }
                    }
                }
                d()
            }
        }
    }, 7);
    qg.push(Sk);
    Y("h", function(a) {
        return {
            S: function(b, c) {
                var d = b.Zb;
                $f(b) && d && Q(a).B("isEU", J(d, "settings.eu"));
                c()
            }
        }
    }, 3);
    og.push(Mn);
    qg.push(ao);
    pg.push(ho);
    P(we, {
        Ge: {
            T: "yaDisableGDPR"
        },
        He: {
            T: "yaGDPRLang"
        }
    });
    ig.push(function(a, b) {
        function c(q) {
            f(q);
            return {
                K: function(v, t) {
                    d(v);
                    t()
                }
            }
        }

        function d(q) {
            var v = U(",", M(kb(vo), xo(e)));
            v = Mo(v, h);
            me(q, "gdpr", v)
        }
        if (te(b.M) || 3 === b.id) return {};
        var e = Ai(a),
            f = G(e, zi),
            g = Jd(a, ""),
            h = g.o;
        if (b.Ge) return c("31");
        var k = Bo(a),
            l = T(a),
            m = l.href,
            p = zo(l.hostname);
        return k || p ? co(a) || eo(a) ? c("17") : g.o("yandex_login") ? (g.B("gdpr", po, 525600), c("13")) : {
            K: function(q, v) {
                if (q.G) {
                    var t = function() {
                            d(q);
                            v()
                        },
                        x = Q(a),
                        E = x.o("f1");
                    E ? E(t) : (E = xo(e), sc(Vb(vo), E) ? t() : (E = h("gdpr"), O(E, oo) ? (f(E === qo ? "12" :
                        "3"), t()) : lo(a).then(lb, r).then(function(C) {
                        C ? (f("28"), t()) : (Lo(t), x.B("f1", Lo), C = n(am).next().value, C(a).then(K("params.eu")).then(function(S) {
                            if (S || Ia(m, "yagdprcheck=1") || g.o("yaGdprCheck")) {
                                g.B("gdpr_popup", qo);
                                Co(a, b);
                                if (Ic(a)) return Do(a, f, b);
                                var ea = Di(a, e);
                                if (ea) return S = Jo(a, f, ea, b, p), S.then(F([a, b], Go)), S
                            }
                            S || f("8");
                            return Z.resolve({
                                value: po,
                                Mb: !0
                            })
                        }).then(function(S) {
                            g.wa("gdpr_popup");
                            if (S) {
                                var ea = S.value;
                                S = S.Mb;
                                O(ea, oo) && g.B("gdpr", ea, S ? void 0 : 525600)
                            }
                            ea = Tg(Ko, be);
                            ej(a, ea, "gdp.t", 20, Qg)(wf(V(a,
                                "gdr"), r));
                            x.B("f1", be)
                        })["catch"](V(a, "gdp.a")))
                    })))
                } else v()
            }
        } : c("14")
    });
    Ad.push("gdpr");
    Ad.push("gdpr_popup");
    Bd.push(function(a, b) {
        var c = Ai(a);
        c = xo(c);
        if (Qb(Vb(wo), c).length) return !0;
        c = b(a, "gdpr");
        return O(c, [po, ro])
    });
    ig.push(function(a) {
        return {
            K: function(b, c) {
                var d = b.ha || {},
                    e;
                b: {
                    if (e = T(a).hostname)
                        if (e = e.match(Qo))
                            if (e = e[3], O(e, fd)) break b;e = !1
                }
                e ? e = Po + "." + e : (e = J(a, "document.referrer")) ? (e = lh(a, e).hostname, e = hd(e), e = Po + "." + (e || Oo)) : e = Rd;
                b.ha = P(d, {
                    Hc: [e]
                });
                c()
            }
        }
    });
    Y("h", Xo, 7);
    Y("a", Xo, 7);
    Y("5", Xo, 7);
    Y("1", Xo, 7);
    jg(Xo, 7);
    pg.push(np);
    Y("g", function(a, b) {
        return {
            K: function(c, d) {
                var e = c.D;
                if (e && e["page-url"]) {
                    var f = e["page-url"];
                    zp(f) || Ap(f) ? Zi(b, function(g) {
                        var h = J(g, "settings.goal_values");
                        if (h) {
                            var k = (g = lh(a, f).query) ? rd(g) : void 0;
                            if (k) {
                                g = c.H || {};
                                g.L || (g.L = {});
                                g.L.__ym || (g.L.__ym = {});
                                var l = zp(f) ? wp : xp;
                                h = Cp(h);
                                h = yp(a, k, h, l);
                                0 !== h.length && (k = {}, h = (k.cgd = h[0], k.cmg = h, k), P(g.L.__ym, h), c.H = P(c.H || {}, g))
                            }
                        }
                        d()
                    })["catch"](N(Qa(d), V(a, "a.g.v"))) : d()
                } else d()
            }
        }
    }, -2);
    sg.push(W("cdl", function(a) {
        var b = Q(a).V;
        if (a = J(a, "navigator.cookieDeprecationLabel")) try {
            a.getValue().then(G("cdl", b), F(["cdl", "e"], b))
        } catch (c) {
            b("cdl", "d")
        } else b("cdl", "na")
    }));
    P(we, {
        Ld: {
            T: "disableYtm",
            rb: Nb
        }
    });
    Gh.ytm = ["f", "x"];
    og.push(W("p.ytm", function(a, b) {
        var c = !1,
            d = [function() {
                c = !0
            }],
            e = F([be, d], M),
            f = bq(a);
        zt(a, b)(xf(function(g) {
            if (c || !g) return zf();
            g = Hh(a, b, "ytm");
            var h = {};
            return yf(Zg(a, g)({
                J: {
                    N: ["ytm"],
                    Fa: !0
                },
                D: f ? (h.nonce = f, h) : void 0
            }, ["https://" + Rd + "/ytm-config/" + b.id]).then(K(yt({
                Ea: 1
            }))))
        }))(wf(V(a, "ytm.s"), function(g) {
            if (!c && B(g)) {
                var h = !(!f || !0 !== g.isPreview);
                Us(a, f);
                if (h) {
                    var k = Ts(a, g);
                    Hk(a, Ls, r, V(a, "ytm.d.in"))
                }
                Vp(a, b, k && k.trigger);
                h = vt(a, b.id, g, h);
                var l = R(b);
                l = xt(a, l).Eb;
                var m = wt(a, g.permissions, b.id, g.containerId),
                    p = Bf(a),
                    q = rt({
                        l: a,
                        counterId: b.id,
                        config: g,
                        I: m,
                        Tb: h,
                        Kd: k,
                        Eb: l,
                        qd: p,
                        uc: D(d.push, d)
                    });
                d.push(h.zc, G(p.ae, pc));
                q.add(ms(a, "ytm.init_consent"));
                q.aa();
                zf()(wf(V(a, "ytm.r"), function() {
                    c || (q.add(ms(a, "ytm.init")), d.push(it(a, q, g)), q.aa())
                }))
            }
        }));
        return function() {
            return e()
        }
    }));
    rg.push(function(a, b, c) {
        c.policy = Ks(a).Ad
    });
    Ad.push("_ytm_preview");
    fs.html = function(a, b, c, d, e, f) {
        d = a.l;
        a.I.checkPermission({
            ja: c,
            permissionType: "html",
            F: null
        });
        a = Jr(a, b, c.data.html);
        xs(d, a, e, f)
    };
    Hs.html = function(a, b) {
        return I(b, "html") ? !!b.html.unsafeSet : !1
    };
    fs.pix = function(a, b, c, d, e, f) {
        d = a.l;
        var g = a.I;
        a = Jr(a, b, c.data.pixelUrl);
        u(a) ? (g.checkPermission({
            ja: c,
            permissionType: "pixel",
            F: {
                url: a
            }
        }), Wp(d, a, e, f)) : f(Ep("ca.p.uns"))
    };
    Hs.pixel = Es;
    qq.addConsentListener = function(a) {
        var b = a.l,
            c = a.I;
        return function(d, e) {
            if (!u(d)) throw Ep("ict");
            if (!y(e)) throw Ep("icl");
            c.checkPermission({
                permissionType: "accessConsent",
                F: {
                    key: d,
                    operation: 2
                }
            });
            no(b).on(d, e)
        }
    };
    qq.isConsentGranted = function(a) {
        var b = a.l,
            c = a.I;
        return function(d) {
            if (!u(d)) throw Ep("ict");
            c.checkPermission({
                permissionType: "accessConsent",
                F: {
                    key: d,
                    operation: 2
                }
            });
            return no(b).get(d)
        }
    };
    qq.setDefaultConsentState = sq;
    qq.updateConsentState = tq;
    fs.consent = function(a, b, c, d, e, f) {
        if (O(b.event, is)) {
            c = b.ytm.action;
            if (O(c, js) && (a = no(a.l).set(c, b.ytm.La))) {
                f(Ep(a));
                return
            }
            e()
        } else f(Dp("t.c.e"))
    };
    Hs.accessConsent = function(a, b, c, d) {
        if (!I(b, c)) return !1;
        a = b[c];
        if (!I(a, "categories")) return !1;
        a = a.categories;
        b = d.key;
        return I(a, b) ? !!(a[b] & d.operation) : !1
    };
    fs.timer = function(a, b, c, d, e, f) {
        var g = a.l,
            h = c.data.trigger,
            k = Cs(a);
        if (k[h]) f(Ep("t.a.s.t"));
        else {
            var l = Jr(a, b, c.data.interval);
            u(l) ? (l = Er(l), A(l) ? f(Dp("t.i.nn")) : (a = qs(a, b, c.data.limit), d = {
                l: g,
                dispatchEvent: N(d.add, d.aa),
                interval: l,
                limit: a
            }, g = d.l, a = 1E3 * d.interval, b = {
                id: null,
                interval: a,
                sequence: 0,
                limit: d.limit || 0,
                startTime: X(g)(gf),
                xe: h
            }, b.id = uf(g, F([d, b], Bs), a, "yt.t"), k[h] = !0, e())) : f(Dp("t.i.ns"))
        }
    };
    fs.elementVisibility = function(a, b, c, d, e, f) {
        var g = a.l,
            h = c.data.trigger,
            k = rs(a);
        if (k[h]) f(Ep("t.a.s.ev"));
        else if (xa("IntersectionObserver", g.IntersectionObserver)) {
            var l = c.data;
            g = l.sm;
            var m = l.srp,
                p = l.lfd,
                q = l.ff,
                v = l.trigger,
                t = qs(a, b, l.sd, !0);
            A(t) || (t = 0 > t ? null : t, A(t) || (t *= 1E3));
            m = qs(a, b, m, !0);
            A(m) || (m = 0 > m || 100 < m ? null : m);
            "id" === g ? (b = Jr(a, b, l.id), c = u(b) && b ? P({}, c, {
                data: {
                    Xc: g,
                    id: b,
                    Wc: t || 0,
                    $b: m || 50,
                    Pc: p,
                    Fc: q,
                    trigger: v
                }
            }) : null) : (b = Jr(a, b, l.selector), c = u(b) && b ? P({}, c, {
                data: {
                    Xc: g,
                    selector: b,
                    Wc: t || 0,
                    $b: m || 50,
                    Pc: p,
                    Fc: q,
                    trigger: v
                }
            }) : null);
            if (A(c)) f(Dp("p.f.ev"));
            else {
                try {
                    ps(a, N(d.add, d.aa), c)
                } catch (x) {
                    f(x);
                    return
                }
                k[h] = !0;
                e()
            }
        } else f(Dp("n.io.ev"))
    };
    fs.scrollDepth = function(a, b, c, d, e, f) {
        var g = zs(a),
            h = c.data;
        c = h.index;
        var k = h.vpt,
            l = h.mode;
        h = h.ps;
        if (g[c]) f(Ep("t.a.s.sd"));
        else {
            if ("pt" === l) {
                if (!k) {
                    f(Dp("t.a.s.sd.t"));
                    return
                }
                b = Jr(a, b, k);
                b = ys(b)
            } else {
                if (!h) {
                    f(Dp("t.a.s.sd.s"));
                    return
                }
                b = Jr(a, b, h);
                if (u(b))
                    if (b = sb(b), A(b) || 0 >= b || 100 < b) b = [];
                    else {
                        f = [];
                        for (k = b; 100 >= k;) f.push(k), k += b;
                        b = f
                    }
                else b = []
            }
            As(a, N(d.add, d.aa))(c, b);
            g[c] = !0;
            e()
        }
    };
    qg.push(Ct);
    sg.push(Dt);
    Et.init || (Et.init = []);
    Et.init.push(function(a, b, c) {
        return !!J(c, "0.ssr")
    });
    qg.push(Pt);
    pg.push(Qt);
    se.getYmclid = "yc";
    qg.push(Tt);
    qg.push(Ut);
    sg.push(Vt);
    qg.push($t);
    jg(au, 6);
    Y("h", au, 6);
    Y("a", au, 6);
    Y("5", au, 6);
    Y("1", au, 6);
    Y("adb");
    Y("n", au, 4);
    Gh.adb = Dh;
    Kh.adb = fh;
    og.push(du);
    var av = {};
    P(Tf, (av.bu = hu, av));
    Gh["6"] = ["f", "x"];
    Kh["6"] = Zg;
    pg.push(ju);
    (function() {
        var a = {};
        P(Tf, (a.mdd = function(b) {
            return Dd(b, "mdd")
        }, a));
        a = {};
        P(ye, (a.cac = Vk("cac"), a.cae = Vk("cae"), a));
        qg.push(qu, ru)
    })();
    jg(yu, 5);
    Y("h", yu, 5);
    Y("a", yu, 5);
    Y("5", yu, 5);
    Y("1", yu, 6);
    Gh.c = Dh;
    Kh.c = Zg;
    jg(Eu, 8);
    Y("h", Eu, 8);
    Y("a", Eu, 8);
    Y("f", Eu, 3);
    Y("n", Eu, 5);
    Y("5", Eu, 8);
    Gh.csu = ["i"];
    Kh.csu = Zg;
    qg.push(W("p.gss", function(a, b) {
        return Zi(b, function(c) {
            var d = ad(a),
                e = d.o,
                f = d.B;
            if (!e("csup"))
                if (d = J(c, "settings.csu"), jd(a) || te(b.M) || !u(d) && !d) f("csu", 0);
                else if (Bu(c)) f("csu", 5);
            else {
                var g = He(a),
                    h = X(a)(hf);
                if ((c = sb(g.o("csu"))) && 1440 >= h - c) f("csu", 1);
                else return f("csup", 1), f("csu", 2), Lh(a, "csu", b)({
                    J: {
                        N: ["csu"]
                    }
                }, [d]).then(function() {
                    f("csu", 4);
                    g.B("csu", h)
                }, F(["csu", 3], f))
            }
        })["catch"](V(a, "s.csu"))
    }));
    var bv = {};
    P(ye, (bv.csu = Vk("csu"), bv));
    Gh.pi = Bh;
    Kh.pi = hh;
    Y("pi", Vf());
    var cv = {};
    P(Tf, (cv.bl = Vk("bl"), cv));
    var dv = {};
    P(ye, (dv.oms = Vk("oms"), dv));
    pg.push(W("isp.bl", Gu("bl", function() {
        return U("=", ["https://fcpe.beeline.ru/sync/me?guid", Hu()])
    }, Fu)));
    pg.push(W("isp.mf", Gu("mf", function(a, b, c, d) {
        b = T(a);
        b = pd(b.protocol + "//" + b.hostname + b.pathname);
        c = "";
        do c += ef(a); while (c.length < d.length);
        c = c.slice(0, d.length);
        a = "";
        for (var e = 0; e < d.length; e += 1) a += (d.charCodeAt(e) + c.charCodeAt(e) - 96) % 10;
        d = n([c, a]);
        a = d.next().value;
        return "https://adstat.yandex.ru/track?service=metrika&id=" + d.next().value + "&mask=" + a + "&ref=" + b
    })));
    pg.push(W("isp.rt", Gu("rt", function(a, b, c, d) {
        c = "" + Sj(d);
        var e = {};
        d = Wg((e.rt = 1, e.u = d, e)).ra();
        e = {};
        a = sd((e["browser-info"] = d, e["page-url"] = T(a).href, e["page-ref"] = a.document.referrer, e["site-info"] = b, e));
        return "https://" + c + ".mc.yandex.ru/watch/99742118/1?" + a
    })));
    pg.push(W("isp.tl2", Gu("tl2", function(a, b, c, d) {
        if (c = J(c, "settings.tl2")) {
            var e = {};
            d = Wg((e.tl2 = 1, e.u = d, e)).ra();
            e = {};
            a = sd((e["browser-info"] = d, e["page-url"] = T(a).href, e["page-ref"] = a.document.referrer, e["site-info"] = b, e));
            return "https://" + c + ".mc.yandex.ru/watch/99742118/1?" + a
        }
    })));
    var ev = {};
    P(ye, (ev.mfs = Vk("mfs"), ev));
    qg.push(W("p.ot", Ju));
    Gh.ci = ["x"];
    Kh.ci = Zg;
    qg.push(W("p.sci", function(a, b) {
        return Zi(b, F([a, b], Ku))["catch"](V(a, "ins.cs"))
    }));
    var fv = {};
    P(ye, (fv.csi = Vk("scip"), fv));
    Gh.pis = Eh;
    Kh.pis = Zg;
    qg.push(W("p.sci", function(a, b) {
        return Zi(b, function(c) {
            var d = J(c, "settings.pis");
            if (d && !Bu(c)) {
                c = Q(a);
                var e = c.o;
                c = c.B;
                e = e("pis");
                if (A(e)) return e = Lh(a, "pis", b), c("pis", "0"), e({
                    J: {
                        N: ["pis"]
                    }
                }, [d]).then(F(["pis", "1"], c), Qa(F(["pis", "a"], c)))
            }
        })["catch"](V(a, "pis"))
    }));
    var gv = {};
    P(ye, (gv.pis = Vk("pis"), gv));
    (function() {
        Gh.pic = ["j"];
        Kh.pic = Zg;
        qg.push(Mu);
        var a = {};
        P(Tf, (a.pic = function(b) {
            return Dd(b, "_ym_fa")
        }, a));
        a = {};
        P(ye, (a.prs = Vk("prs"), a))
    })();
    ye.wds = Vk("wds");
    qg.push(Pu);
    pg.push(function(a, b) {
        var c = Ft(a),
            d = R(b),
            e = c[d];
        e || (e = {}, c[d] = e);
        e.Vd = !0;
        if (c = e.dd) d = Ht(a), M(d, c)
    });
    qg.unshift(function(a, b) {
        Zi(b, function(c) {
            var d = Ld(a),
                e = Ek(a);
            (d || e.id) && Bt(a, "tag_debug", b, c)
        })
    });

    function hv(a, b, c, d) {
        var e = this;
        return V(window, "c.i", function() {
            function f(C) {
                (C = ek(k, m, "", C)(k, m)) && (y(C.then) ? C.then(g) : g(C));
                return C
            }

            function g(C) {
                C && (y(C) ? p.push(C) : B(C) && M(function(S) {
                    var ea = n(S);
                    S = ea.next().value;
                    ea = ea.next().value;
                    y(ea) && ("u" === S ? p.push(ea) : h(ea, S))
                }, dc(C)))
            }

            function h(C, S, ea) {
                e[S] = Uu(k, m, ea || q, S, C)
            }
            var k = window;
            (!k || isNaN(a) && !a) && $d();
            var l = ue(a, b, c, d),
                m = ve(l);
            At(m).oe = l;
            pi(m, m.L || {});
            var p = [],
                q = [Vu, ek, Wu];
            q.unshift(gi);
            var v = M(lb, qg);
            l = R(m);
            m.id || Td(Wd("Invalid Metrika id: " +
                m.id, !0));
            var t = Xu.o("counters", {});
            if (t[l]) return v = {}, Qh(k, l, "dc", (v.key = l, v)), t[l];
            var x = Xi(l),
                E = J(k, "ym.l");
            rb(k, E) && (x.Wd = E);
            x.kb = X(k)(gf);
            t[l] = e;
            Xu.B("counters", t);
            Xu.V("counter", e);
            M(function(C) {
                C(k, m)
            }, ng);
            V(k, "c.i.bh", function() {
                M(f, og)
            })();
            f(Su);
            h(Tu(k, m, p), "destruct", [Vu, Wu]);
            $i(k, F([k, v, f, "a.i", 1], fj), "a.ra");
            V(k, "c.i.ps", function() {
                M(f, pg)
            })();
            l = {};
            Pd(k, (l.counterKey = R(m), l.name = "counter", l.data = ch(m), l))
        })()
    }
    V(window, "wp.i", function() {
        M(Oa(be)(window), sg)
    })();
    if (window.Ya && hv) {
        window.Ya[Qd] = hv;
        Ru(window);
        var iv = window.Ya[Qd];
        Xu.V("staticMethods", {});
        var jv = Xu.o("staticMethods");
        M(N(Jb([window, iv, jv]), be), rg)
    }(function(a) {
        var b = J(a, "ym");
        if (b) {
            var c = J(b, "a");
            c || (b.a = [], c = b.a);
            var d = Ht(a);
            Bi(a, c, function(e) {
                e.Ba.C(d)
            }, !0)
        }
    })(window);
}).call(this);
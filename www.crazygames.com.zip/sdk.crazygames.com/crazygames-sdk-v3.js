(() => {
    "use strict";

    function e(e) {
        return "sdk" === e.messageTarget
    }
    const t = "border-radius: 3px; padding: 0px 4px; color: white;",
        s = ["%cHTML5 SDK", `background-color: #6842FF; ${t}`],
        n = window.location.href.includes("sdk_debug=true");
    class r {
        constructor(e) {
            this.badge = e, this.CSLLogMessage = "cslLogMessage", this.persist = {
                log: (e, ...t) => {
                    this.log(e, ...t), this.postPersistLogMessage("info", e, t)
                },
                verbose: (e, ...t) => {
                    this.verbose(e, ...t), this.postPersistLogMessage("info", e, t)
                },
                warn: (e, ...t) => {
                    this.warn(e, ...t), this.postPersistLogMessage("warn", e, t)
                },
                error: (e, ...t) => {
                    this.error(e, ...t), this.postPersistLogMessage("error", e, t)
                }
            }, this.postPersistLogMessage = (e, t, s) => {
                if (!_e) return;
                const n = {
                    timestamp: Date.now(),
                    message: t,
                    source: `sdk-${this.badge}`,
                    level: e,
                    data: s.length > 0 ? {
                        args: s
                    } : void 0
                };
                _e.postMessage({
                    type: this.CSLLogMessage,
                    data: n
                }, "*")
            }
        }
        isEnabled() {
            return n || r.forceEnable
        }
        log(e, ...n) {
            if (!this.isEnabled()) return;
            if ("none" === this.badge) return console.log(...s, e, ...n.length > 0 ? n : []);
            let r = [];
            switch (this.badge) {
                case "game":
                    r = ["%cGAME", `background-color: #d48f06; ${t}`];
                    break;
                case "user":
                    r = ["%cUSER", `background-color: #3498DB; ${t}`];
                    break;
                case "ad":
                    r = ["%cAD", `background-color: #008A00; ${t}`];
                    break;
                case "banner":
                    r = ["%cBANNER", `background-color: #00ABA9; ${t}`];
                    break;
                case "data":
                    r = ["%cDATA", `background-color: #A21CAF; ${t}`];
                    break;
                case "analytics":
                    r = ["%cANALYTICS", `background-color: #5c5c5c; ${t}`];
                    break;
                case "store":
                    r = ["%cSTORE", `background-color: #E11D48; ${t}`]
            }
            console.log(`${s[0]}%c ${r[0]}`, s[1], "", r[1], e, ...n.length > 0 ? n : [])
        }
        verbose(e, ...t) {
            this.isEnabled() && console.debug(`${s[0]}%c %c${e}`, s[1], "", "color: #3d7fff", ...t.length > 0 ? t : [])
        }
        warn(e, ...t) {
            this.isEnabled() && console.warn(...s, e, ...t.length > 0 ? t : [])
        }
        error(e, ...t) {
            console.error(...s, e, ...t.length > 0 ? t : [])
        }
    }
    r.forceEnable = !1;
    const i = r;
    class o {
        constructor(e, t, s, n) {
            this.bannerRequest = e, this.onWindowResize = () => {
                this.setContainerPosition()
            }, this.containerElement = document.createElement("div"), this.containerId = "overlay-banner-" + e.id, this.containerElement.id = this.containerId, this.bannerRequest = e, this.containerElement.style.position = "absolute", this.containerElement.style.transformOrigin = "top left", this.containerElement.style.userSelect = "none";
            const r = document.getElementById("gfMainContainer");
            r ? r.appendChild(this.containerElement) : document.body.appendChild(this.containerElement);
            const i = e.size.split("x");
            this.onScreenSize = {
                width: parseInt(i[0]),
                height: parseInt(i[1])
            }, this.bannerModule = s, this.callback = n, this.disableBannerCheck = t, this.debouncedWindowResize = function(e) {
                let t;
                return (...s) => {
                    void 0 !== t && clearTimeout(t), t = setTimeout(() => {
                        t = void 0, e(...s)
                    }, 200)
                }
            }(this.onWindowResize), window.addEventListener("resize", this.debouncedWindowResize), this.renderBanner()
        }
        isVisible() {
            const e = this.computeOverlay();
            if (this.disableBannerCheck) return !0;
            const t = e.left + e.width * e.scale,
                s = e.top + e.height * e.scale,
                n = this.getGameContainerDimensions();
            return !(e.top < -4 || e.left < -4 || t > window.innerWidth + 4 || s > n.height + 4)
        }
        computeOverlay() {
            const e = this.getScale(),
                t = this.getOnScreenPosition();
            return {
                width: this.onScreenSize.width,
                height: this.onScreenSize.height,
                top: t.y,
                left: t.x,
                scale: e
            }
        }
        getGameContainerDimensions() {
            const e = document.getElementById("game-container");
            return e ? {
                width: e.clientWidth,
                height: e.clientHeight
            } : {
                width: window.innerWidth,
                height: window.innerHeight
            }
        }
        getScale() {
            return this.getGameContainerDimensions().width / 922
        }
        getOnScreenPosition() {
            const e = this.getGameContainerDimensions(),
                t = this.bannerRequest.anchor.x * e.width,
                s = (1 - this.bannerRequest.anchor.y) * e.height,
                n = this.getScale(),
                r = this.onScreenSize,
                i = r.width * n,
                o = r.height * n,
                a = this.bannerRequest.pivot || {
                    x: .5,
                    y: .5
                };
            return {
                x: t + this.bannerRequest.position.x * n - i * a.x,
                y: s - this.bannerRequest.position.y * n - o * (1 - a.y)
            }
        }
        setContainerPosition() {
            const e = this.computeOverlay();
            this.containerElement.style.width = `${e.width}px`, this.containerElement.style.height = `${e.height}px`, this.containerElement.style.top = `${e.top}px`, this.containerElement.style.left = `${e.left}px`, this.containerElement.style.transform = `scale(${e.scale})`, this.containerElement.style.display = "block"
        }
        async renderBanner() {
            if (this.setContainerPosition(), !this.isVisible()) return this.callback(this.bannerRequest.id, "bannerError", "bannerNotEntirelyVisible"), void(this.containerElement.style.display = "none");
            try {
                await this.bannerModule.requestBanner({
                    id: this.containerId,
                    ...this.onScreenSize
                }), this.callback(this.bannerRequest.id, "bannerRendered")
            } catch (e) {
                this.callback(this.bannerRequest.id, "bannerError", `${e}`)
            }
        }
        destroy() {
            this.containerElement && this.containerElement.remove(), window.removeEventListener("resize", this.debouncedWindowResize)
        }
    }
    const a = "docs.crazygames.com";
    var l;
    ! function(e) {
        e[e.UNINITIALIZED = 0] = "UNINITIALIZED", e[e.REQUESTED = 1] = "REQUESTED", e[e.INITIALIZED = 2] = "INITIALIZED"
    }(l || (l = {}));
    class h {
        constructor(e, t) {
            this.code = e, this.message = t
        }
    }
    const d = ["728x90", "300x250", "320x50", "468x60", "320x100"];
    const c = new i("banner");
    class u extends h {
        constructor(e, t, s) {
            n && c.error(`[BannerError] Code: ${e} - Message: ${t} - ContainerId: ${s}`), super(e, t), this.code = e, this.message = t, this.containerId = s
        }
    }
    const g = new i("banner"),
        m = [{
            width: 970,
            height: 90
        }, {
            width: 320,
            height: 50
        }, {
            width: 160,
            height: 600
        }, {
            width: 336,
            height: 280
        }, {
            width: 728,
            height: 90
        }, {
            width: 300,
            height: 600
        }, {
            width: 468,
            height: 60
        }, {
            width: 970,
            height: 250
        }, {
            width: 300,
            height: 250
        }, {
            width: 250,
            height: 250
        }, {
            width: 120,
            height: 600
        }];

    function p(e) {
        g.log("Rendering fake banner", e);
        const t = document.getElementById(e.id);
        if (!t) return void console.error(`Didn't find container #${e.id} for rendering fake banner`);
        let s = e.width,
            n = e.height;
        if (e.isResponsive) {
            const e = function(e) {
                const t = e.slice();
                for (let e = t.length - 1; e > 0; e--) {
                    const s = Math.floor(Math.random() * (e + 1)),
                        n = t[e];
                    t[e] = t[s], t[s] = n
                }
                return t
            }(m).find(e => s >= e.width && n >= e.height);
            if (!e) throw new u("noAvailableSizes", "No available banner size has been found", t.id);
            s = e.width, n = e.height
        }
        t.innerHTML = "";
        const r = document.createElement("img");
        r.setAttribute("src", `https://images.crazygames.com/crazygames-sdk/${s}x${n}.png`), r.setAttribute("width", `${s}px`), r.setAttribute("height", `${n}px`), t.appendChild(r), t.style.backgroundColor = "rgb(191, 173, 255, 0.25)"
    }
    async function w(e) {
        const t = document.getElementById(e);
        return t ? async function(e) {
            return new Promise(t => {
                const s = new IntersectionObserver(([n]) => {
                    const r = window.getComputedStyle(e),
                        i = n.intersectionRatio > .95;
                    t({
                        visibleState: i ? "visible" : "notVisible",
                        size: {
                            width: Math.ceil("auto" !== r.width ? parseFloat(r.width) : n.boundingClientRect.width),
                            height: Math.ceil("auto" !== r.height ? parseFloat(r.height) : n.boundingClientRect.height)
                        }
                    }), s.disconnect()
                });
                s.observe(e)
            })
        }(t) : {
            visibleState: "notCreated",
            size: {
                width: 0,
                height: 0
            }
        }
    }
    const y = e => `${e}-crazygames-inner`,
        f = e => `${e}`.replace("-crazygames-inner", "");
    async function v(e, t) {
        var s;
        if (!e) throw new u("missingId", "Container id not specified", e);
        const n = await w(e),
            {
                visibleState: r
            } = n;
        if (t) {
            if ("notCreated" === r) throw new u("notCreated", "Container is not present on the page", e);
            if ("notVisible" === r) throw new u("notVisible", "Container is not entirely visible on the page", e)
        }
        const i = y(e);
        if (!document.getElementById(i)) {
            const t = document.createElement("div");
            t.id = i, t.classList.add("crazygames-banner-container"), null === (s = document.getElementById(e)) || void 0 === s || s.append(t)
        }
        return {
            mainContainerId: e,
            innerContainerId: i,
            containerInfo: n
        }
    }

    function b(e) {
        return `${e.width}x${e.height}`
    }

    function k(e) {
        switch (e) {
            case "apple_store":
            case "google_play_store":
                return !0;
            case "pwa":
            case "web":
            case void 0:
                return !1
        }
    }

    function I(e) {
        return null != e
    }

    function S(e, t) {
        const s = e.adsAllowedByPlacement ? .[t];
        return I(s) ? s : function(e, t) {
            return e.isBot ? {
                allowed: !1,
                reason: "Bot, based on the User Agent"
            } : e.isKids ? {
                allowed: !1,
                reason: "Kids mode, where we don't show ads"
            } : function(e) {
                switch (e) {
                    case "basic":
                        return !1;
                    case "full":
                        return !0
                }
            }(e.launchFlow) || "portalBanner" === t ? e.isApp && "midroll" !== t && "rewarded" !== t ? {
                allowed: !1,
                reason: `${t} ads are disabled on the mobile apps`
            } : e.isDesktop || "portalBanner" !== t ? e.isOfflineGaming && "rewarded" !== t ? {
                allowed: !1,
                reason: "Only rewarded ads are available during offline play"
            } : "ingameBanner" === t && e.disableBanners ? {
                allowed: !1,
                reason: "Banner ads are disabled for this game"
            } : "midroll" === t && e.disableMidgameAds ? {
                allowed: !1,
                reason: "Midgame ads are disabled for this game"
            } : "rewarded" === t && e.disableRewardedAds ? {
                allowed: !1,
                reason: "Rewarded ads are disabled for this game"
            } : {
                allowed: !0
            } : {
                allowed: !1,
                reason: "Portal banners only run on desktop"
            } : {
                allowed: !1,
                reason: `Ads are not allowed in ${e.launchFlow} launch flow`
            }
        }({
            isBot: !1,
            isKids: !1,
            isOfflineGaming: !1,
            isDesktop: !0,
            disableBanners: !1,
            disableMidgameAds: !1,
            disableRewardedAds: !1,
            launchFlow: e.launchFlow,
            isApp: k(e.systemInfo.applicationType)
        }, t)
    }
    class A {
        constructor(e) {
            this.onHidden = e, this.containers = new Map, this.observer = "undefined" != typeof ResizeObserver ? new ResizeObserver(e => e.forEach(e => this.onResize(e.target))) : null
        }
        watch(e) {
            const t = document.getElementById(e);
            I(this.observer) && I(t) && !R(t) && (this.unwatch(e), this.containers.set(e, t), this.observer.observe(t))
        }
        unwatch(e) {
            const t = this.containers.get(e);
            I(this.observer) && I(t) && (this.observer.unobserve(t), this.containers.delete(e))
        }
        onResize(e) {
            this.containers.forEach((t, s) => {
                t === e && (e.isConnected ? R(e) && (this.unwatch(s), this.onHidden(s)) : this.unwatch(s))
            })
        }
    }
    const R = e => 0 === e.getClientRects().length,
        P = {
            maxConsecutiveNoFills: 4,
            delayMs: 31e3
        };
    (function(e) {
        return e.ios = "iOS", e.android = "Android", e.linux = "Linux", e.chromeos = "Chromium OS", e.macos = "Mac OS", e.windows = "Windows", e.other = "Other", e
    })({}).ios;
    class M {
        constructor(e, t, s) {
            this.prefetch = e, this.render = t, this.disableBannerCheck = s, this.timeouts = new Map, this.waitingForVisibleTab = new Map, this.noFillCounts = new Map, this.logger = new i("banner"), document.addEventListener("visibilitychange", () => {
                if ("visible" === document.visibilityState)
                    for (const e of this.waitingForVisibleTab.values()) this.logger.log(`Tab visible again, auto refreshing banner #${e.id}`), this.scheduleRefresh(e, 0)
            })
        }
        schedule(e) {
            this.noFillCounts.delete(e.id), this.scheduleRefresh(e)
        }
        cancel(e) {
            clearTimeout(this.timeouts.get(e)), this.timeouts.delete(e), this.waitingForVisibleTab.delete(e)
        }
        scheduleRefresh(e, t = P.delayMs) {
            this.cancel(e.id), this.timeouts.set(e.id, setTimeout(() => this.refresh(e), t))
        }
        async refresh(e) {
            var t;
            const {
                id: s
            } = e, n = this.timeouts.get(s), r = () => this.timeouts.get(s) === n;
            try {
                if ("visible" !== document.visibilityState) return this.logger.log(`Tab not visible, auto refreshing banner #${s} once it is visible again`), this.cancel(s), void this.waitingForVisibleTab.set(s, e);
                const {
                    visibleState: t,
                    size: n
                } = await w(s);
                if (!r()) return;
                if ("notCreated" === t) return this.logger.log(`Container #${s} no longer exists, stopping auto refresh`), void this.cancel(s);
                if ("notVisible" === t && !this.disableBannerCheck) return this.logger.log(`Container #${s} not visible, skipping auto refresh`), void this.scheduleRefresh(e);
                this.logger.log(`Auto refreshing banner #${s}`);
                const i = await this.prefetch(e.isResponsive ? { ...e,
                    ...n
                } : e);
                if (!r()) return;
                if (await this.render(i), !r()) return;
                this.noFillCounts.delete(s), this.scheduleRefresh(e)
            } catch (n) {
                if (!r()) return;
                if (n instanceof u && function(e) {
                        switch (e) {
                            case "missingId":
                            case "notCreated":
                            case "bannersDisabled":
                            case "invalidSize":
                            case "noAvailableSize":
                            case "noAvailableSizes":
                                return !0;
                            case "unfilled":
                            case "notVisible":
                            case "videoAdPlaying":
                            case "other":
                            case "bannerCooldown":
                            case "maxRefreshReached":
                                return !1
                        }
                    }(n.code)) return this.logger.log(`Stopping auto refresh of banner #${s}: ${n.message}`), void this.cancel(s);
                if (n instanceof u && "unfilled" === n.code) {
                    const e = (null !== (t = this.noFillCounts.get(s)) && void 0 !== t ? t : 0) + 1;
                    if (this.noFillCounts.set(s, e), e >= P.maxConsecutiveNoFills) return this.logger.log(`Stopping auto refresh of banner #${s} after ${e} consecutive no fills`), void this.cancel(s)
                }
                this.logger.log(`Auto refresh of banner #${s} failed, will retry`, n), this.scheduleRefresh(e)
            }
        }
    }
    const E = class {
            constructor(e, t) {
                var s;
                this.sdk = e, this.initInfo = t, this.bannerQueue = {}, this.overlayBanners = {}, this.renderedBannerIds = new Set, this.logger = new i("banner"), this.hideWatcher = new A(e => {
                    this.logger.log(`Container #${e} got hidden, auto-clearing its banner`), this.clearBanner(e)
                }), this.prefetchForAutoRefresh = async e => (this.ensureVideoAdNotPlaying(e.id), e.isResponsive ? this.prefetchResponsiveBanner(e) : this.prefetchBanner(e)), this.useTestAds = t.useTestAds || !1, this.disableBannerCheck = t.disableBannerCheck || !1, "enabled" === (null === (s = t.configCatValues) || void 0 === s ? void 0 : s.czyExpClientAutoRefreshIngameBanners) && (this.autoRefresh = new M(this.prefetchForAutoRefresh, e => this.renderBanner(e, !1), this.disableBannerCheck))
            }
            checkBannerAdsEnabled() {
                const e = S(this.initInfo, "ingameBanner");
                if (!e.allowed) throw new u("bannersDisabled", e.reason)
            }
            isBannerAdsEnabled() {
                try {
                    return this.checkBannerAdsEnabled(), !0
                } catch {
                    return !1
                }
            }
            async requestBanner(e) {
                this.checkBannerAdsEnabled(), this.logger.log("Requesting banner with automatic rendering", e), this.ensureVideoAdNotPlaying(e.id);
                const t = await this.prefetchBanner(e);
                return this.renderPrefetchedBanner(t)
            }
            async requestResponsiveBanner(e) {
                this.checkBannerAdsEnabled(), this.logger.log(`Requesting responsive banner with automatic rendering #${e}`), this.ensureVideoAdNotPlaying(e);
                const t = await v(e, !this.disableBannerCheck),
                    {
                        width: s,
                        height: n
                    } = t.containerInfo.size,
                    r = await this.prefetchResponsiveBanner({
                        id: e,
                        width: s,
                        height: n
                    });
                return this.renderPrefetchedBanner(r)
            }
            async prefetchBanner(e) {
                this.checkBannerAdsEnabled(), this.logger.log("Prefetch banner", e);
                const t = y(e.id),
                    s = { ...e,
                        id: t
                    };
                return new Promise((e, t) => {
                    this.bannerQueue[s.id] = {
                        banner: s,
                        resolve: e,
                        reject: t
                    }, this.sdk.postMessage({
                        type: "requestBanner",
                        data: [{
                            containerId: s.id,
                            size: b(s)
                        }]
                    })
                })
            }
            async prefetchResponsiveBanner(e) {
                this.checkBannerAdsEnabled(), this.logger.log(`Prefetch responsive banner #${e.id}`);
                const {
                    width: t,
                    height: s
                } = e, n = {
                    id: y(e.id),
                    width: t,
                    height: s,
                    isResponsive: !0
                };
                return new Promise((e, r) => {
                    this.bannerQueue[n.id] = {
                        banner: n,
                        resolve: e,
                        reject: r
                    }, this.sdk.postMessage({
                        type: "requestResponsiveBanner",
                        data: [{
                            id: n.id,
                            width: t,
                            height: s
                        }]
                    })
                })
            }
            async renderPrefetchedBanner(e) {
                return this.renderBanner(e, !0)
            }
            async renderBanner(e, t) {
                var s;
                this.logger.log("Rendering prefetched banner", e);
                const n = f(e.id);
                return this.ensureVideoAdNotPlaying(n), await v(n, !this.disableBannerCheck), this.renderedBannerIds.add(n), this.hideWatcher.watch(n), t && (null === (s = this.autoRefresh) || void 0 === s || s.schedule({ ...e.banner,
                    id: n
                })), new Promise((t, s) => {
                    const {
                        CrazygamesAds: n
                    } = window, {
                        id: r,
                        banner: i
                    } = e;
                    I(n) ? n.render([r], { ...e.renderOptions,
                        banner: {
                            callback: e => {
                                if (delete this.bannerQueue[e.code], !e.empty) return this.logger.log("Banner rendered", i, "with options", e), this.sdk.postMessage({
                                    type: "bannerProcessed",
                                    data: {
                                        containerId: i.id,
                                        width: i.width,
                                        height: i.height,
                                        minPrice: e.minPrice,
                                        houseAd: e.houseAd,
                                        empty: e.empty
                                    }
                                }), void t();
                                if (this.useTestAds) p(i), this.logger.log("Fake banner rendered", i), t();
                                else {
                                    this.logger.log("No banner available", i);
                                    const t = "Sorry, no banner is available for the moment, please retry";
                                    this.sdk.postMessage({
                                        type: "bannerProcessed",
                                        data: {
                                            containerId: i.id,
                                            width: i.width,
                                            height: i.height,
                                            error: "UnitNotRendered" === e.type ? "Unit ignored for rendering" : t,
                                            minPrice: e.minPrice,
                                            houseAd: e.houseAd,
                                            empty: e.empty
                                        }
                                    }), s(new u("unfilled", t, i.id))
                                }
                            }
                        }
                    }) : s(new u("other", "Cannot find CrazygamesAds", i.id))
                })
            }
            requestOverlayBanners(e, t) {
                const s = S(this.initInfo, "ingameBanner");
                if (!s.allowed) return void t("", "bannerError", s.reason);
                this.logger.log("Requesting overlay banners", e);
                const n = e.map(e => e.id);
                Object.keys(this.overlayBanners).forEach(e => {
                    n.includes(e) || (this.logger.log("Remove overlay banner " + e), this.overlayBanners[e].destroy(), delete this.overlayBanners[e])
                }), e.forEach(e => {
                    if (this.overlayBanners[e.id]) return void this.logger.log("Skip overlay banner update " + e.id);
                    this.logger.log("Create overlay banner " + e.id);
                    const s = new o(e, this.disableBannerCheck, this, t);
                    this.overlayBanners[e.id] = s
                })
            }
            handleEvent(e) {
                switch (e.type) {
                    case "bannerError":
                        return void this.handleBannerErrorEvent(e);
                    case "requestBanner":
                        return void this.handleRequestBannerEvent(e)
                }
            }
            handleBannerErrorEvent(e) {
                const {
                    error: t,
                    containerId: s,
                    code: n = "other"
                } = e;
                this.logger.log("Banner error happened", {
                    error: t,
                    containerId: s
                });
                const r = this.popFromBannerQueue(s);
                if (!r) return;
                const {
                    reject: i
                } = r;
                i(new u(n, `${t}`, s))
            }
            async handleRequestBannerEvent(e) {
                const {
                    request: t
                } = e;
                this.logger.verbose("Received banner data from GF, will prefetch it now", t);
                const s = t.request.units[0].adUnit.code,
                    n = this.popFromBannerQueue(s);
                if (!n) return void this.logger.verbose(`Banner ${s} missing in queue, not prefetching.`);
                const {
                    CrazygamesAds: r
                } = window;
                if (I(r)) try {
                    await r.requestOnly(t.request, t.requestOptions), this.logger.verbose(`Banner ${s} prefetched`), n.resolve({
                        id: s,
                        banner: n.banner,
                        renderOptions: t.renderOptions
                    })
                } catch {
                    n.reject(new u("other", "Failed to prefetch the banner", s))
                } else n.reject(new u("other", "Cannot find CrazygamesAds", s))
            }
            popFromBannerQueue(e) {
                const t = this.bannerQueue[e];
                return t ? (delete this.bannerQueue[e], t) : (this.logger.log(`Cannot retrieve element for id ${e} from the banner queue`), null)
            }
            clearBanner(e) {
                var t;
                this.hideWatcher.unwatch(e), this.sdk.postMessage({
                    type: "clearBanner"
                }), null === (t = this.autoRefresh) || void 0 === t || t.cancel(e);
                const s = document.getElementById(y(e));
                if (!s) return void this.logger.log(`There isn't a banner in container #${e}, not clearing anything.`);
                s.remove(), this.renderedBannerIds.delete(e);
                const n = Object.values(this.overlayBanners).find(t => t.containerId === e);
                n && (n.destroy(), delete this.overlayBanners[n.bannerRequest.id]), this.logger.log(`Cleared the banner from container #${e} ${n?"(also overlay banner)":""}`)
            }
            clearAllBanners() {
                this.sdk.postMessage({
                    type: "clearAllBanners"
                });
                const e = Array.from(this.renderedBannerIds.values());
                this.logger.log("Clearing all banners, ids: ", e.map(e => `#${e}`).join(", ")), e.forEach(e => {
                    this.clearBanner(e)
                })
            }
            ensureVideoAdNotPlaying(e) {
                if (this.sdk.ad.isAdPlaying) throw new u("videoAdPlaying", "Banners cannot be rendered while a video ad is playing", e)
            }
            get activeBannersCount() {
                return this.renderedBannerIds.size
            }
        },
        L = new i("none"),
        C = (e, t) => {
            const {
                delayMs: s,
                methodName: n,
                throwIfThrottled: r = !1
            } = t;
            let i = 0;
            return (...t) => {
                const o = (new Date).getTime();
                if (o - i > s) return i = o, e(...t);
                if (r) throw new h("rateLimited", `${n}() call throttled, delay ${s}`);
                L.error(`${n}() call throttled, delay ${s}`)
            }
        },
        T = new i("game");
    class q extends h {
        constructor(e, t) {
            n && T.error(`[GameError] Code: ${e} - Message: ${t}`), super(e, t), this.code = e, this.message = t
        }
    }

    function B(e) {
        if ("number" != typeof e || Number.isNaN(e)) throw new q("invalidArguments", "percentage must be a number");
        if (!Number.isInteger(e)) throw new q("invalidArguments", "percentage must be an integer");
        if (e < 0 || e > 100) throw new q("invalidArguments", "percentage must be between 0 and 100")
    }
    const x = e => "string" == typeof e && "" !== e.trim(),
        D = e => Number.isInteger(e) && e >= 0,
        F = (e, t) => Object.prototype.hasOwnProperty.call(e, t),
        $ = (...e) => t => e.includes(t),
        U = {
            puzzleStarted: {
                puzzleType: $("daily", "other"),
                attemptId: x
            },
            puzzleEnded: {
                puzzleType: $("daily", "other"),
                attemptId: x,
                outcome: $("completed", "failed", "abandoned")
            }
        },
        z = {
            puzzleStarted: {
                difficulty: x
            },
            puzzleEnded: {
                activeTimeSec: e => "number" == typeof e && Number.isFinite(e) && e >= 0,
                hintsUsed: D,
                videosWatched: D,
                currencySpent: D
            }
        },
        N = {
            puzzleDate: e => "string" == typeof e && /^\d{4}-\d{2}-\d{2}$/.test(e)
        };

    function G(e) {
        if ("object" != typeof(t = e) || null === t || Array.isArray(t) || "string" != typeof e.type || !F(U, e.type)) throw new q("invalidArguments", `dailyEvent type must be one of ${Object.keys(U).join(", ")}`);
        var t;
        const n = e.type,
            r = {
                type: () => !0,
                ...U[n],
                ..."daily" === e.puzzleType && N
            },
            i = z[n],
            o = function(e, t, s = {}) {
                var n;
                return Object.keys(e).find(e => !F(t, e) && !F(s, e)) || (null !== (n = Object.keys(t).find(s => !t[s](e[s]))) && void 0 !== n ? n : null)
            }(e, r, i);
        if (o) throw new q("invalidArguments", `dailyEvent ${n}: missing, invalid or unexpected field "${o}"`);
        const a = { ...e
        };
        return Object.keys(i).filter(e => void 0 !== a[e] && !i[e](a[e])).forEach(e => {
            console.warn(...s, `dailyEvent ${n}: ignored invalid optional field "${e}"`, a[e]), delete a[e]
        }), a
    }

    function O() {
        return {
            source: "dailyPuzzle" === new URLSearchParams(window.location.search).get("launchSource") ? "dailyPuzzle" : "default"
        }
    }

    function _(e) {
        const t = document.documentElement.style;
        t.setProperty("--safe-area-inset-top", `${e.top}px`), t.setProperty("--safe-area-inset-right", `${e.right}px`), t.setProperty("--safe-area-inset-bottom", `${e.bottom}px`), t.setProperty("--safe-area-inset-left", `${e.left}px`)
    }

    function J(e, t, s) {
        const n = (e, t) => null === t ? `${e}+` : `${e}-${t-1}`,
            r = {};
        for (const [e, s] of t) r[n(e, s)] = 0;
        return e.forEach((e, i) => {
            const o = Array.isArray(s) ? s[i] : s;
            for (const [s, i] of t)
                if (e >= s && (null === i || e < i)) {
                    r[n(s, i)] += o;
                    break
                }
        }), r
    }
    class j {
        constructor(e, t) {
            this.logger = e, this.sdk = t, this.fpsList = [], this.fpsSampleWeights = [], this.hitchDurations = [], this.trackingInterval = null, this.sendEventTimeout = null, this.rafId = null, this.lastFrameTime = null, this.framesSinceLastSample = 0, this.lastFpsSampleTime = null, this.measurementMethod = "raf", this.gpuRendererRead = !1, this.unityMetrics = null, this.trackingInitializedOn = Date.now(), this.isTabVisible = "visible" === document.visibilityState, this.isInGameplay = !1, this.onTabVisibilityChange = e => {
                this.isTabVisible = e, this.isTabVisible ? this.startTracking("tabVisible") : this.stopTracking("tabHidden")
            }, this.onGameplayStateChange = e => {
                this.isInGameplay = e, this.isInGameplay ? this.startTracking("gameplayStarted") : this.stopTracking("gameplayStopped")
            }, this.frameLoop = e => {
                if (this.framesSinceLastSample++, null !== this.lastFrameTime) {
                    const t = e - this.lastFrameTime;
                    t >= 250 && this.hitchDurations.push(t)
                }
                this.lastFrameTime = e, this.rafId = window.requestAnimationFrame(this.frameLoop)
            }, document.addEventListener("visibilitychange", () => {
                const e = "visible" === document.visibilityState;
                this.onTabVisibilityChange(e)
            })
        }
        get unityMetricsInfo() {
            var e;
            const t = null === (e = window.unityGameInstance) || void 0 === e ? void 0 : e.GetMetricsInfo;
            return "function" == typeof t ? t : void 0
        }
        rendererFromContext(e) {
            const t = null == e ? void 0 : e.getExtension("WEBGL_debug_renderer_info");
            if (!e || !t) return;
            const s = e.getParameter(t.UNMASKED_RENDERER_WEBGL);
            return "string" == typeof s && s.length > 0 ? s : void 0
        }
        readGpuRenderer() {
            var e, t;
            if (!this.gpuRendererRead) {
                this.gpuRendererRead = !0;
                try {
                    const s = document.createElement("canvas"),
                        n = null !== (e = s.getContext("webgl2", {
                            powerPreference: "high-performance"
                        })) && void 0 !== e ? e : s.getContext("webgl", {
                            powerPreference: "high-performance"
                        });
                    this.gpuRenderer = this.rendererFromContext(n), null === (t = null == n ? void 0 : n.getExtension("WEBGL_lose_context")) || void 0 === t || t.loseContext()
                } catch (e) {
                    this.logger.verbose("Failed to read GPU renderer", e)
                }
            }
        }
        get canStartTracking() {
            return this.isTabVisible && this.isInGameplay && !I(this.trackingInterval)
        }
        startTracking(e) {
            var t;
            this.canStartTracking && (this.unityMetrics = null !== (t = this.unityMetricsInfo) && void 0 !== t ? t : null, this.measurementMethod = this.unityMetrics ? "unity" : "raf", this.readGpuRenderer(), this.logger.verbose(`Starting performance tracking, reason: ${e}, method: ${this.measurementMethod}`), this.framesSinceLastSample = 0, this.lastFpsSampleTime = performance.now(), this.registerSendEventTimeout(), this.trackingInterval = window.setInterval(() => {
                this.track()
            }, 250), this.rafId = window.requestAnimationFrame(this.frameLoop))
        }
        stopTracking(e) {
            I(this.trackingInterval) && (this.logger.verbose(`Stopping performance tracking, reason: ${e}`), this.sendEvent("stopTracking"), this.trackingInterval && (clearInterval(this.trackingInterval), this.trackingInterval = null), this.sendEventTimeout && (clearTimeout(this.sendEventTimeout), this.sendEventTimeout = null), I(this.rafId) && (window.cancelAnimationFrame(this.rafId), this.rafId = null), this.lastFrameTime = null, this.lastFpsSampleTime = null, this.framesSinceLastSample = 0, this.unityMetrics = null)
        }
        readUnityMetrics() {
            if (!this.unityMetrics) return null;
            try {
                return this.unityMetrics()
            } catch {
                return null
            }
        }
        track() {
            const e = performance.now(),
                t = null !== this.lastFpsSampleTime ? e - this.lastFpsSampleTime : 0;
            if (!(t <= 0)) {
                if (this.unityMetrics) {
                    const s = this.readUnityMetrics();
                    return s && (this.fpsList.push(Math.round(s.fps)), this.fpsSampleWeights.push(t)), void(this.lastFpsSampleTime = e)
                }
                this.fpsList.push(Math.round(this.framesSinceLastSample / t * 1e3)), this.fpsSampleWeights.push(t), this.framesSinceLastSample = 0, this.lastFpsSampleTime = e
            }
        }
        registerSendEventTimeout() {
            this.sendEventTimeout = window.setTimeout(() => {
                this.sendEvent("timeout"), this.registerSendEventTimeout()
            }, this.sendEventDelay)
        }
        sendEvent(e) {
            if (this.logger.verbose(`Sending performance event, reason: ${e}`), 0 === this.fpsList.length) return void this.logger.verbose("No FPS data collected, skipping event");
            const t = J(this.fpsList, [
                    [0, 10],
                    [10, 20],
                    [20, 30],
                    [30, 40],
                    [40, 50],
                    [50, 60],
                    [60, 70],
                    [70, 80],
                    [80, 90],
                    [90, null]
                ], this.fpsSampleWeights),
                s = {
                    measurementMethod: this.measurementMethod,
                    gpuRenderer: this.gpuRenderer,
                    fpsHistogram: t,
                    hitches: this.buildHitches(),
                    memory: this.buildMemory()
                };
            this.logger.verbose("Send performance event with data: ", s), this.sdk.postMessage({
                type: "analyticsTrackGamePerformance",
                data: s
            }), this.fpsList = [], this.fpsSampleWeights = [], this.hitchDurations = []
        }
        buildHitches() {
            let e = 0,
                t = 0;
            for (const s of this.hitchDurations) e += s, t = Math.max(t, s);
            return {
                count: this.hitchDurations.length,
                totalMs: Math.round(e),
                maxMs: Math.round(t),
                histogram: J(this.hitchDurations, [
                    [250, 500],
                    [500, 1e3],
                    [1e3, 2e3],
                    [2e3, null]
                ], 1)
            }
        }
        buildMemory() {
            var e;
            const t = this.readUnityMetrics();
            if (t) {
                const {
                    totalWASMHeapSize: e,
                    usedWASMHeapSize: s,
                    totalJSHeapSize: n,
                    usedJSHeapSize: r
                } = t;
                return {
                    totalWASMHeapSize: e,
                    usedWASMHeapSize: s,
                    totalJSHeapSize: n,
                    usedJSHeapSize: r
                }
            }
            const s = null === (e = null === window || void 0 === window ? void 0 : window.performance) || void 0 === e ? void 0 : e.memory;
            if (s) {
                const {
                    totalJSHeapSize: e,
                    usedJSHeapSize: t
                } = s;
                return {
                    totalJSHeapSize: e,
                    usedJSHeapSize: t
                }
            }
        }
        get sendEventDelay() {
            const e = Date.now() - this.trackingInitializedOn;
            return e < 6e4 ? 1e4 : e < 36e5 ? 6e4 : 12e4
        }
    }
    const V = "czy_invite_params";

    function Q(e) {
        const {
            gameLink: t,
            invitedById: s,
            params: n
        } = e, r = new URL(t);
        return r.searchParams.set("czy_invite", "true"), r.searchParams.set("utm_source", "invite"), I(s) && r.searchParams.set("czy_invited_by", s), I(n) && Object.keys(n).length > 0 && r.searchParams.set(V, function(e) {
            const t = new URLSearchParams(e);
            return t.sort(), t.toString()
        }(n)), r.toString()
    }

    function W() {
        return window.location.search.includes("czy_invite=true") ? function(e) {
            try {
                const t = new URL(e),
                    s = {};
                return t.searchParams.forEach((e, t) => {
                        s[t] = e
                    }), delete s.czy_invite, delete s.utm_source,
                    function(e) {
                        const {
                            [V]: t, ...s
                        } = e;
                        if ("string" != typeof t) return e;
                        const n = {};
                        return new URLSearchParams(t).forEach((e, t) => {
                            n[t] = e
                        }), { ...n,
                            ...s
                        }
                    }(s)
            } catch (e) {
                return console.error("Failed to parse invite URL, returning {} params", e), {}
            }
        }(window.location.href) : null
    }
    class X {
        constructor(e) {
            var t, s;
            this.sdk = e, this.getMemory = null, "function" == typeof(null === (t = window.unityGameInstance) || void 0 === t ? void 0 : t.GetMetricsInfo) && (this.getMemory = () => window.unityGameInstance.GetMetricsInfo().usedWASMHeapSize), "function" == typeof(null === (s = window.unityGameInstance) || void 0 === s ? void 0 : s.GetMemoryInfo) && (this.getMemory = () => window.unityGameInstance.GetMemoryInfo().usedWASMHeapSize), I(this.getMemory) && (this.track(this.getMemory), setInterval(() => {
                this.track(this.getMemory)
            }, 5e3))
        }
        track(e) {
            const t = e();
            this.sdk.postMessage({
                type: "qaPerformanceTrack",
                data: {
                    usedMemory: t
                }
            })
        }
    }
    const H = class {
            constructor(e, t, s) {
                var n, r, o, a, l;
                this.sdk = e, this.logger = new i("game"), this.settings = {
                    disableChat: !1,
                    muteAudio: !1
                }, this.isInstantJoin = window.location.search.includes("instantJoin=true"), this.isInstantMultiplayer = window.location.search.includes("instantJoin=true"), this.inviteParams = W(), this.loadStatsSent = !1, this.settingsChangeListeners = [], this.qualityChangeListeners = [], this.joinRoomListener = [], this.multiplayerRoomState = null, this.qaToolMemoryTracker = null, this.invitedByUserId = null, this.throttledHappyTime = C(() => {
                    this.logger.log("Requesting happytime"), this.sdk.postMessage({
                        type: "happytime"
                    })
                }, {
                    delayMs: 1e3,
                    methodName: "happytime"
                }), this.throttledGameplayStart = C(() => {
                    this.logger.log("Requesting gameplay start"), this.sdk.postMessage({
                        type: "gameplayStart"
                    })
                }, {
                    delayMs: 1e3,
                    methodName: "gameplayStart"
                }), this.throttledGameplayStop = C(() => {
                    this.logger.log("Requesting gameplay stop"), this.sdk.postMessage({
                        type: "gameplayStop"
                    })
                }, {
                    delayMs: 1e3,
                    methodName: "gameplayStop"
                }), this.throttledReportGameCompletedPercentage = C(e => {
                    this.logger.log(`Reporting game completed percentage: ${e}`), this.sdk.postMessage({
                        type: "reportGameCompletedPercentage",
                        data: {
                            percentage: e
                        }
                    })
                }, {
                    delayMs: 1e3,
                    methodName: "reportGameCompletedPercentage"
                }), this.throttledUpdateRoom = C(e => {
                    const {
                        roomId: t,
                        isJoinable: s,
                        inviteParams: n
                    } = e;
                    this.sdk.postMessage({
                        type: "updateMultiplayerRoomData",
                        data: {
                            roomId: t,
                            isJoinable: s,
                            inviteParams: n
                        }
                    })
                }, {
                    delayMs: 250,
                    methodName: "updateRoom",
                    throwIfThrottled: !0
                }), this.throttledLeftRoom = C(() => {
                    this.sdk.postMessage({
                        type: "leftMultiplayerRoom"
                    })
                }, {
                    delayMs: 250,
                    methodName: "leftRoom",
                    throwIfThrottled: !0
                }), this.link = t.gameLink, this.id = t.gameId, this.isOfflineMode = null !== (n = t.offlineGaming) && void 0 !== n && n, this.settings.disableChat = null !== (r = t.disableChat) && void 0 !== r && r, this.settings.muteAudio = null !== (o = t.muteAudio) && void 0 !== o && o, this.currentQuality = null !== (a = t.quality) && void 0 !== a ? a : "balanced", t.safeAreaInsets && _(t.safeAreaInsets), this.performanceTracker = new j(this.logger, e), t.isQaTool && new X(e), this.invitedByUserId = null !== (l = null == s ? void 0 : s.__dangerousUserId) && void 0 !== l ? l : null, this.applyBlueBorderFix()
            }
            happytime() {
                this.throttledHappyTime()
            }
            gameplayStart() {
                if (this.throttledGameplayStart(), this.performanceTracker.onGameplayStateChange(!0), !this.loadStatsSent) {
                    this.loadStatsSent = !0;
                    let e = [...window.performance.getEntriesByType("resource"), ...window.performance.getEntriesByType("navigation")].map(e => JSON.parse(JSON.stringify(e)));
                    e = function(e) {
                        const t = new Set,
                            s = [];
                        for (const n of e) {
                            const e = n.name;
                            t.has(e) || (t.add(e), s.push(n))
                        }
                        return s
                    }(e), this.sdk.postMessage({
                        type: "sdkGameLoadStats",
                        data: {
                            resources: e
                        }
                    })
                }
            }
            gameplayStop() {
                this.throttledGameplayStop(), this.performanceTracker.onGameplayStateChange(!1)
            }
            loadingStart() {
                this.logger.log("Requesting game loading start"), this.sdk.postMessage({
                    type: "sdkGameLoadingStart"
                })
            }
            loadingStop() {
                this.logger.log("Requesting game loading stop"), this.sdk.postMessage({
                    type: "sdkGameLoadingStop"
                })
            }
            reportGameCompletedPercentage(e) {
                B(e), this.throttledReportGameCompletedPercentage(e)
            }
            dailyEvent(e) {
                const t = G(e);
                this.logger.log("Reporting daily event", t), this.sdk.postMessage({
                    type: "dailyEvent",
                    data: {
                        dailyEvent: t
                    }
                })
            }
            getLaunchContext() {
                return O()
            }
            inviteLink(e) {
                this.logger.log("Requesting invite link");
                const t = Q({
                    gameLink: this.link,
                    invitedById: this.invitedByUserId,
                    params: e
                });
                return this.logger.log(`Invite link is ${t}`), this.sdk.postMessage({
                    type: "inviteUrl",
                    data: {
                        inviteUrl: t
                    }
                }), t
            }
            showInviteButton(e) {
                this.logger.log("Show invite button");
                const t = Q({
                    gameLink: this.link,
                    invitedById: this.invitedByUserId,
                    params: e
                });
                return this.logger.log(`Invite button link ${t}`), this.sdk.postMessage({
                    type: "showInviteButton",
                    data: {
                        inviteUrl: t
                    }
                }), t
            }
            hideInviteButton() {
                this.logger.log("Hide invite button"), this.sdk.postMessage({
                    type: "hideInviteButton"
                })
            }
            getInviteParam(e) {
                return new URLSearchParams(window.location.search).get(e)
            }
            addSettingsChangeListener(e) {
                this.settingsChangeListeners.push(e), this.sdk.postMessage({
                    type: "settingsChangeListenerChange",
                    data: {
                        count: this.settingsChangeListeners.length
                    }
                })
            }
            removeSettingsChangeListener(e) {
                this.settingsChangeListeners = this.settingsChangeListeners.filter(t => t !== e), this.sdk.postMessage({
                    type: "settingsChangeListenerChange",
                    data: {
                        count: this.settingsChangeListeners.length
                    }
                })
            }
            get quality() {
                return this.currentQuality
            }
            addQualityChangeListener(e) {
                this.qualityChangeListeners.push(e)
            }
            removeQualityChangeListener(e) {
                this.qualityChangeListeners = this.qualityChangeListeners.filter(t => t !== e)
            }
            addJoinRoomListener(e) {
                this.joinRoomListener.push(e), this.sdk.postMessage({
                    type: "onJoinRoomListenerChange",
                    data: {
                        count: this.joinRoomListener.length
                    }
                })
            }
            removeJoinRoomListener(e) {
                this.joinRoomListener = this.joinRoomListener.filter(t => t !== e), this.sdk.postMessage({
                    type: "onJoinRoomListenerChange",
                    data: {
                        count: this.joinRoomListener.length
                    }
                })
            }
            updateRoom(e) {
                var t, s, n, r, i, o, a, l, h;
                if (this.logger.log("Updating room with params:", e), null === this.multiplayerRoomState && void 0 === e.roomId) throw new q("invalidArguments", "roomId must be provided when calling updateRoom for the first time");
                if (e.isJoinable && void 0 === e.inviteParams) throw new q("invalidArguments", "inviteParams must be provided if isJoinable is true");
                if (void 0 !== e.inviteParams && ("object" != typeof e.inviteParams || null === e.inviteParams || Array.isArray(e.inviteParams))) throw new q("invalidArguments", "inviteParams must be an object if provided");
                const d = {
                    roomId: null !== (n = null !== (t = e.roomId) && void 0 !== t ? t : null === (s = this.multiplayerRoomState) || void 0 === s ? void 0 : s.roomId) && void 0 !== n ? n : "",
                    isJoinable: null !== (o = null !== (r = e.isJoinable) && void 0 !== r ? r : null === (i = this.multiplayerRoomState) || void 0 === i ? void 0 : i.isJoinable) && void 0 !== o && o,
                    inviteParams: null !== (h = null !== (a = e.inviteParams) && void 0 !== a ? a : null === (l = this.multiplayerRoomState) || void 0 === l ? void 0 : l.inviteParams) && void 0 !== h ? h : null
                };
                d.isJoinable || (d.inviteParams = null), this.multiplayerRoomState = d, this.throttledUpdateRoom(d)
            }
            leftRoom() {
                this.logger.log("Left room"), this.multiplayerRoomState = null, this.throttledLeftRoom()
            }
            setGameContext(e) {
                if (null !== e && ("object" != typeof e || Array.isArray(e))) throw new q("invalidArguments", "Context must be a JSON object or null");
                if (JSON.stringify(e).length > 1e3) throw new q("invalidArguments", "Context length must be less than 1000 characters when stringified");
                this.logger.verbose("Setting game context:", e), this.sdk.postMessage({
                    type: "setGameContext",
                    data: {
                        context: e
                    }
                })
            }
            clearGameContext() {
                this.logger.verbose("Clearing game context"), this.setGameContext(null)
            }
            handleEvent(e) {
                switch (e.type) {
                    case "userLoggedIn":
                        this.invitedByUserId = e.data.user.__dangerousUserId;
                        break;
                    case "focusStealAttempt":
                        this.restoreCanvasFocus();
                        break;
                    case "callJoinRoomListener":
                        const t = e.params;
                        this.logger.verbose("Calling join room listeners with params:", t), this.joinRoomListener.forEach(e => {
                            try {
                                e(t)
                            } catch (e) {
                                this.logger.error(`Error while calling join room listener: ${e.message}`)
                            }
                        });
                        break;
                    case "audioChanged":
                        const s = e.muteAudio;
                        if (this.settings.muteAudio === s) return;
                        this.settings.muteAudio = s, this.settingsChangeListeners.forEach(e => {
                            try {
                                e(this.settings)
                            } catch (e) {
                                this.logger.error(`Error while calling settings changed listener: ${e.message}`)
                            }
                        });
                        break;
                    case "qualityChanged":
                        const n = e.quality;
                        if (this.currentQuality === n) return;
                        this.currentQuality = n, this.logger.verbose(`Quality changed to: ${n}`), this.qualityChangeListeners.forEach(e => {
                            try {
                                e(n)
                            } catch (e) {
                                this.logger.error(`Error while calling quality changed listener: ${e.message}`)
                            }
                        });
                        break;
                    case "safeAreaInsetsForSdk":
                        _(e.insets);
                        break;
                    case "requestGameScreenshot":
                        this.getGameScreenshot().then(e => {
                            this.sdk.postMessage({
                                type: "requestGameScreenshotResponse",
                                data: {
                                    screenshot: e
                                }
                            })
                        })
                }
            }
            getGameCanvas() {
                const e = document.getElementsByTagName("canvas");
                return 1 !== e.length ? (this.logger.log(`There are ${e.length} canvases, cannot determine game canvas`), null) : e[0]
            }
            getGameScreenshot() {
                return new Promise(e => {
                    requestAnimationFrame(() => {
                        try {
                            const t = this.getGameCanvas();
                            if (!I(t)) return void e(null);
                            e(t.toDataURL())
                        } catch {
                            this.logger.error("Failed to get game screenshot"), e(null)
                        }
                    })
                })
            }
            restoreCanvasFocus() {
                try {
                    const e = this.getGameCanvas();
                    if (!I(e)) return;
                    this.logger.log("Restore focus to canvas"), e.tabIndex = 1, e.focus()
                } catch {
                    this.logger.error("Failed to restore canvas focus")
                }
            }
            applyBlueBorderFix() {
                const e = this.getGameCanvas();
                I(e) && "none" !== e.style.outline && (e.style.outline = "none")
            }
        },
        Z = new i("ad");
    class K extends h {
        constructor(e, t) {
            n && Z.error(`[AdError] Code: ${e} - Message: ${t}`), super(e, t), this.code = e, this.message = t
        }
    }
    const Y = {
            adFinished: () => {},
            adError: () => {},
            adStarted: () => {}
        },
        ee = class {
            constructor(e, t) {
                this.sdk = e, this.initInfo = t, this.adCallbacks = Y, this.requestInProgress = !1, this.adblockDetectionResolvers = [], this.logger = new i("ad"), this.adPlaying = !1, this.adblockPopupListeners = [], this.adblockDetectionTimeout = window.setTimeout(() => {
                    this.logger.log("Adblock timeout executed since there wasn't an adblock event in 5000ms"), this.setAdblockDetectionResult(!1)
                }, 5e3)
            }
            prefetchAd(e) {
                console.warn(...s, "prefetchAd is no longer supported and should not be called.")
            }
            async requestAd(e, t) {
                this.adCallbacks = {
                    adFinished: (null == t ? void 0 : t.adFinished) || Y.adFinished,
                    adError: (null == t ? void 0 : t.adError) || (null == t ? void 0 : t.adFinished) || Y.adFinished,
                    adStarted: (null == t ? void 0 : t.adStarted) || Y.adStarted
                };
                const s = S(this.initInfo, "rewarded" === e ? "rewarded" : "midroll");
                if (!s.allowed) return Qe(this.adCallbacks.adError)(new K("adsDisabled", s.reason));
                if (this.logger.log(`Requesting ${e} ad`), this.requestInProgress) {
                    this.logger.log("Ad already requested");
                    const e = new K("other", "An ad request is already in progress");
                    return Qe(this.adCallbacks.adError)(e)
                }
                this.requestInProgress = !0, this.sdk.postMessage({
                    type: "requestAd",
                    data: {
                        adType: e
                    }
                })
            }
            async hasAdblock() {
                return void 0 !== this.adblockDetectionResult ? this.adblockDetectionResult : (this.sdk.postMessage({
                    type: "hasAdblock"
                }), this.logger.log("Requesting adblock status"), new Promise(e => {
                    this.adblockDetectionResolvers.push(e)
                }))
            }
            handleEvent(e) {
                var t, s;
                switch (e.type) {
                    case "adblockDetectionExecuted":
                        return this.handleAdBlockDetectionExecutedEvent(e);
                    case "adError":
                        this.requestInProgress = !1;
                        const n = new K((null === (t = e.errorData) || void 0 === t ? void 0 : t.reason) || "other", (null === (s = e.errorData) || void 0 === s ? void 0 : s.message) || "Unknown message");
                        return this.adPlaying = !1, Qe(this.adCallbacks.adError)(n);
                    case "adFinished":
                        return this.adPlaying = !1, this.requestInProgress = !1, Qe(this.adCallbacks.adFinished)();
                    case "adStarted":
                        return this.adPlaying = !0, this.sdk.banner.activeBannersCount > 0 && this.sdk.banner.clearAllBanners(), Qe(this.adCallbacks.adStarted)();
                    case "adblockPopupShowed":
                        return void this.callAdblockPopupListeners("open")
                }
            }
            handleAdBlockDetectionExecutedEvent(e) {
                const {
                    hasAdblock: t
                } = e, s = !!t;
                if (void 0 !== this.adblockDetectionResult) return this.logger.log(`Received update for adblock state: (${s}).`), void(this.adblockDetectionResult = s);
                this.setAdblockDetectionResult(s), clearTimeout(this.adblockDetectionTimeout)
            }
            setAdblockDetectionResult(e) {
                this.adblockDetectionResult = e, this.adblockDetectionResolvers.forEach(t => t(e)), this.adblockDetectionResolvers = []
            }
            get isAdPlaying() {
                return this.adPlaying
            }
            addAdblockPopupListener(e) {
                this.adblockPopupListeners.push(e)
            }
            removeAdblockPopupListener(e) {
                this.adblockPopupListeners = this.adblockPopupListeners.filter(t => t !== e)
            }
            callAdblockPopupListeners(e) {
                this.adblockPopupListeners.forEach(t => {
                    try {
                        t(e)
                    } catch (e) {
                        console.error(e)
                    }
                })
            }
        },
        te = new i("user");
    class se extends h {
        constructor(e, t) {
            n && te.error(`[UserError] Code: ${e} - Message: ${t}`), super(e, t), this.code = e, this.message = t
        }
    }

    function ne(e) {
        return "token" in e
    }

    function re(e) {
        return "token" in e
    }
    const ie = class {
            constructor(e, t, s, n) {
                this.sdk = e, this._systemInfo = t, this._userAccountAvailable = s, this.user = null, this.authDeferredPromise = null, this.accountLinkDeferredPromise = null, this.authListeners = [], this.userTokenResolvers = [], this.userTokenRequestInProgress = !1, this.xsollaUserTokenRequestInProgress = !1, this.xsollaUserTokenResolvers = [], this.listFriendsDeferredPromise = null, this.addFriendsDeferredPromise = null, this.nudgeFriendDeferredPromise = null, this.logger = new i("user"), this.throttledListFriends = C(e => {
                    if (this.logger.log("Requesting friends list", e), !I(this.user)) throw new se("userNotAuthenticated", "The user is not signed in");
                    if (I(this.listFriendsDeferredPromise)) throw new se("requestInProgress", "A friends list request is already in progress");
                    return new Promise((t, s) => {
                        this.listFriendsDeferredPromise = {
                            resolve: t,
                            reject: s
                        }, this.sdk.postMessage({
                            type: "requestFriendsList",
                            data: {
                                options: e
                            }
                        })
                    })
                }, {
                    delayMs: 250,
                    methodName: "listFriends",
                    throwIfThrottled: !0
                }), this.throttledAddFriends = C(e => {
                    if (this.logger.log("Requesting add friends overlay", e), I(this.addFriendsDeferredPromise)) throw new se("requestInProgress", "An add friends request is already in progress");
                    return new Promise((t, s) => {
                        this.addFriendsDeferredPromise = {
                            resolve: t,
                            reject: s
                        }, this.sdk.postMessage({
                            type: "requestAddFriends",
                            data: {
                                userId: e
                            }
                        })
                    })
                }, {
                    delayMs: 250,
                    methodName: "addFriends",
                    throwIfThrottled: !0
                }), this.throttledNudgeFriend = C(e => {
                    if (this.logger.log("Requesting nudge friend", e), "string" != typeof e || "" === e.trim()) throw new se("invalidArgument", "userId must be a non-empty string");
                    if (!I(this.user)) throw new se("userNotAuthenticated", "The user is not signed in");
                    if (I(this.nudgeFriendDeferredPromise)) throw new se("requestInProgress", "A nudge friend request is already in progress");
                    return new Promise((t, s) => {
                        this.nudgeFriendDeferredPromise = {
                            resolve: t,
                            reject: s
                        }, this.sdk.postMessage({
                            type: "requestNudgeFriend",
                            data: {
                                userId: e
                            }
                        })
                    })
                }, {
                    delayMs: 250,
                    methodName: "nudgeFriend",
                    throwIfThrottled: !0
                }), this.user = n
            }
            get isUserAccountAvailable() {
                return this.sdk.postMessage({
                    type: "isUserAccountAvailable"
                }), !!this._userAccountAvailable
            }
            get systemInfo() {
                return this.sdk.postMessage({
                    type: "getSystemInfo"
                }), this._systemInfo
            }
            async showAuthPrompt() {
                if (this.logger.log("Requesting auth prompt"), this.authDeferredPromise) throw new se("showAuthPromptInProgress", "The auth prompt is already opened");
                if (this.user) throw new se("userAlreadySignedIn", "The user is already signed in");
                return new Promise((e, t) => {
                    this.authDeferredPromise = {
                        resolve: e,
                        reject: t
                    }, this.sdk.postMessage({
                        type: "showAuthPrompt"
                    })
                })
            }
            handleAuthPromptResponse(e) {
                if (this.logger.log("Received auth prompt response", e), "user" in e) {
                    const {
                        user: t
                    } = e;
                    this.user = null != t ? t : null, this.authDeferredPromise && this.authDeferredPromise.resolve(this.user)
                } else {
                    const {
                        error: t
                    } = e;
                    this.authDeferredPromise && this.authDeferredPromise.reject(new se(t.code, t.message))
                }
                this.authDeferredPromise = null
            }
            async showAccountLinkPrompt() {
                if (this.logger.log("Requesting link account prompt"), this.accountLinkDeferredPromise) throw new se("showAccountLinkPromptInProgress", "The account link prompt is already displayed");
                if (!this.user) throw new se("userNotAuthenticated", "The user is not signed in");
                return new Promise(async (e, t) => {
                    this.accountLinkDeferredPromise = {
                        resolve: e,
                        reject: t
                    }, this.sdk.postMessage({
                        type: "showAccountLinkPrompt"
                    })
                })
            }
            handleAccountLinkPromptResponse(e) {
                this.logger.log("Received account link prompt response", e);
                const {
                    response: t
                } = e.data;
                this.accountLinkDeferredPromise && this.accountLinkDeferredPromise.resolve({
                    response: t
                }), this.accountLinkDeferredPromise = null
            }
            async getUser() {
                return this.logger.log("Requesting user object"), this.sdk.postMessage({
                    type: "getUser"
                }), this.user
            }
            async getUserToken(e) {
                this.userTokenSigningKeyType = null == e ? void 0 : e.signingKeyType, this.logger.log("Requesting user token"), this.tokenExpiresAtMs && this.tokenExpiresAtMs < Date.now() && (this.logger.log("User token expired, clean it so it is requested again"), this.userToken = null, this.tokenExpiresAtMs = null), this.tokenExpiresAtMs && !this.userTokenRequestInProgress && this.tokenExpiresAtMs - 3e4 < Date.now() && (this.logger.log("User token expires soon, request new one in background"), this.requestNewUserToken());
                let t = this.userToken;
                if (I(t) && ne(t)) return this.logger.log("Returning cached user token"), t.token;
                if (this.userTokenRequestInProgress ? this.logger.log("User token request to portal in progress") : (this.logger.log("No user token present in the SDK, request one"), this.requestNewUserToken()), await new Promise(e => {
                        this.userTokenResolvers.push(async () => {
                            e()
                        })
                    }), t = this.userToken, !I(t)) throw this.logger.error("User token missing after portal request finished"), new se("unexpectedError", "User token missing after portal request finished");
                if ("error" in t) throw new se(t.error.code, t.error.message);
                if (!t.token) throw this.logger.error("User token missing, even though there isn't any error"), new se("unexpectedError", "User token missing, even though there isn't any error");
                return t.token
            }
            handleUserTokenResponse(e) {
                this.logger.log("Received token response from portal", e), this.userToken = e, this.userTokenRequestInProgress = !1, ne(e) && (this.tokenExpiresAtMs = Date.now() + 1e3 * e.expiresIn), this.userTokenResolvers.forEach(e => e()), this.userTokenResolvers = []
            }
            requestNewUserToken() {
                this.logger.log("Requesting user token from portal"), this.sdk.postMessage({
                    type: "requestUserToken",
                    data: {
                        signingKeyType: this.userTokenSigningKeyType
                    }
                }), this.userTokenRequestInProgress = !0
            }
            async getXsollaUserToken() {
                this.logger.log("Requesting Xsolla user token"), this.xsollaUserTokenExpiresAtMs && this.xsollaUserTokenExpiresAtMs < Date.now() && (this.logger.log("Xsolla user token expired, clean it so it is requested again"), this.xsollaUserToken = null, this.xsollaUserTokenExpiresAtMs = null), this.xsollaUserTokenExpiresAtMs && !this.xsollaUserTokenRequestInProgress && this.xsollaUserTokenExpiresAtMs - 3e4 < Date.now() && (this.logger.log("Xsolla user token expires soon, request new one in background"), this.requestNewXsollaUserToken());
                let e = this.xsollaUserToken;
                if (I(e) && re(e)) return this.logger.log("Returning cached Xsolla user token"), e.token;
                if (this.xsollaUserTokenRequestInProgress ? this.logger.log("Xsolla user token request to portal in progress") : (this.logger.log("No Xsolla user token present in the SDK, request one"), this.requestNewXsollaUserToken()), await new Promise(e => {
                        this.xsollaUserTokenResolvers.push(async () => {
                            e()
                        })
                    }), e = this.xsollaUserToken, !I(e)) throw this.logger.error("Xsolla user token response missing after portal request finished"), new se("unexpectedError", "Xsolla user token missing after portal request finished");
                if ("error" in e) throw new se(e.error.code, e.error.message);
                if (!e.token) throw this.logger.error("Xsolla user token missing, even though there isn't any error"), new se("unexpectedError", "Xsolla user token missing, even though there isn't any error");
                return e.token
            }
            handleXsollaUserTokenResponse(e) {
                this.logger.log("Received Xsolla user token response from portal", e), this.xsollaUserToken = e, this.xsollaUserTokenRequestInProgress = !1, re(e) && (this.xsollaUserTokenExpiresAtMs = Date.now() + 1e3 * e.expiresIn), this.xsollaUserTokenResolvers.forEach(e => e()), this.xsollaUserTokenResolvers = []
            }
            requestNewXsollaUserToken() {
                this.logger.log("Requesting Xsolla user token from portal"), this.sdk.postMessage({
                    type: "requestXsollaUserToken"
                }), this.xsollaUserTokenRequestInProgress = !0
            }
            addScore(e) {
                this.logger.warn("addScore is no longer supported.")
            }
            addScoreEncrypted(e, t) {
                this.logger.warn("addScoreEncrypted is no longer supported.")
            }
            submitScore(e) {
                this.logger.log("Submitting score.", e), this.sdk.postMessage({
                    type: "submitScore",
                    data: {
                        encryptedScore: e.encryptedScore,
                        requestId: this.generateRequestId(),
                        score: e.score
                    }
                })
            }
            async listFriends(e) {
                return this.throttledListFriends(e)
            }
            handleListFriendsResponse(e) {
                this.logger.log("Received friends list response", e);
                const t = this.listFriendsDeferredPromise;
                t ? (function(e) {
                    return "error" in e
                }(e) ? t.reject(new se(e.error.code, e.error.message)) : t.resolve(e.friendsPage), this.listFriendsDeferredPromise = null) : this.logger.warn("Received friends list response but no request is in progress")
            }
            async addFriends(e) {
                return this.throttledAddFriends(e)
            }
            handleAddFriendsResponse(e) {
                this.logger.log("Received add friends response", e);
                const t = this.addFriendsDeferredPromise;
                t ? (t.resolve(e.outcome), this.addFriendsDeferredPromise = null) : this.logger.warn("Received add friends response but no request is in progress")
            }
            async nudgeFriend(e) {
                return this.throttledNudgeFriend(e)
            }
            handleNudgeFriendResponse(e) {
                this.logger.log("Received nudge friend response", e);
                const t = this.nudgeFriendDeferredPromise;
                t ? (function(e) {
                    return "error" in e
                }(e) ? t.reject(new se(e.error.code, e.error.message)) : t.resolve(e.outcome), this.nudgeFriendDeferredPromise = null) : this.logger.warn("Received nudge friend response but no request is in progress")
            }
            generateRequestId() {
                return "undefined" != typeof crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).substring(2)
            }
            handleEvent(e) {
                switch (e.type) {
                    case "showAuthPromptResponse":
                        this.handleAuthPromptResponse(e);
                        break;
                    case "linkAccountResponse":
                        this.handleAccountLinkPromptResponse(e);
                        break;
                    case "userLoggedIn":
                        this.handleUserLoggedIn(e);
                        break;
                    case "requestUserTokenResponse":
                        this.handleUserTokenResponse(e);
                        break;
                    case "requestXsollaUserTokenResponse":
                        this.handleXsollaUserTokenResponse(e);
                        break;
                    case "requestFriendsListResponse":
                        this.handleListFriendsResponse(e);
                        break;
                    case "requestAddFriendsResponse":
                        this.handleAddFriendsResponse(e);
                        break;
                    case "requestNudgeFriendResponse":
                        this.handleNudgeFriendResponse(e)
                }
            }
            addAuthListener(e) {
                this.sdk.postMessage({
                    type: "addAuthListener"
                }), this.authListeners.push(e)
            }
            removeAuthListener(e) {
                this.sdk.postMessage({
                    type: "removeAuthListener"
                }), this.authListeners = this.authListeners.filter(t => t !== e)
            }
            handleUserLoggedIn(e) {
                var t;
                this.user = null !== (t = e.data.user) && void 0 !== t ? t : null, this.callAuthChangeListeners()
            }
            callAuthChangeListeners() {
                this.authListeners.forEach(e => this.callAuthChangeListener(e))
            }
            callAuthChangeListener(e) {
                try {
                    e(this.user)
                } catch (e) {
                    console.error(e)
                }
            }
        },
        oe = new i("data");
    class ae extends h {
        constructor(e, t) {
            n && oe.error(`[DataError] Code: ${e} - Message: ${t}`), super(e, t), this.code = e, this.message = t
        }
    }
    const le = 1048576;
    class he {
        constructor() {
            this.data = {}, this.clear()
        }
        setItem(e, t) {
            this.data[e] = String(t)
        }
        getItem(e) {
            return this.data.hasOwnProperty(e) ? this.data[e] : void 0
        }
        removeItem(e) {
            delete this.data[e]
        }
        clear() {
            this.data = {}
        }
    }
    class de {
        constructor() {
            this.logger = new i("none"), this.storage = this.getAvailableStorage()
        }
        static get Instance() {
            return this._instance ? this._instance : this._instance = new this
        }
        getItem(e) {
            return this.storage.getItem(e)
        }
        setItem(e, t) {
            this.storage.setItem(e, t)
        }
        removeItem(e) {
            this.storage.removeItem(e)
        }
        clear() {
            return this.storage.clear()
        }
        isFunctioningStorage(e) {
            try {
                const t = `__SafeLocalStorage__${Date.now()}`,
                    s = "test";
                return e.setItem(t, s), e.getItem(t) === s && (window.localStorage.removeItem(t), !0)
            } catch {
                return !1
            }
        }
        getAvailableStorage() {
            try {
                return this.hasWorkingLocalStorage() ? (this.logger.verbose("[SafeLocalStorage] using localStorage"), window.localStorage) : this.hasWorkingSessionStorage() ? (this.logger.verbose("[SafeLocalStorage] fallback to sessionStorage"), window.sessionStorage) : (this.logger.verbose("[SafeLocalStorage] fallback to InMemoryStorage"), new he)
            } catch {
                return this.logger.verbose("[SafeLocalStorage] fallback to InMemoryStorage"), new he
            }
        }
        hasWorkingLocalStorage() {
            try {
                if (!window.hasOwnProperty("localStorage")) return !1;
                const {
                    localStorage: e
                } = window;
                return this.isFunctioningStorage(e)
            } catch {
                return !1
            }
        }
        hasWorkingSessionStorage() {
            try {
                if (!window.hasOwnProperty("sessionStorage")) return !1;
                const {
                    sessionStorage: e
                } = window;
                return this.isFunctioningStorage(e)
            } catch {
                return !1
            }
        }
    }
    class ce {
        constructor(e, t) {
            this.logger = new i("data"), this.data = e, this.lsKey = ue(t), this.logger.persist.log("Local data handler initialized"), this.logger.verbose("With this initial data: ", e)
        }
        clear() {
            this.data = {}, this.saveData()
        }
        getItem(e) {
            return this.data[e] || null
        }
        removeItem(e) {
            delete this.data[e], this.saveData()
        }
        setItem(e, t) {
            this.data[e] = `${t}`, this.saveData()
        }
        saveData() {
            ye(JSON.stringify(this.data));
            const e = {
                data: this.data,
                metadata: {
                    date: new Date
                }
            };
            de.Instance.setItem(this.lsKey, JSON.stringify(e))
        }
    }

    function ue(e) {
        return `SDK_DATA_${e}`
    }
    const ge = new i("data");

    function me(e, t, s) {
        try {
            const t = de.Instance.getItem(e);
            return t && JSON.parse(t).data || {}
        } catch (n) {
            return ge.persist.error(`Failed to retrieve ${s} (${e}), initializing empty data. Error ${n}`), Xe(t, "data"), {}
        }
    }

    function pe(e) {
        return me(ue(e), "load-ls-fail", "local game data")
    }

    function we(e) {
        return me(be(e), "load-cached-cloud-fail", "cached cloud game data from localStorage")
    }

    function ye(e) {
        const t = (new TextEncoder).encode(e);
        if (t.length > le) throw ge.persist.error("Game data when converted to JSON cannot exceed 1048576 bytes. Data was not saved"), Xe("size-exceeded", "data", {
            maxSize: le,
            dataSize: t.length
        }), new ae("dataLimitExcedeed", "Game data when converted to a JSON string cannot exceed 1048576 bytes. Data was not saved");
        t.length > 943718.4 && ge.warn("You are approaching 1048576 bytes data limit.")
    }
    async function fe(e, t) {
        return t.dataModule.isEnabled ? e || t.offlineGaming ? new Promise(e => {
            let s;
            const n = async r => {
                if ("sdkGameDataResponseNew" === r.data.type) {
                    ge.verbose("Received game data from GF", r.data), window.removeEventListener("message", n, !1), void 0 !== s && window.clearTimeout(s);
                    const i = r.data.data;
                    if ("loaded" === i.status) i.hasData ? e({
                        data: i.data,
                        handler: "cloud"
                    }) : (() => {
                        const s = ue(t.gameId);
                        if (de.Instance.getItem(s)) {
                            ge.persist.verbose("Cloud data missing but has local data, initialize with local data");
                            const s = pe(t.gameId);
                            _e.postMessage({
                                type: "saveSdkGameData",
                                data: {
                                    jsonData: JSON.stringify(s)
                                }
                            }, "*"), e({
                                data: s,
                                handler: "cloud"
                            })
                        } else ge.persist.verbose("Cloud data and local data missing, initialize with empty data"), e({
                            data: {},
                            handler: "cloud"
                        })
                    })();
                    else {
                        ge.persist.error("GF failed to load cloud game data, will load cached cloud data.", {
                            status: i.status
                        }), Xe("gf-data-load-fail", "data");
                        const s = we(t.gameId);
                        ge.persist.log("Loaded cached cloud data, data will not be synced in this session", {
                            keyCount: Object.keys(s).length
                        }), e({
                            data: s,
                            handler: "cloud",
                            doNotSync: !0
                        })
                    }
                }
            };
            ge.verbose("Requesting game data from GF"), window.addEventListener("message", n, !1), _e.postMessage({
                type: "requestSdkGameDataNew"
            }, "*"), s = window.setTimeout(() => {
                ge.persist.error("Did not get game data reply from GF in 10000ms. Using cached cloud data if present. Disable data sync for this session."), Xe("gf-response-timeout", "data", {
                    timeoutMs: 1e4
                }), window.removeEventListener("message", n, !1);
                const s = we(t.gameId);
                e({
                    data: s,
                    handler: "cloud",
                    doNotSync: !0
                })
            }, 1e4)
        }) : (ge.persist.verbose("User signed out, loading data from LocalStorage"), {
            data: pe(t.gameId),
            handler: "local"
        }) : {
            handler: "disabled"
        }
    }
    class ve {
        constructor(e, t, s) {
            this.sdk = e, this.doNotSync = t, this.data = s, this.logger = new i("data"), this.cacheLsKey = be(e.game.id), this.logger.persist.log("Cloud data handler initialized. " + (this.doNotSync ? "Data will not be synced due to failed cloud load." : "")), this.logger.verbose("With this initial data: ", s)
        }
        clear() {
            this.data = {}, this.saveData()
        }
        getItem(e) {
            return this.data[e] || null
        }
        removeItem(e) {
            delete this.data[e], this.saveData()
        }
        setItem(e, t) {
            this.data[e] = `${t}`, this.saveData()
        }
        saveData() {
            const e = JSON.stringify(this.data);
            ye(e), this.doNotSync || this.sdk.postMessage({
                type: "saveSdkGameData",
                data: {
                    jsonData: e
                }
            });
            const t = {
                data: this.data,
                metadata: {
                    date: new Date
                }
            };
            de.Instance.setItem(this.cacheLsKey, JSON.stringify(t))
        }
    }

    function be(e) {
        return `SDK_DATA_CLOUD_CACHE_${e}`
    }
    const ke = "https://cza.crazygames.com/event";
    class Ie {
        constructor() {
            this.eventQueue = [], this.initTimedOut = !1
        }
        static getInstance() {
            return Ie.instance || (Ie.instance = new Ie), Ie.instance
        }
        init(e, t) {
            this.initInfo = t, this.sdk = e, this.sdk.postMessage({
                type: "requestAnalyticsInfoFromSDK"
            }), this.initTimeoutId = window.setTimeout(() => {
                this.instanceId || (this.initTimedOut = !0, this.eventQueue = [])
            }, 1e4)
        }
        sendDebugEvent(e, t, s) {
            if (this.initTimedOut) return;
            const n = {
                type: "debug",
                name: e,
                data: JSON.stringify(t)
            };
            this.sendEvent(n, s)
        }
        handleEvent(e) {
            "analyticsInfoResponseFromGF" === e.type && (this.initTimeoutId && window.clearTimeout(this.initTimeoutId), this.instanceId = e.instanceId, this.eventQueue.forEach(e => this.sendEvent(e.event, e.filter)), this.eventQueue = [])
        }
        sendEvent(e, t) {
            this.initInfo ? this.safeIdleCallback(() => {
                var s, n;
                if (this.initInfo.isQaTool) return;
                if (t && !t(this.initInfo)) return;
                const r = new Date,
                    i = r.getTime(),
                    o = r.getTimezoneOffset(),
                    a = { ...e,
                        time: i,
                        timezoneOffset: o,
                        version: "3.6.0",
                        source: "sdk",
                        type: "debug",
                        sampling: 1,
                        userId: "",
                        page: "",
                        instanceId: this.instanceId,
                        gameId: null === (s = this.initInfo) || void 0 === s ? void 0 : s.gameId,
                        buildId: null === (n = this.initInfo) || void 0 === n ? void 0 : n.buildId
                    },
                    l = function(e) {
                        const t = JSON.parse(JSON.stringify(e)),
                            s = Object.keys(t).filter(e => void 0 !== t[e] && null !== t[e]).sort();
                        let n = "";
                        for (const e of s) n += e + "_" + JSON.stringify(t[e]) + "_";
                        return function(e) {
                            let t = 0;
                            if (0 === e.length) return t;
                            for (let s = 0; s < e.length; s++) t = (t << 5) - t + e.charCodeAt(s), t |= 0;
                            return t
                        }(n)
                    }(a);
                a.__i = l, this.sendData(a)
            }) : this.eventQueue.push({
                event: e,
                filter: t
            })
        }
        async sendData(e) {
            const t = e,
                s = async () => {
                    await window.fetch(ke, {
                        method: "post",
                        body: JSON.stringify(t),
                        headers: {
                            "Content-Type": "text/plain"
                        }
                    })
                };
            if (window.navigator) {
                const e = {
                        type: "text/plain"
                    },
                    n = new Blob([JSON.stringify(t)], e);
                if (window.navigator.sendBeacon(ke, n)) return Promise.resolve();
                await s()
            } else await s()
        }
        safeIdleCallback(e) {
            window.requestIdleCallback ? window.requestIdleCallback(e, {
                timeout: 2e3
            }) : window.setTimeout(e, 0)
        }
    }
    const Se = Ie;
    class Ae {
        constructor() {
            this.errorCode = "dataModuleDisabled", this.errorMessage = "The data module is disabled. To enable it, please indicate on the Developer Portal that your game is using it."
        }
        clear() {
            throw new h(this.errorCode, this.errorMessage)
        }
        getItem(e) {
            throw new h(this.errorCode, this.errorMessage)
        }
        removeItem(e) {
            throw new h(this.errorCode, this.errorMessage)
        }
        setItem(e, t) {
            throw new h(this.errorCode, this.errorMessage)
        }
    }
    const Re = class {
            constructor(e, t) {
                if (this.sdk = e, this.logger = new i("data"), this.alreadySent = [], "local" === t.handler) this.dataHandler = new ce(t.data, e.game.id);
                else if ("cloud" === t.handler) this.dataHandler = new ve(e, !!t.doNotSync, t.data);
                else {
                    if ("disabled" !== t.handler) throw new h("unexpectedError", `Unknown data handler ${t.handler}`);
                    this.dataHandler = new Ae
                }
            }
            clear() {
                this.dataHandler.clear(), this.logger.persist.log("Clear data"), this.sdk.postMessage({
                    type: "useDataModule",
                    data: {
                        action: "clear"
                    }
                })
            }
            getItem(e) {
                const t = this.dataHandler.getItem(e);
                return this.logger.log(`Get "${e}", returning ${t}`), this.debugEvent("getItem", e), this.sdk.postMessage({
                    type: "useDataModule",
                    data: {
                        action: "getItem"
                    }
                }), t
            }
            removeItem(e) {
                this.dataHandler.removeItem(e), this.logger.log(`Remove "${e}"`), this.sdk.postMessage({
                    type: "useDataModule",
                    data: {
                        action: "removeItem"
                    }
                }), this.debugEvent("removeItem", e)
            }
            setItem(e, t) {
                this.dataHandler.setItem(e, t), this.logger.log(`Set "${e}" = ${t}`), this.sdk.postMessage({
                    type: "useDataModule",
                    data: {
                        action: "setItem"
                    }
                }), this.debugEvent("setItem", e, t)
            }
            syncUnityGameData() {
                this.logger.log("Requesting to sync unity game data"), this.sdk.postMessage({
                    type: "syncUnityGameData"
                })
            }
            debugEvent(e, t, s) {
                const n = `${e}-${t}`;
                this.alreadySent.includes(n) || (this.alreadySent.push(n), Se.getInstance().sendDebugEvent("dataEventWithoutSDKPS", {
                    method: e,
                    key: t,
                    value: s
                }, e => !!e.dataModule && "sdk" !== e.dataModule.apsStorageType))
            }
        },
        Pe = ["xsolla"];
    class Me extends h {
        constructor(e, t) {
            super(e, t), this.code = e, this.message = t
        }
    }
    const Ee = class {
        constructor(e) {
            this.sdk = e, this.logger = new i("analytics")
        }
        trackOrder(e, t) {
            if (!We(t)) throw new Me("invalidArgument", "Order must be a JSON object.");
            if (!Pe.includes(e)) throw new Me("invalidArgument", `Unsupported payment provider. Supported providers: ${Pe.join(",")}`);
            this.logger.log(`Track "${e}" order`, t), this.sdk.postMessage({
                type: "analyticsTrackIAPOrder",
                data: {
                    paymentProvider: e,
                    orderJson: JSON.stringify(t)
                }
            })
        }
    };
    class Le extends h {
        constructor(e, t) {
            super(e, t), this.code = e, this.message = t
        }
    }

    function Ce(e) {
        var t, s;
        const n = null !== (t = null == e ? void 0 : e.limit) && void 0 !== t ? t : 50,
            r = null !== (s = null == e ? void 0 : e.offset) && void 0 !== s ? s : 0;
        if (!Number.isInteger(n) || n < 1 || n > 50) throw new Le("invalidArgument", "The limit must be a whole number between 1 and 50.");
        if (!Number.isInteger(r) || r < 0) throw new Le("invalidArgument", "The offset must be a whole number of 0 or more.");
        return {
            limit: n,
            offset: r
        }
    }
    const Te = "https://store.xsolla.com/api/v2/project",
        qe = class {
            constructor(e, t, s) {
                this.sdk = e, this.xsollaProjectId = t, this.isAvailable = s, this.logger = new i("store"), this.sandbox = !1, this.purchaseInProgress = !1, this.pendingPurchase = null, this.lastCatalogRequestId = 0, this.pendingCatalogRequest = null
            }
            handleEvent(e) {
                switch (e.type) {
                    case "storeBuyItemResponse":
                        this.handleBuyItemResponse(e);
                        break;
                    case "storeGetCatalogItemsResponse":
                        this.handleGetCatalogItemsResponse(e)
                }
            }
            handleBuyItemResponse(e) {
                const t = this.pendingPurchase;
                if (t) return t.itemId !== e.itemId ? (this.logger.error(`Received a store response for ${e.itemId} while buying ${t.itemId}`), void t.settle({
                    type: "storeBuyItemResponse",
                    itemId: t.itemId,
                    error: {
                        code: "unexpectedError",
                        message: "The store responded about a different item."
                    }
                })) : void t.settle(e);
                this.logger.log(`Ignoring a store response for ${e.itemId}, no purchase is in progress`)
            }
            handleGetCatalogItemsResponse(e) {
                const t = this.pendingCatalogRequest;
                t && t.requestId === e.requestId ? t.settle(e) : this.logger.log(`Ignoring a catalog response for request ${e.requestId}, it is no longer awaited`)
            }
            setSandbox(e) {
                this.logger.log(`Setting sandbox mode to ${e}`), this.sandbox = e
            }
            async buyItem(e) {
                if (this.purchaseInProgress) throw new Le("purchaseInProgress", "A purchase is already in progress.");
                this.purchaseInProgress = !0;
                try {
                    return await this.performPurchase(e)
                } finally {
                    this.purchaseInProgress = !1, this.pendingPurchase = null
                }
            }
            async getCatalogItems(e) {
                if (I(this.pendingCatalogRequest)) throw new Le("requestInProgress", "A catalog request is already in progress.");
                const t = this.xsollaProjectId;
                if (!I(t)) throw new Le("unexpectedError", "Xsolla project ID is missing. Please contact Technical Support team.");
                const {
                    limit: s,
                    offset: n
                } = Ce(e), r = ++this.lastCatalogRequestId;
                return this.logger.log(`Requesting catalog items, limit ${s}, offset ${n}`), new Promise((e, i) => {
                    const o = setTimeout(() => {
                            this.logger.error("No catalog response after 10000ms, abandoning the request"), a({
                                type: "storeGetCatalogItemsResponse",
                                requestId: r,
                                error: {
                                    code: "catalogFetchFailed",
                                    message: "The catalog request timed out."
                                }
                            })
                        }, 1e4),
                        a = t => {
                            clearTimeout(o), this.pendingCatalogRequest = null,
                                function(e) {
                                    return "error" in e
                                }(t) ? i(new Le(t.error.code, t.error.message)) : (this.logger.log(`Received ${t.catalogPage.items.length} catalog items`), e(t.catalogPage))
                        };
                    this.pendingCatalogRequest = {
                        requestId: r,
                        settle: a
                    }, this.sdk.postMessage({
                        type: "storeGetCatalogItems",
                        data: {
                            requestId: r,
                            xsollaProjectId: t,
                            limit: s,
                            offset: n
                        }
                    })
                })
            }
            async getPlayerInventory(e) {
                const t = this.xsollaProjectId;
                if (!I(t)) throw new Le("unexpectedError", "Xsolla project ID is missing. Please contact Technical Support team.");
                const {
                    limit: s,
                    offset: n
                } = Ce(e);
                this.logger.log(`Requesting the player inventory, limit ${s}, offset ${n}`);
                const r = await this.getXsollaUserToken("read their inventory"),
                    i = `${Te}/${t}/user/inventory/items?limit=${s}&offset=${n}`,
                    o = new AbortController,
                    a = setTimeout(() => o.abort(), 1e4);
                let l;
                try {
                    let e;
                    try {
                        e = await fetch(i, {
                            method: "GET",
                            headers: {
                                Authorization: `Bearer ${r}`
                            },
                            signal: o.signal
                        })
                    } catch (e) {
                        throw this.logger.error("Network error while fetching the Xsolla inventory", e), new Le("inventoryFetchFailed", "Could not reach the Xsolla store API.")
                    }
                    if (!e.ok) throw this.logger.error(`Error fetching the inventory: ${e.status} ${e.statusText}`), new Le("inventoryFetchFailed", "The Xsolla store API could not return the inventory.");
                    try {
                        l = await e.json()
                    } catch (e) {
                        throw this.logger.error("Failed to parse the Xsolla inventory response", e), new Le("inventoryFetchFailed", "Received an invalid response from the Xsolla store API.")
                    }
                } finally {
                    clearTimeout(a)
                }
                const h = l.items.map(e => this.toInventoryItem(e));
                return this.logger.log(`Received ${h.length} inventory items`), {
                    items: h
                }
            }
            async consumeItem(e, t) {
                var s;
                const n = this.xsollaProjectId;
                if (!I(n)) throw new Le("unexpectedError", "Xsolla project ID is missing. Please contact Technical Support team.");
                if ("string" != typeof e || 0 === e.length) throw new Le("invalidArgument", "sku must be a non-empty string.");
                if (!Number.isInteger(t) || t < 1) throw new Le("invalidArgument", "quantity must be a positive integer.");
                this.logger.log(`Consuming ${t} of item ${e}`);
                const r = await this.getXsollaUserToken("consume an item"),
                    i = `${Te}/${n}/user/inventory/item/consume`,
                    o = new AbortController,
                    a = setTimeout(() => o.abort(), 1e4);
                let l;
                try {
                    l = await fetch(i, {
                        method: "POST",
                        headers: {
                            Authorization: `Bearer ${r}`,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            sku: e,
                            quantity: t
                        }),
                        signal: o.signal
                    })
                } catch (e) {
                    throw this.logger.error("Network error while consuming the Xsolla item", e), new Le("consumeItemFailed", "Could not reach the Xsolla store API.")
                } finally {
                    clearTimeout(a)
                }
                if (!l.ok) {
                    const n = await this.readXsollaError(l);
                    this.logger.error(`Error consuming item ${e}: ${l.status} ${l.statusText}`, n);
                    const r = null == n ? void 0 : n.errorMessage,
                        i = null !== (s = null == r ? void 0 : r.toLowerCase()) && void 0 !== s ? s : "";
                    if (i.includes("not consumable")) throw new Le("itemNotConsumable", `Item ${e} is not consumable.`);
                    if (i.includes("not found in user inventory")) throw new Le("itemNotInInventory", `Item ${e} is not in the player's inventory.`);
                    if (i.includes("not enough item")) throw new Le("insufficientItemQuantity", `The player does not own ${t} of ${e}.`);
                    throw new Le("consumeItemFailed", `The Xsolla store API could not consume ${t} of ${e}.${r?` Xsolla error: ${r}`:""}`)
                }
                this.logger.log(`Consumed ${t} of item ${e}`)
            }
            async readXsollaError(e) {
                try {
                    const t = await e.json();
                    return "object" == typeof t && null !== t ? t : null
                } catch {
                    return null
                }
            }
            async getXsollaUserToken(e) {
                try {
                    return await this.sdk.user.getXsollaUserToken()
                } catch (t) {
                    if (this.logger.error(`Could not get an Xsolla user token to ${e}`, t), t instanceof h && "userNotAuthenticated" === t.code) throw new Le("userNotAuthenticated", `The player must be signed in to ${e}.`);
                    throw new Le("unexpectedError", "Could not get the Xsolla user token.")
                }
            }
            toInventoryItem(e) {
                return {
                    sku: e.sku,
                    name: e.name,
                    description: e.description,
                    imageUrl: e.image_url,
                    quantity: e.quantity
                }
            }
            performPurchase(e) {
                if (!I(this.xsollaProjectId)) throw new Le("unexpectedError", "Xsolla project ID is missing. Please contact Technical Support team.");
                const t = this.xsollaProjectId;
                return this.logger.log(`Initiating purchase for item ${e}`), new Promise((s, n) => {
                    this.pendingPurchase = {
                        itemId: e,
                        settle: e => {
                            this.pendingPurchase = null,
                                function(e) {
                                    return "error" in e
                                }(e) ? n(new Le(e.error.code, e.error.message)) : s({
                                    itemId: e.itemId
                                })
                        }
                    }, this.sdk.postMessage({
                        type: "storeBuyItem",
                        data: {
                            itemId: e,
                            xsollaProjectId: t,
                            sandbox: this.sandbox
                        }
                    })
                })
            }
        };

    function Be(e) {
        return I(e) && "" !== e.trim()
    }
    const xe = "An error occurred";

    function De(e, t = {}) {
        if (!e) return xe;
        let s = "";
        const {
            includeStack: n = !1
        } = t;
        if (e instanceof Error) s = n && e.stack || e.message;
        else try {
            s = e.toString(), s.startsWith("[object") && s.endsWith("]") && (s = JSON.stringify(e))
        } catch {
            try {
                s = JSON.stringify(e)
            } catch {
                s = xe
            }
        }
        if ("string" != typeof s) try {
            s = JSON.stringify(s)
        } catch {
            s = xe
        }
        return Be(s) ? s : function(e) {
            const t = [Fe(e), $e(e)].filter(Be);
            return t.length > 0 ? t.join(" ") : xe
        }(e)
    }

    function Fe(e) {
        if (!(e instanceof Error)) return;
        if (Be(e.name) && "Error" !== e.name) return e.name;
        const t = e.constructor ? .name;
        return Be(t) && "Error" !== t && "Object" !== t ? t : void 0
    }

    function $e(e) {
        const t = e ? .code;
        return Be(t) ? t : "number" == typeof t ? String(t) : void 0
    }
    const Ue = class {
        constructor(t, s, n) {
            var r;
            this.logger = new i("none"), this._isQaTool = !1, this.receiveMessage = async t => {
                const s = t.data;
                e(s) && s.type && (this.logger.verbose("Received message from GF", s), "reinitSdkGameDataAfterLogin" !== s.type ? (this.bannerModule.handleEvent(s), this.adModule.handleEvent(s), this.userModule.handleEvent(s), this.gameModule.handleEvent(s), this.storeModule.handleEvent(s), Se.getInstance().handleEvent(s)) : this.switchDataModuleAfterLogin())
            }, this.switchDataModuleAfterLogin = async () => {
                const e = await this.userModule.getUser();
                if (!e) return this.logger.persist.warn("reinitSdkGameDataAfterLogin: no user"), void this.postMessage({
                    type: "sdkGameDataModuleSwitchResult",
                    data: {
                        ok: !1
                    }
                });
                const t = await fe(e, this.initializeReply);
                this.dataModule = new Re(this, t), this.logger.persist.log("reinitSdkGameDataAfterLogin: posting ack", {
                    sdkVersion: "3.8.0",
                    hasGFWindow: !!_e
                }), this.postMessage({
                    type: "sdkGameDataModuleSwitchResult",
                    data: {
                        ok: !0
                    }
                })
            }, this.initializeReply = t, !0 === t.debug && (i.forceEnable = !0), this.adModule = new ee(this, t), this.bannerModule = new E(this, t), this.gameModule = new H(this, t, n), this.userModule = new ie(this, t.systemInfo, !!t.userAccountAvailable, n), this.dataModule = new Re(this, s), this.analyticsModule = new Ee(this), this.storeModule = new qe(this, t.xsollaProjectId, null !== (r = t.storeAvailable) && void 0 !== r && r), window.addEventListener("message", this.receiveMessage, !1), Se.getInstance().init(this, t), this.propagateErrors(), this.addPointerLockDetection()
        }
        get environment() {
            return this.postMessage({
                type: "getEnvironment"
            }), "crazygames"
        }
        get isQaTool() {
            return this.logger.warn("isQaTool is deprecated and should no longer be called."), this.postMessage({
                type: "isQATool"
            }), this._isQaTool
        }
        get banner() {
            return this.bannerModule
        }
        get game() {
            return this.gameModule
        }
        get user() {
            return this.userModule
        }
        get ad() {
            return this.adModule
        }
        get data() {
            return this.dataModule
        }
        get analytics() {
            return this.analyticsModule
        }
        get store() {
            return this.storeModule
        }
        propagateErrors() {
            window.addEventListener("error", e => {
                const t = e.error;
                this.postMessage({
                    type: "error",
                    data: {
                        name: t instanceof Error ? t.name : "Error",
                        message: e.message || De(t),
                        filename: e.filename || "Unknown file",
                        lineno: e.lineno || 0,
                        colno: e.colno || 0,
                        stack: t instanceof Error && t.stack || "No stack trace available",
                        url: window.location.href
                    }
                })
            }), window.addEventListener("unhandledrejection", e => {
                const t = e.reason;
                this.postMessage({
                    type: "error",
                    data: {
                        name: "UnhandledRejection",
                        message: De(t),
                        stack: t instanceof Error && t.stack || "No stack trace available",
                        url: window.location.href
                    }
                })
            })
        }
        addPointerLockDetection() {
            document.addEventListener("pointerlockchange", () => {
                const e = !!document.pointerLockElement;
                this.logger.verbose("Pointer lock " + (e ? "on" : "off")), this.postMessage({
                    type: "pointerLockChanged",
                    data: {
                        isLocked: e
                    }
                })
            })
        }
        postMessage(e) {
            this.logger.verbose("Message to GF", e), _e ? _e.postMessage(e, "*") : this.logger.log("Missing GF_WINDOW, message won't be sent")
        }
    };
    class ze {
        constructor() {
            this.QUEUE_FLUSH_INTERVAL_IN_MS = 100, this.missingResourcesQueue = [], this.queueInterval = null, this.performanceObserver = null, this.patchPerformanceObserver()
        }
        static getInstance() {
            return ze.instance || (ze.instance = new ze), ze.instance
        }
        shutDown() {
            this.performanceObserver && (this.performanceObserver.disconnect(), this.performanceObserver = null), this.queueInterval && (clearInterval(this.queueInterval), this.queueInterval = null), this.missingResourcesQueue = []
        }
        patchPerformanceObserver() {
            this.isPerformanceObserverAvailable() && (this.performanceObserver = new PerformanceObserver(e => {
                const t = e.getEntries();
                for (const e of t)
                    if (404 !== e.responseStatus) {
                        if (void 0 === e.responseStatus) {
                            const t = e.duration,
                                s = e.transferSize,
                                n = e.encodedBodySize,
                                r = e.decodedBodySize,
                                i = 0 === t && (0 === s || 0 === n || 0 === r),
                                o = e.initiatorType,
                                a = ["img", "script", "link", "fetch", "xmlhttprequest"].includes(o);
                            i && a && this.enqueueOrSend(e.name)
                        }
                    } else this.enqueueOrSend(e.name)
            }), this.performanceObserver.observe({
                type: "resource",
                buffered: !0
            }))
        }
        isPerformanceObserverAvailable() {
            return "PerformanceObserver" in window
        }
        enqueueOrSend(e) {
            this.isSdkAvailable() ? this.sendMissingResourceErrorMessage(e) : (this.missingResourcesQueue.push(e), this.queueInterval && clearInterval(this.queueInterval), this.queueInterval = setInterval(() => this.flushQueue(), this.QUEUE_FLUSH_INTERVAL_IN_MS))
        }
        flushQueue() {
            var e;
            if (!this.isSdkAvailable()) return;
            const t = null === (e = window.CrazyGames) || void 0 === e ? void 0 : e.SDK;
            if (t && t.instance instanceof Ue) {
                for (; this.missingResourcesQueue.length > 0;) {
                    const e = this.missingResourcesQueue.shift();
                    this.sendMissingResourceErrorMessage(e)
                }
                this.queueInterval && (clearInterval(this.queueInterval), this.queueInterval = null)
            }
        }
        isSdkAvailable() {
            var e;
            const t = null === (e = window.CrazyGames) || void 0 === e ? void 0 : e.SDK;
            return t && t.instance instanceof Ue
        }
        sendMissingResourceErrorMessage(e) {
            const t = {
                path: e
            };
            window.CrazyGames.SDK.instance.postMessage({
                type: "missingGameResourceError",
                data: t
            })
        }
    }

    function Ne(e) {
        return new Promise(t => setTimeout(t, e))
    }
    ze.instance = null;
    const Ge = new i("user"),
        Oe = new i("none");
    let _e = null;

    function Je(e) {
        return new Promise(t => {
            const s = window.setTimeout(() => {
                    window.removeEventListener("message", n, !1), Xe("gf-init-response-timeout", null, {
                        timeoutMs: 5e3
                    }), Oe.error("Gf Init response timeout 5000ms"), t(null)
                }, 5e3),
                n = async e => {
                    if ("initialized" === e.data.type) {
                        Oe.verbose("Received init from GF", e.data), window.clearTimeout(s), window.removeEventListener("message", n, !1);
                        const r = e.data.data;
                        (function(e) {
                            try {
                                if (!e) return !1;
                                const {
                                    pathname: t
                                } = new URL(e);
                                return /^\/preview\/[^/]+/.test(t)
                            } catch {
                                return !1
                            }
                        })(r.gameLink) || ze.getInstance().shutDown(), t(r)
                    }
                };
            window.addEventListener("message", n, !1), _e.postMessage({
                type: "init-js-sdk",
                data: {
                    version: "3.8.0",
                    sdkType: "js",
                    ...e
                }
            }, "*")
        })
    }

    function je(e) {
        return new URLSearchParams(window.location.search).get(e)
    }

    function Ve(e) {
        const t = document.createElement("style");
        t.textContent = e, document.head.append(t)
    }

    function Qe(e) {
        return t => {
            try {
                e(t)
            } catch (e) {
                console.error(e)
            }
        }
    }

    function We(e) {
        return !("object" != typeof e || null === e || Array.isArray(e))
    }

    function Xe(e, t, s) {
        if (!_e) return;
        const n = {
            type: "sdkError",
            data: {
                errorName: e,
                module: t,
                specificValues: s || {}
            }
        };
        _e.postMessage(n, "*")
    }
    var He = class extends Error {
        _event;
        _source;
        _lineNumber;
        _columnNumber;
        _error;
        constructor(e, t, s, n, r, i) {
            super(e), this._event = t, this._source = s, this._lineNumber = n, this._columnNumber = r, this._error = i
        }
        get event() {
            return this._event
        }
        get source() {
            return this._source
        }
        get lineNumber() {
            return this._lineNumber
        }
        get columnNumber() {
            return this._columnNumber
        }
        get error() {
            return this._error
        }
        toString() {
            const e = "string" == typeof this.event ? this.event : `event[${this.event.type}]`;
            return `${super.toString()}: event: ${e} - source: ${this.source} - lineNumber: ${this.lineNumber} - columnNumber: ${this.columnNumber} - error: ${this.error} `
        }
    };

    function Ze(e, t, s, n) {
        return window.CrazygamesAds || !t.banner.isBannerAdsEnabled() ? Promise.resolve() : function(e, t, s, n) {
            return Ke || (Ke = async function(e, t = {}) {
                return s = {
                    type: "source",
                    src: e,
                    customProps: t
                }, new Promise((e, t) => {
                    const n = document.createElement("script");
                    switch (n.onload = () => e(), n.onerror = (e, n, r, i, o) => {
                        let a;
                        if ("string" == typeof e) a = e;
                        else {
                            const t = e.currentTarget;
                            a = `type: ${e.type} - target: ${t.tagName}#${t.id||"no-id"}`
                        }
                        t(new He(`LoadScript error (${function(e){switch(e.type){case"source":return`from url ${e.src}`;case"content":return"from content"}}(s)}): ${a}.`, e, n, r, i, o))
                    }, n.async = !0, s.type) {
                        case "source":
                            n.src = s.src;
                            break;
                        case "content":
                            n.text = s.content
                    }
                    I(s.customProps) && Object.entries(s.customProps).forEach(([e, t]) => {
                        n.setAttribute(e, t)
                    }), document.head.appendChild(n)
                });
                var s
            }(e).catch(t => {
                throw new Error(`Error while loading script ${e}. Reason: ${De(t)}`)
            }).then(() => {
                const e = window.CrazygamesAds;
                if (!I(e)) throw new Error("CrazygamesAds not found, maybe using an adblocker.");
                const r = e => {
                    t.postMessage({
                        type: "adsAnalyticsEvent",
                        data: {
                            event: e
                        }
                    })
                };
                try {
                    e.initAds({
                        source: "sdk",
                        analyticsEventHandler: r,
                        clientInfo: s,
                        configCatValues: n
                    })
                } catch (e) {
                    throw new Error(`Error in initAds. Reason: ${De(e)}`)
                }
            }), Ke)
        }(e, t, s, n)
    }
    let Ke;
    const Ye = class {
            constructor() {
                this.message = `CrazySDK is disabled on this domain. Check ${a} for more info.`, this.code = "sdkDisabled"
            }
            get ad() {
                throw new h(this.code, this.message)
            }
            get banner() {
                throw new h(this.code, this.message)
            }
            get game() {
                throw new h(this.code, this.message)
            }
            get user() {
                throw new h(this.code, this.message)
            }
            get data() {
                throw new h(this.code, this.message)
            }
            get analytics() {
                throw new h(this.code, this.message)
            }
            get store() {
                throw new h(this.code, this.message)
            }
            get environment() {
                return "disabled"
            }
            get isQaTool() {
                return !1
            }
        },
        et = class {
            constructor(e) {
                this.sdk = e, this.requestInProgress = !1, this.overlay = null, this.logger = new i("ad"), this.adPlaying = !1
            }
            init() {
                this.overlay = document.createElement("div"), this.overlay.id = "local-overlay", this.createOverlayStyle(), document.body.appendChild(this.overlay)
            }
            prefetchAd(e) {
                console.warn(...s, "prefetchAd is no longer supported and should not be called.")
            }
            async requestAd(e, t) {
                if (this.requestInProgress)
                    if (null == t ? void 0 : t.adError) {
                        const e = "An ad request is already in progress";
                        Qe(t.adError)(new K("other", e))
                    } else(null == t ? void 0 : t.adFinished) && Qe(t.adFinished)();
                else this.adPlaying = !0, (null == t ? void 0 : t.adStarted) && Qe(t.adStarted)(), this.sdk.banner.activeBannersCount > 0 && this.sdk.banner.clearAllBanners(), await this.renderFakeAd(e), this.adPlaying = !1, (null == t ? void 0 : t.adFinished) && Qe(t.adFinished)()
            }
            async hasAdblock() {
                return this.logger.log("Requesting adblock status (always false) (local)"), !1
            }
            addAdblockPopupListener() {}
            removeAdblockPopupListener() {}
            async renderFakeAd(e) {
                return this.logger.log(`Requesting ${e} ad`), this.requestInProgress = !0, this.showOverlay(), this.overlay.innerHTML = `<h1>A ${e} ad would appear here</h1>`, new Promise(e => {
                    window.setTimeout(() => {
                        this.requestInProgress = !1, this.hideOverlay(), e()
                    }, 5e3)
                })
            }
            showOverlay() {
                this.overlay.style.display = "flex"
            }
            hideOverlay() {
                this.overlay.style.display = "none", this.overlay.innerHTML = ""
            }
            createOverlayStyle() {
                const e = {
                    position: "fixed",
                    display: "none",
                    inset: 0,
                    "font-family": "Arial, Helvetica, sans-serif",
                    color: "white",
                    "align-items": "center",
                    "justify-content": "center",
                    "background-color": "rgba(0,0,0,0.75)",
                    "z-index": "10000"
                };
                for (const t in e) this.overlay.style[t] = e[t]
            }
            get isAdPlaying() {
                return this.adPlaying
            }
        },
        tt = class {
            constructor(e) {
                this.sdk = e, this.disableBannerCheck = !1, this.overlayBanners = {}, this.renderedBannerIds = new Set, this.logger = new i("banner"), this.hideWatcher = new A(e => {
                    this.logger.log(`Container #${e} got hidden, auto-clearing its banner`), this.clearBanner(e)
                })
            }
            async requestBanner(e) {
                this.logger.log("Requesting banner with automatic rendering", e), this.ensureVideoAdNotPlaying(e.id);
                const t = await this.prefetchBanner(e);
                return this.renderPrefetchedBanner(t)
            }
            async requestResponsiveBanner(e) {
                this.logger.log(`Requesting responsive banner with automatic rendering #${e}`), this.ensureVideoAdNotPlaying(e);
                const t = await v(e, !this.disableBannerCheck),
                    {
                        width: s,
                        height: n
                    } = t.containerInfo.size,
                    r = await this.prefetchResponsiveBanner({
                        id: e,
                        width: s,
                        height: n
                    });
                return this.renderPrefetchedBanner(r)
            }
            async prefetchBanner(e) {
                if (this.logger.log("Prefetch banner", e), t = e.width, s = e.height, ! function(e) {
                        return d.some(t => t === e)
                    }(`${t}x${s}`)) return Promise.reject("Invalid banner size");
                var t, s;
                const n = y(e.id),
                    r = { ...e,
                        id: n
                    };
                return {
                    id: r.id,
                    banner: r,
                    renderOptions: {}
                }
            }
            async prefetchResponsiveBanner(e) {
                this.logger.log(`Prefetch responsive banner #${e.id}`);
                const {
                    width: t,
                    height: s
                } = e, n = {
                    id: y(e.id),
                    width: t,
                    height: s,
                    isResponsive: !0
                };
                return {
                    id: n.id,
                    banner: n,
                    renderOptions: {}
                }
            }
            async renderPrefetchedBanner(e) {
                this.logger.log("Rendering prefetched banner", e);
                const t = f(e.id);
                this.ensureVideoAdNotPlaying(t), await v(t, !0), this.renderedBannerIds.add(t), this.hideWatcher.watch(t), p(e.banner)
            }
            ensureVideoAdNotPlaying(e) {
                if (this.sdk.ad.isAdPlaying) throw new u("videoAdPlaying", "Banners cannot be rendered while a video ad is playing", e)
            }
            requestOverlayBanners(e, t) {
                const s = e.map(e => e.id);
                Object.keys(this.overlayBanners).forEach(e => {
                    s.includes(e) || (this.logger.log("Remove overlay banner " + e), this.overlayBanners[e].destroy(), delete this.overlayBanners[e])
                }), e.forEach(e => {
                    if (this.overlayBanners[e.id]) return void this.logger.log("Skip overlay banner update " + e.id);
                    this.logger.log("Create overlay banner " + e.id);
                    const s = new o(e, this.disableBannerCheck, this, t);
                    this.overlayBanners[e.id] = s
                })
            }
            clearBanner(e) {
                this.hideWatcher.unwatch(e);
                const t = document.getElementById(y(e));
                t ? (t.remove(), this.renderedBannerIds.delete(e), this.logger.log(`Cleared the banner from container #${e}`)) : this.logger.log(`There isn't a banner in container #${e}, not clearing anything.`)
            }
            clearAllBanners() {
                const e = Array.from(this.renderedBannerIds.values());
                this.logger.log("Clearing all banners, ids: ", e.map(e => `#${e}`).join(", ")), e.forEach(e => {
                    this.clearBanner(e)
                })
            }
            get activeBannersCount() {
                return this.renderedBannerIds.size
            }
        };

    function st() {
        const e = navigator.userAgent.toLowerCase(),
            t = /mobile/i.test(e),
            s = /tablet/i.test(e) || t && /ipad/i.test(e);
        return t ? "mobile" : s ? "tablet" : "desktop"
    }
    const nt = class {
            constructor() {
                this.systemInfo = {
                    browser: {
                        name: "demo",
                        version: "demo"
                    },
                    countryCode: "US",
                    locale: "en-US",
                    os: {
                        name: "demo",
                        version: "demo"
                    },
                    device: {
                        type: st()
                    },
                    applicationType: "web"
                }, this.isUserAccountAvailable = "false" !== je("user_account_available"), this.demoUser1 = {
                    __dangerousUserId: "idUser1",
                    username: "User1",
                    profilePictureUrl: "https://images.crazygames.com/userportal/avatars/1.png"
                }, this.demoUser2 = {
                    __dangerousUserId: "idUser2",
                    username: "User2",
                    profilePictureUrl: "https://images.crazygames.com/userportal/avatars/2.png"
                }, this.user1Token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJpZFVzZXIxIiwidXNlcm5hbWUiOiJVc2VyMSIsImdhbWVJZCI6InlvdXJHYW1lSWQiLCJwcm9maWxlUGljdHVyZVVybCI6Imh0dHBzOi8vaW1hZ2VzLmNyYXp5Z2FtZXMuY29tL3VzZXJwb3J0YWwvYXZhdGFycy8xLnBuZyIsImlhdCI6MTY2ODU5MzMxNCwiZXhwIjo0ODI0Mjg4NTE0fQ.u4N2DzCC6Vmo6Gys-XSl8rHQR0NUJAcWQWr29eLd54qMDPbCopPG0kye8TAidOU6dWAqNWO_kERbl75nTxNcJjbW4yqBS_bIPingIhuCCJsjvnQPkalfmVotmoZGQP21Q9MyZPfpjZNogioA3a0vm6APXAqzudTA9lTioztnT4YvgndISngOMQVNoDCJ_DgCbKy8GFQDcCN-AHFFb0WIVWiTYszv-9JZohUzULt-ueYL31pXVGHQ5C4rHESEg7LYzx1IaLKw1zcoYGxul0RxR35nm3yD_bGa6fQVzCfnKnhEBRifUZsIN1LfIHfNB23ZOh1llG7PEOdvtCSfIxP9ZK6t4gRkGn1VsqZFAMhq1LgJebO8hcm_Iqx0wF3WkdMysoQuWThTNKnwmphv9pguuALILYJluUP8UQll3qiF6gzoLPy1MfD_9l4TPZeP9Bv50B-Tm6Lk3OW248jyuFRKP_VgwZutTb5pJ7LggFcqWFXsBv5ZG3V2zsfVwpAPDhpmb4ykjoB2xLSuxjrvs1dzMhl02QAQjqTUgHj4fstgX-2jYowDyyPjj6JbT2ZC7vrrdmPvc8AcNvyCszamfRYjexElGaeJDDt6vtRuJw_JVwsCLaYHGif4UaKCoe6BECg3mRVUkH08Nm-qQPQw9slpYZmxckFEQQPCGkkPhgOBFkE", this.user2Token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJpZFVzZXIyIiwidXNlcm5hbWUiOiJVc2VyMiIsImdhbWVJZCI6InlvdXJHYW1lSWQiLCJwcm9maWxlUGljdHVyZVVybCI6Imh0dHBzOi8vaW1hZ2VzLmNyYXp5Z2FtZXMuY29tL3VzZXJwb3J0YWwvYXZhdGFycy8yLnBuZyIsImlhdCI6MTY2ODU5MzMxNCwiZXhwIjo0ODI0Mjg4NTE0fQ.kh60HYKR8txKvLoCB6dQ9hQG8Mu1UgtneTGs3Y15HvBWrZoLKp3x3pTf_Vhq8xzs7fQYJKr94zYAxxFRztHey7Tv7PBBmPESUFo8Le-_s2xDy982sFhpM6XDt84ohhvEuJEsOW8wIcCaCK6wzm6UWY6n1bpw1cO1KNASyZRSkDRhfyzDVJ5e167OLgGe3euodTHgClJPDv0ZYhle9KH86PepWamCm0429VrzyOu6QdbtFcRlRNZVnTtgNrCpyvss4AyDhnY5qV9yng7xHVt4zlocP_Z7btBL_kxrzYskhJi6KYuQAYmqLxqHSDnehlIvgO4cdEpJA_FOTeACTohhEu8zjXRrfdAFvEe0W6qqUo5HNFoElRoxYWf11WGSdrJCjpF4Qei9BPgprFaVH2Xi-ITAjKyElQxeKs5p6VmvaMAGwdqZgM4fm7OSex8QQGK0HFJ7wFoCTV5PLl-MBVvTSTfemJMWEwc8od124gwT_uGdDKrASovT2pijgBsAi3jxwgfEr1RPq8uCgZtksrTqaAM9TMv9Z6Zv35pdgTrWzTrOn-G-uc4EPZq7iQaEnglWEFj8Qsm_nMQMgtIM7MYG8KwPC4if3-Yc8KwaAL_taVvkqyMaV3W5j4MX9b1bbf_fw3jrGt74MACb7FtgzKudxoz2CXKZqTppadxS_IOnlMk", this.expiredToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJpZFVzZXIxIiwidXNlcm5hbWUiOiJVc2VyMSIsImdhbWVJZCI6InlvdXJHYW1lSWQiLCJwcm9maWxlUGljdHVyZVVybCI6Imh0dHBzOi8vaW1hZ2VzLmNyYXp5Z2FtZXMuY29tL3VzZXJwb3J0YWwvYXZhdGFycy8xLnBuZyIsImlhdCI6MTY2ODU5MzQ5MSwiZXhwIjoxNjY4NTkzNDkyfQ.l_0cyeD-suEM7n9l-Vb2nP5vTJi-e3HwZQWLUESJMdVTX1zPDuQhwnSgHhcGVGFnhG5Wvtni-ElpM8HnVNvY7hRthbeP23n2ScAJBvAX10vrzPuLJRn_Nj_5GcRQpK4fH813Ij8ZWuOaS2hD4gKaEUessZs5n5hNBTQN9T5j4wkNvfhuw9vqtVOha2aPveqeVy1eA5XAWI7IirHi31-Dw60MSVgsp3r4tpYEHTlUPktzLsQvO9Sk9IE7iybg9ycoFoS6L1eAvxGWVF1BMHRerPwdOV9CN0rtrqrTM3pyb1fpmFfgQpoA8AgPuVrU58mwyeTpUQ4WSrPrltGjxxfiGQOATBDBrJk5V173BfUgBEgAEP0TifWAQt02iijJa9G6q-V8p0GWto1EYSdvEDmG0YhoRBVxnOQH3U1Fu0yxMWGMm9VmZVVhVN8PpLjitEhP4Gn33IafpS05d1-Q0NFMb9-FvQCdtXjTaGbaBVIeBN-aO0r4ERvoBE9R0AUrywd9Z2zK_qKRvp35NyryLjnedsYt5Xrc9TA2uDMR77TjByyqsdQ_qv4zhLfhuiMiweXyPfYzltAiNJmEUohxlP7OvH33B6xpT7Qz2ZyEeMHBrQRQGGlT6MowcMYx_2LFNSK8PwZJNlMs0Uw_uCIu-4TvqleVleIg7sLhWiijw1cxtmM", this.logger = new i("user"), this.throttledListFriends = C(e => {
                    var t, s;
                    const n = [{
                            id: "1",
                            username: "Alice",
                            profilePictureUrl: "https://images.crazygames.com/userportal/avatars/3.png"
                        }, {
                            id: "2",
                            username: "Bob",
                            profilePictureUrl: "https://images.crazygames.com/userportal/avatars/4.png"
                        }],
                        r = n.length,
                        i = null !== (t = e.page) && void 0 !== t ? t : 1,
                        o = null !== (s = e.size) && void 0 !== s ? s : 10,
                        a = Math.max(0, (i - 1) * o),
                        l = Math.max(0, Math.min(o, r - a));
                    return {
                        friends: n.slice(a, a + l),
                        page: i,
                        size: o,
                        hasMore: a + l < r,
                        total: r
                    }
                }, {
                    delayMs: 250,
                    methodName: "listFriends",
                    throwIfThrottled: !0
                })
            }
            async showAuthPrompt() {
                switch (this.logger.log("Requesting auth prompt (local)"), je("show_auth_prompt_response")) {
                    case "user1":
                    default:
                        return this.demoUser1;
                    case "user2":
                        return this.demoUser2;
                    case "user_cancelled":
                        throw new se("userCancelled", "User cancelled the auth prompt")
                }
            }
            async showAccountLinkPrompt() {
                switch (this.logger.log("Requesting link account prompt (local)"), je("link_account_response")) {
                    case "yes":
                    default:
                        return {
                            response: "yes"
                        };
                    case "no":
                        return {
                            response: "no"
                        };
                    case "logged_out":
                        throw new se("userNotAuthenticated", "The user is not authenticated")
                }
            }
            async getUser() {
                switch (this.logger.log("Requesting user object (local)"), je("user_response")) {
                    case "user1":
                    default:
                        return this.demoUser1;
                    case "user2":
                        return this.demoUser2;
                    case "logged_out":
                        return null
                }
            }
            async getUserToken() {
                switch (this.logger.log("Requesting user token (local)"), je("token_response")) {
                    case "user1":
                    default:
                        return this.user1Token;
                    case "user2":
                        return this.user2Token;
                    case "expired_token":
                        return this.expiredToken;
                    case "logged_out":
                        throw new se("userNotAuthenticated", "The user is not authenticated")
                }
            }
            async getXsollaUserToken() {
                return this.logger.log("Requesting Xsolla user token (local). Xsolla token not supported locally."), "Xsolla token not supported locally"
            }
            addScore(e) {
                this.logger.warn("addScore is no longer supported.")
            }
            addScoreEncrypted(e, t) {
                this.logger.warn("addScoreEncrypted is no longer supported.")
            }
            submitScore(e) {
                this.logger.log("Submitting score (local).", e.encryptedScore, e.score)
            }
            async listFriends(e) {
                return this.throttledListFriends(e)
            }
            async addFriends(e) {
                return "shown"
            }
            async nudgeFriend(e) {
                return "sent"
            }
            addAuthListener() {}
            removeAuthListener() {}
        },
        rt = class {
            constructor(e) {
                this.logger = new i("data");
                const t = pe(e.game.id);
                this.localDataHandler = new ce(t, e.game.id)
            }
            clear() {
                this.logger.log("Clear data"), this.localDataHandler.clear()
            }
            getItem(e) {
                const t = this.localDataHandler.getItem(e);
                return this.logger.log(`Get "${e}", returning ${t}`), t
            }
            removeItem(e) {
                this.logger.log(`Remove "${e}"`), this.localDataHandler.removeItem(e)
            }
            setItem(e, t) {
                this.logger.log(`Set "${e}" = ${t}`), this.localDataHandler.setItem(e, t)
            }
            syncUnityGameData() {
                this.logger.log("Requesting to sync unity PlayerPrefs (local)")
            }
        },
        it = [{
            sku: "local_item_1",
            name: "Local item 1",
            description: "A fake item, only returned locally.",
            imageUrl: "https://placehold.co/512x512",
            price: {
                amount: "1.99",
                amountWithoutDiscount: "1.99",
                currency: "USD"
            },
            isFree: !1,
            canBeBought: !0
        }, {
            sku: "local_item_2",
            name: "Local item 2",
            description: "A fake item, only returned locally.",
            imageUrl: "https://placehold.co/512x512",
            price: {
                amount: "9.99",
                amountWithoutDiscount: "19.99",
                currency: "USD"
            },
            isFree: !1,
            canBeBought: !0
        }, {
            sku: "local_item_3",
            name: "Local item 3",
            description: "A fake free item, only returned locally.",
            imageUrl: "https://placehold.co/512x512",
            price: null,
            isFree: !0,
            canBeBought: !0
        }],
        ot = [{
            sku: "local_item_1",
            name: "Local item 1",
            description: "A fake item, only returned locally.",
            imageUrl: "https://placehold.co/512x512",
            quantity: 3
        }, {
            sku: "local_item_3",
            name: "Local item 3",
            description: "A fake free item, only returned locally.",
            imageUrl: "https://placehold.co/512x512",
            quantity: 1
        }],
        at = class {
            constructor() {
                this.adModule = new et(this), this.bannerModule = new tt(this), this.userModule = new nt, this.dataModule = new rt(this), this.gameLogger = new i("game"), this.analyticsLogger = new i("analytics"), this.storeLogger = new i("store"), this.throttledHappyTime = C(() => this.gameLogger.log("Requesting happytime (local)"), {
                    delayMs: 1e3,
                    methodName: "happytime"
                }), this.throttledGameplayStart = C(() => this.gameLogger.log("Requesting gameplay start (local)"), {
                    delayMs: 1e3,
                    methodName: "gameplayStart"
                }), this.throttledGameplayStop = C(() => this.gameLogger.log("Requesting gameplay stop (local)"), {
                    delayMs: 1e3,
                    methodName: "gameplayStop"
                }), this.showInviteButton = e => {
                    this.gameLogger.log("Show invite button (local)");
                    const t = Q({
                        gameLink: this.game.link,
                        params: e
                    });
                    return this.gameLogger.log(`Invite button link ${t}`), t
                }, this.inviteLink = e => {
                    this.gameLogger.log("Requesting invite link (local)");
                    const t = Q({
                        gameLink: this.game.link,
                        params: e
                    });
                    return this.gameLogger.log(`Invite link is ${t}`), t
                }, this.adModule.init(), this.bannerModule.disableBannerCheck = "true" === je("disable_banner_check")
            }
            get ad() {
                return this.adModule
            }
            get banner() {
                return this.bannerModule
            }
            get user() {
                return this.userModule
            }
            get data() {
                return this.dataModule
            }
            get environment() {
                return "local"
            }
            get isQaTool() {
                return !1
            }
            get game() {
                return {
                    link: "https://www.crazygames.com/game/your-game-will-appear-here",
                    id: "local",
                    isInstantJoin: window.location.search.includes("instantJoin=true"),
                    isInstantMultiplayer: window.location.search.includes("instantJoin=true"),
                    isOfflineMode: !1,
                    inviteParams: W(),
                    happytime: () => this.throttledHappyTime(),
                    gameplayStart: () => this.throttledGameplayStart(),
                    gameplayStop: () => this.throttledGameplayStop(),
                    loadingStart: () => this.gameLogger.log("Requesting game loading start (local)"),
                    loadingStop: () => this.gameLogger.log("Requesting game loading stop (local)"),
                    reportGameCompletedPercentage: e => {
                        B(e), this.gameLogger.log(`Reporting game completed percentage (local): ${e}`)
                    },
                    dailyEvent: e => {
                        this.gameLogger.log("Reporting daily event (local)", G(e))
                    },
                    getLaunchContext: O,
                    inviteLink: this.inviteLink,
                    showInviteButton: this.showInviteButton,
                    hideInviteButton: () => this.gameLogger.log("Hide invite button (local)"),
                    addSettingsChangeListener: () => this.gameLogger.log("Add settings change listener (local)"),
                    removeSettingsChangeListener: () => this.gameLogger.log("Remove settings change listener (local)"),
                    addQualityChangeListener: () => this.gameLogger.log("Add quality change listener (local)"),
                    removeQualityChangeListener: () => this.gameLogger.log("Remove quality change listener (local)"),
                    addJoinRoomListener: () => this.gameLogger.log("Add join room listener (local)"),
                    removeJoinRoomListener: () => this.gameLogger.log("Remove join room listener (local)"),
                    getInviteParam: e => new URLSearchParams(window.location.search).get(e),
                    updateRoom: e => {
                        this.gameLogger.log("Update room (local) with params:", e)
                    },
                    leftRoom: () => {
                        this.gameLogger.log("Left room (local)")
                    },
                    setGameContext: e => {
                        this.gameLogger.log("Set game context (local)", e)
                    },
                    clearGameContext: () => {
                        this.gameLogger.log("Clear game context (local)")
                    },
                    settings: {
                        disableChat: "true" === je("disableChat"),
                        muteAudio: "true" === je("muteAudio")
                    },
                    quality: "performance" === je("quality") ? "performance" : "balanced"
                }
            }
            get analytics() {
                return {
                    trackOrder: (e, t) => {
                        if (!We(t)) throw new Me("invalidArgument", "Order must be a JSON object.");
                        if (!Pe.includes(e)) throw new Me("invalidArgument", `Unsupported payment provider. Supported providers: ${Pe.join(",")}`);
                        this.analyticsLogger.log(`Track "${e}" order`, t)
                    }
                }
            }
            get store() {
                return {
                    isAvailable: !0,
                    buyItem: async e => (this.storeLogger.log(`Buying item "${e}" (local). Simulating a successful purchase.`), {
                        itemId: e
                    }),
                    getCatalogItems: async e => {
                        const {
                            limit: t,
                            offset: s
                        } = Ce(e);
                        return this.storeLogger.log(`Listing catalog items (local), limit ${t}, offset ${s}. Returning a fake catalog.`), {
                            items: it.slice(s, s + t),
                            hasMore: s + t < it.length
                        }
                    },
                    getPlayerInventory: async e => {
                        const {
                            limit: t,
                            offset: s
                        } = Ce(e);
                        return this.storeLogger.log(`Getting the player inventory (local), limit ${t}, offset ${s}. Returning a fake inventory.`), {
                            items: ot.slice(s, s + t)
                        }
                    },
                    consumeItem: async (e, t) => {
                        this.storeLogger.log(`Consuming ${t} of item "${e}" (local). Simulating a successful consume.`)
                    },
                    setSandbox: e => {
                        this.storeLogger.log(`Setting sandbox mode to ${e} (local).`)
                    }
                }
            }
        },
        lt = class {
            constructor() {
                this.logger = new i("none"), this.code = "sdkNotInitialized", this.message = `CrazySDK is not initialized yet. Check ${a} for more info.`
            }
            get ad() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get banner() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get game() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get user() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get data() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get analytics() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get store() {
                throw console.error(this.message), new h(this.code, this.message)
            }
            get environment() {
                return "uninitialized"
            }
            get isQaTool() {
                return !1
            }
        },
        ht = "SDK Fail mode enabled",
        dt = class {
            constructor(e) {
                this.initReply = e, console.log("%c[CrazyGames SDK] FAIL MODE ENABLED!", "color: red; font-size: 16px; font-weight: bold;", "\nAll the SDK methods will throw errors.")
            }
            get ad() {
                return {
                    prefetchAd: function(e) {
                        console.warn(...s, "prefetchAd is no longer supported and should not be called.")
                    },
                    requestAd: function(e, t) {
                        throw new K("other", ht)
                    },
                    hasAdblock: function() {
                        throw new K("other", ht)
                    },
                    addAdblockPopupListener() {},
                    removeAdblockPopupListener() {},
                    isAdPlaying: !1
                }
            }
            get banner() {
                return {
                    prefetchBanner: function(e) {
                        throw new u("other", ht, e.id)
                    },
                    requestBanner: function(e) {
                        throw new u("other", ht, e.id)
                    },
                    prefetchResponsiveBanner: function(e) {
                        throw new u("other", ht, e.id)
                    },
                    requestResponsiveBanner: function(e) {
                        throw new u("other", ht, e)
                    },
                    renderPrefetchedBanner: function(e) {
                        throw new u("other", ht, e.id)
                    },
                    clearBanner: function(e) {
                        throw new u("other", ht, e)
                    },
                    clearAllBanners: function() {
                        throw new u("other", ht, "")
                    },
                    requestOverlayBanners: function(e, t) {
                        throw new u("other", ht, "")
                    },
                    activeBannersCount: 0
                }
            }
            get game() {
                var e, t;
                return {
                    link: this.initReply.gameLink,
                    id: this.initReply.gameId,
                    settings: {
                        disableChat: !!this.initReply.disableChat,
                        muteAudio: !1
                    },
                    quality: null !== (e = this.initReply.quality) && void 0 !== e ? e : "balanced",
                    isInstantJoin: window.location.search.includes("instantJoin=true"),
                    isInstantMultiplayer: window.location.search.includes("instantJoin=true"),
                    isOfflineMode: null !== (t = this.initReply.offlineGaming) && void 0 !== t && t,
                    inviteParams: null,
                    happytime: function() {
                        throw new h("other", ht)
                    },
                    gameplayStart: function() {
                        throw new h("other", ht)
                    },
                    gameplayStop: function() {
                        throw new h("other", ht)
                    },
                    loadingStart: function() {
                        throw new h("other", ht)
                    },
                    loadingStop: function() {
                        throw new h("other", ht)
                    },
                    reportGameCompletedPercentage: function(e) {
                        throw new h("other", ht)
                    },
                    dailyEvent: function() {
                        throw new h("other", ht)
                    },
                    getLaunchContext: function() {
                        throw new h("other", ht)
                    },
                    inviteLink: function(e) {
                        throw new h("other", ht)
                    },
                    showInviteButton: function(e) {
                        throw new h("other", ht)
                    },
                    hideInviteButton: function() {
                        throw new h("other", ht)
                    },
                    getInviteParam: function(e) {
                        throw new h("other", ht)
                    },
                    addSettingsChangeListener: function() {
                        throw new h("other", ht)
                    },
                    removeSettingsChangeListener: function() {
                        throw new h("other", ht)
                    },
                    addQualityChangeListener: function() {
                        throw new h("other", ht)
                    },
                    removeQualityChangeListener: function() {
                        throw new h("other", ht)
                    },
                    addJoinRoomListener: function() {
                        throw new h("other", ht)
                    },
                    removeJoinRoomListener: function() {
                        throw new h("other", ht)
                    },
                    updateRoom: function(e) {
                        throw new h("other", ht)
                    },
                    leftRoom: function() {
                        throw new h("other", ht)
                    },
                    setGameContext: function(e) {
                        throw new h("other", ht)
                    },
                    clearGameContext: function() {
                        throw new h("other", ht)
                    }
                }
            }
            get user() {
                return {
                    isUserAccountAvailable: !0,
                    systemInfo: this.initReply.systemInfo,
                    showAuthPrompt: function() {
                        throw new se("other", ht)
                    },
                    showAccountLinkPrompt: function() {
                        throw new se("other", ht)
                    },
                    getUser: function() {
                        throw new se("other", ht)
                    },
                    addAuthListener: function(e) {
                        throw new se("other", ht)
                    },
                    removeAuthListener: function(e) {
                        throw new se("other", ht)
                    },
                    getUserToken: function() {
                        throw new se("other", ht)
                    },
                    getXsollaUserToken: function() {
                        throw new se("other", ht)
                    },
                    submitScore: function(e) {
                        throw new se("other", ht)
                    },
                    addScore: function(e) {
                        throw new se("other", ht)
                    },
                    addScoreEncrypted: function(e, t) {
                        throw new se("other", ht)
                    },
                    listFriends: function(e) {
                        throw new se("other", ht)
                    },
                    addFriends: function(e) {
                        throw new se("other", ht)
                    },
                    nudgeFriend: function(e) {
                        throw new se("other", ht)
                    }
                }
            }
            get data() {
                return {
                    clear: function() {
                        throw new ae("other", ht)
                    },
                    getItem: function(e) {
                        throw new ae("other", ht)
                    },
                    removeItem: function(e) {
                        throw new ae("other", ht)
                    },
                    setItem: function(e, t) {
                        throw new ae("other", ht)
                    },
                    syncUnityGameData: function() {
                        throw new ae("other", ht)
                    }
                }
            }
            get analytics() {
                return {
                    trackOrder: function(e, t) {
                        throw new Me("other", ht)
                    }
                }
            }
            get store() {
                return {
                    isAvailable: !1,
                    buyItem: function(e) {
                        throw new Le("other", ht)
                    },
                    getCatalogItems: function(e) {
                        throw new Le("other", ht)
                    },
                    getPlayerInventory: function(e) {
                        throw new Le("other", ht)
                    },
                    consumeItem: function(e, t) {
                        throw new Le("other", ht)
                    },
                    setSandbox: function(e) {
                        throw new Le("other", ht)
                    }
                }
            }
            get environment() {
                return "crazygames"
            }
            get isQaTool() {
                return !1
            }
        };
    class ct {
        constructor(e) {
            this.getDataModule = e
        }
        clear() {
            this.getDataModule().clear()
        }
        getItem(e) {
            return this.getDataModule().getItem(e)
        }
        removeItem(e) {
            this.getDataModule().removeItem(e)
        }
        setItem(e, t) {
            this.getDataModule().setItem(e, t)
        }
        syncUnityGameData() {
            this.getDataModule().syncUnityGameData()
        }
    }
    window.CrazyGames = {
        SDK: new class {
            constructor() {
                this.logger = new i("none"), this.sdk = new lt, this.dataModuleProxy = new ct(() => this.sdk.data)
            }
            async init(t) {
                return this.initializingPromise || (this.initializingPromise = new Promise(async (n, r) => {
                    var o;
                    if (this.logger.log("Request init, options: ", t), ["localhost", "127.0.0.1", "preview.construct.net"].includes(window.location.hostname) || "true" === je("useLocalSdk")) i.forceEnable = !0, this.sdk = new at, await Ne(200);
                    else {
                        const s = await async function() {
                            let e, t = !1;
                            const s = new Promise(t => {
                                    e = t
                                }),
                                n = s => {
                                    var n;
                                    "crazyGamesGFConfirmation" === (null === (n = null == s ? void 0 : s.data) || void 0 === n ? void 0 : n.type) && (_e = s.source, t = !0, e())
                                },
                                r = new Promise(async e => {
                                    await Ne(7e3), e()
                                });
                            window.addEventListener("message", n, !1);
                            const i = {
                                type: "checkCrazyGamesGF"
                            };
                            return window.postMessage(i, "*"), window.parent.postMessage(i, "*"), window.parent.parent.postMessage(i, "*"), window.parent.parent.parent.postMessage(i, "*"), await Promise.race([s, r]), window.removeEventListener("message", n), {
                                isOnCrazyGames: t
                            }
                        }();
                        if (s.isOnCrazyGames) {
                            if (!_e) return r(new h("unexpectedError", "Missing GF_WINDOW, even though running on CrazyGames"));
                            const [s, n] = await Promise.all([Je(t), new Promise(t => {
                                const s = window.setTimeout(() => {
                                        window.removeEventListener("message", n, !1), Xe("gf-user-response-timeout", null, {
                                            timeoutMs: 5e3
                                        }), Oe.error('Gf user response timeout 5000ms, continuing with "null" (signed out) user'), t(null)
                                    }, 5e3),
                                    n = async r => {
                                        var i;
                                        if (!e(r.data)) return;
                                        const o = r.data;
                                        if ("initialUserSet" === o.type) {
                                            Ge.verbose("Received initial user from GF", o), window.clearTimeout(s), window.removeEventListener("message", n, !1);
                                            const e = null !== (i = o.data.user) && void 0 !== i ? i : null;
                                            t(e)
                                        }
                                    };
                                window.addEventListener("message", n, !1)
                            })]);
                            if (null === s) throw new h("initFailed", "The SDK failed to initialize");
                            if (this.logger.log("Init response received from GF", s), s.useFailModule) this.sdk = new dt(s);
                            else {
                                const e = await fe(n, s);
                                this.sdk = new Ue(s, e, n);
                                try {
                                    await Ze(s.rafvertizingUrl, this.sdk, s.clientInfo, null !== (o = s.configCatValues) && void 0 !== o ? o : {})
                                } catch (e) {
                                    Xe("ads-script-load-fail", "ad", {
                                        error: De(e)
                                    }), this.logger.error("Failed to load ads", e)
                                }
                            }
                        } else this.sdk = new Ye
                    }
                    console.log(...s, "CrazyGames HTML SDK initialized", {
                        version: "3.8.0",
                        environment: this.sdk.environment,
                        initOptions: t
                    }), n()
                })), this.initializingPromise
            }
            get instance() {
                return this.sdk
            }
            get ad() {
                return this.sdk.ad
            }
            get banner() {
                return this.sdk.banner
            }
            get game() {
                return this.sdk.game
            }
            get user() {
                return this.sdk.user
            }
            get data() {
                return this.dataModuleProxy
            }
            get analytics() {
                return this.sdk.analytics
            }
            get store() {
                return this.sdk.store
            }
            get environment() {
                return this.sdk.environment
            }
            get isQaTool() {
                return this.sdk.isQaTool
            }
        }
    }, ze.getInstance(), Ve("\n:root {\n  --safe-area-inset-top: env(safe-area-inset-top, 0px);\n  --safe-area-inset-right: env(safe-area-inset-right, 0px);\n  --safe-area-inset-bottom: env(safe-area-inset-bottom, 0px);\n  --safe-area-inset-left: env(safe-area-inset-left, 0px);\n}\n"), Ve("\n.crazygames-banner-container {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 100%;\n}\n")
})();
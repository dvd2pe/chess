(() => {
    "use strict";

    function t(t) {
        return "function" == typeof t
    }

    function e(e) {
        return t(e) ? (...t) => !e(...t) : !e
    }
    let {
        toString: n
    } = Object.prototype;

    function r(t) {
        return "[object Array]" === (null == (e = t) ? void 0 === e ? "[object Undefined]" : "[object Null]" : n.call(e));
        var e
    }

    function i(t, e) {
        if (null != t)
            if ("object" != typeof t && (t = [t]), r(t))
                for (let n = 0, r = t.length; n < r; n++) e.call(null, t[n], n, t);
            else
                for (const n in t) Object.prototype.hasOwnProperty.call(t, n) && e.call(null, t[n], n, t)
    }

    function o() {
        try {
            window.top.document
        } catch {
            return !0
        }
        return !1
    }

    function c() {}
    const s = 0,
        a = 1,
        u = 2,
        l = 3,
        h = -1;

    function b(n, {
        period: r = 1e3,
        context: o,
        args: b = [],
        wind: d = window
    } = {}) {
        if (e(t(n))) return null;
        let g = null,
            w = null,
            m = 0,
            f = null,
            p = r,
            y = c;

        function v() {
            f = Date.now(), n.apply(o, b)
        }

        function O() {
            m += r, v()
        }

        function E() {
            d.clearInterval(g), d.clearTimeout(w), y()
        }
        return {
            state: s,
            getCurrentTime: () => m,
            set() {
                this.state !== a && (g = d.setInterval(O, r), p = r, f = Date.now(), this.state = a)
            },
            start() {
                this.state !== a && (v(), this.set())
            },
            pause() {
                this.state !== a && this.state !== l || (p -= Date.now() - f, E(), this.state = u)
            },
            async resume() {
                if (this.state === u) {
                    this.state = l, f = Date.now();
                    try {
                        await (t = p, new Promise(((e, n) => {
                            w = d.setTimeout(e, t), y = n
                        }))), O(), this.set()
                    } catch {}
                    var t
                }
            },
            reset() {
                E(), this.state = s, m = 0, this.set()
            },
            restart() {
                E(), this.state = s, m = 0, this.start()
            },
            cancel() {
                E(), this.state = h, i(this, ((e, n) => {
                    t(this[n]) && (this[n] = c)
                }))
            }
        }
    }

    function d(e, ...n) {
        if (!t(e)) throw new Error("pipe requires at least one function argument");
        return (...t) => {
            const r = e(...t);
            return n.reduce(((t, e) => e(t)), r)
        }
    }

    function g(t, e) {
        return function n(r) {
            return function(...i) {
                const o = [...r, ...i];
                return o.length >= t ? e(...o) : n(o)
            }
        }([])
    }

    function w(e) {
        return function(e) {
            return null !== e && ("object" == typeof e || t(e))
        }(e) && !t(e) && !r(e)
    }
    const m = g(2, ((t, e) => {
            if (r(e)) return e.map(t);
            if (w(e)) return Object.entries(e).reduce(((e, [n, r]) => Object.assign(e, {
                [n]: t(r, n)
            })), {});
            throw new Error(`Cannot apply map to ${e}`)
        })),
        f = g(2, ((t, e) => {
            if (r(e)) return e.filter(t);
            if (w(e)) return Object.entries(e).reduce(((e, [n, r]) => ({ ...e,
                ...t(r, n) && {
                    [n]: r
                }
            })), {});
            throw new Error(`Cannot apply filter to ${e}`)
        }));

    function p(n, r = "") {
        if (e(t(n))) throw new Error(`${r||n} should be a function!`)
    }
    class y {
        constructor(t, e) {
            this.target = t, this.options = e
        }
        getTarget() {
            return this.target
        }
        hasNativeSupport() {
            return !1
        }
        createObserver() {
            throw new Error("Not implemented!")
        }
        createInterval(t, e = 100) {
            return setInterval(t, e)
        }
        subscribe(t) {
            let e;
            var n, r;
            return p(t, "callback"), this.hasNativeSupport() ? e = this.createObserver(t) : (n = this.createInterval(t), e = {
                disconnect() {
                    clearInterval(n)
                }
            }), r = e, {
                unsubscribe() {
                    r.disconnect()
                }
            }
        }
        subscribeOnce(t) {
            p(t, "callback");
            const e = this.subscribe((() => {
                e.unsubscribe(), t()
            }));
            return e
        }
    }
    class v extends y {
        hasNativeSupport() {
            return !0
        }
        createObserver(t) {
            const e = this.getTarget(),
                n = this.options || {
                    threshold: [0, 1]
                },
                r = new IntersectionObserver((e => {
                    const [n, ...r] = e;
                    t(n)
                }), n);
            return r.observe(e), r
        }
        static createObservable(...t) {
            return new v(...t)
        }
    }

    function O(t) {
        const n = [];
        return function() {
            for (var r = arguments.length, i = new Array(r), o = 0; o < r; o++) i[o] = arguments[o];
            e((t => n.some((e => 0 === e.length ? 0 === t.length : e.every(((e, n) => t[n] === e)))))(i)) && (t(...i), n.push(i))
        }
    }

    function E() {
        const t = function(t) {
            const e = {
                width: 1 / 0,
                height: 1 / 0,
                area: 1 / 0
            };
            try {
                return !Number.isNaN(t.document.body.clientWidth) && t.document.body.clientWidth > 0 && (e.width = t.document.body.clientWidth), !Number.isNaN(t.document.body.clientHeight) && t.document.body.clientHeight > 0 && (e.height = t.document.body.clientHeight), t.document.documentElement && t.document.documentElement.clientWidth && !Number.isNaN(t.document.documentElement.clientWidth) && (e.width = t.document.documentElement.clientWidth), t.document.documentElement && t.document.documentElement.clientHeight && !Number.isNaN(t.document.documentElement.clientHeight) && (e.height = t.document.documentElement.clientHeight), t.innerWidth && !Number.isNaN(t.innerWidth) && (e.width = Math.min(e.width, t.innerWidth)), t.innerHeight && !Number.isNaN(t.innerHeight) && (e.height = Math.min(e.height, t.innerHeight)), e.area = e.height * e.width, e
            } catch (t) {
                return e.width = 0, e.height = 0, e.area = 0, e
            }
        };

        function e(t, n) {
            const r = n,
                i = n.parent;
            let o = {
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            };
            if (t) {
                const n = t.getBoundingClientRect();
                r !== i && (o = e(r.frameElement, i)), o = {
                    left: n.left + o.left,
                    right: n.right + o.left,
                    top: n.top + o.top,
                    bottom: n.bottom + o.top
                }
            }
            return o
        }

        function n(t, r) {
            const i = r,
                o = r.parent;
            let c = {
                width: 0,
                height: 0,
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            };
            if (t) {
                const s = e(t, r);
                if (s.width = s.right - s.left, s.height = s.bottom - s.top, c = s, i !== o) {
                    const t = n(i.frameElement, o);
                    t.bottom < c.bottom && (t.bottom < c.top && (c.top = t.bottom), c.bottom = t.bottom), t.right < c.right && (t.right < c.left && (c.left = t.right), c.right = t.right), c.width = c.right - c.left, c.height = c.bottom - c.top
                }
            }
            return c
        }
        this.getViewabilityState = function(e, r) {
            const i = function() {
                let e = t(window),
                    n = e.area,
                    r = window;
                for (; r !== window.top;) {
                    r = r.parent;
                    const i = t(r);
                    i.area < n && (n = i.area, e = i)
                }
                return e
            }();
            let o;
            if (i.area === 1 / 0) return {
                error: "Failed to determine viewport"
            };
            let c = {
                width: 0,
                height: 0,
                area: 0
            };
            const s = e.getBoundingClientRect(),
                a = s.width * s.height;
            if (i.area / a < .5) o = Math.floor(100 * i.area / a);
            else {
                c = t(window.top);
                const i = n(e, r);
                i.bottom > c.height && (i.height -= i.bottom - c.height), i.top < 0 && (i.height += i.top), i.left < 0 && (i.width += i.left), i.right > c.width && (i.width -= i.right - c.width), o = Math.floor(i.width * i.height * 100 / a)
            }
            return {
                clientWidth: c.width,
                clientHeight: c.height,
                objTop: s.top,
                objBottom: s.bottom,
                objLeft: s.left,
                objRight: s.right,
                percentViewable: o
            }
        }
    }

    function V() {
        const t = new E,
            e = {
                percentObscured: 0,
                percentViewable: 0,
                acceptedViewablePercentage: 50,
                viewabiltyStatus: !1,
                duration: 0
            };

        function n(t, e) {
            const n = t.width * t.height;
            return Math.max(0, Math.min(t.right, e.right) - Math.max(t.left, e.left)) * Math.max(0, Math.min(t.bottom, e.bottom) - Math.max(t.top, e.top)) / n
        }
        this.DEBUG_MODE = !1, this.checkViewability = function(r, i) {
            let o = 0;
            const c = this,
                s = setInterval((() => {
                    ! function(r) {
                        const i = r.getBoundingClientRect();
                        return i.width * i.height >= 242500 && (e.acceptedViewablePercentage = 50), !0 !== function(t) {
                            const e = window.getComputedStyle(t, null),
                                n = e.getPropertyValue("visibility"),
                                r = e.getPropertyValue("display");
                            try {
                                if (void 0 !== window.parent.document.getElementById(window.name) && null != window.parent.document.getElementById(window.name)) {
                                    const t = window.getComputedStyle(window.parent.document.getElementById(window.name), null),
                                        e = t.getPropertyValue("visibility"),
                                        i = t.getPropertyValue("display");
                                    if ("hidden" === n || "none" === r || "hidden" === e || "none" === i) return !0
                                } else if ("hidden" === n || "none" === r) return !0
                            } catch (t) {
                                if ("hidden" === n || "none" === r) return !0
                            }
                            return !1
                        }(r) && !0 !== function(t) {
                            const r = t.getBoundingClientRect(),
                                i = r.left + 12,
                                o = r.right - 12,
                                c = r.top + 12,
                                s = r.bottom - 12,
                                a = Math.floor(r.left + r.width / 2),
                                u = Math.floor(r.top + r.height / 2),
                                l = [{
                                    x: i,
                                    y: c
                                }, {
                                    x: a,
                                    y: c
                                }, {
                                    x: o,
                                    y: c
                                }, {
                                    x: i,
                                    y: u
                                }, {
                                    x: a,
                                    y: u
                                }, {
                                    x: o,
                                    y: u
                                }, {
                                    x: i,
                                    y: s
                                }, {
                                    x: a,
                                    y: s
                                }, {
                                    x: o,
                                    y: s
                                }];
                            for (const i in l)
                                if (l[i] && l[i].x >= 0 && l[i].y >= 0) {
                                    const o = document.elementFromPoint(l[i].x, l[i].y);
                                    if (null !== o && o !== t && !t.contains(o) && n(r, o.getBoundingClientRect()) > 0 && (e.percentObscured = 100 * n(r, o.getBoundingClientRect()), e.percentObscured > e.acceptedViewablePercentage)) return e.percentViewable = 100 - e.percentObscured, !0
                                }
                            return !1
                        }(r) && (function(n) {
                            e.percentObscured = e.percentObscured || 0;
                            const r = t.getViewabilityState(n, window);
                            r.error || (e.percentViewable = r.percentViewable - e.percentObscured)
                        }(r), !(e.percentViewable && e.percentViewable < e.acceptedViewablePercentage || !e.percentViewable))
                    }(r) ? o = 0: o += 1, e.duration = 100 * o, o >= 9 && (e.viewabiltyStatus = !0, c.DEBUG_MODE || clearInterval(s)), i(e)
                }), 100)
        }
    }
    const x = 1,
        I = 2,
        N = 3,
        M = "measurable",
        P = "loadImpression",
        $ = "visualEngagement",
        j = "viewable",
        B = "attention",
        C = [2, 4, 6, 8, 10, 15, 20, 25, 30, 40, 50, 60];
    var S;
    e(t(window.initExteVision)) && (S = {
        initExteVision: async function(n) {
            let {
                slot: c,
                trackers: a
            } = n;
            try {
                const n = function() {
                        let t = window;
                        try {
                            for (; t.parent && t !== t.parent && t.parent.location.href;) t = t.parent
                        } catch {}
                        return t
                    }(),
                    {
                        context: u,
                        $slot: l
                    } = function(e, n) {
                        return o() && t(e ? .$sf ? .ext ? .inViewPercentage) ? {
                            context: I,
                            $slot: n
                        } : o() ? {
                            context: N,
                            $slot: e.document.body
                        } : {
                            context: x,
                            $slot: n
                        }
                    }(n, c),
                    {
                        fire: h
                    } = function(e, n) {
                        const o = function(...e) {
                            if (!e.length) throw new Error("compose requires at least one argument");
                            return function(e) {
                                if (!t(e)) throw new Error("reverseArgs argument must be a function");
                                return (...t) => e(...t.reverse())
                            }(d)(...e)
                        }(m(((t, e) => e === M || e === j ? m((t => `${t}&intgr=${n}`), t) : t)), f((t => r(t))))(e);
                        return {
                            fire: O((function(t, e) {
                                i(o[t], (t => {
                                    var n;
                                    n = e ? `${t}&tm=${e}` : t, new Image(1, 1).src = n
                                }))
                            }))
                        }
                    }(a, u),
                    {
                        loadImpressionObserver: g,
                        visualEngagementObserver: w,
                        viewabilityObserver: p
                    } = function(t, n) {
                        if (t === x) {
                            const t = new V;
                            return {
                                loadImpressionObserver(t) {
                                    const e = v.createObservable(t, {
                                        rootMargin: "150px",
                                        threshold: 0
                                    });
                                    return {
                                        subscribeOnce(t) {
                                            const n = e.subscribe((e => {
                                                let {
                                                    isIntersecting: r
                                                } = e;
                                                r && (n.unsubscribe(), t())
                                            }))
                                        }
                                    }
                                },
                                visualEngagementObserver(t) {
                                    const e = v.createObservable(t, {
                                        treshold: .2
                                    });
                                    return {
                                        subscribeOnce(t) {
                                            const n = e.subscribe((e => {
                                                let {
                                                    isIntersecting: r
                                                } = e;
                                                r && (n.unsubscribe(), t())
                                            }))
                                        }
                                    }
                                },
                                viewabilityObserver: n => ({
                                    subscribe(r) {
                                        t.checkViewability(n, (i => {
                                            let {
                                                viewabiltyStatus: o
                                            } = i;
                                            if (o) {
                                                r();
                                                let i = 1,
                                                    o = 0;
                                                const c = b((() => {
                                                    t.checkViewability(n, (t => {
                                                        let {
                                                            percentViewable: e
                                                        } = t;
                                                        o = e
                                                    })), o >= 50 && e(document.hidden) && (i += 1, i >= C[C.length - 1] && c.cancel(), C.includes(i) && r(i))
                                                }), {
                                                    period: 1e3
                                                });
                                                c.start()
                                            }
                                        }))
                                    }
                                })
                            }
                        }
                        return t === N ? {
                            loadImpressionObserver: t => ({
                                subscribeOnce(e) {
                                    new IntersectionObserver((t => {
                                        t[0].isIntersecting && e()
                                    }), {
                                        root: null,
                                        rootMargin: "150px",
                                        threshold: [0]
                                    }).observe(t)
                                }
                            }),
                            visualEngagementObserver(t) {
                                const e = v.createObservable(t, {
                                    threshold: .2
                                });
                                return {
                                    subscribeOnce(t) {
                                        const n = e.subscribe((e => {
                                            let {
                                                isIntersecting: r
                                            } = e;
                                            r && (n.unsubscribe(), t())
                                        }))
                                    }
                                }
                            },
                            viewabilityObserver: () => ({
                                subscribe(t) {
                                    let e = 0;
                                    const n = b((() => {
                                            e += 1, t(), C.includes(e) && t(e)
                                        }), {
                                            period: 1e3
                                        }),
                                        r = new IntersectionObserver((t => {
                                            e >= C[C.length - 1] && (n.cancel(), r.unobserve(document.body)), t[0].isIntersecting && t[0].isVisible ? n[n.state === s ? "start" : "restart"]() : n.pause()
                                        }), {
                                            root: null,
                                            threshold: [.5],
                                            trackVisibility: !0,
                                            delay: 100
                                        });
                                    r.observe(document.body)
                                }
                            })
                        } : {
                            loadImpressionObserver: () => ({
                                subscribeOnce(t) {
                                    const e = b((() => {
                                        n.$sf.ext.inViewPercentage() > 0 && (e.cancel(), t())
                                    }), {
                                        period: 1e3
                                    });
                                    e.start()
                                }
                            }),
                            visualEngagementObserver: () => ({
                                subscribeOnce(t) {
                                    const e = b((() => {
                                        n.$sf.ext.inViewPercentage() > 20 && (e.cancel(), t())
                                    }), {
                                        period: 1e3
                                    });
                                    e.start()
                                }
                            }),
                            viewabilityObserver: () => ({
                                subscribe(t) {
                                    let r = 0;
                                    const i = b((() => {
                                        n.$sf.ext.inViewPercentage() >= 50 && e(document.hidden) && (t(), r += 1, r >= C[C.length - 1] && i.cancel(), C.includes(r) && t(r))
                                    }), {
                                        period: 1e3
                                    });
                                    i.start()
                                }
                            })
                        }
                    }(u, n);
                h(M), g(l).subscribeOnce((() => h(P))), w(l).subscribeOnce((() => h($))), p(l).subscribe((t => {
                    var e;
                    ! function(t) {
                        return void 0 === t
                    }(e = t) && null !== e ? h(B, t) : h(j)
                }))
            } catch {}
        }
    }, i(S, ((t, e) => {
        window[e] = t
    })))
})();
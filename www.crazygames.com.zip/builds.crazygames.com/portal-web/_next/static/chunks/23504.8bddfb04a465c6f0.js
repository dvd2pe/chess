! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (null != n)
                    for (var s in n) n.hasOwnProperty(s) && (e[s] = n[s])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "1c55d152-140e-4fcf-8580-8767ddfe0252", e._sentryDebugIdIdentifier = "sentry-dbid-1c55d152-140e-4fcf-8580-8767ddfe0252")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [23504], {
        10862: (e, t, n) => {
            "use strict";
            n.d(t, {
                Ff: () => l,
                oq: () => r,
                po: () => i
            });
            let s = null,
                o = new Set;

            function r(e) {
                return (null === s || s === e) && (s = e, !0)
            }

            function i(e) {
                s === e && (s = null, o.forEach(e => e()))
            }

            function l(e) {
                return o.add(e), () => {
                    o.delete(e)
                }
            }
        },
        23504: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => N
            });
            var s = n(6029),
                o = n(75155),
                r = n(55729),
                i = n(77650),
                l = n(79942),
                c = n(8023),
                u = n(54944),
                a = n(71855),
                d = n(14886),
                g = n(45364),
                m = n(71684),
                y = n(10862),
                _ = n(46887);
            let f = n(28478).A.LocalStorage,
                h = "czy_odi_survey_nudge_shown",
                v = {
                    survey1: "https://form.typeform.com/to/oNHJk6JE",
                    survey2: "https://form.typeform.com/to/ofpgJAP4",
                    survey3: "https://form.typeform.com/to/yxFCkYLh",
                    survey4: "https://form.typeform.com/to/U58DjIuy",
                    survey5: "https://form.typeform.com/to/oisz4k9c",
                    survey6: "https://form.typeform.com/to/akOdHu8F"
                },
                w = "odi-survey-nudge";

            function F() {
                return (0, y.po)(w)
            }
            var b = n(41053),
                p = n.n(b);
            let N = () => {
                let e, t, n, b, N, k = (0, o.c)(9),
                    {
                        open: x,
                        onTakeSurvey: E,
                        onClose: S
                    } = function() {
                        let e, t, n, s, i, l, c, u, b = (0, o.c)(18),
                            {
                                user: p,
                                loadingUser: N
                            } = r.useContext(d.R),
                            {
                                crazyAnalyticsService: k
                            } = r.useContext(m.A).services,
                            x = (0, a.U)("czyExpClientOdiSurveyVariant_CZY_21372");
                        b[0] === Symbol.for("react.memo_cache_sentinel") ? (e = window.location.search.includes("forceOdiSurveyNudge"), b[0] = e) : e = b[0];
                        let E = e,
                            S = !N && !p && (E || "disabled" !== x),
                            [I, A] = r.useState(!1),
                            L = r.useRef(!1);
                        I && !S && A(!1), b[1] !== k || b[2] !== S ? (t = () => {
                            if (!S) return;
                            let e = !1,
                                t = () => {
                                    var t;
                                    let n;
                                    !e || L.current || !E && (null !== f.getItem(h) || (t = Date.now(), Number.isFinite(n = parseInt(_.A.get("_czyFirstSeen") || "", 10)) && !(t - n >= 864e5))) || !(g.A.isFullscreen() || g.A.isFakeFullscreen()) && (0, y.oq)(w) && (L.current = !0, f.setItem(h, String(Date.now())), A(!0), k.notificationActionEvent(w, "shown"))
                                },
                                n = window.setTimeout(() => {
                                    e = !0, t()
                                }, 1e4 * !E);
                            g.A.addFullscreenListener(t), g.A.addFakeFullscreenListener(t);
                            let s = (0, y.Ff)(t);
                            return () => {
                                window.clearTimeout(n), g.A.removeFullscreenListener(t), g.A.removeFakeFullscreenListener(t), s()
                            }
                        }, n = [S, E, k], b[1] = k, b[2] = S, b[3] = t, b[4] = n) : (t = b[3], n = b[4]), r.useEffect(t, n), b[5] !== I ? (s = () => {
                            if (I) return F
                        }, i = [I], b[5] = I, b[6] = s, b[7] = i) : (s = b[6], i = b[7]), r.useEffect(s, i), b[8] !== k || b[9] !== x || b[10] !== p ? .uid ? (l = () => {
                            var e, t;
                            let n;
                            k.notificationActionEvent(w, "clicked"), window.open((e = p ? .uid ? ? "", t = k.getUserId(), n = "disabled" === x ? v.survey1 : v[x], `${n}#accountid=${encodeURIComponent(e)}&userid=${encodeURIComponent(t)}`), "_blank", "noopener"), A(!1)
                        }, b[8] = k, b[9] = x, b[10] = p ? .uid, b[11] = l) : l = b[11];
                        let j = l;
                        b[12] !== k ? (c = e => {
                            k.notificationActionEvent(w, "timeout" === e ? "ignored" : "closed"), A(!1)
                        }, b[12] = k, b[13] = c) : c = b[13];
                        let Z = c;
                        return b[14] !== Z || b[15] !== j || b[16] !== I ? (u = {
                            open: I,
                            onTakeSurvey: j,
                            onClose: Z
                        }, b[14] = Z, b[15] = j, b[16] = I, b[17] = u) : u = b[17], u
                    }(),
                    I = (0, c.d)();
                k[0] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, s.jsx)(l.x6, {
                    id: "common.odiSurveyNudge.title"
                }), t = (0, s.jsx)(l.x6, {
                    id: "common.odiSurveyNudge.body"
                }), n = (0, s.jsx)(l.x6, {
                    id: "common.odiSurveyNudge.action"
                }), b = i.Ru._("common.odiSurveyNudge.close"), k[0] = e, k[1] = t, k[2] = n, k[3] = b) : (e = k[0], t = k[1], n = k[2], b = k[3]);
                let A = I ? p().aboveBottomNavigation : void 0;
                return k[4] !== S || k[5] !== E || k[6] !== x || k[7] !== A ? (N = (0, s.jsx)(u.A, {
                    open: x,
                    title: e,
                    body: t,
                    actionLabel: n,
                    closeLabel: b,
                    className: A,
                    onAction: E,
                    onClose: S
                }), k[4] = S, k[5] = E, k[6] = x, k[7] = A, k[8] = N) : N = k[8], N
            }
        },
        41053: e => {
            e.exports = {
                aboveBottomNavigation: "OdiSurveyNudge_aboveBottomNavigation__5rTJx"
            }
        },
        45364: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => o
            });
            class s {
                removeFullscreenListener(e) {
                    this.eventKeys.forEach(t => {
                        document.removeEventListener(t, e)
                    })
                }
                addFullscreenListener(e) {
                    this.eventKeys.forEach(t => {
                        document.addEventListener(t, e)
                    })
                }
                addFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners.push(e)
                }
                removeFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners = this.fakeFullscreenListeners.filter(t => t !== e)
                }
                isFullscreen() {
                    let e = window.document;
                    return !!(e.fullscreenElement || e.mozFullScreenElement || e.webkitFullscreenElement || e.msFullscreenElement)
                }
                isFakeFullscreen() {
                    return this.isInFakeFullscreen
                }
                enteredFakeFullscreen() {
                    this.isInFakeFullscreen || (this.isInFakeFullscreen = !0, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitFakeFullscreen() {
                    this.isInFakeFullscreen && (this.isInFakeFullscreen = !1, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitNativeFullscreen() {
                    let e = window.document,
                        t = e.exitFullscreen || e.mozCancelFullScreen || e.webkitExitFullscreen || e.msExitFullscreen;
                    return !!t && (window.document.fullscreenElement && t.call(e), !0)
                }
                constructor() {
                    this.fakeFullscreenListeners = [], this.eventKeys = ["fullscreenchange", "webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange"], this.isInFakeFullscreen = !1, this.forceLockOrientation = async (e, t) => {
                        if (!t || "BOTH" === t || !("screen" in window) || !window.screen || !window.screen.orientation || !window.screen.orientation.lock) return;
                        let n = null;
                        try {
                            await Promise.race([window.screen.orientation.lock("PORTRAIT" === t ? "portrait" : "landscape"), new Promise((t, s) => {
                                n = setTimeout(() => {
                                    e.trackGenericError("timeoutError", {
                                        message: "Error in orientation lock timeout"
                                    }), s(Error("Orientation lock timeout"))
                                }, 1e3)
                            })])
                        } catch (e) {} finally {
                            n && clearTimeout(n)
                        }
                    }
                }
            }
            let o = new s
        },
        54944: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => m
            });
            var s = n(6029),
                o = n(75155),
                r = n(55729),
                i = n(50212),
                l = n(56760),
                c = n(81930),
                u = n(93800),
                a = n(95848),
                d = n.n(a);
            let g = "crazygames/ziggy_nudge3x.png",
                m = e => {
                    let t, n, a, m, y, _, f, h, v, w, F, b, p, N, k, x, E, S, I, A = (0, o.c)(48),
                        {
                            open: L,
                            title: j,
                            body: Z,
                            actionLabel: C,
                            actionIcon: z,
                            closeLabel: T,
                            autoCloseMs: M,
                            className: O,
                            onAction: R,
                            onClose: B
                        } = e,
                        D = r.useId(),
                        [H, P] = r.useState(L),
                        [U, q] = r.useState(L);
                    if (L !== U && (q(L), L && P(!0)), A[0] !== L ? (t = () => {
                            if (L) return;
                            let e = window.setTimeout(() => P(!1), 200);
                            return () => window.clearTimeout(e)
                        }, n = [L], A[0] = L, A[1] = t, A[2] = n) : (t = A[1], n = A[2]), r.useEffect(t, n), !H || "u" < typeof document) return null;
                    let J = !L && d().leaving;
                    A[3] !== O || A[4] !== J ? (a = (0, i.A)(d().nudge, J, O), A[3] = O, A[4] = J, A[5] = a) : a = A[5];
                    let V = `${void 0===M?2e4:M}ms`;
                    A[6] !== V ? (m = {
                        "--nudge-auto-close-duration": V,
                        "--nudge-transition-duration": "200ms"
                    }, A[6] = V, A[7] = m) : m = A[7];
                    let K = m;
                    return A[8] !== j || A[9] !== D ? (y = (0, s.jsx)("div", {
                        id: D,
                        className: d().title,
                        children: j
                    }), A[8] = j, A[9] = D, A[10] = y) : y = A[10], A[11] !== Z ? (_ = (0, s.jsx)("div", {
                        className: d().body,
                        children: Z
                    }), A[11] = Z, A[12] = _) : _ = A[12], A[13] !== _ || A[14] !== y ? (f = (0, s.jsxs)("div", {
                        className: d().text,
                        children: [y, _]
                    }), A[13] = _, A[14] = y, A[15] = f) : f = A[15], A[16] !== z ? (h = z && (0, s.jsx)(u.A, {
                        name: z,
                        size: 20
                    }), A[16] = z, A[17] = h) : h = A[17], A[18] !== C ? (v = (0, s.jsx)("span", {
                        children: C
                    }), A[18] = C, A[19] = v) : v = A[19], A[20] !== R || A[21] !== h || A[22] !== v ? (w = (0, s.jsxs)("button", {
                        type: "button",
                        className: d().action,
                        onClick: R,
                        children: [h, v]
                    }), A[20] = R, A[21] = h, A[22] = v, A[23] = w) : w = A[23], A[24] !== f || A[25] !== w ? (F = (0, s.jsxs)("div", {
                        className: d().bubble,
                        children: [f, w]
                    }), A[24] = f, A[25] = w, A[26] = F) : F = A[26], A[27] === Symbol.for("react.memo_cache_sentinel") ? (b = (0, s.jsx)("svg", {
                        className: d().tail,
                        width: "26",
                        height: "13",
                        viewBox: "0 0 25.7783 12.9639",
                        "aria-hidden": !0,
                        children: (0, s.jsx)("path", {
                            d: "M25.7783 0C22.7099 4.3149 16.3804 12.13 12.9082 12.9531V12.9629C12.902 12.9615 12.8959 12.9594 12.8896 12.958C12.8821 12.9597 12.8747 12.9622 12.8672 12.9639V12.9521C9.39437 12.1253 3.06752 4.31366 0 0H25.7783Z"
                        })
                    }), A[27] = b) : b = A[27], A[28] !== F ? (p = (0, s.jsxs)("div", {
                        className: d().speech,
                        children: [F, b]
                    }), A[28] = F, A[29] = p) : p = A[29], A[30] !== B ? (N = () => B("dismissed"), A[30] = B, A[31] = N) : N = A[31], A[32] !== B || A[33] !== L ? (k = (0, s.jsx)("svg", {
                        className: d().countdown,
                        viewBox: "0 0 30 30",
                        "aria-hidden": !0,
                        children: (0, s.jsx)("circle", {
                            className: d().countdownRing,
                            cx: "15",
                            cy: "15",
                            r: "12",
                            pathLength: 100,
                            onAnimationEnd: () => {
                                L && B("timeout")
                            }
                        })
                    }), A[32] = B, A[33] = L, A[34] = k) : k = A[34], A[35] === Symbol.for("react.memo_cache_sentinel") ? (x = (0, s.jsx)(u.A, {
                        name: "close",
                        className: d().closeIcon
                    }), A[35] = x) : x = A[35], A[36] !== T || A[37] !== N || A[38] !== k ? (E = (0, s.jsxs)("button", {
                        type: "button",
                        className: d().close,
                        "aria-label": T,
                        onClick: N,
                        children: [k, x]
                    }), A[36] = T, A[37] = N, A[38] = k, A[39] = E) : E = A[39], A[40] === Symbol.for("react.memo_cache_sentinel") ? (S = (0, s.jsx)("img", {
                        className: d().ziggy,
                        src: (0, c.Ay)(g, {
                            width: 153
                        }),
                        srcSet: (0, c.Wn)(g, {
                            width: 153
                        }),
                        width: 153,
                        height: 111,
                        alt: ""
                    }), A[40] = S) : S = A[40], A[41] !== p || A[42] !== E || A[43] !== S || A[44] !== a || A[45] !== K || A[46] !== D ? (I = (0, l.createPortal)((0, s.jsxs)("div", {
                        className: a,
                        role: "dialog",
                        "aria-labelledby": D,
                        style: K,
                        children: [p, E, S]
                    }), document.body), A[41] = p, A[42] = E, A[43] = S, A[44] = a, A[45] = K, A[46] = D, A[47] = I) : I = A[47], I
                }
        },
        95848: e => {
            e.exports = {
                nudge: "ZiggyNudge_nudge__Hr6EJ",
                "nudge-enter": "ZiggyNudge_nudge-enter__e1VRF",
                leaving: "ZiggyNudge_leaving__s_TOI",
                "nudge-leave": "ZiggyNudge_nudge-leave__7qVlB",
                speech: "ZiggyNudge_speech___HOo3",
                bubble: "ZiggyNudge_bubble__ES82b",
                text: "ZiggyNudge_text__Ee_LI",
                title: "ZiggyNudge_title__NaEz3",
                body: "ZiggyNudge_body__ZgC_6",
                action: "ZiggyNudge_action__dgUoI",
                tail: "ZiggyNudge_tail__fibSq",
                close: "ZiggyNudge_close__xqem1",
                closeIcon: "ZiggyNudge_closeIcon__HNDZu",
                countdown: "ZiggyNudge_countdown__a6rBS",
                countdownRing: "ZiggyNudge_countdownRing__gB_vQ",
                "nudge-countdown": "ZiggyNudge_nudge-countdown__SEeGv",
                ziggy: "ZiggyNudge_ziggy__vp6ly"
            }
        }
    }
]);
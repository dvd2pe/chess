! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var o = arguments[t];
                if (null != o)
                    for (var n in o) o.hasOwnProperty(n) && (e[n] = o[n])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "546095a8-b191-42ee-93e8-86b3fc4c2338", e._sentryDebugIdIdentifier = "sentry-dbid-546095a8-b191-42ee-93e8-86b3fc4c2338")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [48200, 82067], {
        3016: e => {
            e.exports = {
                divider: "Divider_divider__rv5PT",
                horizontal: "Divider_horizontal__YEZTp",
                vertical: "Divider_vertical__PF74_",
                my1: "Divider_my1__qn2V_",
                borderBlack50: "Divider_borderBlack50__1TBhI",
                marginTopSpacing: "Divider_marginTopSpacing__G3HQA"
            }
        },
        48200: (e, t, o) => {
            "use strict";
            o.d(t, {
                A: () => s
            });
            var n = o(6029),
                i = o(75155);
            o(55729);
            var l = o(50212),
                a = o(3016),
                r = o.n(a);
            let c = {
                    default: void 0,
                    black50: r().borderBlack50,
                    spacing: r().marginTopSpacing,
                    my1: r().my1
                },
                s = e => {
                    let t, o, a = (0, i.c)(6),
                        {
                            orientation: s,
                            className: d,
                            variant: u
                        } = e,
                        _ = "vertical" === (void 0 === s ? "horizontal" : s) ? r().vertical : r().horizontal,
                        C = c[void 0 === u ? "default" : u];
                    return a[0] !== d || a[1] !== _ || a[2] !== C ? (t = (0, l.A)(r().divider, _, C, d), a[0] = d, a[1] = _, a[2] = C, a[3] = t) : t = a[3], a[4] !== t ? (o = (0, n.jsx)("div", {
                        role: "separator",
                        className: t
                    }), a[4] = t, a[5] = o) : o = a[5], o
                }
        },
        53372: e => {
            e.exports = {
                czyButton: "ControllerNotification_czyButton__1gdZm",
                "czyButton--contained--purple": "ControllerNotification_czyButton--contained--purple__E1KWA",
                "czyButton--contained--white": "ControllerNotification_czyButton--contained--white__VSqkq",
                "czyButton--contained--grey": "ControllerNotification_czyButton--contained--grey__pEpGr",
                "czyButton--contained--warning": "ControllerNotification_czyButton--contained--warning__fTr6n",
                "czyButton--contained--alert": "ControllerNotification_czyButton--contained--alert__QPi1K",
                "czyButton--contained--success": "ControllerNotification_czyButton--contained--success__vLCD7",
                "czyButton--contained--black": "ControllerNotification_czyButton--contained--black__jYx8h",
                "czyButton--contained--green-gradient": "ControllerNotification_czyButton--contained--green-gradient__bZ6XS",
                "czyButton--contained--animated-green-gradient": "ControllerNotification_czyButton--contained--animated-green-gradient__TtSfS",
                "scroll-gradient": "ControllerNotification_scroll-gradient__UvwyV",
                "czyButton--outlined--purple": "ControllerNotification_czyButton--outlined--purple__tsqsP",
                "czyButton--link--purple": "ControllerNotification_czyButton--link--purple__V2Pst",
                "czyButton--outlined--white": "ControllerNotification_czyButton--outlined--white__KzdGA",
                "czyButton--link--white": "ControllerNotification_czyButton--link--white__PRzNE",
                "czyButton--outlined--grey": "ControllerNotification_czyButton--outlined--grey__dC88J",
                "czyButton--link--grey": "ControllerNotification_czyButton--link--grey__Pa1wZ",
                "czyButton--outlined--warning": "ControllerNotification_czyButton--outlined--warning__46LAR",
                "czyButton--link--warning": "ControllerNotification_czyButton--link--warning__rz0wb",
                "czyButton--outlined--alert": "ControllerNotification_czyButton--outlined--alert__SoMoe",
                "czyButton--link--alert": "ControllerNotification_czyButton--link--alert__ZhKWD",
                "czyButton--outlined--success": "ControllerNotification_czyButton--outlined--success__Pe_Rg",
                "czyButton--link--success": "ControllerNotification_czyButton--link--success__dDa5p",
                "czyButton--outlined": "ControllerNotification_czyButton--outlined__0UYta",
                "czyButton--disabled": "ControllerNotification_czyButton--disabled__Ab0fX",
                "czyButton--height50": "ControllerNotification_czyButton--height50__8pYto",
                "czyButton--height34": "ControllerNotification_czyButton--height34__BnaRV",
                "czyButton--height28": "ControllerNotification_czyButton--height28__H0X8b",
                "czyButton--fullWidth": "ControllerNotification_czyButton--fullWidth__OG4Mh",
                "czyButton--headerIcon": "ControllerNotification_czyButton--headerIcon__jfXee",
                "czyButton--headerIcon--desktop": "ControllerNotification_czyButton--headerIcon--desktop__7rQ_q",
                "czyButton--headerIcon--mobile": "ControllerNotification_czyButton--headerIcon--mobile__ML6kw",
                "czyButton--headerIcon--withLabel": "ControllerNotification_czyButton--headerIcon--withLabel__FS3MG",
                button: "ControllerNotification_button__Fno38",
                gamepadIcon: "ControllerNotification_gamepadIcon__fV1VZ",
                title: "ControllerNotification_title__xWebH",
                message: "ControllerNotification_message__e5D7w",
                closeButton: "ControllerNotification_closeButton__lVdbH",
                slidingContainer: "ControllerNotification_slidingContainer__MqCGx",
                open: "ControllerNotification_open__6ftmM",
                notification: "ControllerNotification_notification__x11qH"
            }
        },
        78266: (e, t, o) => {
            "use strict";
            o.d(t, {
                A: () => r
            });
            var n = o(28478);
            let i = "question-notification",
                l = [];
            class a {
                static# e = this.instance = null;
                static getInstance() {
                    return this.instance || (this.instance = new a), this.instance
                }
                constructor() {
                    this.storage = null
                }
                save() {
                    n.A.LocalStorage.setItem(i, JSON.stringify(this.getStorage()))
                }
                questionWasShownToUser(e) {
                    this.updateQuestionData(e, e => ({ ...e,
                        askedTimes: e.askedTimes + 1
                    }))
                }
                questionWasIgnored(e) {
                    this.updateQuestionData(e, e => ({ ...e,
                        ignore: !0
                    }))
                }
                questionPassedSamplingRate(e, t) {
                    this.updateQuestionData(e, e => ({ ...e,
                        passedSamplingRate: t
                    }))
                }
                questionWasAnswered(e) {
                    this.updateQuestionData(e, e => ({ ...e,
                        answered: !0
                    }))
                }
                getQuestionToAsk() {
                    let e = l.find(e => this.shouldShowQuestion(e));
                    return e || null
                }
                shouldShowQuestionNotification(e) {
                    return "en-US" === e && 0 !== l.length && l.some(e => this.shouldShowQuestion(e))
                }
                shouldShowQuestion(e) {
                    let t = e.id,
                        o = this.getStorage()[t],
                        n = void 0 !== e.samplingRate;
                    if (!o) {
                        if (n && Math.random() <= e.samplingRate) this.questionPassedSamplingRate(t, !0);
                        else if (n) return this.questionPassedSamplingRate(t, !1), !1;
                        return !0
                    }
                    return !(n && !o.passedSamplingRate || o.answered || o.ignore || o.askedTimes >= 3)
                }
                getStorage() {
                    if (!this.storage) {
                        let e = n.A.LocalStorage.getItem(i) || "{}";
                        this.storage = JSON.parse(e)
                    }
                    return this.storage
                }
                updateQuestionData(e, t) {
                    let o = this.getStorage(),
                        n = t(o[e] || {
                            askedTimes: 0
                        });
                    o[e] = n, this.save()
                }
            }
            let r = a
        },
        82067: (e, t, o) => {
            "use strict";
            o.r(t), o.d(t, {
                default: () => D
            });
            var n = o(6029),
                i = o(75155),
                l = o(55729),
                a = o(79942),
                r = o(50212),
                c = o(81278),
                s = o(48200),
                d = o(81664),
                u = o(93389),
                _ = o(28478),
                C = o(43711),
                f = o(93800),
                h = o(51196),
                g = o(71684),
                p = o(37434);
            let y = l.memo(e => {
                let {
                    className: t
                } = e;
                return (0, n.jsxs)("svg", {
                    className: t,
                    width: "73",
                    height: "57",
                    viewBox: "0 0 73 57",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, n.jsxs)("g", {
                        filter: "url(#filter0_d_20_692)",
                        children: [(0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M56.1276 7.97304C56.1775 7.82791 56.5568 6.99722 56.6267 6.43676C56.8113 5.01057 48.2769 3.22908 48.0972 4.65527L47.9276 5.99138L56.1276 7.97304Z",
                            fill: "#D0D0D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M18.0821 7.7478C18.0372 7.60268 17.6678 6.76198 17.6029 6.20151C17.4382 4.77032 26.0026 3.11894 26.1623 4.55013L26.312 5.88625L18.0871 7.7478H18.0821Z",
                            fill: "#D0D0D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M37.1822 7.32747C35.9594 7.30245 31.3828 7.18235 30.6691 6.87209C29.8556 6.5168 27.8243 5.15066 27.1954 4.98552C24.8048 4.365 18.1619 5.34082 17.014 7.31746C17.014 7.31746 13.5354 14.5335 12.0331 22.0197C10.5309 29.5009 10.9052 34.4851 11.6388 36.5668C12.3775 38.6486 13.216 39.5093 14.5036 39.6444C15.7913 39.7795 17.2985 39.3842 20.1733 37.5477C23.043 35.7111 24.4754 33.4242 28.0688 32.1281C30.689 31.1823 34.9063 31.1223 36.9975 31.1573C39.0887 31.1523 43.306 31.2774 45.9112 32.2632C49.4797 33.6144 50.8772 35.9213 53.722 37.8029C56.5668 39.6844 58.069 40.1048 59.3567 39.9897C60.6443 39.8746 61.4978 39.0289 62.2713 36.9572C63.0399 34.8854 63.4841 29.9113 62.0967 22.405C60.7092 14.8988 57.3403 7.62772 57.3403 7.62772C56.2274 5.63606 49.5995 4.56017 47.1989 5.14065C46.57 5.29077 44.5188 6.63189 43.7003 6.97217C42.9816 7.27243 38.4049 7.32247 37.1822 7.32747Z",
                            fill: "#BBC6DC"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M37.1822 7.32747C35.9594 7.30245 31.3828 7.18235 30.6691 6.87209C29.8556 6.5168 27.8243 5.15066 27.1954 4.98552C24.8048 4.365 18.1619 5.34082 17.014 7.31746C17.014 7.31746 13.5354 14.5335 12.0331 22.0197C11.4242 25.0773 11.1198 27.7145 11.03 29.9113C11.0899 31.8779 11.3394 33.3291 11.6588 34.2299C12.3975 36.3116 13.2359 37.1723 14.5236 37.3075C15.8112 37.4426 17.3185 37.0422 20.1932 35.2057C23.063 33.3692 24.4954 31.0823 28.0888 29.7862C30.709 28.8404 34.9263 28.7803 37.0175 28.8154C39.1087 28.8154 43.326 28.9355 45.9312 29.9213C49.4997 31.2724 50.8971 33.5793 53.7419 35.4609C56.5867 37.3425 58.089 37.7628 59.3766 37.6477C60.6643 37.5326 61.5227 36.6869 62.2913 34.6152C62.6257 33.7145 62.8952 32.2683 62.9851 30.3066C62.9252 28.1098 62.6656 25.4626 62.1017 22.395C60.7142 14.8888 57.3454 7.61771 57.3454 7.61771C56.2324 5.62605 49.6045 4.55016 47.2039 5.13064C46.575 5.28077 44.5238 6.62188 43.7053 6.96217C42.9866 7.26242 38.4099 7.31246 37.1872 7.31746L37.1822 7.32747Z",
                            fill: "url(#paint0_linear_20_692)"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M23.1578 17.9313C25.259 17.9463 26.9808 16.2449 27.0008 14.1382C27.0157 12.0314 25.3188 10.3 23.2177 10.2849C21.1165 10.2699 19.3897 11.9714 19.3747 14.0781C19.3597 16.1849 21.0566 17.9113 23.1578 17.9313Z",
                            fill: "#B9C1D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M23.1628 16.7804C24.6301 16.7904 25.8329 15.5994 25.8479 14.1282C25.8579 12.6569 24.67 11.4459 23.2027 11.4359C21.7354 11.4259 20.5276 12.6169 20.5176 14.0881C20.5076 15.5594 21.6955 16.7654 23.1628 16.7804Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M44.7683 27.7895C46.8994 27.8045 48.6562 26.0731 48.6712 23.9363C48.6862 21.7995 46.9643 20.0431 44.8282 20.023C42.6971 20.008 40.9453 21.7345 40.9253 23.8763C40.9104 26.013 42.6372 27.7745 44.7683 27.7895Z",
                            fill: "#B9C1D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M44.7783 26.6186C46.2656 26.6286 47.4933 25.4176 47.5033 23.9263C47.5133 22.4351 46.3055 21.204 44.8182 21.194C43.3309 21.184 42.1032 22.39 42.0932 23.8863C42.0832 25.3775 43.291 26.6085 44.7783 26.6186Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M30.7589 27.6994C32.9749 27.7145 34.7915 25.923 34.8065 23.7011C34.8215 21.4843 33.0348 19.6577 30.8188 19.6427C28.6078 19.6277 26.7912 21.4192 26.7712 23.6411C26.7562 25.8579 28.543 27.6844 30.7589 27.6994Z",
                            fill: "#B9C1D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M31.9617 20.6386C31.9018 22.4551 31.9517 22.4851 33.7984 22.4501C33.9531 22.8354 34.0379 23.2558 34.0379 23.6961C34.0379 24.1165 33.9531 24.5218 33.8034 24.8921C31.9218 24.8271 31.8869 24.8571 31.9218 26.7236C31.5624 26.8588 31.1732 26.9288 30.7689 26.9238C30.3147 26.9238 29.8755 26.8237 29.4813 26.6486C29.5411 24.8821 29.4912 24.8121 27.7644 24.8421C27.6246 24.4718 27.5448 24.0664 27.5498 23.6461C27.5498 23.2057 27.6446 22.7854 27.8043 22.4051C29.4962 22.4601 29.5611 22.385 29.5312 20.6736C29.9304 20.5035 30.3646 20.4134 30.8188 20.4134C31.2231 20.4134 31.6074 20.4935 31.9667 20.6336L31.9617 20.6386Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M52.1199 11.6161C53.1779 11.6261 54.0414 10.7653 54.0513 9.70947C54.0613 8.65359 53.2079 7.78286 52.1498 7.77285C51.0917 7.76284 50.2283 8.61856 50.2183 9.67944C50.2084 10.7353 51.0668 11.606 52.1199 11.6161Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M47.8177 15.5543C48.8758 15.5644 49.7392 14.7086 49.7492 13.6478C49.7592 12.5919 48.9058 11.7212 47.8477 11.7111C46.7946 11.7011 45.9262 12.5619 45.9162 13.6177C45.9062 14.6736 46.7597 15.5443 47.8177 15.5543Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M52.055 19.7729C53.1131 19.7829 53.9765 18.9271 53.9865 17.8663C53.9964 16.8054 53.143 15.9397 52.0849 15.9297C51.0319 15.9196 50.1634 16.7754 50.1535 17.8362C50.1435 18.8921 50.9969 19.7628 52.055 19.7729Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M56.1076 15.6143C57.1657 15.6244 58.0291 14.7636 58.0391 13.7078C58.0491 12.6519 57.1956 11.7812 56.1376 11.7711C55.0795 11.7611 54.2161 12.6168 54.2061 13.6777C54.1961 14.7336 55.0495 15.6043 56.1076 15.6143Z",
                            fill: "#767A8E"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M33.7534 16.5402C34.3424 16.5402 34.8265 16.0698 34.8265 15.4793C34.8315 14.8888 34.3573 14.4034 33.7684 14.3984C33.1795 14.3984 32.6954 14.8688 32.6904 15.4593C32.6904 16.0498 33.1595 16.5352 33.7484 16.5352L33.7534 16.5402Z",
                            fill: "#B9C1D0"
                        }), (0, n.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M40.4412 16.6202C41.0451 16.6202 41.5442 16.1348 41.5492 15.5293C41.5492 14.9238 41.0651 14.4234 40.4562 14.4184C39.8523 14.4184 39.3532 14.9038 39.3482 15.5143C39.3432 16.1198 39.8323 16.6202 40.4362 16.6252L40.4412 16.6202Z",
                            fill: "#B9C1D0"
                        })]
                    }), (0, n.jsxs)("defs", {
                        children: [(0, n.jsxs)("filter", {
                            id: "filter0_d_20_692",
                            x: "0.997498",
                            y: "0",
                            width: "71.9981",
                            height: "56.0072",
                            filterUnits: "userSpaceOnUse",
                            colorInterpolationFilters: "sRGB",
                            children: [(0, n.jsx)("feFlood", {
                                floodOpacity: "0",
                                result: "BackgroundImageFix"
                            }), (0, n.jsx)("feColorMatrix", { in: "SourceAlpha",
                                type: "matrix",
                                values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                result: "hardAlpha"
                            }), (0, n.jsx)("feOffset", {
                                dy: "6"
                            }), (0, n.jsx)("feGaussianBlur", {
                                stdDeviation: "5"
                            }), (0, n.jsx)("feComposite", {
                                in2: "hardAlpha",
                                operator: "out"
                            }), (0, n.jsx)("feColorMatrix", {
                                type: "matrix",
                                values: "0 0 0 0 0.320524 0 0 0 0 0.189375 0 0 0 0 0.841667 0 0 0 1 0"
                            }), (0, n.jsx)("feBlend", {
                                mode: "normal",
                                in2: "BackgroundImageFix",
                                result: "effect1_dropShadow_20_692"
                            }), (0, n.jsx)("feBlend", {
                                mode: "normal",
                                in: "SourceGraphic",
                                in2: "effect1_dropShadow_20_692",
                                result: "shape"
                            })]
                        }), (0, n.jsxs)("linearGradient", {
                            id: "paint0_linear_20_692",
                            x1: "37.0075",
                            y1: "4.79999",
                            x2: "37.0075",
                            y2: "37.6653",
                            gradientUnits: "userSpaceOnUse",
                            children: [(0, n.jsx)("stop", {
                                stopColor: "white"
                            }), (0, n.jsx)("stop", {
                                offset: "1",
                                stopColor: "#DDE8FC"
                            })]
                        })]
                    })]
                })
            });
            var m = o(53372),
                v = o.n(m);
            let B = "controllerCloseCounter",
                x = "controllerPreventNotification",
                z = () => {
                    let e, t, o, m, z, w, N, S, j, b, R, k, A, D, M, I, L, Z = (0, i.c)(31),
                        [E, P] = l.useState(!1),
                        {
                            routeHelper: T
                        } = l.useContext(u.A),
                        {
                            pageUrlHelper: q
                        } = l.useContext(h.e),
                        {
                            crazyAnalyticsService: G
                        } = l.useContext(g.A).services;
                    Z[0] !== G || Z[1] !== q ? (e = () => {
                        let e;
                        if (!G) return;
                        let t = q.isOnSpecificTagOrCategoryPage("controller"),
                            o = q.isGamePage(),
                            n = n => {
                                !t && !o && (!n && JSON.parse(_.A.LocalStorage.getItem(x) || "false") || (G.controllerNotificationDisplayed(), P(!0), e = window.setTimeout(() => P(!1), 7e3)))
                            };
                        new URL(window.location.href).searchParams.has("forceController") && n();
                        let i = () => {
                                n(!0)
                            },
                            l = () => {
                                P(!1)
                            };
                        for (let e of (c.Router.events.on("routeChangeStart", l), navigator.getGamepads ? navigator.getGamepads() : []))
                            if (e && e.connected) {
                                n();
                                break
                            }
                        return window.addEventListener("gamepadconnected", i),
                            function() {
                                e && window.clearTimeout(e), window.removeEventListener("gamepadconnected", i), c.Router.events.off("routeChangeStart", l)
                            }
                    }, t = [q, G], Z[0] = G, Z[1] = q, Z[2] = e, Z[3] = t) : (e = Z[2], t = Z[3]), l.useEffect(e, t), Z[4] !== G ? (o = () => {
                        G.controllerNotificationClose();
                        let e = Number(_.A.LocalStorage.getItem(B));
                        e && e + 1 === 3 ? _.A.LocalStorage.setItem(x, "true") : _.A.LocalStorage.setItem(B, (e ? e + 1 : 1).toString()), P(!1)
                    }, Z[4] = G, Z[5] = o) : o = Z[5];
                    let Q = o;
                    Z[6] !== G ? (m = () => {
                        G.controllerNotificationExplore()
                    }, Z[6] = G, Z[7] = m) : m = Z[7];
                    let O = m;
                    Z[8] !== T ? (z = T.tagPageDirectLink("controller"), Z[8] = T, Z[9] = z) : z = Z[9];
                    let F = z;
                    return Z[10] !== E ? (w = (0, r.A)(v().slidingContainer, {
                        [v().open]: E
                    }), Z[10] = E, Z[11] = w) : w = Z[11], Z[12] === Symbol.for("react.memo_cache_sentinel") ? (N = (0, n.jsx)(y, {
                        className: v().gamepadIcon
                    }), Z[12] = N) : N = Z[12], Z[13] === Symbol.for("react.memo_cache_sentinel") ? (S = (0, n.jsx)("div", {
                        className: v().title,
                        children: (0, n.jsx)(a.x6, {
                            id: "common.controller.title"
                        })
                    }), Z[13] = S) : S = Z[13], Z[14] === Symbol.for("react.memo_cache_sentinel") ? (j = (0, n.jsxs)("div", {
                        children: [S, (0, n.jsx)("div", {
                            className: v().message,
                            children: (0, n.jsx)(a.x6, {
                                id: "common.controller.message"
                            })
                        })]
                    }), Z[14] = j) : j = Z[14], Z[15] === Symbol.for("react.memo_cache_sentinel") ? (b = (0, n.jsx)(a.x6, {
                        id: "common.controller.button"
                    }), Z[15] = b) : b = Z[15], Z[16] !== O ? (R = (0, n.jsx)(p.A, {
                        variant: "contained",
                        color: "white",
                        height: 34,
                        onClick: O,
                        children: b
                    }), Z[16] = O, Z[17] = R) : R = Z[17], Z[18] !== F || Z[19] !== R ? (k = (0, n.jsx)(C.A, { ...F,
                        className: v().button,
                        children: R
                    }), Z[18] = F, Z[19] = R, Z[20] = k) : k = Z[20], Z[21] === Symbol.for("react.memo_cache_sentinel") ? (A = (0, n.jsx)(s.A, {
                        orientation: "vertical"
                    }), Z[21] = A) : A = Z[21], Z[22] === Symbol.for("react.memo_cache_sentinel") ? (D = (0, n.jsx)(f.A, {
                        name: "close",
                        size: 20
                    }), Z[22] = D) : D = Z[22], Z[23] !== Q ? (M = (0, n.jsx)(d.A, {
                        className: v().closeButton,
                        onClick: Q,
                        "aria-label": "Close",
                        children: D
                    }), Z[23] = Q, Z[24] = M) : M = Z[24], Z[25] !== k || Z[26] !== M ? (I = (0, n.jsxs)("div", {
                        className: v().notification,
                        children: [N, j, k, A, M]
                    }), Z[25] = k, Z[26] = M, Z[27] = I) : I = Z[27], Z[28] !== I || Z[29] !== w ? (L = (0, n.jsx)("div", {
                        className: w,
                        children: I
                    }), Z[28] = I, Z[29] = w, Z[30] = L) : L = Z[30], L
                };
            var w = o(71024),
                N = o.n(w),
                S = o(50190),
                j = o(61411),
                b = o(74198),
                R = o(78266);
            let k = N()(() => Promise.all([o.e(61019), o.e(30483), o.e(46804)]).then(o.bind(o, 46804)), {
                    loadableGenerated: {
                        webpack: () => [46804]
                    },
                    loading: () => null,
                    ssr: !1
                }),
                A = () => {
                    let e = (0, i.c)(1),
                        t = (0, S.A)(),
                        {
                            locale: o
                        } = l.useContext(b.A),
                        {
                            pageUrlHelper: a
                        } = l.useContext(h.e),
                        r = a.routeData.hostname,
                        c = r ? (0, j.cy)(r) : o;
                    if (!t || a.isOnPreviewPage()) return null;
                    if (R.A.getInstance().shouldShowQuestionNotification(c)) {
                        let t;
                        return e[0] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, n.jsx)(k, {}), e[0] = t) : t = e[0], t
                    }
                    return null
                },
                D = () => {
                    let e, t = (0, i.c)(1);
                    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, n.jsxs)(n.Fragment, {
                        children: [(0, n.jsx)(A, {}), (0, n.jsx)(z, {})]
                    }), t[0] = e) : e = t[0], e
                }
        }
    }
]);
! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                if (null != r)
                    for (var a in r) r.hasOwnProperty(a) && (e[a] = r[a])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "a333a561-724f-42a0-b290-308ff2019fdf", e._sentryDebugIdIdentifier = "sentry-dbid-a333a561-724f-42a0-b290-308ff2019fdf")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [20299, 95325], {
        20299: (e, t, r) => {
            "use strict";
            r.d(t, {
                cy: () => K,
                Ay: () => B,
                qF: () => G
            });
            var a = r(6029),
                n = r(75155),
                i = r(55729),
                s = r(7234),
                o = r(55654),
                l = r(98417),
                u = r(71727),
                c = r(24615),
                d = r(88047),
                f = r(14434),
                g = r(81278),
                p = r(58312),
                m = r(13246),
                h = r(46861),
                y = r(68402),
                w = r(42191),
                v = r(33165),
                S = r(31211),
                A = r(51196),
                b = r(10945),
                I = r(33052),
                k = r(28478),
                C = r(81556),
                P = r.n(C),
                _ = r(86381),
                O = r(54805),
                E = r(4230),
                M = r(50293),
                N = r(61411),
                L = r(1372),
                D = r(45684),
                x = r(60574),
                R = r(71237),
                T = r(23348),
                U = r(74198),
                $ = r(71684),
                j = r(74532),
                q = r(95325),
                z = r(56064),
                F = r(14886);
            let K = i.createContext({
                    loginHasStarted: !1,
                    setLoginHasStarted: () => {},
                    setMessage: () => {},
                    logout: async () => {},
                    triggerLogin: () => Promise.resolve(!0),
                    loading: !1,
                    setLoading: () => {}
                }),
                G = async () => {
                    if ((0, p.q)()) try {
                        let e = await fetch(`${m.A.Instance.data.userPortal}/auth/session-logout`, {
                            method: "POST",
                            credentials: "include"
                        });
                        if (!e.ok) throw Error(`Session-logout failed: ${e.status}`);
                        await (0, y.m)()
                    } catch (e) {
                        console.error("session-logout", e)
                    }
                },
                Z = async () => {
                    (0, p.q)() && await G()
                },
                V = async e => {
                    if (!(0, p.q)()) try {
                        let t = await fetch(`${m.A.Instance.data.userPortal}/auth/session-login`, {
                            method: "POST",
                            headers: {
                                Authorization: `Bearer ${await e.getIdToken()}`,
                                "Content-Type": "application/json"
                            },
                            credentials: "include"
                        });
                        if (!t.ok) throw Error(`Session-login failed: ${t.status}`);
                        await (0, y.m)()
                    } catch (e) {
                        console.error("session-login", e)
                    }
                },
                B = e => {
                    let t, r, m, y, C, G, B, J, H, W, Y, Q, X, ee, et = (0, n.c)(56),
                        {
                            setUser: er,
                            setIsNewUser: ea,
                            setLoadingUser: en,
                            setUserTokenExists: ei
                        } = i.useContext(F.R),
                        {
                            openDrawer: es
                        } = i.useContext(v.lv),
                        {
                            openedDrawer: eo
                        } = i.useContext(v.l9),
                        {
                            locale: el
                        } = i.useContext(U.A),
                        [eu, ec] = i.useState(!1),
                        {
                            analyticsService: ed,
                            crazyAnalyticsService: ef
                        } = i.useContext($.A).services,
                        {
                            countryCode: eg
                        } = i.useContext(j.A),
                        ep = (0, g.useRouter)(),
                        em = i.useContext(E.A),
                        [eh, ey] = (0, i.useState)(),
                        [ew, ev] = (0, i.useState)(!1),
                        eS = (0, d.x$)(),
                        {
                            forceRefetch: eA
                        } = R.Jd(),
                        [eb] = (0, s.n)(_.Ii),
                        {
                            pageUrlHelper: eI
                        } = i.useContext(A.e);
                    et[0] !== eI ? (t = eI.isOnDeleteAccount(), et[0] = eI, et[1] = t) : t = et[1];
                    let ek = t,
                        {
                            recordNow: eC
                        } = (0, D.Y)(),
                        {
                            syncGuestScores: eP
                        } = (ee = (0, b.m)(), {
                            syncGuestScores: async () => {
                                try {
                                    let e = Object.keys(localStorage).filter(e => e.startsWith(I.hl)).map(async e => {
                                        try {
                                            let t = k.A.LocalStorage.getItem(e);
                                            if (!t) return;
                                            let {
                                                gameId: r,
                                                encryptedScore: a,
                                                timestamp: n
                                            } = JSON.parse(t);
                                            if (!r || !a || !n) throw Error("Missing required fields");
                                            let i = new Date(n);
                                            if (isNaN(i.getTime())) throw Error(`Invalid timestamp: ${n}`);
                                            (new Date().getTime() - i.getTime()) / 36e5 <= I.Z4 && await ee.mutate({
                                                mutation: P(),
                                                variables: {
                                                    input: {
                                                        gameId: r,
                                                        encryptedScore: a,
                                                        timestamp: n
                                                    }
                                                },
                                                errorPolicy: "ignore"
                                            })
                                        } catch (t) {
                                            console.error(`Failed to sync guest score from ${e}:`, t)
                                        } finally {
                                            k.A.LocalStorage.removeItem(e)
                                        }
                                    });
                                    await Promise.allSettled(e)
                                } catch (e) {
                                    console.error("Error syncing guest scores:", e)
                                }
                            }
                        }),
                        e_ = (0, w.i)("portal-auth"),
                        eO = i.useRef(eo);
                    et[2] !== eo ? (r = () => {
                        eO.current = eo
                    }, m = [eo], et[2] = eo, et[3] = r, et[4] = m) : (r = et[3], m = et[4]), i.useEffect(r, m), et[5] !== ed || et[6] !== eg || et[7] !== ef || et[8] !== em || et[9] !== eA || et[10] !== e_.persist || et[11] !== es || et[12] !== eC || et[13] !== ep || et[14] !== ea || et[15] !== ek || et[16] !== eP || et[17] !== eb ? (y = async (e, t) => {
                        ey(void 0), k.A.LocalStorage.setItem(S.r_, "true"), k.A.LocalStorage.setItem(S.zW, "true");
                        let r = !1,
                            a = (0, f.getAdditionalUserInfo)(e);
                        a && a.isNewUser ? (ea("yes"), await eA(), (0, l.O)(eg) && await eb({
                            variables: {
                                input: {
                                    countryCode: eg
                                }
                            }
                        }), r = !0, (0, L.i8)(e.user) && await q.firebaseAuth.currentUser ? .reload()) : ea("no"), eC(!0), await eP(), ef.userAction("authentication", "auth_success", r ? "new" : "returning"), ed.trackSignIn(r);
                        let n = eO.current ? .drawer === "appOnboarding";
                        if (e_.persist.log("User logged in", {
                                isNewUser: r,
                                isInAppOnboarding: n,
                                openedDrawer: eO.current ? .drawer
                            }), n) return !0;
                        let i = (0, M.Gz)(em) ? (0, O.KE)() : void 0,
                            s = t ? .redirectUrl || i;
                        return r ? es("authUsernameSelector", {
                            inMainContent: !1
                        }) : ek ? es("deleteAccount") : eO.current ? .params ? .openDrawerAfterLogin ? es(eO.current.params.openDrawerAfterLogin) : s ? (es(null), ep.push(s)) : eO.current ? .inMainContent || es(null), !0
                    }, et[5] = ed, et[6] = eg, et[7] = ef, et[8] = em, et[9] = eA, et[10] = e_.persist, et[11] = es, et[12] = eC, et[13] = ep, et[14] = ea, et[15] = ek, et[16] = eP, et[17] = eb, et[18] = y) : y = et[18];
                    let eE = y;
                    et[19] !== ed || et[20] !== eA || et[21] !== e_.persist || et[22] !== ew || et[23] !== ea || et[24] !== en || et[25] !== er || et[26] !== ei ? (C = () => {
                        let e = async e => {
                                e ? ((0, T.kg)(e), (0, c.gV)({
                                    id: e.uid
                                }), (0, h.yj)(e.uid), await V(e), ei((0, p.q)()), ew && e ? .metadata.lastSignInTime === e ? .metadata.creationTime && await eA(), er(e), (0, x.C$)(e.uid, e.email), ed.setUserLoggedIn(e.uid), ew || ea("no")) : (er(null), ea("unknown"), (0, x.sZ)(), (0, T.kg)(), (0, c.gV)(null), (0, h.yj)(null), await Z(), ei(!1)), en(!1)
                            },
                            t = (0, f.onAuthStateChanged)(q.firebaseAuth, t => {
                                e(t).catch(e => {
                                    e_.persist.error("Auth state change handling failed", {
                                        error: (0, u.M)(e)
                                    }), en(!1)
                                })
                            });
                        return function() {
                            t()
                        }
                    }, et[19] = ed, et[20] = eA, et[21] = e_.persist, et[22] = ew, et[23] = ea, et[24] = en, et[25] = er, et[26] = ei, et[27] = C) : C = et[27], et[28] !== ed || et[29] !== ef || et[30] !== eA || et[31] !== e_.persist || et[32] !== ew || et[33] !== ea || et[34] !== en || et[35] !== er || et[36] !== ei ? (G = [er, ea, ew, ed, en, ei, ef, eA, e_.persist], et[28] = ed, et[29] = ef, et[30] = eA, et[31] = e_.persist, et[32] = ew, et[33] = ea, et[34] = en, et[35] = er, et[36] = ei, et[37] = G) : G = et[37], (0, i.useEffect)(C, G), et[38] !== el ? (B = () => {
                        if (!el) return;
                        let e = (0, o.lR)((0, N.qz)(el));
                        q.firebaseAuth.languageCode = e
                    }, J = [el], et[38] = el, et[39] = B, et[40] = J) : (B = et[39], J = et[40]), (0, i.useEffect)(B, J), et[41] !== ei ? (H = () => {
                        ei((0, p.q)())
                    }, W = [ei], et[41] = ei, et[42] = H, et[43] = W) : (H = et[42], W = et[43]), (0, i.useEffect)(H, W), et[44] !== e_.persist || et[45] !== eS ? (Y = async e => {
                        if (eS.isIdentified()) try {
                            await eS.reset()
                        } catch (e) {
                            console.error("SuprSend reset failed during logout", e)
                        }
                        await (0, z.r)(e), e_.persist.log("User logged out")
                    }, et[44] = e_.persist, et[45] = eS, et[46] = Y) : Y = et[46];
                    let eM = Y;
                    et[47] !== eM || et[48] !== eu || et[49] !== ew || et[50] !== eh || et[51] !== eE ? (Q = {
                        errorMessage: eh,
                        loading: eu,
                        setLoading: ec,
                        setMessage: ey,
                        triggerLogin: eE,
                        logout: eM,
                        loginHasStarted: ew,
                        setLoginHasStarted: ev
                    }, et[47] = eM, et[48] = eu, et[49] = ew, et[50] = eh, et[51] = eE, et[52] = Q) : Q = et[52];
                    let eN = Q;
                    return et[53] !== eN || et[54] !== e.children ? (X = (0, a.jsx)(K.Provider, {
                        value: eN,
                        children: e.children
                    }), et[53] = eN, et[54] = e.children, et[55] = X) : X = et[55], X
                }
        },
        33052: (e, t) => {
            "use strict";
            t.Ss = t.hl = t.Z4 = void 0, t.Z4 = 24, t.hl = "guest_score_", t.Ss = e => `${t.hl}${e}`
        },
        42191: (e, t, r) => {
            "use strict";
            r.d(t, {
                i: () => i
            });
            var a = r(55729),
                n = r(30815);

            function i(e) {
                let {
                    createClientSideLogger: t
                } = a.useContext(n.p);
                return a.useMemo(() => t(e), [t, e])
            }
        },
        54805: (e, t, r) => {
            "use strict";
            r.d(t, {
                Cf: () => s,
                KE: () => l,
                KZ: () => i,
                dy: () => o
            });
            var a = r(13246),
                n = r(70792);

            function i(e) {
                let t;
                try {
                    t = new URL(e)
                } catch {
                    return !1
                }
                if ("http:" !== t.protocol && "https:" !== t.protocol) return !1;
                let r = t.hostname;
                return a.A.Instance.data.domains.some(e => (0, n.sc)(e.host) === (0, n.sc)(r))
            }
            let s = "/";

            function o(e, t, r) {
                let a = new URL(e);
                return a.search = "", a.searchParams.set("drawer", t), r && a.searchParams.set("preSelectedEmail", r), a.toString()
            }

            function l() {
                let {
                    pathname: e,
                    search: t,
                    hash: r
                } = window.location, a = r.includes("?") ? r.slice(r.indexOf("?")) : "";
                return e + (t || a)
            }
        },
        60402: (e, t, r) => {
            "use strict";
            r.d(t, {
                F: () => i
            });
            var a = r(98417),
                n = r(78354);

            function i(e) {
                if (!(0, a.O)(e)) return null;
                let t = e.trim().toLowerCase().replace(/\+[^@]*@/g, "@");
                return (0, n.j)(t) ? null : t
            }
        },
        60574: (e, t, r) => {
            "use strict";
            r.d(t, {
                C$: () => f,
                H7: () => d,
                jU: () => g,
                sZ: () => p
            });
            var a = r(8660),
                n = r(67989),
                i = r(60402),
                s = r(78354),
                o = r(98417),
                l = r(72232),
                u = r(28478);
            let c = "czy_user_identity";

            function d() {
                if ("u" < typeof document) return;
                if ("true" !== (0, l.R)(a.j)) return void p();
                let e = u.A.LocalStorage.getItem(c) ? ? "";
                if ((0, s.j)(e)) return;
                let t = (e => {
                    try {
                        let t = JSON.parse(e),
                            r = (0, i.F)(t.email);
                        return (0, s.y)(t.userId) && (0, o.O)(r) ? {
                            userId: t.userId,
                            email: r
                        } : null
                    } catch {
                        return null
                    }
                })(e);
                return (0, o.O)(t) ? t : void p()
            }

            function f(e, t) {
                let r = (0, i.F)(t);
                (0, s.y)(e) && (0, o.O)(r) ? u.A.LocalStorage.setItem(c, JSON.stringify({
                    userId: e,
                    email: r
                })): p()
            }

            function g() {
                let e = d();
                return (0, o.O)(e) ? {
                    [n.RU]: e.email
                } : {}
            }

            function p() {
                u.A.LocalStorage.removeItem(c)
            }
        },
        81556: e => {
            e.exports = {
                kind: "Document",
                definitions: [{
                    kind: "OperationDefinition",
                    operation: "mutation",
                    name: {
                        kind: "Name",
                        value: "SaveGuestScore"
                    },
                    variableDefinitions: [{
                        kind: "VariableDefinition",
                        variable: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "input"
                            }
                        },
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SaveGuestScoreInput"
                                }
                            }
                        },
                        directives: []
                    }],
                    directives: [],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "saveGuestScore"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "input"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "input"
                                    }
                                }
                            }],
                            directives: []
                        }]
                    }
                }]
            }
        },
        95325: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                appleProvider: () => p,
                facebookProvider: () => g,
                firebaseAuth: () => d,
                googleProvider: () => f
            });
            var a = r(11286);
            (0, a.KO)("firebase", "12.9.0", "app");
            var n = r(14434),
                i = r(7846),
                s = r(13246);
            let o = {
                    apiKey: s.A.Instance.data.firebase.apiKey,
                    authDomain: s.A.Instance.data.firebase.authDomain,
                    projectId: s.A.Instance.data.firebase.projectId,
                    storageBucket: s.A.Instance.data.firebase.storageBucket,
                    messagingSenderId: s.A.Instance.data.firebase.messagingSenderId,
                    appId: s.A.Instance.data.firebase.appId
                },
                l = (0, a.Wp)(o),
                u = ["Mobile Safari", "Safari"].includes((0, i.d)().device ? .browser.name ? ? ""),
                c = "localhost" === window.location.hostname,
                d = (0, n.initializeAuth)(l, {
                    persistence: [n.browserLocalPersistence],
                    popupRedirectResolver: u || c ? n.browserPopupRedirectResolver : void 0,
                    errorMap: n.prodErrorMap
                }),
                f = new n.GoogleAuthProvider,
                g = new n.FacebookAuthProvider,
                p = new n.OAuthProvider("apple.com");
            p.addScope("email"), p.addScope("name")
        }
    }
]);
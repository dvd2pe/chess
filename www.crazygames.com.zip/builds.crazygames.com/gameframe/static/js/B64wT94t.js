! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "613c62f9-aa18-530f-89ff-dad6b6e16c6c")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `6154f25e-01c8-4a4f-baa7-b0b2aa93bb5c`, e._sentryDebugIdIdentifier = `sentry-dbid-6154f25e-01c8-4a4f-baa7-b0b2aa93bb5c`)
    } catch {}
})();
import {
    $ as e,
    At as t,
    Ct as n,
    Et as r,
    Ft as i,
    Q as a,
    Rt as o,
    Sn as s,
    T as c,
    Vt as l,
    Wt as u,
    Y as d,
    Z as f,
    _n as p,
    _t as m,
    cn as h,
    d as g,
    f as _,
    ft as v,
    gn as y,
    it as b,
    kt as x,
    l as S,
    mt as C,
    on as w,
    p as T,
    q as E,
    u as D,
    yn as O
} from "../../bundle.js";

function k(e, t, n) {
    let [r, i] = D(n ? .in, e, t), a = A(r, i), o = Math.abs(S(r, i));
    r.setDate(r.getDate() - a * o);
    let s = a * (o - Number(A(r, i) === -a));
    return s === 0 ? 0 : s
}

function A(e, t) {
    let n = e.getFullYear() - t.getFullYear() || e.getMonth() - t.getMonth() || e.getDate() - t.getDate() || e.getHours() - t.getHours() || e.getMinutes() - t.getMinutes() || e.getSeconds() - t.getSeconds() || e.getMilliseconds() - t.getMilliseconds();
    return n < 0 ? -1 : n > 0 ? 1 : n
}

function j(e) {
    return t => {
        let n = (e ? Math[e] : Math.trunc)(t);
        return n === 0 ? 0 : n
    }
}

function M(e, t, n) {
    let [r, i] = D(n ? .in, e, t), a = (r - +i) / _;
    return j(n ? .roundingMethod)(a)
}

function N(e, t) {
    return g(e) - +g(t)
}

function P(e, t, n) {
    let r = N(e, t) / T;
    return j(n ? .roundingMethod)(r)
}

function F(e, t, n) {
    let r = N(e, t) / 1e3;
    return j(n ? .roundingMethod)(r)
}
var I = s(O()),
    L = h(),
    R = {
        footerButton: `_footerButton_1xewu_1`,
        isInert: `_isInert_1xewu_24`,
        isActive: `_isActive_1xewu_34`,
        footerButtonLabel: `_footerButtonLabel_1xewu_50`,
        footerButtonIcon: `_footerButtonIcon_1xewu_53`,
        spin: `_spin_1xewu_53`,
        rotate: `_rotate_1xewu_1`,
        "footerButton--start": `_footerButton--start_1xewu_56`,
        "footerButton--end": `_footerButton--end_1xewu_60`,
        "footerButton--success": `_footerButton--success_1xewu_64`,
        "footerButton--warning": `_footerButton--warning_1xewu_67`,
        "footerButton--error": `_footerButton--error_1xewu_70`
    },
    z = y();

function B() {
    document.getElementById(r) ? .contentWindow ? .focus()
}
var V = I.forwardRef((e, t) => {
        let n = (0, L.c)(22),
            {
                icon: r,
                children: i,
                label: a,
                onClick: o,
                isActive: s,
                status: c,
                spinIcon: l,
                segment: u,
                isInert: f,
                disabled: p,
                testId: m,
                id: h
            } = e,
            g = c && R[`footerButton--${c}`],
            _ = u && R[`footerButton--${u}`],
            v = s && R.isActive,
            y = f && R.isInert,
            b;
        n[0] !== g || n[1] !== _ || n[2] !== v || n[3] !== y ? (b = C(R.footerButton, g, _, v, y), n[0] = g, n[1] = _, n[2] = v, n[3] = y, n[4] = b) : b = n[4];
        let x;
        n[5] === o ? x = n[6] : (x = e => {
            o(e), e.currentTarget.blur(), B()
        }, n[5] = o, n[6] = x);
        let S;
        n[7] !== i || n[8] !== r || n[9] !== l ? (S = i ? ? (r && (0, z.jsx)(d, {
            name: r,
            size: `small`,
            className: C(R.footerButtonIcon, l && R.spin)
        })), n[7] = i, n[8] = r, n[9] = l, n[10] = S) : S = n[10];
        let w;
        n[11] === a ? w = n[12] : (w = a != null && (0, z.jsx)(`span`, {
            className: R.footerButtonLabel,
            children: a
        }), n[11] = a, n[12] = w);
        let T;
        return n[13] !== p || n[14] !== h || n[15] !== t || n[16] !== b || n[17] !== x || n[18] !== S || n[19] !== w || n[20] !== m ? (T = (0, z.jsxs)(`button`, {
            type: `button`,
            "data-testid": m,
            id: h,
            className: b,
            ref: t,
            onClick: x,
            disabled: p,
            children: [S, w]
        }), n[13] = p, n[14] = h, n[15] = t, n[16] = b, n[17] = x, n[18] = S, n[19] = w, n[20] = m, n[21] = T) : T = n[21], T
    }),
    H = {
        root: `_root_mbhy4_7`,
        button: `_button_mbhy4_14`,
        landscape: `_landscape_mbhy4_29`,
        inert: `_inert_mbhy4_32`,
        icon: `_icon_mbhy4_37`,
        success: `_success_mbhy4_43`,
        warning: `_warning_mbhy4_46`,
        error: `_error_mbhy4_49`,
        spin: `_spin_mbhy4_61`,
        rotate: `_rotate_mbhy4_1`
    },
    U = e => {
        let t = (0, L.c)(17),
            {
                icon: n,
                children: r,
                iconSize: i,
                onClick: a,
                tone: o,
                spinIcon: s,
                landscape: c,
                inert: l,
                disabled: u,
                testId: d
            } = e,
            f = c && H.landscape,
            p = l && H.inert,
            m;
        t[0] !== f || t[1] !== p ? (m = C(H.button, f, p), t[0] = f, t[1] = p, t[2] = m) : m = t[2];
        let h;
        t[3] === a ? h = t[4] : (h = e => {
            a(e), e.currentTarget.blur(), B()
        }, t[3] = a, t[4] = h);
        let g;
        t[5] !== r || t[6] !== n || t[7] !== i || t[8] !== s || t[9] !== o ? (g = r ? ? (n && (0, z.jsx)(v, {
            name: n,
            size: i,
            className: C(H.icon, o && H[o], s && H.spin)
        })), t[5] = r, t[6] = n, t[7] = i, t[8] = s, t[9] = o, t[10] = g) : g = t[10];
        let _;
        return t[11] !== u || t[12] !== m || t[13] !== h || t[14] !== g || t[15] !== d ? (_ = (0, z.jsx)(`div`, {
            className: H.root,
            children: (0, z.jsx)(`button`, {
                type: `button`,
                "data-testid": d,
                className: m,
                onClick: h,
                disabled: u,
                children: g
            })
        }), t[11] = u, t[12] = m, t[13] = h, t[14] = g, t[15] = d, t[16] = _) : _ = t[16], _
    };

function W(e) {
    let t = (0, L.c)(3),
        [n, r] = (0, I.useState)(G),
        [i, a] = (0, I.useState)(e);
    i !== e && (a(e), e && r(new Date));
    let o, s;
    return t[0] === e ? (o = t[1], s = t[2]) : (o = () => {
        if (!e) return;
        let t = window.setInterval(() => {
            r(new Date)
        }, 1e3);
        return () => window.clearInterval(t)
    }, s = [e], t[0] = e, t[1] = o, t[2] = s), (0, I.useEffect)(o, s), n
}

function G() {
    return new Date
}
var K = {
    default: `cloud-default`,
    offline: `cloud-offline`,
    issue: `cloud-issue`,
    uploaded: `cloud-uploaded`,
    syncing: `refresh`
};

function q(e) {
    switch (e) {
        case `success`:
            return `cloud_check`;
        case `warning`:
        case `error`:
            return `cloud_error`;
        default:
            return `cloud`
    }
}

function J(e, t) {
    let n = F(e, t);
    if (n < 60) return n === 1 ? p._(`secondAgo`, {
        value: n
    }) : p._(`secondsAgo`, {
        value: n
    });
    if (n < 3600) {
        let n = P(e, t);
        return n === 1 ? p._(`minuteAgo`, {
            value: n
        }) : p._(`minutesAgo`, {
            value: n
        })
    }
    if (n < 3600 * 24) {
        let n = M(e, t);
        return n === 1 ? p._(`hourAgo`, {
            value: n
        }) : p._(`hoursAgo`, {
            value: n
        })
    }
    let r = k(e, t);
    return r === 1 ? p._(`dayAgo`, {
        value: r
    }) : p._(`daysAgo`, {
        value: r
    })
}
var Y = e => {
        let t = (0, L.c)(21),
            {
                isMobileBar: r,
                isLandscape: a
            } = e,
            {
                iconsStatus: s,
                progressSyncHandler: d
            } = I.useContext(x),
            {
                accountId: h
            } = I.useContext(i),
            [g, _] = (0, I.useState)(!1),
            {
                isFullscreen: v,
                disableFullscreen: y
            } = I.useContext(c),
            b = m(),
            S = W(g);
        if ((b === `unknown` || d === `none`) && !n()) return null;
        let C;
        t[0] !== h || t[1] !== S || t[2] !== s.lastSaveAt || t[3] !== s.lastSyncType || t[4] !== s.status ? (C = () => {
            let e = ``,
                t = ``,
                n, r = `default`;
            if (l()) return e = p._(`progressSyncIndicator.offline.title`), {
                tooltipTitleText: e,
                tooltipSubtitleText: ``,
                buttonStatus: n,
                cloudState: `offline`,
                inert: !0
            };
            if (!h) return e = p._(`progressSyncIndicator.noUser`), {
                tooltipTitleText: e,
                tooltipSubtitleText: ``,
                buttonStatus: `error`,
                cloudState: `issue`
            };
            bb19: switch (s.status) {
                case `none`:
                    e = p._(`progressSyncIndicator.loadNotStarted`);
                    break bb19;
                case `ingameautologin`:
                    e = p._(`progressSyncIndicator.ingameautologin`);
                    break bb19;
                case `syncing`:
                    e = p._(s.lastSyncType === `save` ? `progressSyncIndicator.saving` : `progressSyncIndicator.loading`), r = `syncing`;
                    break bb19;
                case `synced-success`:
                    n = `success`, r = `uploaded`;
                    break bb19;
                case `synced-warning`:
                    s.lastSyncType === `load` ? r = `syncing` : (e = p._(`progressSyncIndicator.warning.title`), n = `warning`, r = `issue`, s.lastSaveAt && (t = `${p._(`progressSyncIndicator.lastProgressSave`)} ${J(S,s.lastSaveAt)}`));
                    break bb19;
                case `synced-error`:
                    e = p._(`progressSyncIndicator.error.title`), n = `error`, r = `issue`, s.lastSaveAt && (t = `${p._(`progressSyncIndicator.lastProgressSave`)} ${J(S,s.lastSaveAt)}
`);
                    break bb19;
                case `synced`:
                    if (r = `uploaded`, s.lastSyncType === `load`)
                        if (s.lastSaveAt) try {
                            e = p._(`progressSyncIndicator.lastProgressLoad`, {
                                time: p.date(s.lastSaveAt, {
                                    month: `short`,
                                    day: `2-digit`,
                                    hour: `numeric`,
                                    minute: `numeric`,
                                    hour12: !1
                                })
                            })
                        } catch (e) {
                            console.error(`Failed to format tooltip title text`, e)
                        } else e = p._(`progressSyncIndicator.noProgress`);
                    s.lastSyncType === `save` && s.lastSaveAt && (e = `${p._(`progressSyncIndicator.progressSaved`)} ${J(S,s.lastSaveAt)}`)
            }
            return {
                tooltipTitleText: e,
                tooltipSubtitleText: t,
                buttonStatus: n,
                cloudState: r
            }
        }, t[0] = h, t[1] = S, t[2] = s.lastSaveAt, t[3] = s.lastSyncType, t[4] = s.status, t[5] = C) : C = t[5];
        let w = C,
            T, E;
        if (t[6] !== h || t[7] !== w || t[8] !== y || t[9] !== s || t[10] !== v || t[11] !== a || t[12] !== r) {
            T = w();
            let e = () => {
                    if (!T.inert) {
                        if (o.Instance.isFullscreen() && o.Instance.exitFullscreen(), v && y(), u.exitFullscreen(), !h) {
                            u.showLoginDrawer(`progressSyncIndicator`, `Gfprogressicon`);
                            return
                        }
                        s.status !== `syncing` && u.openProgressStatusDrawer(s)
                    }
                },
                n = T.cloudState === `syncing`,
                i = s.status === `syncing`;
            E = r ? (0, z.jsx)(U, {
                icon: K[T.cloudState],
                spinIcon: n,
                tone: T.buttonStatus,
                inert: T.inert,
                landscape: a,
                disabled: i,
                onClick: e,
                testId: `footer-progress-sync-indicator-button`
            }) : (0, z.jsx)(V, {
                icon: n ? `updated` : q(T.buttonStatus),
                spinIcon: n,
                status: T.buttonStatus,
                isInert: T.inert,
                disabled: i,
                onClick: e,
                testId: `footer-progress-sync-indicator-button`
            }), t[6] = h, t[7] = w, t[8] = y, t[9] = s, t[10] = v, t[11] = a, t[12] = r, t[13] = T, t[14] = E
        } else T = t[13], E = t[14];
        let D = E;
        if (T.tooltipTitleText) {
            let e, n;
            t[15] === Symbol.for(`react.memo_cache_sentinel`) ? (e = () => _(!0), n = () => _(!1), t[15] = e, t[16] = n) : (e = t[15], n = t[16]);
            let r;
            return t[17] !== D || t[18] !== T.tooltipSubtitleText || t[19] !== T.tooltipTitleText ? (r = (0, z.jsx)(f, {
                titleText: T.tooltipTitleText,
                subtitleText: T.tooltipSubtitleText,
                onOpen: e,
                onClose: n,
                children: D
            }), t[17] = D, t[18] = T.tooltipSubtitleText, t[19] = T.tooltipTitleText, t[20] = r) : r = t[20], r
        } else return D
    },
    X = I.memo(e => {
        let n = (0, L.c)(26),
            {
                isMobileBar: r,
                isLandscape: i
            } = e,
            o;
        n[0] === Symbol.for(`react.memo_cache_sentinel`) ? (o = w(), n[0] = o) : o = n[0];
        let s = o,
            {
                gameLoadStatus: c
            } = I.useContext(t),
            {
                platformMuted: l,
                appAudioMuteSupported: d,
                setPlatformMuted: f
            } = E(),
            p, m;
        if (n[1] !== c || n[2] !== l ? (p = () => {
                s.platformAudioMuteSupported && c === `GAME_LOADED` && l && u.sendMuteAudioMessageToGameIframe(l)
            }, m = [c, l, s], n[1] = c, n[2] = l, n[3] = p, n[4] = m) : (p = n[3], m = n[4]), I.useEffect(p, m), !s || !s.platformAudioMuteSupported && !d) return null;
        let h;
        n[5] === f ? h = n[6] : (h = () => {
            f(!1), u.toggleMute(!1)
        }, n[5] = f, n[6] = h);
        let g = h,
            _;
        n[7] === f ? _ = n[8] : (_ = () => {
            f(!0), u.toggleMute(!0)
        }, n[7] = f, n[8] = _);
        let v = _,
            y;
        n[9] !== v || n[10] !== l || n[11] !== g ? (y = () => l ? g() : v(), n[9] = v, n[10] = l, n[11] = g, n[12] = y) : y = n[12];
        let x = y;
        if (r) {
            let e = l ? `volume-off` : `volume-on`,
                t;
            return n[13] !== i || n[14] !== e || n[15] !== x ? (t = (0, z.jsx)(U, {
                icon: e,
                landscape: i,
                onClick: x,
                testId: `footer-mute-button`
            }), n[13] = i, n[14] = e, n[15] = x, n[16] = t) : t = n[16], t
        }
        let S = l ? `tooltip.unmute` : `tooltip.mute`,
            C;
        n[17] === S ? C = n[18] : (C = (0, z.jsx)(b, {
            id: S
        }), n[17] = S, n[18] = C);
        let T = l ? `mute` : `unmute`,
            D = !!l,
            O;
        n[19] !== T || n[20] !== D || n[21] !== x ? (O = (0, z.jsx)(V, {
            icon: T,
            isActive: D,
            onClick: x,
            testId: `footer-mute-button`
        }), n[19] = T, n[20] = D, n[21] = x, n[22] = O) : O = n[22];
        let k;
        return n[23] !== O || n[24] !== C ? (k = (0, z.jsx)(a, {
            title: C,
            placement: `top`,
            children: O
        }), n[23] = O, n[24] = C, n[25] = k) : k = n[25], k
    }),
    Z = t => {
        let n = (0, L.c)(8),
            {
                isOn: r,
                compact: i
            } = t,
            a = i ? `xsmall` : `small`,
            o;
        n[0] === a ? o = n[1] : (o = (0, z.jsx)(d, {
            name: `notifications`,
            size: a
        }), n[0] = a, n[1] = o);
        let s;
        n[2] !== i || n[3] !== r ? (s = r && (0, z.jsx)(`span`, {
            className: C(e.notificationsBadge, i && e.notificationsBadgeCompact),
            "data-testid": `footer-notifications-badge`,
            children: (0, z.jsx)(d, {
                name: `check`,
                size: `custom`
            })
        }), n[2] = i, n[3] = r, n[4] = s) : s = n[4];
        let c;
        return n[5] !== o || n[6] !== s ? (c = (0, z.jsxs)(`div`, {
            className: e.notificationsInner,
            children: [o, s]
        }), n[5] = o, n[6] = s, n[7] = c) : c = n[7], c
    };
export {
    V as a, U as i, X as n, Y as r, Z as t
};
//# debugId=613c62f9-aa18-530f-89ff-dad6b6e16c6c
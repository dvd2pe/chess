! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "e06d1d99-0a6b-5c10-b495-72b7368133df")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `4082a181-1a08-4ddc-865a-ae813607ad9e`, e._sentryDebugIdIdentifier = `sentry-dbid-4082a181-1a08-4ddc-865a-ae813607ad9e`)
    } catch {}
})();
import {
    At as e,
    Jt as t,
    Kt as n,
    Sn as r,
    ft as i,
    gn as a,
    it as o,
    mt as s,
    tn as c,
    yn as l
} from "../../bundle.js";
var u = r(l()),
    d = {
        notice: `_notice_18ap8_7`,
        atFooter: `_atFooter_18ap8_49`,
        atBottom: `_atBottom_18ap8_53`,
        pending: `_pending_18ap8_57`,
        visible: `_visible_18ap8_62`,
        content: `_content_18ap8_67`,
        close: `_close_18ap8_74`
    },
    f = a(),
    p = 2,
    m = 7,
    h = 1440 * 60,
    g = `batterynotice_hidden_hour`,
    _ = () => {
        let {
            gameLoadStatus: r
        } = (0, u.useContext)(e), a = c(), l = u.useRef(null), [_, v] = u.useState(!1), [y, b] = u.useState(!1), [x, S] = u.useState(!1), [C] = u.useState(() => Date.now()), w = n.Instance.getItem(g), T = w ? C - Number(w) : null, E = r === `GAME_LOADED` && !(T && T < h), D = () => {
            S(!1), v(!1), b(!0), t.getInstance().userAction(`batteryWarning`, `batteryWarningClosed`);
            let e = Date.now();
            n.Instance.setItem(g, `${e}`)
        };
        if (u.useEffect(() => {
                let e = null,
                    n, r;
                return typeof navigator < `u` && typeof navigator.getBattery == `function` && navigator.getBattery().then(i => {
                    e = i, !y && !_ && e && e.level <= .2 && !e.charging && (b(!1), v(!0), t.getInstance().userAction(`batteryWarning`, `batteryWarningDisplayed`)), n = () => {
                        e.charging && _ && (b(!0), a && S(!1), v(!1), t.getInstance().userAction(`batteryWarning`, `batteryWarningRemovedChargingChange`))
                    }, e.addEventListener(`chargingchange`, n), r = () => {
                        y && !_ && e.level <= .2 && !e.charging && (b(!1), a && S(!0), v(!0), t.getInstance().userAction(`batteryWarning`, `batteryWarningDisplayedLevelChange`))
                    }, e.addEventListener(`levelchange`, r)
                }), () => {
                    e && (e.removeEventListener(`chargingchange`, n), e.removeEventListener(`levelchange`, r))
                }
            }, [_, a]), u.useEffect(() => {
                let e, t;
                if (!a) return;
                let n = new IntersectionObserver(([n]) => {
                    n.isIntersecting && !x && (e || = window.setTimeout(() => {
                        S(!0), t || = window.setTimeout(D, m * 1e3)
                    }, p * 1e3))
                });
                return l && l.current && n.observe(l.current),
                    function() {
                        n.disconnect(), e && window.clearTimeout(e), t && window.clearTimeout(t)
                    }
            }, [a, l, r, _]), !_ || !E) return null;
        let O = x || !a;
        return (0, f.jsxs)(`div`, {
            className: s(d.notice, a ? d.atBottom : d.atFooter, O ? d.visible : d.pending),
            ref: l,
            id: `hornotice`,
            children: [(0, f.jsxs)(`div`, {
                className: d.content,
                children: [(0, f.jsx)(i, {
                    name: `low-power`
                }), (0, f.jsx)(o, {
                    id: `batteryWarning.info.text`
                })]
            }), (0, f.jsx)(`button`, {
                type: `button`,
                className: d.close,
                onClick: D,
                children: (0, f.jsx)(i, {
                    name: `close`
                })
            })]
        })
    };
export {
    _ as
    default
};
//# debugId=e06d1d99-0a6b-5c10-b495-72b7368133df